/** Renderer-independent physics shared by players, mobs and other moving actors. */
export function sweepActorAxis(actor, axis, delta, policy) {
  if (!delta) return false;
  const steps=Math.max(1,Math.ceil(Math.abs(delta)/(policy.stepSize||.14))), step=delta/steps;
  for(let index=0;index<steps;index++) {
    const next=actor[axis]+step, x=axis==='x'?next:actor.x, y=axis==='y'?next:actor.y, z=axis==='z'?next:actor.z;
    if(policy.collides(x,y,z,axis)) {
      if(policy.tryStep?.(x,y,z,axis,step)) {actor[axis]=next;policy.sync?.(axis);continue;}
      policy.onBlocked?.(axis,step);return true;
    }
    actor[axis]=next;policy.sync?.(axis);
  }
  return false;
}
export function applyGravity(actor,dt,{gravity=25,terminal=24}={}) {
  actor.vy=Math.max(-terminal,actor.vy-gravity*dt);return actor.vy;
}
export function applyFluidVertical(actor,dt,{lift=0,currentY=0,drag=.89,min=-3.1,max=5.4}={}) {
  actor.vy=Math.max(min,Math.min(max,actor.vy*drag+(lift+currentY*8)*dt));return actor.vy;
}
export function fallDamage(velocity) {return velocity<-13?Math.ceil((-velocity-12)*.75):0;}
export function applyKnockback(actor,source,strength=1,options={}) {
  if(actor.definition?.knockbackImmune)return false;
  const dx=actor.x-source.x,dz=actor.z-source.z,length=Math.hypot(dx,dz)||1;
  const force=(options.horizontal??8)*strength*(1-(options.resistance||0)),damping=options.damping??.5;
  const xKey=options.xKey||'vx',zKey=options.zKey||'vz';
  actor[xKey]=(actor[xKey]||0)*damping+dx/length*force;
  actor[zKey]=(actor[zKey]||0)*damping+dz/length*force;
  if(!actor.flight && (options.liftAlways||actor.grounded)) {
    actor.vy=options.liftAlways?Math.max(actor.vy,options.vertical??8):Math.min(8,actor.vy*.5+(options.vertical??8));
  }
  if(!actor.flight)actor.grounded=false;
  actor.hitStun=options.hitStun??.2;return true;
}
export function approachesActor(actor,x,y,z,other,{radius=.29,height=1.7,padding=.05}={},otherShape={radius:.29,height:1.7}) {
  if(y+height<=other.y+padding||y+padding>=other.y+otherShape.height)return false;
  const next=(x-other.x)**2+(z-other.z)**2,previous=(actor.x-other.x)**2+(actor.z-other.z)**2;
  return next<(radius+otherShape.radius)**2&&next<previous-1e-5;
}
