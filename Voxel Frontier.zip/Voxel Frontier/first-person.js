import {lightBrightness} from './grid-light-material.js';
import {itemIconURL} from './item-icons.js';
import {createPlayerModel} from './player-model.js';
import bow0 from './textures/bow_pulling_0.png';
import bow1 from './textures/bow_pulling_1.png';
import bow2 from './textures/bow_pulling_2.png';

export function createFirstPerson(THREE,api){
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(55,1,.01,10),root=new THREE.Group();
  const ambient=new THREE.AmbientLight(0xffffff,.8);scene.add(root,ambient);const light=new THREE.DirectionalLight(0xffffff,.7);light.position.set(-1,2,3);scene.add(light);
  const rig=createPlayerModel(THREE)(),hand=rig.limbs[0];hand.removeFromParent();root.add(hand);hand.position.set(.52,-.62,-.95);hand.rotation.set(-.5,0,-.2);hand.scale.setScalar(.7);
  const loader=new THREE.TextureLoader(),textures=new Map(),models=new Map(),plane=new THREE.PlaneGeometry(1,1);
  let current=null,key='',swing=0,bob=0;
  function texture(url){if(!textures.has(url)){const t=loader.load(url);t.magFilter=t.minFilter=THREE.NearestFilter;t.colorSpace=THREE.SRGBColorSpace;textures.set(url,t)}return textures.get(url);}
  function block(id){const parts=api.items[id]?.packParts||api.items[id]?.modelParts||api.blockParts(id,0,0,0,0),geometry=new THREE.BufferGeometry();
    if(parts){const d=api.partsData(parts,id);geometry.setAttribute('position',new THREE.Float32BufferAttribute(d.p,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(d.u,2));geometry.setAttribute('color',new THREE.Float32BufferAttribute(d.c,3));geometry.setIndex(d.i);geometry.computeVertexNormals();geometry.translate(-.5,-.5,-.5);if(api.items[id]?.modelParts){geometry.translate(0,0,-.5);geometry.scale(.7,.7,.7);}}
    else {const cube=new THREE.BoxGeometry(1,1,1),uv=cube.attributes.uv;for(let f=0;f<6;f++){const [u0,v0,u1,v1]=api.faceUV(id,f);for(let i=0;i<4;i++){const at=f*4+i;uv.setXY(at,u0+(u1-u0)*uv.getX(at),v0+(v1-v0)*uv.getY(at));}}geometry.copy(cube);const colors=[];for(let f=0;f<6;f++){const col=api.iconColor(id,f);for(let v=0;v<4;v++)colors.push(col.r,col.g,col.b);}geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));cube.dispose();}
    return new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({map:api.atlas(),vertexColors:true,alphaTest:.1,side:THREE.DoubleSide}));
  }
  function render(dt){if(!api.visible())return;const brightness=lightBrightness(api.lightLevel?.()??15);ambient.intensity=.8*brightness;light.intensity=.7*brightness;const id=api.selected(),item=api.items[id],draw=api.bowTime(),stage=draw===null?-1:draw>=.9?2:draw>=.65?1:0;
    const url=draw===null?itemIconURL(item):api.bowTexture?.(stage)||[bow0,bow1,bow2][stage],next=id+':'+url;
    if(next!==key){key=next;if(current)root.remove(current);current=null;
      if(item){if(!models.has(next))models.set(next,(api.blocks[id]||item.packParts)&&draw===null?block(id):new THREE.Mesh(plane,new THREE.MeshLambertMaterial({map:texture(url),alphaTest:.1,side:THREE.DoubleSide})));current=models.get(next);root.add(current);}
    }
    swing=Math.max(0,swing-dt*3.3);bob+=dt*8;const walking=api.moving(),wave=Math.sin(bob)*(walking?.025:0),strike=Math.sin(swing*Math.PI);
    hand.visible=!item;hand.position.y=-.62+wave-strike*.12;
    if(current&&(api.blocks[id]||item.packParts)&&draw===null)current.material.map=api.atlas();
    if(current){const isBlock=!!api.blocks[id]&&draw===null;current.position.set(draw===null?.58:.36,-.42+wave-strike*.18,-1.03-strike*.14);current.scale.setScalar(isBlock?.36:.62);current.rotation.set(isBlock?.25:0,isBlock?-.6:-.3,isBlock?0:-.28-strike*.7);if(draw!==null){current.position.x-=Math.min(1,draw)*.08;current.rotation.y=-.12;}const display=item.packDisplay?.firstperson_righthand;if(display&&draw===null){if(display.rotation)current.rotation.fromArray(display.rotation.map(v=>v*Math.PI/180));if(display.translation)current.position.add(new THREE.Vector3(...display.translation).multiplyScalar(.9/16));if(display.scale)current.scale.fromArray(display.scale).multiplyScalar(.9);}}
    const renderer=api.renderer,canvas=renderer.domElement;const aspect=canvas.clientWidth/Math.max(1,canvas.clientHeight);if(camera.aspect!==aspect){camera.aspect=aspect;camera.updateProjectionMatrix();}const auto=renderer.autoClear;renderer.autoClear=false;try{renderer.clearDepth();renderer.render(scene,camera);}finally{renderer.autoClear=auto;}
  }
  function icon(id){const renderer=api.renderer,target=new THREE.WebGLRenderTarget(64,64),oldTarget=renderer.getRenderTarget(),oldColor=renderer.getClearColor(new THREE.Color()),oldAlpha=renderer.getClearAlpha(),oldAuto=renderer.autoClear;const iconScene=new THREE.Scene(),mesh=block(id),view=new THREE.OrthographicCamera(-.9,.9,.9,-.9,.01,20);iconScene.add(mesh,new THREE.AmbientLight(0xffffff,.8));const sun=new THREE.DirectionalLight(0xffffff,.7);sun.position.set(-2,5,3);iconScene.add(sun);view.position.set(3,2,3);view.lookAt(0,0,0);const pixels=new Uint8Array(64*64*4),canvas=document.createElement('canvas');canvas.width=canvas.height=64;try{renderer.autoClear=true;renderer.setRenderTarget(target);renderer.setClearColor(0,0);renderer.render(iconScene,view);renderer.readRenderTargetPixels(target,0,0,64,64,pixels);const ctx=canvas.getContext('2d'),data=ctx.createImageData(64,64);for(let y=0;y<64;y++)data.data.set(pixels.subarray(y*256,(y+1)*256),(63-y)*256);ctx.putImageData(data,0,0);return canvas.toDataURL();}finally{renderer.setRenderTarget(oldTarget);renderer.setClearColor(oldColor,oldAlpha);renderer.autoClear=oldAuto;target.dispose();mesh.geometry.dispose();mesh.material.dispose();}}
  return {render,icon,worldItem(id){const item=api.items[id];if(!item)return null;const mesh=api.blocks[id]||item.packParts?block(id):new THREE.Mesh(plane,new THREE.MeshLambertMaterial({map:texture(itemIconURL(item)),alphaTest:.1,side:THREE.DoubleSide}));mesh.geometry.userData.shared=mesh.geometry===plane;mesh.scale.setScalar(api.blocks[id]?.25:.5);return mesh;},swing(){swing=1},invalidate(){for(const m of models.values()){if(m.geometry!==plane)m.geometry.dispose();m.material.dispose();}models.clear();key='';}};
}
