// Java FoodData rules: 20 Hz, exhaustion first consumes the saturation buffer.
export function initFood(player){
  player.saturation=Math.max(0,Math.min(player.hunger,Number.isFinite(player.saturation)?player.saturation:5));
  player.exhaustion=Number.isFinite(player.exhaustion)?player.exhaustion:0;
  player.foodTimer=Number.isFinite(player.foodTimer)?player.foodTimer:0;
}
export function exhaust(player,amount){player.exhaustion=Math.min(40,(player.exhaustion||0)+Math.max(0,amount));}
export function eatFood(player,nutrition,modifier){player.hunger=Math.min(20,player.hunger+nutrition);player.saturation=Math.min(player.hunger,(player.saturation||0)+nutrition*modifier*2);}
export function foodTick(player,{difficulty='normal',naturalRegeneration=true}={}){
  if(player.exhaustion>4){player.exhaustion-=4;if(player.saturation>0)player.saturation=Math.max(0,player.saturation-1);else if(difficulty!=='peaceful')player.hunger=Math.max(0,player.hunger-1);}
  const fast=naturalRegeneration&&player.hunger===20&&player.saturation>0&&player.health<20;
  const slow=naturalRegeneration&&player.hunger>=18&&player.health<20;
  if(fast||slow||player.hunger===0){
    if(++player.foodTimer>=(fast?10:80)){
      player.foodTimer=0;
      if(fast||slow){const amount=fast?Math.min(player.saturation,6):6;player.health=Math.min(20,player.health+amount/6);exhaust(player,amount);}
      else if(player.health>(difficulty==='easy'?10:difficulty==='hard'?0:1)&&difficulty!=='peaceful')return 1;
    }
  }else player.foodTimer=0;
  return 0;
}
export function foodValues(name){
  const key=name.toLowerCase().replaceAll('_',' ');
  const foods={bread:[5,.6],apple:[4,.3],carrot:[3,.6],potato:[1,.3],'baked potato':[5,.6],'poisonous potato':[2,.3],
    'raw meat':[3,.3],'raw beef':[3,.3],'raw porkchop':[3,.3],'cooked meat':[8,.8],steak:[8,.8],'cooked beef':[8,.8],'cooked porkchop':[8,.8],
    'raw chicken':[2,.3],'cooked chicken':[6,.6],'rotten flesh':[4,.1],'glow berries':[2,.1],'sweet berries':[2,.1],
    'golden carrot':[6,1.2],'golden apple':[4,1.2],cookie:[2,.1],'melon slice':[2,.3],'pumpkin pie':[8,.3],
    'raw mutton':[2,.3],'cooked mutton':[6,.8],'raw rabbit':[3,.3],'cooked rabbit':[5,.6],cod:[2,.1],salmon:[2,.1],
    'cooked cod':[5,.6],'cooked salmon':[6,.8],'mushroom stew':[6,.6],'beetroot soup':[6,.6],beetroot:[1,.6]};
  return foods[key]||null;
}
