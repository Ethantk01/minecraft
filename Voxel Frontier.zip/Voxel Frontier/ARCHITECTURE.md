# Engine modules

`game.js` composes state, rendering, input and network callbacks. `survival.js` composes survival state and systems. Their contexts expose live bindings so switching dimensions does not leave stale references.

- `systems/`: 26 injected subsystems covering terrain, chunks, models, fluids, lighting, redstone, portals, vehicles, actors, inventory, equipment, UI and networking.
- `content/`: block/item catalog, symbolic crafting and smelting recipes, entity traits and machine interfaces.
- `entity-registry.js` + `entity-behaviors.js`: one entity factory, configurable models/skins/collision/attacks, and named behavior components.
- `content-registry.js`: shared registration and event dispatch for custom visuals, interactions and collision.
- `actor-physics.js`: common movement sweeps, gravity, water forces, actor overlap, fall damage and knockback for players and mobs. Multiplayer overlap uses this module too.
- `player-model.js`: shared player skin and cuboid rig for multiplayer and the inventory preview.
- `item-icons.js`: common icon resolver for inventory, hotbar, machine screens and dropped items. All existing items have verified embedded PNGs.

## Adding content

Register an entity definition with `entityRegistry.register(type, definition)`. Select named components with `behaviors: {beforeTick: ['sunburn'], attack: ['explode']}` or register another handler with `registerBehavior`. Supply a model, texture, collider, ranged attack or custom `visual` handler. `noAI` disables behavior and attacks.

Register item definitions/actions through `itemRegistry.register(id, definition, onUse)`. Register block model, collision and interaction handlers through `blockRegistry.registerHandler(event, id, handler)`. Existing numeric IDs remain stable for saves and multiplayer.

Subsystems retain specialized algorithms where features differ (for example dragon flight versus walking). This is a modular engine, not a promise that any Minecraft mod can run unchanged.

## Building

Install dependencies with `npm install`, then `npm run build`. Open `index.html` or serve the folder. The bundled game runs without a build step. Source modules and required imported assets are included in the portable archive.

## Resource and presentation modules (0.16.0)

`resource-pack.js` handles ZIP resources, model inheritance, blockstates, atlas rebuilding and persistent pack selection. `cem-expressions.js` parses supported animation expressions without evaluating arbitrary JavaScript. `first-person.js` renders held content through the same block model and icon providers. `chest-animation.js` applies lid transforms through existing immediate model buffers. `spawn-safety.js` finds collision-free supported spawn positions; `suffocation.js` supplies the shared eye-volume test. `end-portal-material.js` isolates the End surface shader.

Resource packs define appearance for registered content; they do not execute external scripts or create new gameplay rules. See README for the compatibility limits.
