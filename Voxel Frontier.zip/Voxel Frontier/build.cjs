let esbuild;
try { esbuild = require('esbuild'); }
catch { esbuild = require('../build-tools/node_modules/esbuild'); }
const fs = require('fs');
const path = require('path');

const root = __dirname;
esbuild.build({
  entryPoints: ['game.js'],
  absWorkingDir: root,
  outfile: path.join(root, 'game.bundle.js'),
  bundle: true,
  format: 'iife',
  minify: !process.env.VF_PROFILE,
  plugins: [{
    name: 'workspace-files',
    setup(build) {
      build.onResolve({filter: /.*/}, args => ({
        path: path.resolve(args.resolveDir || root, args.path),
        namespace: 'workspace',
      }));
      build.onLoad({filter: /.*/, namespace: 'workspace'}, args => ({
        contents: fs.readFileSync(args.path),
        loader: ['.png','.ogg'].includes(path.extname(args.path)) ? 'dataurl'
          : path.extname(args.path) === '.json' ? 'json' : 'js',
        resolveDir: path.dirname(args.path),
      }));
    },
  }],
}).catch(error => { console.error(error); process.exitCode = 1; });

