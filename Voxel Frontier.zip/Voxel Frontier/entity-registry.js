import {ENTITY_TRAITS} from './content/entity-traits.js';
import {createDefinitionRegistry} from './content-registry.js';
import {ENTITY_COMBAT} from './combat.js';

// Models, skins, drops and behavior hooks are definitions; every mob uses one factory.
export const ENTITY_DEFINITIONS={
  cow:{drop:'RAW_MEAT',count:2,speed:.75,temptation:'WHEAT'},sheep:{drop:'WOOL',count:2,speed:.85,temptation:'WHEAT',noDropWhen:'sheared',behaviors:{beforeTick:['graze']}},
  villager:{speed:.65,professions:['farmer','librarian','armorer'],naturalSpawn:'village',behaviors:{steer:['avoid-hostiles']}},
  zombie:{drop:'ROTTEN_FLESH',speed:1.35,hostile:true,meleeRange:1.5,behaviors:{beforeTick:['sunburn']}},
  creeper:{drop:'GUNPOWDER',count:2,speed:1.1,hostile:true,behaviors:{attack:['explode']}},
  blaze:{drop:'BLAZE_ROD',speed:1,hostile:true,flight:{offset:1,frequency:2,amplitude:.25}},piglin:{drop:'GOLD_INGOT',speed:1.2,neutral:true,hostile:true,meleeRange:1.5,behaviors:{beforeTick:['gold-neutrality'],pauseTick:['barter']}},
  enderman:{drop:'ENDER_PEARL',speed:1.7,neutral:true,hostile:true,meleeRange:2.2,behaviors:{beforeTick:['enderman']}},dragon:{speed:2.1,hostile:true,spawnEgg:false,viewDistance:130,customAnimation:true,behaviors:{specialTick:['dragon']}},
  skeleton:{drop:'BONE',count:2,speed:1.25,hostile:true,backOffRange:5,behaviors:{beforeTick:['sunburn']}},spider:{drop:'STRING',count:2,speed:1.55,neutral:true,hostile:true,behaviors:{beforeTick:['dark-neutrality']}},
  witch:{drop:'SPIDER_EYE',speed:1,hostile:true},ghast:{drop:'GHAST_TEAR',speed:.75,hostile:true,limit:3,flight:{offset:3,frequency:1.2,amplitude:.45}},
  shulker:{drop:'SHULKER_SHELL',speed:0,hostile:true}
};
export const MOB_TYPES=Object.keys(ENTITY_DEFINITIONS);
export function createEntityRegistry(ids,models,skins){
  const definitions={}, behaviors=new Map(), registry=createDefinitionRegistry(definitions);
  function registerBehavior(name,handler){behaviors.set(name,handler);return handler;}
  function runBehavior(phase,mob,context){for(const name of mob.definition.behaviors?.[phase]||[]){const handler=typeof name==='function'?name:behaviors.get(name);if(handler?.(mob,context)===false)return false;}return true;}
  function register(type,definition){
    definitions[type]={health:20,count:1,drop:0,speed:1,color:0xffffff,head:0xffffff,model:models[type],texture:skins[type],...ENTITY_COMBAT[type],...ENTITY_TRAITS[type],...definition};
    if(definition.temptation)definitions[type].temptationItem=ids[definition.temptation];
    return definitions[type];
  }
  for(const [type,definition] of Object.entries(ENTITY_DEFINITIONS))register(type,{...definition,drop:ids[definition.drop]||0});
  function create(type,visual,x,y,z,state={}){
    const definition=definitions[type];if(!definition||!visual)return null;
    const mob={type,definition,...visual,x,z,homeY:y,vx:0,vy:0,vz:0,grounded:false,hitStun:0,
      health:definition.health,dir:Math.random()*Math.PI*2,decision:0,attack:0,fuse:0,path:[],pathTimer:0,
      aggro:!!definition.hostile&&!definition.neutral,walkPhase:0,
      profession:definition.professions?.[Math.floor(Math.random()*definition.professions.length)]||null,...state};
    Object.defineProperty(mob,'y',{get:()=>mob.group.position.y,set:value=>mob.group.position.y=value});
    mob.group.position.set(x,y,z);definition.onSpawn?.(mob);return mob;
  }
  return {...registry,definitions,register,create,registerBehavior,runBehavior};
}
export function registerSpawnEggs(items){
  MOB_TYPES.filter(type=>ENTITY_DEFINITIONS[type].spawnEgg!==false).forEach((type,index)=>{
    items[700+index]={name:type[0].toUpperCase()+type.slice(1)+' spawn egg',icon:type+'_spawn_egg',color:0xffffff,stackSize:64,spawnEntity:type,category:'Spawn eggs'};
  });
}
