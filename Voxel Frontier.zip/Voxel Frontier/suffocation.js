/** Shared eye-volume test. Partial blocks do not suffocate actors. */
export function isSuffocating(actor,occludes,eyeHeight=1.55,radius=.3){
  const y=actor.y+eyeHeight;
  for(const dx of [-radius*.8,radius*.8])for(const dz of [-radius*.8,radius*.8])for(const dy of [-.05,.05])
    if(occludes(Math.floor(actor.x+dx),Math.floor(y+dy),Math.floor(actor.z+dz)))return true;
  return false;
}
