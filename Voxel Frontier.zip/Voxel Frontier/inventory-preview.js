import {createPlayerModel} from './player-model.js';
/** The inventory uses the same skin, cuboid UVs and pose rig as multiplayer players. */
export function createInventoryPreview(THREE,canvas) {
  let renderer,scene,camera,model,last=0,dirty=true,mouseX=.15,mouseY=0,width=0,height=0;
  document.addEventListener('pointermove',event=>{const rect=canvas.getBoundingClientRect();if(!rect.width)return;mouseX=Math.max(-1,Math.min(1,(event.clientX-rect.left-rect.width/2)/160));mouseY=Math.max(-1,Math.min(1,(event.clientY-rect.top-rect.height/2)/160));dirty=true;},{passive:true});
  function initialize(){
    renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:false,powerPreference:'low-power'});
    renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.outputColorSpace=THREE.SRGBColorSpace;
    scene=new THREE.Scene();scene.add(new THREE.HemisphereLight(0xffffff,0x777777,2));
    const light=new THREE.DirectionalLight(0xffffff,2);light.position.set(-2,4,5);scene.add(light);
    camera=new THREE.OrthographicCamera(-.85,.85,1.15,-1.15,.1,20);camera.position.set(0,1.0,-5);camera.lookAt(0,1.0,0);
    model=createPlayerModel(THREE)();scene.add(model.group);dirty=true;
  }
  function update(){
    if(!canvas.isConnected||!canvas.getBoundingClientRect().width||canvas.closest('[hidden]'))return;
    if(!renderer)initialize();const now=performance.now();if(now-last<33)return;
    const rect=canvas.getBoundingClientRect();if(rect.width!==width||rect.height!==height){width=rect.width;height=rect.height;renderer.setSize(width,height,false);const aspect=width/height;camera.left=-1.15*aspect;camera.right=1.15*aspect;camera.updateProjectionMatrix();dirty=true;}
    // Redraw after skin upload as well as pointer motion. Work is limited to the open inventory.
    if(!dirty&&now-last<500)return;last=now;dirty=false;
    model.animate(0,0,mouseY*.35);model.group.rotation.y=.2+mouseX*.65;
    renderer.render(scene,camera);
  }
  return {update};
}
