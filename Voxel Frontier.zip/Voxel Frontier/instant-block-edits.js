import {fluidHeight,fluidSideBottom} from './fluid-geometry.js';
/** Immediate cell-sized visual edits while section rebuilding remains budgeted. */
export function createInstantBlockEdits(ctx){
 const pending=new Map();let dimension=ctx.dimension,editFrame=-1,editCount=0;
 const cells=[[0,0,0],[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
 function remove(entry){for(const mesh of entry.meshes){mesh.removeFromParent();mesh.geometry.dispose();}}
 function sync(){for(const [key,entry] of pending)if(dimension!==ctx.dimension||ctx.chunks.get(entry.chunkId)!==entry.chunk){remove(entry);pending.delete(key);}dimension=ctx.dimension;}
 function mask(chunk,cell){for(const mesh of chunk.meshes){const range=mesh.userData.blockRanges?.get(cell);if(!range?.count)continue;const attr=mesh.geometry.getAttribute('position'),offset=range.start*3;for(let n=0;n<range.count*3;n++)attr.array[offset+n]=0;attr.addUpdateRange(offset,range.count*3);attr.needsUpdate=true;}}
 function cellData(type,x,y,z){
  const d={p:[],c:[],u:[],i:[]},parts=ctx.blockParts(type,x,y,z,0);
  if(parts){for(const part of parts)if(part.kind==='box')ctx.appendModelBox(d,type,x,y,z,...part.bounds,part.texture,part.faces,part.rotation,part.slope);else for(const angle of [45,-45])ctx.appendModelBox(d,type,x,y,z,0,0,.5,1,part.height||1,.5,null,{4:{tile:part.texture||'short_grass',uv:[0,0,16,16]},5:{tile:part.texture||'short_grass',uv:[0,0,16,16]}},{axis:'y',angle,origin:[.5,.5,.5]});return d;}
  const liquid=type===ctx.WATER||type===ctx.LAVA,top=liquid?fluidHeight(ctx,x,y,z):1;
  for(let f=0;f<6;f++){const face=ctx.faces[f],neighbor=ctx.getBlock(x+face.d[0],y+face.d[1],z+face.d[2]);if(ctx.occludes(neighbor)||type===ctx.GLASS&&neighbor===type)continue;let bottom=0;if(liquid&&neighbor===type){bottom=fluidSideBottom(ctx,x,y,z,face,top);if(bottom===null)continue}const start=d.p.length/3,col=ctx.colorFor(type,f,x,y,z),uv=ctx.faceUV(type,f,x,z,y);for(const v of face.v){d.p.push(x+v[0],y+(liquid?(v[1]===1?top:bottom):v[1]),z+v[2]);d.c.push(col.r,col.g,col.b);}d.u.push(uv[0],uv[1],uv[0],uv[3],uv[2],uv[3],uv[2],uv[1]);d.i.push(start,start+1,start+2,start,start+2,start+3);}return d;
 }
 function edit(x,y,z){const frame=Math.floor(performance.now()/16);if(frame!==editFrame){editFrame=frame;editCount=0;}if(editCount++>=8)return;sync();for(const [dx,dy,dz] of cells){const X=x+dx,Y=y+dy,Z=z+dz;if(Y<ctx.MIN_Y||Y>=ctx.MAX_Y)continue;const id=ctx.key(Math.floor(X/ctx.SIZE),Math.floor(Z/ctx.SIZE)),chunk=ctx.chunks.get(id);if(!chunk)continue;const cell=ctx.editKey(X,Y,Z),old=pending.get(cell);if(old)remove(old);mask(chunk,cell);const type=ctx.getBlock(X,Y,Z),meshes=[];
   if(type!==ctx.AIR&&!(ctx.save.experiments&&ctx.portalUsesPreview(type))){const d=cellData(type,X,Y,Z);if(d.p.length){const T=ctx.THREE,g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(d.p,3));g.setAttribute('color',new T.Float32BufferAttribute(d.c,3));g.setAttribute('uv',new T.Float32BufferAttribute(d.u,2));g.setAttribute('normal',new T.BufferAttribute(ctx.quadNormals(d.p),3));g.setIndex(d.i);ctx.applyGridLighting(g);const m=new T.Mesh(g,type===ctx.WATER?ctx.materials.water:type===ctx.LAVA?ctx.materials.lava:type===ctx.GLASS?ctx.materials.glass:type===ctx.END_PORTAL||type===9990?ctx.materials.endPortal:ctx.materials.solid);const dimension=ctx.dimension;m.onBeforeRender=(_r,_s,_c,_g,material)=>material.userData.updateGridLight?.(dimension);m.userData.instantEdit=true;ctx.scene.add(m);meshes.push(m);}}
   pending.set(cell,{chunk,chunkId:id,section:Math.floor(Y/16),meshes});
  }}
 function commit(chunk,section,revision){for(const [cell,entry] of pending){if(entry.chunk!==chunk||entry.section!==section)continue;if(revision===(chunk.visualRevision||0)){remove(entry);pending.delete(cell);}else mask(chunk,cell);}}
 return {edit,sync,commit,pending};
}
