/** Shared definition protocol for blocks, items and entities. Numeric IDs remain save-compatible. */
export function createDefinitionRegistry(definitions = {}) {
  const handlers = new Map();
  function register(id, definition = {}) {
    const existing = definitions[id] || {};
    definitions[id] = Object.assign(existing, definition);
    return definitions[id];
  }
  function registerHandler(event, id, handler) {
    if (!handlers.has(event)) handlers.set(event, new Map());
    handlers.get(event).set(id, handler);
    return handler;
  }
  function dispatch(event, id, context) {
    const definition = definitions[id];
    const handler = handlers.get(event)?.get(id) || definition?.[event];
    if (typeof handler !== 'function') return {handled:false};
    return {handled:true, value:handler(context, definition)};
  }
  return {definitions,register,registerHandler,dispatch,get:id=>definitions[id],has:id=>!!definitions[id]};
}
export function createBlockRegistry(blocks, nonOccluding) {
  const registry = createDefinitionRegistry(blocks);
  blocks.forEach((block,id)=>{if(block)block.occludes=block.occludes??(!!block.solid&&!nonOccluding.has(id));});
  return registry;
}
