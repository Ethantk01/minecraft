import minecraftTexturesPack from './minecraft-textures-pack.json';
import {unzipSync,strFromU8} from './vendor/fflate.js';
import vanillaModels from './vanilla-models.json';
import vanillaStates from './vanilla-blockstates.json';
import {compileCemExpression} from './cem-expressions.js';
import soundResources from './resource-sounds.json';
import atlasResources from './resource-atlas.json';

const resource=(name,folder,extension='json')=>{const [namespace,path]=name.includes(':')?name.split(':'):['minecraft',name];return `assets/${namespace}/${folder}/${path}.${extension}`;};
const faceIds={east:0,west:1,up:2,down:3,south:4,north:5};
export function readResourcePack(bytes){
  let expanded=0;const files=unzipSync(new Uint8Array(bytes),{filter:file=>{expanded+=file.originalSize;if(expanded>512*1024*1024||file.originalSize>64*1024*1024)throw new Error('Resource pack is too large');return !file.name.endsWith('/');}});
  const metadata=Object.keys(files).find(path=>path==='pack.mcmeta'||path.endsWith('/pack.mcmeta'));
  if(!metadata)throw new Error('This ZIP does not contain pack.mcmeta');
  const prefix=metadata.slice(0,-11),assets=new Map(Object.entries(files).filter(([path])=>path.startsWith(prefix)).map(([path,data])=>[path.slice(prefix.length),data]));
  const json=path=>assets.has(path)?JSON.parse(strFromU8(assets.get(path))):null,meta=json('pack.mcmeta');if(!meta?.pack)throw new Error('Invalid pack metadata');
  return {assets,json,meta};
}
export function createModelResolver(pack,tile){
  const cache=new Map();
  function model(name,chain=[]){if(cache.has(name))return cache.get(name);if(chain.includes(name)||chain.length>32)throw new Error('Cyclic model parent: '+name);
    const raw=pack.json(resource(name,'models'))||vanillaModels[name.replace(/^minecraft:/,'')];if(!raw)return null;
    const parent=raw.parent?model(raw.parent,[...chain,name]):null,result={...parent,...raw,textures:{...parent?.textures,...raw.textures},display:{...parent?.display,...raw.display}};cache.set(name,result);return result;
  }
  function parts(name,variant={}){const data=model(name);if(!data)return null;const textures=data.textures||{},resolve=(name,chain=[])=>{if(!name)return null;if(!name.startsWith('#'))return name;if(chain.includes(name))return null;return resolve(textures[name.slice(1)],[...chain,name]);};
    return (data.elements||[]).map(element=>{const from=element.from||[0,0,0],to=element.to||[16,16,16],faces={};for(const [side,face] of Object.entries(element.faces||{})){const texture=resolve(face.texture);if(!texture)continue;const [x,y,z]=from,[X,Y,Z]=to;
      const fallback={down:[x,16-Z,X,16-z],up:[x,z,X,Z],north:[16-X,16-Y,16-x,16-y],south:[x,16-Y,X,16-y],west:[z,16-Y,Z,16-y],east:[16-Z,16-Y,16-z,16-y]}[side];
      faces[faceIds[side]]={tile:tile(texture),uv:face.uv||fallback,rotation:face.rotation||0,tintindex:face.tintindex};}
      const rotation=[];if(element.rotation)rotation.push({...element.rotation,origin:element.rotation.origin.map(n=>n/16)});for(const axis of ['x','y'])if(variant[axis])rotation.push({axis,angle:-variant[axis],origin:[.5,.5,.5]});
      return {kind:'box',bounds:[...from,...to].map(n=>n/16),faces,rotation};});
  }
  const matches=(condition,properties)=>!condition||Object.entries(condition).every(([key,value])=>key==='OR'?value.some(c=>matches(c,properties)):key==='AND'?value.every(c=>matches(c,properties)):String(value).split('|').includes(String(properties[key])));
  function variants(name,properties={}){const state=pack.json(resource(name,'blockstates'))||vanillaStates[name.replace(/^minecraft:/,'')];if(!state)return null;
    const result=[];for(const [selector,value] of Object.entries(state.variants||{})){const condition=Object.fromEntries(selector?selector.split(',').map(pair=>pair.split('=')):[]);if(matches(condition,properties)){result.push(Array.isArray(value)?value[0]:value);break;}}
    for(const entry of state.multipart||[])if(matches(entry.when,properties))result.push(Array.isArray(entry.apply)?entry.apply[0]:entry.apply);return result;
  }
  return {model,parts,variants};
}

export function createResourcePacks(THREE,api){
  const urls=new Map(),bitmaps=new Map(),animations=[],warnings=new Set();let active=null,atlas=null,atlasTexture=null,frameTick=-1;
  const status=document.getElementById('packStatus'),toggle=document.getElementById('minecraftTexturesToggle');toggle.checked=localStorage.getItem('vf-minecraft-textures')==='true';toggle.onchange=()=>{localStorage.setItem('vf-minecraft-textures',String(toggle.checked));location.reload();};
  function blobURL(path){if(!active?.assets.has(path))return null;if(!urls.has(path))urls.set(path,URL.createObjectURL(new Blob([active.assets.get(path)],{type:path.endsWith('.png')?'image/png':path.endsWith('.ogg')?'audio/ogg':'application/octet-stream'})));return urls.get(path);}
  async function image(path){if(bitmaps.has(path))return bitmaps.get(path);const url=blobURL(path);if(!url)return null;const im=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=reject;img.src=url;});bitmaps.set(path,im);return im;}
  async function store(bytes){const db=await database();return new Promise((resolve,reject)=>{const tx=db.transaction('packs','readwrite');bytes?tx.objectStore('packs').put(bytes,'active'):tx.objectStore('packs').delete('active');tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>reject(tx.error);});}
  async function database(){return new Promise((resolve,reject)=>{const request=indexedDB.open('vf-resource-packs',1);request.onupgradeneeded=()=>request.result.createObjectStore('packs');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
  async function restore(){if(!toggle.checked)return;try{while(!api.materials.solid.map?.image)await new Promise(resolve=>requestAnimationFrame(resolve));await apply(Uint8Array.from(atob(minecraftTexturesPack.data),c=>c.charCodeAt(0)).buffer);status.textContent='Minecraft textures enabled';}catch(error){status.textContent='Minecraft textures failed: '+error.message;}}
  function canonical(id){return api.names[id]||api.items[id]?.name.toLowerCase().replaceAll(' ','_');}
  async function apply(bytes){
    api.loading.begin('pack','Loading resource pack','Reading Minecraft resources');api.pause();
    try{
      if(active){await store(bytes);location.reload();return;}await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));active=readResourcePack(bytes);const names=[...active.assets.keys()];warnings.clear();animations.length=0;
      for(const path of names)if(/\/(ctm|cit|random|sky|shaders)\//.test(path))warnings.add('CTM, CIT, random variants, custom skies and shaders require additional rendering features');
      // A fixed logical tile grid preserves 16-pixel model UVs at higher resolutions.
      for(let tries=0;!api.materials.solid.map?.image&&tries<120;tries++)await new Promise(resolve=>requestAnimationFrame(resolve));
      const original=api.atlasMap,oldColumns=original.columns,oldRows=original.rows,oldImage=api.materials.solid.map?.image;
      const specs=new Map(Object.entries(atlasResources));for(const [name,spec]of specs){if(active.assets.has(spec.path))continue;const normalized=spec.path.replace(/(oak_door_(?:top|bottom))[12]\.png$/,'$1.png');if(active.assets.has(normalized))specs.set(name,{...spec,path:normalized});}for(const key of Object.keys(original.tiles)){if(!specs.has(key)){const name=key.replace(/^(structure_block_|default3d_)/,'').replace(/_opaque$/,'');specs.set(key,{path:resource('block/'+name,'textures','png'),opaque:key.endsWith('_opaque')});}}const refs=new Set();
      for(const path of names)if(path.includes('/models/')&&path.endsWith('.json')){const data=active.json(path);for(const value of Object.values(data?.textures||{}))if(typeof value==='string'&&!value.startsWith('#'))refs.add(value);}
      function tile(ref){const path=resource(ref,'textures','png'),short=ref.replace(/^minecraft:/,'').replace(/^block\//,'');if(original.tiles[short]!==undefined)return short;const key='pack_'+ref.replace(/[^a-z0-9_/]/gi,'_');if(original.tiles[key]===undefined)original.tiles[key]=Math.max(...Object.values(original.tiles))+1;specs.set(key,{path});return key;}
      for(const ref of refs)tile(ref);
      const paths=[...new Set([...specs.values()].map(spec=>spec.path).filter(path=>active.assets.has(path)))];await Promise.all(paths.map(async path=>{try{await image(path)}catch{warnings.add('Invalid PNG: '+path)}}));const images=new Map();for(const [key,spec]of specs)if(bitmaps.has(spec.path))images.set(key,bitmaps.get(spec.path));
      if([...images.values()].some(im=>im.width>128))warnings.add('Textures above 128 pixels per tile are downsampled');
      const tileSize=16,columns=32,rows=Math.ceil((Math.max(...Object.values(original.tiles))+1)/columns);
      atlas=document.createElement('canvas');atlas.width=columns*tileSize;atlas.height=rows*tileSize;const ctx=atlas.getContext('2d');ctx.imageSmoothingEnabled=false;
      const drawn=new Set();const ordered=Object.entries(original.tiles).sort(([a],[b])=>Number(images.has(a))-Number(images.has(b)));for(const [key,index] of ordered){const x=index%columns*tileSize,y=Math.floor(index/columns)*tileSize;if(oldImage&&!drawn.has(index))ctx.drawImage(oldImage,index%oldColumns*oldImage.width/oldColumns,Math.floor(index/oldColumns)*oldImage.height/oldRows,oldImage.width/oldColumns,oldImage.height/oldRows,x,y,tileSize,tileSize);
        drawn.add(index);const im=images.get(key),spec=specs.get(key);if(!im)continue;ctx.clearRect(x,y,tileSize,tileSize);
        if(spec.crop){const [u,v,U,V]=spec.crop,scale=im.width/spec.baseSize;ctx.drawImage(im,u*scale,v*scale,(U-u)*scale,(V-v)*scale,x,y,tileSize,tileSize);}
        else{if(spec.opaque){ctx.fillStyle='#9d9d9d';ctx.fillRect(x,y,tileSize,tileSize);}const metadata=active.json(spec.path+'.mcmeta')?.animation,frames=metadata?.frames||Array.from({length:Math.floor(im.height/im.width)},(_,i)=>i);const first=typeof frames[0]==='number'?frames[0]:frames[0]?.index||0;ctx.drawImage(im,0,first*im.width,im.width,im.width,x,y,tileSize,tileSize);if(metadata&&frames.length>1){animations.push({im,x,y,size:tileSize,frames,time:metadata.frametime||1,last:-1});if(metadata.interpolate)warnings.add('Texture animation interpolation is not supported');}}
      }
      original.columns=columns;original.rows=rows;api.clearUV();atlasTexture=new THREE.CanvasTexture(atlas);atlasTexture.magFilter=atlasTexture.minFilter=THREE.NearestFilter;atlasTexture.generateMipmaps=false;atlasTexture.colorSpace=THREE.SRGBColorSpace;
      for(const material of Object.values(api.materials))if(!material.isShaderMaterial){material.map=atlasTexture;material.needsUpdate=true;}
      const resolver=createModelResolver(active,tile);
      // Only supplied block models replace geometry; texture-only packs retain shapes.
      for(const [id,block] of Object.entries(api.blocks)){if(!block)continue;const name=canonical(id)||block.minecraftId;if(!name)continue;const state=active.json(resource(name,'blockstates'))||vanillaStates[name];if(!state)continue;const choices=[...Object.values(state.variants||{}),...(state.multipart||[]).map(e=>e.apply)].flat();if(!active.assets.has(resource(name,'blockstates'))&&!choices.some(choice=>choice?.model&&active.assets.has(resource(choice.model,'models'))))continue;
        const defaults=api.properties[id]||{};if(choices.some(choice=>choice.uvlock))warnings.add('UV-locked rotated models may differ from Minecraft');if(choices.some(choice=>choice.weight))warnings.add('Weighted model variants currently use the first variant');for(const choice of choices)try{resolver.parts(choice.model,choice);}catch(error){warnings.add(error.message);}
        api.registry.registerHandler('model',Number(id),position=>{const variants=resolver.variants(name,{...defaults,...api.state(Number(id),position)});try{return variants?.flatMap(choice=>resolver.parts(choice.model,choice)||[])||null;}catch{return null;}});api.modelTypes.add(Number(id));
      }
      for(const [id,item] of Object.entries(api.items)){const name=canonical(id),definition=active.json(resource(name,'items'))?.model,modelName=definition?.type==='minecraft:model'?definition.model:'item/'+name,model=resolver.model(modelName);let path=resource('item/'+name,'textures','png');
        if(model?.textures?.layer0){let ref=model.textures.layer0,seen=new Set();while(ref?.startsWith('#')&&!seen.has(ref)){seen.add(ref);ref=model.textures[ref.slice(1)];}if(ref)path=resource(ref,'textures','png');}
        if(active.assets.has(path)){const im=await image(path),meta=active.json(path+'.mcmeta')?.animation;if(meta&&im.height>im.width){const first=meta.frames?.[0],index=typeof first==='number'?first:first?.index||0,canvas=document.createElement('canvas');canvas.width=canvas.height=im.width;canvas.getContext('2d').drawImage(im,0,index*im.width,im.width,im.width,0,0,im.width,im.width);item.iconURL=canvas.toDataURL();warnings.add('Animated inventory sprites currently display their first frame');}else item.iconURL=blobURL(path);}
        if(model?.display)item.packDisplay=model.display;if(model?.elements&&active.assets.has(resource(modelName,'models')))item.packParts=resolver.parts(modelName);
      }
      const skins={cow:'cow/cow_temperate',sheep:'sheep/sheep',sheep_wool:'sheep/sheep_wool',villager:'villager/villager',zombie:'zombie/zombie',creeper:'creeper/creeper',blaze:'blaze',piglin:'piglin/piglin',enderman:'enderman/enderman',dragon:'enderdragon/dragon',skeleton:'skeleton/skeleton',spider:'spider/spider',witch:'witch',ghast:'ghast/ghast',shulker:'shulker/shulker'};
      for(const [type,skin] of Object.entries(skins)){const path='assets/minecraft/textures/entity/'+skin+'.png',texture=blobURL(path);let model=null;const modelPath=['optifine','mcpatcher'].map(folder=>`assets/minecraft/${folder}/cem/${type}.jem`).find(path=>active.assets.has(path));
        if(modelPath){model=active.json(modelPath);const dir=modelPath.slice(0,modelPath.lastIndexOf('/')+1),bases=new Map();const expand=(part,depth=0)=>{if(depth>32)throw new Error('CEM nesting limit exceeded');let value={...part};if(part.baseId)value={...bases.get(part.baseId),...value};if(part.model){const external=active.json(dir+part.model);if(external)value={...external,...value};else warnings.add('Missing CEM part: '+part.model);}if(value.id)bases.set(value.id,value);if(value.texture){const raw=value.texture,path=raw.startsWith('textures/')?'assets/minecraft/'+raw:dir+raw;value.packTexture=blobURL(path.replace(/\.png$/,'')+'.png');}value.submodels=(value.submodels||[]).map(p=>expand(p,depth+1));return value;};model.models=(model.models||[]).map(p=>expand(p));const check=node=>{if(node.attach||node.sprites||node.scale||node.invertAxis&&node.invertAxis!=='xy')warnings.add('Some CEM attachment, sprite, scale or axis transforms are not supported');for(const expression of node.animations||[])for(const source of Object.values(expression))try{compileCemExpression(source)}catch(error){warnings.add(error.message)}for(const child of node.submodels||[])check(child)};model.models.forEach(check);if(model.texture){const ref=model.texture.startsWith('textures/')?'assets/minecraft/'+model.texture:dir+model.texture;model.packTexture=blobURL(ref.replace(/\.png$/,'')+'.png');}}
        if(texture||model)api.entityAppearance(type,model,model?.packTexture||texture);
      }
      // Crop vanilla 256x256 GUI sheets to the exact panel dimensions used by slots.
      const gui={inventory:[176,166,'inventory'],crafting_table:[176,166,'crafting'],furnace:[176,166,'furnace'],dispenser:[176,166,'dispenser'],hopper:[176,133,'hopper'],shulker_box:[176,166,'shulker_box'],crafter:[176,166,'crafter'],brew:[176,166,'brewing_stand'],smith:[176,166,'smithing'],anvil:[176,166,'anvil'],enchant:[176,166,'enchanting_table'],stonecut:[176,166,'stonecutter'],trade:[276,166,'villager']};
      const css=[];for(const [ui,[w,h,file]] of Object.entries(gui)){const im=await image('assets/minecraft/textures/gui/container/'+file+'.png');if(!im)continue;const canvas=document.createElement('canvas');canvas.width=w*im.width/256;canvas.height=h*im.width/256;canvas.getContext('2d').drawImage(im,0,0,canvas.width,canvas.height,0,0,canvas.width,canvas.height);css.push(`.inventory-panel.ui-${ui}{background-image:url('${canvas.toDataURL()}')!important}`);}
      const chestSheet=await image('assets/minecraft/textures/gui/container/generic_54.png');if(chestSheet){const scale=chestSheet.width/256,canvas=document.createElement('canvas');canvas.width=176*scale;canvas.height=168*scale;const ctx=canvas.getContext('2d');ctx.drawImage(chestSheet,0,0,176*scale,71*scale,0,0,176*scale,71*scale);ctx.drawImage(chestSheet,0,126*scale,176*scale,97*scale,0,71*scale,176*scale,97*scale);css.push(`.inventory-panel.ui-chest,.inventory-panel.ui-trapped_chest{background-image:url('${canvas.toDataURL()}')!important}`);}
      for(const sheet of [...document.styleSheets]){let rules;try{rules=sheet.cssRules}catch{continue;}for(const rule of rules||[]){if(!rule.cssText.includes('textures/gui/client/'))continue;const replaced=rule.cssText.replace(/url\(["']?textures\/gui\/client\/([^)'" ]+)["']?\)/g,(whole,name)=>{const url=blobURL('assets/minecraft/textures/gui/'+name);return url?`url('${url}')`:whole;});if(replaced!==rule.cssText)css.push(replaced);}}

      let style=document.getElementById('resourcePackStyle');if(!style){style=document.createElement('style');style.id='resourcePackStyle';document.head.append(style)}style.textContent=css.join('\n');
      const playerSkin=blobURL('assets/minecraft/textures/entity/player/wide/steve.png')||blobURL('assets/minecraft/textures/entity/steve.png');if(playerSkin)api.setPlayerSkin(playerSkin);
      const sounds=active.json('assets/minecraft/sounds.json');
      for(const [name,path] of Object.entries(soundResources)){let url=blobURL('assets/minecraft/sounds/'+path);if(!url&&sounds){const event=Object.values(sounds).find(event=>event.sounds?.some(sound=>(typeof sound==='string'?sound:sound.name)===path.slice(0,-4)));const replacement=event?.sounds?.[0],ref=typeof replacement==='string'?replacement:replacement?.name;if(ref)url=blobURL(resource(ref,'sounds','ogg'));}if(url)await api.replaceSound(name,url);}
      for(const [uniform,path] of [['sky','environment/end_sky'],['portal','entity/end_portal']]){const url=blobURL('assets/minecraft/textures/'+path+'.png');if(url){const t=new THREE.TextureLoader().load(url);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.magFilter=t.minFilter=THREE.NearestFilter;api.materials.endPortal.uniforms[uniform].value=t;}}
      for(const path of names)if(/\/font\/|\/equipment\/|\/particles\//.test(path))warnings.add('Custom fonts, equipment layers and particle definitions are not supported');
      await api.refresh();
      const description=typeof active.meta.pack.description==='string'?active.meta.pack.description:JSON.stringify(active.meta.pack.description);status.textContent=description+' — '+images.size+' block textures, '+animations.length+' animations'+(warnings.size?'\nCompatibility: '+[...warnings].join('; '):'');
    }finally{api.loading.end('pack');}
  }
  function tick(time){const next=Math.floor(time*20);if(next===frameTick||!animations.length)return;frameTick=next;let changed=false;const ctx=atlas.getContext('2d');for(const animation of animations){const duration=animation.frames.reduce((sum,f)=>sum+(typeof f==='number'?animation.time:f.time||animation.time),0);let at=next%duration,selected=0;for(const f of animation.frames){const length=typeof f==='number'?animation.time:f.time||animation.time;if(at<length){selected=typeof f==='number'?f:f.index;break;}at-=length;}if(selected===animation.last)continue;animation.last=selected;ctx.clearRect(animation.x,animation.y,animation.size,animation.size);ctx.drawImage(animation.im,0,selected*animation.im.width,animation.im.width,animation.im.width,animation.x,animation.y,animation.size,animation.size);changed=true;}if(changed)atlasTexture.needsUpdate=true;}
  return {missingTextures:()=>Object.keys(api.atlasMap.tiles).filter(name=>{const spec=atlasResources[name];return spec&&!active?.assets.has(spec.path)&&!active?.assets.has(spec.path.replace(/(oak_door_(?:top|bottom))[12]\.png$/,'$1.png'));}),apply,restore,tick,active:()=>!!active,texture:path=>blobURL('assets/minecraft/textures/'+path+'.png'),warnings};
}
