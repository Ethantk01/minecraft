// Retain faint visibility at zero without lifting the whole Minecraft brightness curve.
export function lightBrightness(level){const normalized=Math.max(0,Math.min(15,level))/15;return .003+.997*normalized/(4-3*normalized);}
/** Grid light shading: day/night changes only update a uniform, not chunk meshes. */
export function installGridLightMaterial(material,getDay){
 material.defaultAttributeValues={...material.defaultAttributeValues,gridLight:[15,0]};
 material.onBeforeCompile=shader=>{shader.uniforms.skyDarkness={value:0};shader.vertexShader='attribute vec2 gridLight; varying vec2 vGridLight;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvGridLight=gridLight;');shader.fragmentShader='uniform float skyDarkness; varying vec2 vGridLight;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\nfloat gridLevel=max(vGridLight.y,max(0.0,vGridLight.x-skyDarkness))/15.0;diffuseColor.rgb*=0.003+0.997*gridLevel/(4.0-3.0*gridLevel);');material.userData.gridShader=shader;};
 material.customProgramCacheKey=()=> 'voxel-grid-light-v2';
 material.userData.updateGridLight=dimension=>{if(material.userData.gridShader)material.userData.gridShader.uniforms.skyDarkness.value=15-(dimension==='overworld'?getDay():0);};
}
