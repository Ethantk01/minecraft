/** Liquid heights and exposed vertical steps shared by both mesh paths. */
export function fluidHeight(ctx,x,y,z){
 const level=ctx.flowLevels.get(ctx.editKey(x,y,z))||8;
 return Math.min(1,.14+level*.86/8);
}
export function fluidSideBottom(ctx,x,y,z,face,top){
 if(face.d[1])return null;
 const bottom=fluidHeight(ctx,x+face.d[0],y,z+face.d[2]);
 return bottom<top?bottom:null;
}
