/** Pickup delays are seconds of simulation time, persisted with each drop. */
export const PLAYER_TOSS_PICKUP_DELAY=40/20;
export const NORMAL_DROP_PICKUP_DELAY=.25;
export function tickPickupDelay(drop,dt){drop.pickupDelay=Math.max(0,(Number.isFinite(drop.pickupDelay)?drop.pickupDelay:0)-dt);}
export function canPickupDrop(drop){return !(drop.pickupDelay>0)&&(!Number.isFinite(drop.age)||drop.age>NORMAL_DROP_PICKUP_DELAY);}
