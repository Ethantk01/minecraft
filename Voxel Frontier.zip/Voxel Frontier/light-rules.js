/** Minecraft emission values. Counts/activation are block states, not brightness guesses. */
const fixed={beacon:15,copper_lantern:15,end_gateway:15,end_portal:15,ochre_froglight:15,verdant_froglight:15,pearlescent_froglight:15,glowstone:15,jack_o_lantern:15,lantern:15,lava:15,lava_cauldron:15,sea_lantern:15,shroomlight:15,fire:15,copper_torch:14,end_rod:14,torch:14,wall_torch:14,glow_berries:14,nether_portal:11,crying_obsidian:10,soul_fire:10,soul_lantern:10,soul_torch:10,soul_wall_torch:10,enchanting_table:7,end_chest:7,ender_chest:7,glow_lichen:7,sculk_catalyst:6,amethyst_cluster:5,large_amethyst_bud:4,magma_block:3,medium_amethyst_bud:2,brewing_stand:1,brown_mushroom:1,dragon_egg:1,end_portal_frame:1,small_amethyst_bud:1};
const on=value=>value===true||value==='true';
export function isDynamicEmitter(name){return /candle|copper_bulb|respawn_anchor|sea_pickle|campfire|furnace|smoker|redstone_lamp|redstone_torch|redstone_wall_torch|redstone_ore|sculk_sensor|cave_vines|conduit|vault|trial_spawner|firefly_bush|^light$/.test(name);}
export function blockEmission(name,state={}){
 name=name.replace(/^minecraft:/,'');if(name==='conduit')return on(state.active)?15:0;
 if(name==='redstone_lamp')return on(state.lit)?15:0;
 if(/redstone_(?:wall_)?torch$/.test(name))return on(state.lit)?7:0;
 if(/copper_bulb$/.test(name))return on(state.lit)?name.includes('oxidized')?4:name.includes('weathered')?8:name.includes('exposed')?12:15:0;
 if(name==='respawn_anchor')return [0,3,7,11,15][Math.max(0,Math.min(4,Number(state.charges)||0))];
 if(name==='sea_pickle')return on(state.waterlogged)?Math.min(4,Math.max(1,Number(state.pickles)||1))*3+3:0;
 if(name.includes('candle'))return on(state.lit)?name.endsWith('_cake')?3:Math.min(4,Math.max(1,Number(state.candles)||1))*3:0;
 if(name.endsWith('campfire'))return on(state.lit)?name==='soul_campfire'?10:15:0;
 if(['furnace','blast_furnace','smoker'].includes(name))return on(state.lit)?13:0;
 if(name.endsWith('redstone_ore'))return on(state.lit)?9:0;
 if(name.includes('sculk_sensor'))return state.sculk_sensor_phase==='active'||on(state.active)?1:0;
 if(name.startsWith('cave_vines'))return on(state.berries)?14:0;
 if(name==='trial_spawner')return state.trial_spawner_state==='active'?8:state.trial_spawner_state==='waiting_for_players'?4:0;
 if(name==='vault')return state.vault_state==='active'||state.vault_state==='unlocking'||state.vault_state==='ejecting'?12:6;
 if(name==='firefly_bush')return on(state.snowy)?0:2;
 if(name==='light')return Math.max(0,Math.min(15,Number(state.level)||0));
 return fixed[name]||0;
}
const falling={clear:[[12041,14],[12210,13],[12377,12],[12542,11],[12705,10],[12867,9],[13027,8],[13188,7],[13348,6],[13509,5],[13670,4]],rain:[[12010,11],[12256,10],[12497,9],[12734,8],[12969,7],[13203,6],[13436,5],[13670,4]],thunder:[[11942,9],[12300,8],[12648,7],[12990,6],[13330,5],[13670,4]]};
const rising={clear:[[22331,5],[22492,6],[22653,7],[22813,8],[22974,9],[23135,10],[23297,11],[23460,12],[23624,13],[23791,14],[23961,15]],rain:[[22331,5],[22566,6],[22799,7],[23032,8],[23267,9],[23505,10],[23746,11],[23992,12]],thunder:[[22331,5],[22672,6],[23011,7],[23353,8],[23701,9],[60,10]]};
export function internalSkyLight(time,weather='clear'){
 const t=((Math.floor(time)%24000)+24000)%24000,kind=weather==='thunder'?'thunder':weather==='clear'?'clear':'rain';let level={clear:15,rain:12,thunder:10}[kind];
 if(kind==='thunder'&&t<60)return 9;
 if(t>=22331){level=4;for(const [start,value]of rising[kind])if(start>=22331&&t>=start)level=value;return level;}
 for(const [start,value]of falling[kind])if(t>=start)level=value;return level;
}
