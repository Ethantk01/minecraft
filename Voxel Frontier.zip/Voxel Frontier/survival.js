import {registerMachineInterfaces} from './content/machine-interfaces.js';
import {createCraftingRecipes,createSmeltingRecipes} from './content/recipes.js';
import {installEntityBehaviors} from './entity-behaviors.js';
import {createSystemContext} from './systems/context.js';
import {createSurvivalEntityModelsSystem} from './systems/survival-entity-models.js';
import {createSurvivalInventorySystem} from './systems/survival-inventory.js';
import {createSurvivalEquipmentSystem} from './systems/survival-equipment.js';
import {createSurvivalSurvivalInteractionsSystem} from './systems/survival-survival-interactions.js';
import {createSurvivalEntityCombatSystem} from './systems/survival-entity-combat.js';
import {createSurvivalEntityPhysicsSystem} from './systems/survival-entity-physics.js';
import {createSurvivalEntityAiSystem} from './systems/survival-entity-ai.js';
import {createSurvivalEntityEffectsSystem} from './systems/survival-entity-effects.js';
import {createSurvivalEntityNetworkSystem} from './systems/survival-entity-network.js';
import {createSurvivalEntityDimensionsSystem} from './systems/survival-entity-dimensions.js';
import {createEntityRegistry} from './entity-registry.js';
import {createItemRegistry} from './item-registry.js';
import {initFood,exhaust,eatFood,foodTick,foodValues} from './hunger.js';
import {ENTITY_COMBAT,meleeAttack,armorDamage,acceptDamage,bowPower} from './combat.js';
import {MinHeap} from './priority-queue.js';
import PI from "./textures/texture-data.json";
import Uw from "./textures/cem-skins.json";
import kI from "./textures/cem-models.json";
import equipmentValues from "./equipment-values.json";
function Ow(i) {
const $systemContext = createSystemContext({$:()=>$,
$1:()=>$1,
$b:()=>$b,
$e:()=>$e,
$h:()=>$h,
$p:()=>$p,
$r:()=>$r,
A:()=>A,
Af:()=>Af,
Am:()=>Am,
An:()=>An,
At:()=>At,
B:()=>B,
BE:()=>BE,
Be:()=>Be,
Bl:()=>Bl,
Bp:()=>Bp,
Bt:()=>Bt,
By:()=>By,
C:()=>C,
CE:()=>CE,
Ce:()=>Ce,
Cf:()=>Cf,
DE:()=>DE,
Db:()=>Db,
Dc:()=>Dc,
De:()=>De,
Di:()=>Di,
Dp:()=>Dp,
E:()=>E,
EE:()=>EE,
Ei:()=>Ei,
En:()=>En,
Et:()=>Et,
Ey:()=>Ey,
FE:()=>FE,
Fa:()=>Fa,
Fb:()=>Fb,
Fc:()=>Fc,
Fl:()=>Fl,
Fp:()=>Fp,
Fs:()=>Fs,
G:()=>G,
GE:()=>GE,
Ga:()=>Ga,
Gc:()=>Gc,
Gl:()=>Gl,
Gt:()=>Gt,
HE:()=>HE,
Hb:()=>Hb,
Hc:()=>Hc,
Hh:()=>Hh,
Hn:()=>Hn,
Hp:()=>Hp,
Hr:()=>Hr,
Hs:()=>Hs,
Ht:()=>Ht,
I:()=>I,
Ie:()=>Ie,
If:()=>If,
In:()=>In,
JE:()=>JE,
Jb:()=>Jb,
Jh:()=>Jh,
Jp:()=>Jp,
Jr:()=>Jr,
K:()=>K,
KE:()=>KE,
Kb:()=>Kb,
Kh:()=>Kh,
Kp:()=>Kp,
Ks:()=>Ks,
LE:()=>LE,
La:()=>La,
Lb:()=>Lb,
Lc:()=>Lc,
Le:()=>Le,
Ll:()=>Ll,
Lp:()=>Lp,
Lt:()=>Lt,
ME:()=>ME,
MinHeap:()=>MinHeap,
Ml:()=>Ml,
Mt:()=>Mt,
NE:()=>NE,
Ni:()=>Ni,
Nl:()=>Nl,
Np:()=>Np,
Nt:()=>Nt,
O:()=>O,
Ob:()=>Ob,
Oc:()=>Oc,
Ol:()=>Ol,
Op:()=>Op,
PE:()=>PE,
PI:()=>PI,
Pc:()=>Pc,
Pe:()=>Pe,
Pi:()=>Pi,
Pl:()=>Pl,
Pp:()=>Pp,
Q:()=>Q,
QE:()=>QE,
Qb:()=>Qb,
Qc:()=>Qc,
Qe:()=>Qe,
Qh:()=>Qh,
Qn:()=>Qn,
Qo:()=>Qo,
Qp:()=>Qp,
Qs:()=>Qs,
RE:()=>RE,
Ry:()=>Ry,
S:()=>S,
SE:()=>SE,
Sl:()=>Sl,
Sy:()=>Sy,
T:()=>T,
TE:()=>TE,
Tl:()=>Tl,
Tt:()=>Tt,
Ty:()=>Ty,
U:()=>U,
Ul:()=>Ul,
Uw:()=>Uw,
VE:()=>VE,
Va:()=>Va,
Vb:()=>Vb,
Vc:()=>Vc,
Vl:()=>Vl,
Vp:()=>Vp,
Vs:()=>Vs,
W:()=>W,
WE:()=>WE,
Wb:()=>Wb,
Wh:()=>Wh,
Wp:()=>Wp,
Wr:()=>Wr,
XE:()=>XE,
Xb:()=>Xb,
Xe:()=>Xe,
Xh:()=>Xh,
Xp:()=>Xp,
Xr:()=>Xr,
Xt:()=>Xt,
YE:()=>YE,
Yb:()=>Yb,
Yc:()=>Yc,
Yh:()=>Yh,
Yn:()=>Yn,
Yo:()=>Yo,
Ys:()=>Ys,
Z:()=>Z,
ZE:()=>ZE,
Zb:()=>Zb,
Ze:()=>Ze,
Zh:()=>Zh,
Zr:()=>Zr,
Zt:()=>Zt,
_:()=>_,
_E:()=>_E,
_b:()=>_b,
_e:()=>_e,
_n:()=>_n,
_y:()=>_y,
a:()=>a,
aE:()=>aE,
acceptDamage:()=>acceptDamage,
activateDimension:()=>activateDimension,
activeEntityDimension:()=>activeEntityDimension,
activeEntityRecord:()=>activeEntityRecord,
addExhaustion:()=>addExhaustion,
ae:()=>ae,
af:()=>af,
am:()=>am,
animateVanillaDragon:()=>animateVanillaDragon,
ao:()=>ao,
armorDamage:()=>armorDamage,
arrowModel:()=>arrowModel,
attackElapsed:()=>attackElapsed,
attackMeter:()=>attackMeter,
attackProfile:()=>attackProfile,
ay:()=>ay,
backgroundEntities:()=>backgroundEntities,
be:()=>be,
bl:()=>bl,
blockProperty:()=>blockProperty,
bowHeld:()=>bowHeld,
bowPower:()=>bowPower,
c:()=>c,
cE:()=>cE,
catalogKey:()=>catalogKey,
ce:()=>ce,
cf:()=>cf,
ci:()=>ci,
cm:()=>cm,
ct:()=>ct,
cy:()=>cy,
d:()=>d,
dE:()=>dE,
damageMob:()=>damageMob,
deflectFireball:()=>deflectFireball,
destroyCrystal:()=>destroyCrystal,
df:()=>df,
dm:()=>dm,
dn:()=>dn,
dragonBodyClearance:()=>dragonBodyClearance,
dragonBreathCloud:()=>dragonBreathCloud,
dragonBreathClouds:()=>dragonBreathClouds,
dragonCrystals:()=>dragonCrystals,
dragonMeshHitDistance:()=>dragonMeshHitDistance,
dragonPhase:()=>dragonPhase,
dy:()=>dy,
e:()=>e,
eE:()=>eE,
eatFood:()=>eatFood,
ee:()=>ee,
ef:()=>ef,
em:()=>em,
enchantmentTier:()=>enchantmentTier,
ensureDragonCrystals:()=>ensureDragonCrystals,
entityArrays:()=>entityArrays,
entityDimensions:()=>entityDimensions,
entityObject:()=>entityObject,
entityObjects:()=>entityObjects,
entityRegistry:()=>entityRegistry,
eo:()=>eo,
equipmentValues:()=>equipmentValues,
es:()=>es,
et:()=>et,
exhaust:()=>exhaust,
ey:()=>ey,
fE:()=>fE,
ff:()=>ff,
foodAccumulator:()=>foodAccumulator,
foodTick:()=>foodTick,
foodValues:()=>foodValues,
fr:()=>fr,
g:()=>g,
gE:()=>gE,
gf:()=>gf,
gi:()=>gi,
gm:()=>gm,
gt:()=>gt,
hE:()=>hE,
hf:()=>hf,
hitDragonCrystal:()=>hitDragonCrystal,
hm:()=>hm,
hr:()=>hr,
ht:()=>ht,
hudValues:()=>hudValues,
hudWrite:()=>hudWrite,
hy:()=>hy,
i:()=>i,
iE:()=>iE,
ie:()=>ie,
ii:()=>ii,
im:()=>im,
inStoredEntities:()=>inStoredEntities,
io:()=>io,
it:()=>it,
itemRegistry:()=>itemRegistry,
itemWhiteTexture:()=>itemWhiteTexture,
iy:()=>iy,
j:()=>j,
jE:()=>jE,
jb:()=>jb,
je:()=>je,
jh:()=>jh,
jp:()=>jp,
k:()=>k,
kE:()=>kE,
kI:()=>kI,
ka:()=>ka,
kb:()=>kb,
kc:()=>kc,
ki:()=>ki,
kl:()=>kl,
l:()=>l,
lastAttackItem:()=>lastAttackItem,
le:()=>le,
lm:()=>lm,
ly:()=>ly,
m:()=>m,
mE:()=>mE,
me:()=>me,
meleeAttack:()=>meleeAttack,
mn:()=>mn,
mt:()=>mt,
n:()=>n,
ne:()=>ne,
networkAttackQueue:()=>networkAttackQueue,
networkDrops:()=>networkDrops,
networkEntities:()=>networkEntities,
networkPickupQueue:()=>networkPickupQueue,
nf:()=>nf,
nm:()=>nm,
no:()=>no,
nt:()=>nt,
ny:()=>ny,
o:()=>o,
oE:()=>oE,
oa:()=>oa,
oe:()=>oe,
of:()=>of,
om:()=>om,
oo:()=>oo,
oy:()=>oy,
p:()=>p,
pE:()=>pE,
parkDimension:()=>parkDimension,
pb:()=>pb,
pe:()=>pe,
pf:()=>pf,
playerDamageState:()=>playerDamageState,
pn:()=>pn,
prepareDimension:()=>prepareDimension,
properTool:()=>properTool,
qE:()=>qE,
qb:()=>qb,
qh:()=>qh,
qp:()=>qp,
qr:()=>qr,
r:()=>r,
rE:()=>rE,
re:()=>re,
recordDragonFlight:()=>recordDragonFlight,
refreshXP:()=>refreshXP,
releaseEntity:()=>releaseEntity,
restoreEntitySave:()=>restoreEntitySave,
rf:()=>rf,
rm:()=>rm,
rt:()=>rt,
ry:()=>ry,
s:()=>s,
sE:()=>sE,
se:()=>se,
shieldDisabled:()=>shieldDisabled,
shieldHeld:()=>shieldHeld,
sm:()=>sm,
st:()=>st,
syncNetworkDrops:()=>syncNetworkDrops,
syncNetworkEntities:()=>syncNetworkEntities,
t:()=>t,
tE:()=>tE,
te:()=>te,
tf:()=>tf,
tickCombat:()=>tickCombat,
tm:()=>tm,
to:()=>to,
ts:()=>ts,
u:()=>u,
uE:()=>uE,
uf:()=>uf,
um:()=>um,
updateDragon:()=>updateDragon,
updateDragonBreathClouds:()=>updateDragonBreathClouds,
vE:()=>vE,
ve:()=>ve,
vi:()=>vi,
vo:()=>vo,
vt:()=>vt,
vy:()=>vy,
w:()=>w,
wE:()=>wE,
we:()=>we,
wl:()=>wl,
wn:()=>wn,
x:()=>x,
xe:()=>xe,
xi:()=>xi,
xpBatch:()=>xpBatch,
xpCapacity:()=>xpCapacity,
xpGeometry:()=>xpGeometry,
xpMaterial:()=>xpMaterial,
xy:()=>xy,
y:()=>y,
yE:()=>yE,
yl:()=>yl,
yt:()=>yt,
zE:()=>zE,
zb:()=>zb,
zc:()=>zc,
zp:()=>zp,
zs:()=>zs},{t:value=>t=value,
backgroundEntities:value=>backgroundEntities=value,
n:value=>n=value,
Jr:value=>Jr=value,
Bt:value=>Bt=value,
Fc:value=>Fc=value,
io:value=>io=value,
If:value=>If=value,
catalogKey:value=>catalogKey=value,
Qo:value=>Qo=value,
ci:value=>ci=value,
p:value=>p=value,
m:value=>m=value,
zb:value=>zb=value,
lastAttackItem:value=>lastAttackItem=value,
attackElapsed:value=>attackElapsed=value,
bowHeld:value=>bowHeld=value,
hr:value=>hr=value,
shieldHeld:value=>shieldHeld=value,
shieldDisabled:value=>shieldDisabled=value,
Yo:value=>Yo=value,
xpBatch:value=>xpBatch=value,
Xp:value=>Xp=value,
dm:value=>dm=value,
cf:value=>cf=value,
xpCapacity:value=>xpCapacity=value,
foodAccumulator:value=>foodAccumulator=value,
zc:value=>zc=value,
gf:value=>gf=value,
activeEntityDimension:value=>activeEntityDimension=value});
const {releaseEntity,ka,df,jr,Yb,Hb,Kb,animateVanillaDragon,Ty} = createSurvivalEntityModelsSystem($systemContext);
const {dropInventory,wn,En,mt,qr,hudWrite,ao,Xb,kl,im,DE,om,Zb,NE,jb,ff,PE,am,kE,Cf,qb,GE,ty,sm,Fa,VE,$r,iy,Am,zE,lm,Va,Ll,gm,Hn} = createSurvivalInventorySystem($systemContext);
const {blockProperty,properTool,oy,enchantmentTier,vo,ay,ry,es,sy,QE,Ay,attackProfile,consumeAttack,beginBow,releaseBow} = createSurvivalEquipmentSystem($systemContext);
const {gy,cy,dy,py,my,yy} = createSurvivalSurvivalInteractionsSystem($systemContext);
const {damageMob,Qc,xi,dragonMeshHitDistance,fy,Cy,YE,hitDragonCrystal,syncCrystals,destroyCrystal,HE,eU,Iy,dragonBreathCloud,updateDragonBreathClouds,arrowModel,Fl,deflectFireball,KE,tickCombat} = createSurvivalEntityCombatSystem($systemContext);
const {xy,Yc,dragonBodyClearance,wy,WE,My,by,Vl,um,XE,fr,hm,Hc} = createSurvivalEntityPhysicsSystem($systemContext);
const {ts,uy,hy,ensureDragonCrystals,_y,Ey,Sy,JE,dragonPhase,recordDragonFlight,updateDragon,ZE,Ry,jE} = createSurvivalEntityAiSystem($systemContext);
const {refreshXP,prepareEffects,Wb,La,Pl,uf,Jb,hf,nm,Yn,pf,qE,By,addExhaustion,ly,Uy} = createSurvivalEntityEffectsSystem($systemContext);
const {commandEntities,killCommandEntity,teleportCommandEntity,networkEntities,syncNetworkEntities,networkDrops,syncNetworkDrops,networkCollect,networkPickupRequests,networkGrant,networkHits,networkHit} = createSurvivalEntityNetworkSystem($systemContext);
const {entityObjects,activeEntityRecord,parkDimension,restoreEntitySave,activateDimension,prepareDimension,renderDimension,simulateDimension,dimensionIds,entityPositions,mobStates,transferMob,dimensionSnapshots,inStoredEntities,syncStoredDimension,serializeEntities} = createSurvivalEntityDimensionsSystem($systemContext);

  let backgroundEntities=false;
  let { THREE: e, scene: t, player: n, camera: o, save: a, ITEMS: r, ids: s, getBlock: A, setBlock: l, setBlockBatch: g, activateNetherPortal: c, terrain: d, spawnPoint: h, showToast: p, playSound: m, markDirty: I, refreshHotbar: u } = i, { AIR: E, GRASS: C, DIRT: _, STONE: w, SAND: M, WOOD: y, LEAVES: B, WATER: S, COAL: x, IRON: U, BRICK: F, GLASS: Y, TABLE: W, TORCH: $, PLANKS: G, FURNACE: ae, TNT: te, DEEPSLATE: Ae, COPPER_ORE: se, GOLD_ORE: xe, DIAMOND_ORE: nt, REDSTONE_ORE: gt, LAPIS_ORE: Tt, SNOW: Et, CACTUS: de, GRAVEL: Ce, BEDROCK: Ze, SPRUCE_LOG: rt, SPRUCE_LEAVES: it, OBSIDIAN: vt, NETHERRACK: dn, LAVA: Q, FIRE: Ie, NETHER_BRICKS: fe, GLOWSTONE: ge, SOUL_SAND: ce, END_STONE: ke, PURPUR: Me, CHEST: Be, STONE_BRICKS: xt, MOSSY_BRICKS: It, NETHER_PORTAL: k, END_PORTAL: T, END_FRAME: ee, BIRCH_LOG: oe, BIRCH_LEAVES: pe, SPRUCE_PLANKS: re, BIRCH_PLANKS: $e, RED_SAND: Oe, SANDSTONE: at, FARMLAND: et, WHEAT_CROP: be, DEEPSLATE_COAL: Qe, DEEPSLATE_IRON: ct, STICK: we, PICKAXE: Ve, SWORD: wt, RAW_MEAT: K, COOKED_MEAT: ye, WOOL: De, WHEAT: Pe, BREAD: me, GUNPOWDER: le, STONE_PICKAXE: ot, IRON_PICKAXE: pt, DIAMOND_PICKAXE: an, WOOD_AXE: en, STONE_AXE: zo, IRON_AXE: $i, WOOD_SHOVEL: Uc, STONE_SHOVEL: Pa, IRON_SHOVEL: Gs, IRON_SWORD: xl, DIAMOND_SWORD: Ls, RAW_IRON: Hr, IRON_INGOT: _e, DIAMOND: eo, GOLD_INGOT: In, REDSTONE_DUST: Ht, LAPIS_LAZULI: Fs, COPPER_INGOT: Vs, APPLE: wl, CARROT: Rp, POTATO: Tp, ENDER_PEARL: Ml, BLAZE_ROD: O, EYE_OF_ENDER: Z, FLINT_STEEL: ne, FLINT: ie, BLAZE_POWDER: j, BOW: ve, ARROW: Le, STRING: Xe, BONE: je, ROTTEN_FLESH: ht, BUCKET: st, WATER_BUCKET: At, LEATHER: yt, PAPER: Xt, BOOK: Lt, EMERALD: Gt, RAW_CHICKEN: An, COOKED_CHICKEN: dt, BED: pn, DOOR: Nt, DOOR_TOP: gi, LADDER: Kr, SAPLING: Di, CROP_0: Wr, CROP_1: _n, CROP_2: to, WHEAT_SEEDS: Ei, WOOD_HOE: Qn, LAVA_BUCKET: ii, SHIELD: Ni, IRON_HELMET: no, IRON_CHESTPLATE: zs, IRON_LEGGINGS: bl, IRON_BOOTS: Oc, RAW_GOLD: $1, RAW_COPPER: eE, FEATHER: Ib, CHARCOAL: Dc, BRICK_ITEM: Nc, COAL_ITEM: Bp, QUARTZ_ITEM: yl, GOLD_NUGGET: pb } = s, { REDSTONE_WIRE: mb, LEVER: tE, REDSTONE_LAMP: nE, PISTON: Up, ENCHANTING_TABLE: Op, ANVIL: Dp, BREWING_STAND: iE, RAIL: oE, POWERED_RAIL: aE, SPAWNER: Qh, ANCIENT_DEBRIS: Qs, SHULKER_BOX: oa, BOOKSHELF: rE, NETHER_WART_CROP: sE, SMITHING_TABLE: Np, FISHING_ROD: Yh, COD: _b, BOAT: Hh, MINECART: Kh, ELYTRA: Sl, FIREWORK: Pp, SHULKER_SHELL: Wh, NETHERITE_SCRAP: Rl, NETHERITE_INGOT: Jh, NETHERITE_PICKAXE: kp, NETHERITE_SWORD: Gp, NETHERITE_AXE: AE, NETHERITE_SHOVEL: lE, GLASS_BOTTLE: Lp, WATER_BOTTLE: Fp, AWKWARD_POTION: Ys, HEALING_POTION: Xh, SPEED_POTION: Zh, STRENGTH_POTION: jh, NETHER_WART: Vp, GHAST_TEAR: gE, SPIDER_EYE: cE, UPGRADE_TEMPLATE: zp, SUGAR: dE, GLISTERING_MELON: uE, REGENERATION_POTION: qh, POISON_POTION: $h, SHEARS: Tl } = s, { STICKY_PISTON: Eb, REDSTONE_TORCH: Hs, REPEATER: hE, COMPARATOR: fE, STONE_BUTTON: CE, STONE_PRESSURE_PLATE: IE, OBSERVER: vb, DETECTOR_RAIL: pE, SLIME_BALL: xb } = s, { DISPENSER: Qp, DROPPER: ef, HOPPER: tf, DAYLIGHT_DETECTOR: mE, TARGET: _E, TRAPPED_CHEST: nf, NOTE_BLOCK: EE, WOODEN_BUTTON: vE, WOODEN_PRESSURE_PLATE: wb, LIGHT_WEIGHTED_PLATE: Mb, HEAVY_WEIGHTED_PLATE: bb, COPPER_BULB: yb, TRIPWIRE_HOOK: xE, TRIPWIRE: Sb, SCULK_SENSOR: Rb, CALIBRATED_SCULK_SENSOR: Tb, CRAFTER: Ks, OAK_TRAPDOOR: wE, IRON_TRAPDOOR: ME, HAY_BALE: bE, AMETHYST_SHARD: Yp, LIGHTNING_ROD: Bb, LECTERN: Pc, CHISELED_BOOKSHELF: Hp, ACTIVATOR_RAIL: Ub } = s, { POWDER_SNOW: kc, POINTED_DRIPSTONE_UP: Ob, POINTED_DRIPSTONE_DOWN: Db, GLOW_BERRIES: yE, POWDER_SNOW_BUCKET: of, MUSIC_DISC_OTHERSIDE: af, LEATHER_BOOTS: Gc, SNOWBALL: Pi } = s, { STONECUTTER: Kp, CUT_COPPER: SE, JUKEBOX: rf } = s, Lc = i.extraId("copper_block"), Bl = 428, sf = i.extraId("iron_block"), Mt = i.extraId("cobblestone"), Wp = i.extraId("blackstone"), RE = i.extraId("clay"), Nb = i.extraId("smooth_stone"), Pb = i.extraId("redstone_block"), kb = createSmeltingRecipes(s,i), TE = [G, re, $e, ...["acacia", "dark_oak", "jungle", "mangrove", "cherry", "bamboo", "crimson", "warped"].map((f) => i.extraId(f + "_planks"))], Jp = document.getElementById("inventoryOverlay"), BE = document.getElementById("inventoryItems"), Af = document.getElementById("craftGrid"), Ul = document.getElementById("craftResult"), Gb = document.getElementById("recipeGuide"), Lb = document.getElementById("hearts"), Fb = document.getElementById("hunger"), Vb = document.getElementById("air"), ki = createCraftingRecipes(s,i);
  ki.push({ name: "Redstone block", pattern: [[Ht, Ht, Ht], [Ht, Ht, Ht], [Ht, Ht, Ht]], out: Pb, count: 1 }, { name: "Redstone torch", pattern: [[Ht], [we]], out: Hs, count: 1 }, { name: "Stone button", pattern: [[w]], out: CE, count: 1 }, { name: "Stone pressure plate", pattern: [[w, w]], out: IE, count: 1 }, { name: "Sticky piston", pattern: [[xb], [Up]], out: Eb, count: 1 }, { name: "Repeater", pattern: [[Hs, Ht, Hs], [w, w, w]], out: hE, count: 1 }, { name: "Comparator", pattern: [[0, Hs, 0], [Hs, yl, Hs], [w, w, w]], out: fE, count: 1 }, { name: "Observer", pattern: [[Mt, Mt, Mt], [Ht, Ht, yl], [Mt, Mt, Mt]], out: vb, count: 1 }, { name: "Detector rail \xD76", pattern: [[_e, 0, _e], [_e, IE, _e], [_e, Ht, _e]], out: pE, count: 6 }), ki.push({ name: "Dispenser", pattern: [[Mt, Mt, Mt], [Mt, ve, Mt], [Mt, Ht, Mt]], out: Qp, count: 1 }, { name: "Dropper", pattern: [[Mt, Mt, Mt], [Mt, 0, Mt], [Mt, Ht, Mt]], out: ef, count: 1 }, { name: "Hopper", pattern: [[_e, 0, _e], [_e, Be, _e], [0, _e, 0]], out: tf, count: 1 }, { name: "Daylight detector", pattern: [[Y, Y, Y], [yl, yl, yl], [G, G, G]], out: mE, count: 1 }, { name: "Hay bale", pattern: [[Pe, Pe, Pe], [Pe, Pe, Pe], [Pe, Pe, Pe]], out: bE, count: 1 }, { name: "Target", pattern: [[0, Ht, 0], [Ht, bE, Ht], [0, Ht, 0]], out: _E, count: 1 }, { name: "Tripwire hooks \xD72", pattern: [[_e], [we], [G]], out: xE, count: 2 }, { name: "Tripwire", pattern: [[Xe]], out: Sb, count: 1 }, { name: "Trapped chest", pattern: [[Be, xE]], out: nf, count: 1 }, { name: "Note block", pattern: [[G, G, G], [G, Ht, G], [G, G, G]], out: EE, count: 1 }, { name: "Oak button", pattern: [[G]], out: vE, count: 1 }, { name: "Oak pressure plate", pattern: [[G, G]], out: wb, count: 1 }, { name: "Light weighted pressure plate", pattern: [[In, In]], out: Mb, count: 1 }, { name: "Heavy weighted pressure plate", pattern: [[_e, _e]], out: bb, count: 1 }, { name: "Copper bulb \xD74", pattern: [[Lc, Lc, Lc], [0, O, 0], [0, Ht, 0]], out: yb, count: 4 }, { name: "Calibrated sculk sensor", pattern: [[Yp, Yp, Yp], [0, Rb, 0]], out: Tb, count: 1 }, { name: "Crafter", pattern: [[_e, _e, _e], [_e, W, _e], [Ht, ef, Ht]], out: Ks, count: 1 }, { name: "Oak trapdoors \xD72", pattern: [[G, G, G], [G, G, G]], out: wE, count: 2 }, { name: "Iron trapdoor", pattern: [[_e, _e], [_e, _e]], out: ME, count: 1 }, { name: "Lightning rod", pattern: [[Vs], [Vs], [Vs]], out: Bb, count: 1 }, { name: "Lectern", pattern: [[G, G, G], [0, Lt, 0], [0, G, 0]], out: Pc, count: 1 }, { name: "Chiseled bookshelf", pattern: [[G, G, G], [G, 0, G], [G, G, G]], out: Hp, count: 1 }, { name: "Activator rails x6", pattern: [[_e, we, _e], [_e, Hs, _e], [_e, we, _e]], out: Ub, count: 6 }), ki.push({ name: "Iron block", pattern: [[_e, _e, _e], [_e, _e, _e], [_e, _e, _e]], out: sf, count: 1 }, { name: "Redstone wire", pattern: [[Ht]], out: mb, count: 1 }, { name: "Lever", pattern: [[we], [Mt]], out: tE, count: 1 }, { name: "Redstone lamp", pattern: [[0, Ht, 0], [Ht, ge, Ht], [0, Ht, 0]], out: nE, count: 1 }, { name: "Piston", pattern: [[G, G, G], [Mt, _e, Mt], [Mt, Ht, Mt]], out: Up, count: 1 }, { name: "Enchanting table", pattern: [[0, Lt, 0], [eo, vt, eo], [vt, vt, vt]], out: Op, count: 1 }, { name: "Bookshelf", pattern: [[G, G, G], [Lt, Lt, Lt], [G, G, G]], out: rE, count: 1 }, { name: "Anvil", pattern: [[sf, sf, sf], [0, _e, 0], [_e, _e, _e]], out: Dp, count: 1 }, { name: "Brewing stand", pattern: [[0, O, 0], [Mt, Mt, Mt]], out: iE, count: 1 }, { name: "Rail x16", pattern: [[_e, 0, _e], [_e, we, _e], [_e, 0, _e]], out: oE, count: 16 }, { name: "Powered rail x6", pattern: [[In, 0, In], [In, we, In], [In, Ht, In]], out: aE, count: 6 }, { name: "Fishing rod", pattern: [[0, 0, we], [0, we, Xe], [we, 0, Xe]], out: Yh, count: 1 }, { name: "Oak boat", pattern: [[G, 0, G], [G, G, G]], out: Hh, count: 1 }, { name: "Minecart", pattern: [[_e, 0, _e], [_e, _e, _e]], out: Kh, count: 1 }, { name: "Firework rockets x3", pattern: [[Xt], [le]], out: Pp, count: 3 }, { name: "Shulker box", pattern: [[Wh], [Be], [Wh]], out: oa, count: 1 }, { name: "Netherite ingot", pattern: [[Rl, Rl, In], [Rl, Rl, In], [In, In, 0]], out: Jh, count: 1 }, { name: "Glass bottles x3", pattern: [[Y, 0, Y], [0, Y, 0]], out: Lp, count: 3 }, { name: "Smithing table", pattern: [[_e, _e], [G, G], [G, G]], out: Np, count: 1 }), ki.push({ name: "Shears", pattern: [[0, _e], [_e, 0]], out: Tl, count: 1 }), ki.push({ name: "Golden helmet", pattern: [[In, In, In], [In, 0, In]], out: Bl, count: 1 }), ki.push({ name: "Leather boots", pattern: [[yt, 0, yt], [yt, 0, yt]], out: Gc, count: 1 }), ki.push({ name: "Stonecutter", pattern: [[0, _e, 0], [w, w, w]], out: Kp, count: 1 }), ki.push({ name: "Jukebox", pattern: [[G, G, G], [G, eo, G], [G, G, G]], out: rf, count: 1 });
  for (let [f, b, R, v, N] of [[G, Ve, en, Uc, wt], [Mt, ot, zo, Pa, 0], [_e, pt, $i, Gs, xl], [eo, an, 0, 0, Ls]]) ki.push({ name: r[b].name, pattern: [[f, f, f], [0, we, 0], [0, we, 0]], out: b, count: 1 }), R && ki.push({ name: r[R].name, pattern: [[f, f], [f, we], [0, we]], out: R, count: 1 }), v && ki.push({ name: r[v].name, pattern: [[f], [we], [we]], out: v, count: 1 }), N && ki.push({ name: r[N].name, pattern: [[f], [f], [we]], out: N, count: 1 });
  let vi = { [Ve]: { kind: "pick", tier: 0, speed: 2, durability: 59 }, [ot]: { kind: "pick", tier: 1, speed: 4, durability: 131 }, [pt]: { kind: "pick", tier: 2, speed: 6, durability: 250 }, [an]: { kind: "pick", tier: 3, speed: 8, durability: 1561 }, [en]: { kind: "axe", tier: 0, speed: 2, durability: 59 }, [zo]: { kind: "axe", tier: 1, speed: 4, durability: 131 }, [$i]: { kind: "axe", tier: 2, speed: 6, durability: 250 }, [Uc]: { kind: "shovel", tier: 0, speed: 2, durability: 59 }, [Pa]: { kind: "shovel", tier: 1, speed: 4, durability: 131 }, [Gs]: { kind: "shovel", tier: 2, speed: 6, durability: 250 }, [wt]: { kind: "sword", tier: 0, damage: 4, durability: 59 }, [xl]: { kind: "sword", tier: 2, damage: 6, durability: 250 }, [Ls]: { kind: "sword", tier: 3, damage: 7, durability: 1561 }, [ne]: { kind: "utility", tier: 0, durability: 64 }, [Qn]: { kind: "hoe", tier: 0, speed: 2, durability: 59 }, [Ni]: { kind: "shield", tier: 0, durability: 336 }, [no]: { kind: "armor", tier: 2, durability: 165 }, [zs]: { kind: "armor", tier: 2, durability: 240 }, [bl]: { kind: "armor", tier: 2, durability: 225 }, [Oc]: { kind: "armor", tier: 2, durability: 195 }, [kp]: { kind: "pick", tier: 4, speed: 9, durability: 2031 }, [Gp]: { kind: "sword", tier: 4, damage: 8, durability: 2031 }, [AE]: { kind: "axe", tier: 4, speed: 9, durability: 2031 }, [lE]: { kind: "shovel", tier: 4, speed: 9, durability: 2031 }, [Yh]: { kind: "utility", tier: 0, durability: 64 }, [Sl]: { kind: "armor", tier: 0, durability: 432 }, [Tl]: { kind: "utility", tier: 0, durability: 238 }, [Bl]: { kind: "armor", tier: 0, durability: 77 }, [Gc]: { kind: "armor", tier: 0, durability: 65 } }, lf = /* @__PURE__ */ new Set([w, Ae, Mt, Wp, x, U, Qe, ct, se, xe, nt, gt, Tt, F, ae, vt, dn, fe, ge, ke, Me, xt, It, at]);
  for (let f of [Qs, Up, Op, Dp, Qh, nE, Np, Kp, SE, ...["emerald_ore", "deepslate_diamond_ore", "deepslate_gold_ore", "deepslate_redstone_ore", "deepslate_lapis_ore", "deepslate_copper_ore", "deepslate_emerald_ore", "nether_gold_ore", "nether_quartz_ore"].map(i.extraId)]) lf.add(f);
  let UE = /* @__PURE__ */ new Set([y, rt, oe, G, re, $e, W, rf]), OE = /* @__PURE__ */ new Set([_, C, M, Oe, Et, Ce, et]), io = 2, mn = Array(9).fill(0), Bt = null, Fc = null, Jr = false, zb = false, Qo = null, ci = null, Vc = false, Xp = 4, Zp = 0, Yo = 0, zc = 0, gf = 0, cf = 1, hr = null;
  for (const [id, gear] of Object.entries(equipmentValues)) {
    vi[id] = { kind: gear.kind, tier: gear.tier ?? 0, speed: gear.speed ?? 1, damage: gear.damage, durability: gear.durability, enchantability: gear.enchantability, repair: gear.repair, defense: gear.defense ?? 0, toughness: gear.toughness ?? 0, knockbackResistance: gear.knockbackResistance ?? 0, slot: gear.slot };
  }
  const craftMaterials = { wood: G, stone: Mt, copper: Vs, iron: _e, gold: In, diamond: eo, leather: yt, turtle: 640 };
  for (const [id, gear] of Object.entries(equipmentValues)) {
    if (+id < 600 || !(gear.material in craftMaterials)) continue;
    let material = craftMaterials[gear.material], pattern = null;
    if (gear.slot) {
      pattern = { helmet: [[material, material, material], [material, 0, material]], chestplate: [[material, 0, material], [material, material, material], [material, material, material]], leggings: [[material, material, material], [material, 0, material], [material, 0, material]], boots: [[material, 0, material], [material, 0, material]] }[gear.slot];
    } else pattern = { pick: [[material, material, material], [0, we, 0], [0, we, 0]], axe: [[material, material], [material, we], [0, we]], shovel: [[material], [we], [we]], sword: [[material], [material], [we]], hoe: [[material, material], [0, we], [0, we]] }[gear.kind];
    if (pattern) ki.push({ name: gear.name, pattern, out: +id, count: 1 });
  }
  a.chests ??= {}, a.armor ??= {}, a.xp ??= 0, a.enchants ??= {}, a.effects ??= {}, a.tradeRanks ??= {}, a.brewJobs ??= {}, a.furnaceJobs ??= {}, a.furnaceFuel ??= {}, a.furnaceOutputs ??= {};
  let Qb = ["helmet", "chestplate", "leggings", "boots", "offhand"], jp = { helmet: [], chestplate: [Sl], leggings: [], boots: [], offhand: Ni }, Ol = document.createElement("div");
  for (const [id, gear] of Object.entries(equipmentValues)) if (gear.slot) jp[gear.slot].push(+id);
  Ol.className = "item-cursor", document.body.append(Ol), document.addEventListener("mousemove", (f) => {
    Ol.style.left = f.clientX + 12 + "px", Ol.style.top = f.clientY + 12 + "px";
  });
  let oo = [], Zt = [], Xr = [], Zr = [], Dl = new e.BoxGeometry(1, 1, 1), Nl = /* @__PURE__ */ new Map(), qp = /* @__PURE__ */ new Map(), $p = new e.TextureLoader();
  Dl.userData.shared=true;
  
  
  
  
  let em = /* @__PURE__ */ new Map(), tm = /* @__PURE__ */ new Map();
  
  
  
  const itemWhiteTexture=new e.DataTexture(new Uint8Array([255,255,255,255]),1,1);itemWhiteTexture.colorSpace=e.SRGBColorSpace;itemWhiteTexture.needsUpdate=true;
  const xpGeometry=new e.SphereGeometry(.115,6,4),xpMaterial=new e.MeshBasicMaterial({color:10807628});
  let xpCapacity=1024,xpBatch=new e.InstancedMesh(xpGeometry,xpMaterial,xpCapacity);
  xpBatch.count=0;xpBatch.frustumCulled=false;xpBatch.instanceMatrix.setUsage(e.DynamicDrawUsage);t.add(xpBatch);
  
  
  
  const entityRegistry=createEntityRegistry(s,kI,Uw),Ga=entityRegistry.definitions,itemRegistry=createItemRegistry(r);
  registerMachineInterfaces(i.blockRegistry,s,(kind,hit)=>$r(kind,hit));
  installEntityBehaviors(entityRegistry, {
    THREE:e, player:()=>n, camera:()=>o, dimension:()=>i.getDimension(), daylight:()=>cf, background:()=>backgroundEntities,
    armor:()=>a.armor, skyExposed:mob=>hm(mob), canSee:mob=>fr(mob), raining:(x,z)=>i.isRaining?.(x,z),
    ids:{WATER:S,GRASS:C,DIRT:_,GRAVEL:Ce,GOLD_HELMET:Bl}, block:(...args)=>A(...args), setBlock:(...args)=>l(...args),
    teleport:mob=>Hc(mob),toast:text=>p(text),drop:(...args)=>Yn(...args),move:(...args)=>um(...args),
    entities:()=>Zt,barterItems:()=>[Ml,vt,Ce,Xe,_e],explode:(...args)=>Qc(...args),
    remove:mob=>{releaseEntity(mob.group);const index=Zt.indexOf(mob);if(index>=0)Zt.splice(index,1)},
    updateDragon:(...args)=>updateDragon(...args),animate:(...args)=>Ty(...args)
  });
  let attackElapsed=10,lastAttackItem=Hn(),shieldHeld=0,shieldDisabled=0,bowHeld=null;
  const playerDamageState={hurtRemaining:0,lastHurt:0};
  const attackMeter=document.createElement('div');attackMeter.className='attack-recharge';attackMeter.innerHTML='<i></i>';document.body.append(attackMeter);
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  const hudValues=new WeakMap();
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  document.getElementById("recipeButton").onclick = () => {
    Vc = !Vc, GE();
  };
  let $b = ["All", "Building", "Nature", "Functional", "Redstone", "Tools", "Combat", "Food", "Spawn eggs", "Ingredients"], If = "All", LE = document.getElementById("creativeSearch"), FE = document.getElementById("creativeTabs"), Gl = document.getElementById("catalogItems"), ey = document.getElementById("creativeCount"), rm = Object.keys(r).map(Number).filter((f) => r[f]?.name).sort((f, b) => r[f].name.localeCompare(r[b].name));
  
  let ny = new Map(rm.map((f) => [f, ty(f)]));
  let catalogKey=null;
  
  LE.addEventListener("input", () => {
    Gl.scrollTop = 0, sm();
  });
  
  
  
  
  
  
  Ul.onclick = () => {
    let f = Am();
    if (f) {
      if (En(f.out, f.count) < f.count) {
        p("INVENTORY FULL");
        return;
      }
      mn.fill(0), zE(f), Fa();
    }
  };
  
  
  
  
  document.getElementById("closeInventory").onclick = gm, Gb.innerHTML = "<b>FIELD RECIPES</b> \xB7 Log \u2192 4 planks \xB7 2 planks vertical \u2192 4 sticks \xB7 4 planks square \u2192 table \xB7 Table: 3 planks + 2 sticks \u2192 pickaxe \xB7 2 planks + stick \u2192 sword \xB7 Coal + stick \u2192 torches \xB7 8 stone ring \u2192 furnace \xB7 3 wheat \u2192 bread \xB7 Gunpowder + sand checkerboard \u2192 TNT";
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  initFood(n);let foodAccumulator=0;
  
  
  
  
  
  
  
  
  
  
  let cm = new e.Raycaster();
  
  
  
  
  const dragonCrystals=[];
  
  
  
  
  
  
  
  
  
  
  let dm = 7;
  
  let vy = { arrow: { speed: 32, color: 14209978, size: 0.12 }, fireball: { speed: 6, color: 15962673, size: 0.38 }, dragon_fireball: { speed: 9, color: 10945694, size: 0.46 }, blaze: { speed: 9, color: 16755255, size: 0.2 }, potion: { speed: 8, color: 10712251, size: 0.2 }, bullet: { speed: 4, color: 10185659, size: 0.26 } };
  const dragonBreathClouds=[];
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  const networkAttackQueue=[],networkPickupQueue=[];
  
  
  
  
  
  
  
  
  
  const entityDimensions=new Map();let activeEntityDimension=i.getDimension();
  const entityArrays=()=>({mobs:Zt,drops:oo,xp:Xr,projectiles:Zr,crystals:dragonCrystals,clouds:dragonBreathClouds});
  const entityObject=(kind,entity)=>kind==='mobs'?entity.group:entity.mesh;
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  if(!a.combatVersion){
    const old={cow:8,sheep:6,zombie:10,creeper:8,blaze:10,piglin:12,enderman:16,skeleton:10,spider:8,witch:13,shulker:15};
    for(const record of Object.values(a.entityStates||{}))for(const mob of record.mobs||[]){if(old[mob.type]&&Number.isFinite(mob.state?.health))mob.state.health=Math.min(Ga[mob.type].health,mob.state.health/old[mob.type]*Ga[mob.type].health);}
    a.combatVersion=1;I();
  }
  restoreEntitySave(activeEntityDimension);refreshXP();
  function igniteMob(hit){if(Hn()!==i.ids.FLINT_STEEL)return false;const direction=new e.Vector3();o.getWorldDirection(direction);let target=null,range=Math.min(4,hit?.distance??Infinity);for(const mob of Zt){const shape=Yc(mob),center=new e.Vector3(mob.x,mob.group.position.y+shape.height*.5,mob.z),relative=center.sub(o.position),along=relative.dot(direction),distance=relative.clone().addScaledVector(direction,-along).length();if(along>0&&along<range&&distance<Math.max(shape.radius,.45)){range=along;target=mob;}}if(!target)return false;es(i.ids.FLINT_STEEL);m('fire');if(i.isRemoteWorld?.())networkAttackQueue.push({id:target.networkId,ignite:true,damage:0,x:n.x,z:n.z});else if(!target.definition.fireImmune){target.fireTime=8;target.burnTimer=0;if(!target.definition.hostile){target.flee=5;target.panicOrigin={x:n.x,z:n.z};target.path=[];target.pathTimer=0;}}return true;}
  function refreshItemIcons(){catalogKey=null;for(const material of qp.values()){material.dispose();}qp.clear();for(const list of [oo,...[...entityDimensions.values()].map(record=>record.drops)])for(const drop of list||[])drop.mesh.material=Wb(drop.id);}
  function entityAppearance(type,model,texture,textureSize=null){
    const definition=Ga[type];if(!definition&&type!=='sheep_wool')return;
    if(textureSize&&!model){if(type==='sheep_wool')kI.sheep_wool={...kI.sheep_wool,textureSize};else definition.model={...(definition.model||kI[type]),textureSize};}
    if(type==='sheep_wool'){if(model)kI.sheep_wool=model;if(texture)Uw.sheep_wool=texture;}else {if(model){definition.model={...kI[type],...model,models:[...(model.models||[]),...kI[type].models.filter(p=>!model.models.some(m=>m.part===p.part))],packAnimations:true};}if(texture)definition.texture=texture;}
    em.get(type)?.dispose();em.delete(type);tm.clear();
    const lists=[Zt,...[...entityDimensions.values()].map(record=>record.mobs)];
    for(const list of lists)for(const mob of list||[]){if(mob.type!==type&&!(type==='sheep_wool'&&mob.type==='sheep'))continue;const parent=mob.group.parent,position=mob.group.position.clone(),rotation=mob.group.rotation.clone(),scale=mob.group.scale.clone(),visual=Kb(mob.type);if(!visual)continue;releaseEntity(mob.group);Object.assign(mob,visual);mob.group.position.copy(position);mob.group.rotation.copy(rotation);mob.group.scale.copy(scale);parent?.add(mob.group);}
  }
  return window.__VF_TEST__ && Object.assign(window.__VF_TEST__, { makeMob: ts, mobs: Zt, projectiles: Zr, drops: oo, teleportMob: Hc, canSeePlayer: fr, updateMobs: jE, advanceMob: um, knockbackMob: YE, updateDrops: qE, fireProjectile: Fl, updateProjectiles: KE }), { igniteMob,refreshCatalog:()=>{catalogKey=null;Fa();},dropInventory,refreshItemIcons,entityAppearance, bowTime:()=>bowHeld, initializeFood:()=>initFood(n),syncCrystals,destroyCrystal,addExhaustion,tickCombat,consumeAttack,attackProfile,beginBow,releaseBow,damageMob,mobStates,commandEntities,teleportCommandEntity,transferMob,entityCombat:ENTITY_COMBAT,parkDimension,activateDimension,prepareDimension,renderDimension,simulateDimension,dimensionIds,entityPositions,dimensionSnapshots,syncStoredDimension,inStoredEntities,serializeEntities,prepareEffects,networkDrops,syncNetworkDrops,networkCollect,networkPickupRequests,networkGrant,networkEntities,syncNetworkEntities,networkHits,networkHit,entityRegistry,itemRegistry,killCommandEntity,spawnMob: ts, removeMobs: (kind) => { let count = 0; for (let index = Zt.length - 1; index >= 0; index--) { const mob = Zt[index]; if (kind && mob.type !== kind) continue; releaseEntity(mob.group); Zt.splice(index, 1); count++; } return count; }, update: Uy, mine: Ay, miningTime: sy, interact: gy, attackMob: Iy, tradeMob: py, openInventory: Ll, closeInventory: gm, isOpen: () => Jr, nearbyTable: my, hurt: xi, refresh: ao, count: wn, selectedId: Hn, drop: Yn, clearEntities: uy, collidesPlayer: wy, isPlatePressed: WE, plateWeight: My, collectHopperDrop: by, autoCraft: yy, explode: Qc, nearestEntityDistance: fy, pushEntitiesByPiston: Cy, getCursor: () => Bt, setCursor: (f) => {
    Bt = f, Fa();
  }, renderInventory: Fa };
}
export { Ow as createSurvival };
