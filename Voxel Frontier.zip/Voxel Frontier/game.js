window.addEventListener('error',event=>console.error('Game error:',event.message));
window.addEventListener('unhandledrejection',event=>console.error('Game async error:',String(event.reason)));
import {pointerLockUnavailable,requestGamePointerLock} from './pointer-lock.js';
import {installGridLightMaterial} from './grid-light-material.js';
import {configureDynamicIcons,invalidateDynamicIcons} from './item-icons.js';
import {createNatureSystem} from './nature-system.js';
import {createGameplayRepairs} from './gameplay-repairs.js';
import {applyItemIcons} from './item-icons.js';
import {createBlockRegistry} from './content-registry.js';
import {createContentCatalog} from './content/block-catalog.js';
import {createSystemContext} from './systems/context.js';
import {createBlockContentSystem} from './systems/block-content.js';
import {createWeatherSystem} from './systems/weather.js';
import {createTerrainSystem} from './systems/terrain.js';
import {createWorldAccessSystem} from './systems/world-access.js';
import {createLightingSystem} from './systems/lighting.js';
import {createFluidsSystem} from './systems/fluids.js';
import {createBlockPhysicsSystem} from './systems/block-physics.js';
import {createBlockModelsSystem} from './systems/block-models.js';
import {createChunksSystem} from './systems/chunks.js';
import {createBlockInteractionsSystem} from './systems/block-interactions.js';
import {createRedstoneSystem} from './systems/redstone.js';
import {createDimensionsSystem} from './systems/dimensions.js';
import {createPortalsSystem} from './systems/portals.js';
import {createPlayerPhysicsSystem} from './systems/player-physics.js';
import {createVehiclesSystem} from './systems/vehicles.js';
import {createGameUiSystem} from './systems/game-ui.js';
import {createResourcePacks} from './resource-pack.js';
import {setPlayerSkin} from './player-model.js';
import {replaceSound} from './sound-player.js';
import {createChestAnimation} from './chest-animation.js';
import {createFirstPerson} from './first-person.js';
import {createEndPortalMaterial} from './end-portal-material.js';
import {safeSpawn} from './spawn-safety.js';
import {createChestLoot,chestRandom} from './chest-loot.js';
import {createLoadingScreen} from './loading-screen.js';
import {createMobileControls} from './mobile-controls.js';
import {createMultiplayer} from './multiplayer.js';
import * as THREE from './vendor/three.module.js';
import {createSurvival} from './machine-ui.js';
import {createPortalWindow,mapPortalPoint,mapPortalYaw} from './portal-experiments.js';
import {playGameSound,prepareInteractionSounds,unlockSounds} from './sound-player.js';
import {MOB_TYPES,registerSpawnEggs} from './entity-registry.js';
import structureAssets from './structure-assets.json';
import blockModelStates from './block-model-states.json';
import {createCommandRunner} from './commands.js';
import atlasMap from './textures/atlas-map.json';
import blockAtlasUrl from './textures/block_atlas.png';
import default3dModels from './textures/default3d-models.json';
import extraBlocks from './extra-blocks.json';
import vanillaBlockProperties from './block-properties.json';
import equipmentValues from './equipment-values.json';
const $systemContext = createSystemContext({ACTIVATOR_RAIL:()=>ACTIVATOR_RAIL,
AIR:()=>AIR,
ANCIENT_DEBRIS:()=>ANCIENT_DEBRIS,
ANVIL:()=>ANVIL,
ARROW:()=>ARROW,
AZALEA:()=>AZALEA,
BED:()=>BED,
BEDROCK:()=>BEDROCK,
BEE_NEST:()=>BEE_NEST,
BIG_DRIPLEAF:()=>BIG_DRIPLEAF,
BIRCH_LEAVES:()=>BIRCH_LEAVES,
BIRCH_LOG:()=>BIRCH_LOG,
BIRCH_PLANKS:()=>BIRCH_PLANKS,
BLOCKS:()=>BLOCKS,
BLOCK_TEXTURES:()=>BLOCK_TEXTURES,
BOAT:()=>BOAT,
BONE_BLOCK:()=>BONE_BLOCK,
BREWING_STAND:()=>BREWING_STAND,
BUCKET:()=>BUCKET,
CACTUS:()=>CACTUS,
CALIBRATED_SCULK_SENSOR:()=>CALIBRATED_SCULK_SENSOR,
CHEST:()=>CHEST,
CHISELED_BOOKSHELF:()=>CHISELED_BOOKSHELF,
COMPARATOR:()=>COMPARATOR,
COPPER_BULB:()=>COPPER_BULB,
COPPER_ORE:()=>COPPER_ORE,
CRAFTER:()=>CRAFTER,
CRIMSON_FUNGUS:()=>CRIMSON_FUNGUS,
CRIMSON_ROOTS:()=>CRIMSON_ROOTS,
CRIMSON_STEM:()=>CRIMSON_STEM,
CROP_0:()=>CROP_0,
CROP_1:()=>CROP_1,
CROP_2:()=>CROP_2,
DAYLIGHT_DETECTOR:()=>DAYLIGHT_DETECTOR,
DEEPSLATE:()=>DEEPSLATE,
DEEPSLATE_IRON:()=>DEEPSLATE_IRON,
DETECTOR_RAIL:()=>DETECTOR_RAIL,
DIRT:()=>DIRT,
DISPENSER:()=>DISPENSER,
DOOR:()=>DOOR,
DOOR_TOP:()=>DOOR_TOP,
DROPPER:()=>DROPPER,
ENCHANTING_TABLE:()=>ENCHANTING_TABLE,
END_FRAME:()=>END_FRAME,
END_PORTAL:()=>END_PORTAL,
END_STONE:()=>END_STONE,
FARMLAND:()=>FARMLAND,
FIRE:()=>FIRE,
FISHING_ROD:()=>FISHING_ROD,
FLOWERING_AZALEA:()=>FLOWERING_AZALEA,
FURNACE:()=>FURNACE,
GLASS:()=>GLASS,
GLASS_BOTTLE:()=>GLASS_BOTTLE,
GLOWSTONE:()=>GLOWSTONE,
GLOW_BERRIES:()=>GLOW_BERRIES,
GRASS:()=>GRASS,
GRAVEL:()=>GRAVEL,
HANGING_ROOTS:()=>HANGING_ROOTS,
HEAVY_WEIGHTED_PLATE:()=>HEAVY_WEIGHTED_PLATE,
HEIGHT:()=>HEIGHT,
HOPPER:()=>HOPPER,
IRON_TRAPDOOR:()=>IRON_TRAPDOOR,
ITEMS:()=>ITEMS,
JUKEBOX:()=>JUKEBOX,
LADDER:()=>LADDER,
LAVA:()=>LAVA,
LAVA_BUCKET:()=>LAVA_BUCKET,
LEATHER_BOOTS:()=>LEATHER_BOOTS,
LEAVES:()=>LEAVES,
LECTERN:()=>LECTERN,
LEVER:()=>LEVER,
LIGHTNING_ROD:()=>LIGHTNING_ROD,
LIGHT_WEIGHTED_PLATE:()=>LIGHT_WEIGHTED_PLATE,
MAX_Y:()=>MAX_Y,
MEADOW_FLOWER:()=>MEADOW_FLOWER,
MINECART:()=>MINECART,
MIN_Y:()=>MIN_Y,
MOSSY_BRICKS:()=>MOSSY_BRICKS,
MOSS_CARPET:()=>MOSS_CARPET,
NETHERRACK:()=>NETHERRACK,
NETHER_BRICKS:()=>NETHER_BRICKS,
NETHER_FOG:()=>NETHER_FOG,
NETHER_PORTAL:()=>NETHER_PORTAL,
NETHER_WART_CROP:()=>NETHER_WART_CROP,
NOTE_BLOCK:()=>NOTE_BLOCK,
OAK_TRAPDOOR:()=>OAK_TRAPDOOR,
OBSERVER:()=>OBSERVER,
OBSIDIAN:()=>OBSIDIAN,
PISTON:()=>PISTON,
PISTON_HEAD:()=>PISTON_HEAD,
PLANKS:()=>PLANKS,
POINTED_DRIPSTONE_DOWN:()=>POINTED_DRIPSTONE_DOWN,
POINTED_DRIPSTONE_UP:()=>POINTED_DRIPSTONE_UP,
POLISHED_BASALT:()=>POLISHED_BASALT,
POWDER_SNOW:()=>POWDER_SNOW,
POWERED_RAIL:()=>POWERED_RAIL,
RAIL:()=>RAIL,
RAIL_TYPES:()=>RAIL_TYPES,
REDSTONE_BLOCK:()=>REDSTONE_BLOCK,
REDSTONE_COMPONENTS:()=>REDSTONE_COMPONENTS,
REDSTONE_LAMP:()=>REDSTONE_LAMP,
REDSTONE_TORCH:()=>REDSTONE_TORCH,
REDSTONE_WIRE:()=>REDSTONE_WIRE,
RED_SAND:()=>RED_SAND,
REPEATER:()=>REPEATER,
SAND:()=>SAND,
SANDSTONE:()=>SANDSTONE,
SAPLING:()=>SAPLING,
SAVE_KEY:()=>SAVE_KEY,
SCULK_SENSOR:()=>SCULK_SENSOR,
SEA:()=>SEA,
SHAPED_BLOCKS:()=>SHAPED_BLOCKS,
SHIELD:()=>SHIELD,
SHROOMLIGHT:()=>SHROOMLIGHT,
SHULKER_BOX:()=>SHULKER_BOX,
SIZE:()=>SIZE,
SMALL_DRIPLEAF:()=>SMALL_DRIPLEAF,
SMITHING_TABLE:()=>SMITHING_TABLE,
SNOW:()=>SNOW,
SOUL_SAND:()=>SOUL_SAND,
SOUL_SOIL:()=>SOUL_SOIL,
SPAWNER:()=>SPAWNER,
SPORE_BLOSSOM:()=>SPORE_BLOSSOM,
SPRUCE_LEAVES:()=>SPRUCE_LEAVES,
SPRUCE_LOG:()=>SPRUCE_LOG,
SPRUCE_PLANKS:()=>SPRUCE_PLANKS,
STICKY_PISTON:()=>STICKY_PISTON,
STONE:()=>STONE,
STONECUTTER:()=>STONECUTTER,
STONE_BRICKS:()=>STONE_BRICKS,
STONE_BUTTON:()=>STONE_BUTTON,
STONE_PRESSURE_PLATE:()=>STONE_PRESSURE_PLATE,
TABLE:()=>TABLE,
TARGET:()=>TARGET,
THREE:()=>THREE,
TNT:()=>TNT,
TORCH:()=>TORCH,
TRAPPED_CHEST:()=>TRAPPED_CHEST,
TRIPWIRE:()=>TRIPWIRE,
TRIPWIRE_HOOK:()=>TRIPWIRE_HOOK,
TWISTING_VINES:()=>TWISTING_VINES,
WARPED_FUNGUS:()=>WARPED_FUNGUS,
WARPED_ROOTS:()=>WARPED_ROOTS,
WARPED_STEM:()=>WARPED_STEM,
WATER:()=>WATER,
WATER_BUCKET:()=>WATER_BUCKET,
WEEPING_VINES:()=>WEEPING_VINES,
WHEAT_CROP:()=>WHEAT_CROP,
WOOD:()=>WOOD,
WOODEN_BUTTON:()=>WOODEN_BUTTON,
WOODEN_PRESSURE_PLATE:()=>WOODEN_PRESSURE_PLATE,
activateRedstoneDevice:()=>activateRedstoneDevice,
activateVehicleDimension:()=>activateVehicleDimension,
activeVehicleDimension:()=>activeVehicleDimension,
ambient:()=>ambient,
appendModelBox:()=>appendModelBox,
applyAtmosphere:()=>applyAtmosphere,
assistWaterExit:()=>assistWaterExit,
refreshEmissionChanges:()=>refreshEmissionChanges,updateLightingAt:()=>updateLightingAt,applyGridLighting:()=>applyGridLighting,atlasMap:()=>atlasMap,
atlasUVCache:()=>atlasUVCache,
backgroundEntityTime:()=>backgroundEntityTime,
bedState:()=>bedState,
biome:()=>biome,
blockCollisionCache:()=>blockCollisionCache,
blockModelStates:()=>blockModelStates,
blockParts:()=>blockParts,
blockSoundMaterial:()=>blockSoundMaterial,
blockTexture:()=>blockTexture,
blockRegistry:()=>blockRegistry,
blocking:()=>blocking,
boardVehicleAtCrosshair:()=>boardVehicleAtCrosshair,
buildChunk:()=>buildChunk,
buildChunkTask:()=>buildChunkTask,
buttonUntil:()=>buttonUntil,
cacheSample:()=>cacheSample,
cachedNetherPortalSite:()=>cachedNetherPortalSite,
camera:()=>camera,
canFlowSideways:()=>canFlowSideways,
canvas:()=>canvas,
cardinalName:()=>cardinalName,
cartSoundTimer:()=>cartSoundTimer,
caveBiome:()=>caveBiome,
chatLog:()=>chatLog,
chatUntil:()=>chatUntil,
chestLoot:()=>chestLoot,
chestRandom:()=>chestRandom,
chunkLOD:()=>chunkLOD,
chunks:()=>chunks,
climate:()=>climate,
climateCache:()=>climateCache,
cloudLayer:()=>cloudLayer,
colorFor:()=>colorFor,
commandBar:()=>commandBar,
commandFeedback:()=>commandFeedback,
commandInput:()=>commandInput,
commandMode:()=>commandMode,
commandOpen:()=>commandOpen,
computeLightingTask:()=>computeLightingTask,
containerSlotsAt:()=>containerSlotsAt,
crossExperimentalPortal:()=>crossExperimentalPortal,
crossedPortal:()=>crossedPortal,
currentEdits:()=>currentEdits,
currentFluidStates:()=>currentFluidStates,
curvedRailParts:()=>curvedRailParts,
default3dIds:()=>default3dIds,
default3dParts:()=>default3dParts,
destinationPortalCenter:()=>destinationPortalCenter,
dimension:()=>dimension,
dimensionVoxelCaches:()=>dimensionVoxelCaches,
dirtySave:()=>dirtySave,
discAudio:()=>discAudio,
dismountVehicle:()=>dismountVehicle,
disposePortalWorld:()=>disposePortalWorld,
disposePreviewChunks:()=>disposePreviewChunks,
doorInfo:()=>doorInfo,
drawWeather:()=>drawWeather,
editKey:()=>editKey,
editLightingQueue:()=>editLightingQueue,
effectsPrepared:()=>effectsPrepared,
effectsReady:()=>effectsReady,
endExitArrival:()=>endExitArrival,
endEyeKey:()=>endEyeKey,
endPillars:()=>endPillars,
endPortalRingAt:()=>endPortalRingAt,
ensureChunk:()=>ensureChunk,
entityTerrainTasks:()=>entityTerrainTasks,
entityWorldChunks:()=>entityWorldChunks,
entityWorldContext:()=>entityWorldContext,
extraId:()=>extraId,
faceUV:()=>faceUV,
faces:()=>faces,
fallingBlockMesh:()=>fallingBlockMesh,
fallingBlocks:()=>fallingBlocks,
fireCells:()=>fireCells,
fireTimer:()=>fireTimer,
firstMeshQueue:()=>firstMeshQueue,
flowDropDistance:()=>flowDropDistance,
flowFalling:()=>flowFalling,
flowHead:()=>flowHead,
flowLevels:()=>flowLevels,
flowPassable:()=>flowPassable,
flowQueue:()=>flowQueue,
flowQueued:()=>flowQueued,
flowSources:()=>flowSources,
flowStep:()=>flowStep,
flowTimer:()=>flowTimer,
fluidDirections:()=>fluidDirections,
flushChunkMesh:()=>flushChunkMesh,
flushEditLighting:()=>flushEditLighting,
foregroundEntityDistance:()=>foregroundEntityDistance,
foregroundRaycaster:()=>foregroundRaycaster,
fpsTime:()=>fpsTime,
frames:()=>frames,
gateOutputs:()=>gateOutputs,
gatePending:()=>gatePending,
generate:()=>generate,
generateChunk:()=>generateChunk,
getBlock:()=>getBlock,
getClientLightLevel:()=>getClientLightLevel,getBlockLightLevel:()=>getBlockLightLevel,getLightLevel:()=>getLightLevel,
gravityHead:()=>gravityHead,
gravityQueue:()=>gravityQueue,
gravityQueued:()=>gravityQueued,
gravityTimer:()=>gravityTimer,
growPlants:()=>growPlants,
growthCells:()=>growthCells,
growthTimer:()=>growthTimer,
hasEndEye:()=>hasEndEye,
hash:()=>hash,
hash3:()=>hash3,
hitMinecartAtCrosshair:()=>hitMinecartAtCrosshair,
hitVoxel:()=>hitVoxel,
hopperAt:()=>hopperAt,
hudAt:()=>hudAt,
idx:()=>idx,
inDimension:()=>inDimension,
indexPortalCells:()=>indexPortalCells,
insertStack:()=>insertStack,
instantModelTypes:()=>instantModelTypes,
gameplayRepairs:()=>gameplayRepairs,
natureSystem:()=>natureSystem,
intersects:()=>intersects,
intersectsBody:()=>intersectsBody,
ensureSafeSpawn:()=>ensureSafeSpawn,
firstPerson:()=>firstPerson,
resourcePacks:()=>resourcePacks,
chestAnimation:()=>chestAnimation,
respawnPlayer:()=>respawnPlayer,
isDoor:()=>isDoor,
isSource:()=>isSource,
isStrongholdFrame:()=>isStrongholdFrame,
isTree:()=>isTree,
isVillageChest:()=>isVillageChest,
key:()=>key,
keys:()=>keys,
lastSensorStep:()=>lastSensorStep,
lastTime:()=>lastTime,
lightDay:()=>lightDay,
lightDirections:()=>lightDirections,
lightDisplay:()=>lightDisplay,
lightRebuildQueue:()=>lightRebuildQueue,
lightTimer:()=>lightTimer,
lightingBand:()=>lightingBand,
lightningFlash:()=>lightningFlash,
liquidLevel:()=>liquidLevel,
loadVehicleSave:()=>loadVehicleSave,
loading:()=>loading,
lodCheckAt:()=>lodCheckAt,
lookHit:()=>lookHit,
makePortalPreviewScene:()=>makePortalPreviewScene,
mapPortalPoint:()=>mapPortalPoint,
mapPortalYaw:()=>mapPortalYaw,
materials:()=>materials,
meshColor:()=>meshColor,
meshRebuildQueue:()=>meshRebuildQueue,
mining:()=>mining,
miningFill:()=>miningFill,
miningTrack:()=>miningTrack,
mirrorModelZ:()=>mirrorModelZ,
mobile:()=>mobile,
modelBlockTypes:()=>modelBlockTypes,
modelUV:()=>modelUV,
modelVertexData:()=>modelVertexData,
mountVehicle:()=>mountVehicle,
move:()=>move,
moveAxis:()=>moveAxis,
moveMobsThroughPortals:()=>moveMobsThroughPortals,
multiplayer:()=>multiplayer,
nearPortal:()=>nearPortal,
nearbyWorldProgress:()=>nearbyWorldProgress,
netherBase:()=>netherBase,
netherBiome:()=>netherBiome,
netherCeiling:()=>netherCeiling,
netherPortalSite:()=>netherPortalSite,
noise:()=>noise,
noise3:()=>noise3,
noiseLattice:()=>noiseLattice,
notifyObservers:()=>notifyObservers,
observerUntil:()=>observerUntil,
occludes:()=>occludes,
occupied:()=>occupied,
oreBands:()=>oreBands,
outline:()=>outline,
outlineCache:()=>outlineCache,
outlineGeometry:()=>outlineGeometry,
outputItem:()=>outputItem,
overworldSky:()=>overworldSky,
parkSourceWorldForPortal:()=>parkSourceWorldForPortal,
parkVehicleDimension:()=>parkVehicleDimension,
parkedVehicles:()=>parkedVehicles,
partUV:()=>partUV,
patchModelBuffers:()=>patchModelBuffers,
pendingEditLighting:()=>pendingEditLighting,
pendingGeneration:()=>pendingGeneration,
pendingMeshing:()=>pendingMeshing,
pistonBreakable:()=>pistonBreakable,
pistonDirection:()=>pistonDirection,
pistonMoveable:()=>pistonMoveable,
pistonPowered:()=>pistonPowered,
placeDoor:()=>placeDoor,
placeRedstoneComponent:()=>placeRedstoneComponent,
playGameSound:()=>playGameSound,
playNote:()=>playNote,
playSound:()=>playSound,
player:()=>player,
playing:()=>playing,
portalArrival:()=>portalArrival,
portalCells:()=>portalCells,
portalCooldown:()=>portalCooldown,
portalDestination:()=>portalDestination,
portalDestinationAxis:()=>portalDestinationAxis,
portalExitLock:()=>portalExitLock,
portalInfoAt:()=>portalInfoAt,
portalPreviewChunks:()=>portalPreviewChunks,
portalPreviewCursor:()=>portalPreviewCursor,
portalPreviewMode:()=>portalPreviewMode,
portalPreviewScene:()=>portalPreviewScene,
portalPreviewState:()=>portalPreviewState,
portalPreviewWorlds:()=>portalPreviewWorlds,
portalScanAt:()=>portalScanAt,
portalUsesPreview:()=>portalUsesPreview,
portalWindow:()=>portalWindow,
preparePortalPreview:()=>preparePortalPreview,
prepareVehicleDimension:()=>prepareVehicleDimension,
processFire:()=>processFire,
processFlow:()=>processFlow,
processGravity:()=>processGravity,
processRedstone:()=>processRedstone,
punchMinecart:()=>punchMinecart,
pushMinecartsByPlayer:()=>pushMinecartsByPlayer,
quadNormals:()=>quadNormals,
queue:()=>queue,
queueAround:()=>queueAround,
queueFlow:()=>queueFlow,
queueGravity:()=>queueGravity,
queued:()=>queued,
railShape:()=>railShape,
railSlopePoint:()=>railSlopePoint,
rainCount:()=>rainCount,
rainDrops:()=>rainDrops,
rainGeometry:()=>rainGeometry,
rainLines:()=>rainLines,
rainPositions:()=>rainPositions,
redstoneByDimension:()=>redstoneByDimension,
redstoneCells:()=>redstoneCells,
redstoneData:()=>redstoneData,
redstoneDoorPowered:()=>redstoneDoorPowered,
redstoneEdge:()=>redstoneEdge,
redstoneLevels:()=>redstoneLevels,
redstoneTimer:()=>redstoneTimer,
refreshEditedLighting:()=>refreshEditedLighting,
refreshTorchLights:()=>refreshTorchLights,
renderVehicleDimension:()=>renderVehicleDimension,
renderer:()=>renderer,
resetPortalPreview:()=>resetPortalPreview,
resettingWorld:()=>resettingWorld,
resuming:()=>resuming,
retainEntityTerrain:()=>retainEntityTerrain,
rotateModelPoint:()=>rotateModelPoint,
runEntityWorld:()=>runEntityWorld,
save:()=>save,
saveGame:()=>saveGame,
scene:()=>scene,
scheduleBlockMesh:()=>scheduleBlockMesh,
scheduleChunkMesh:()=>scheduleChunkMesh,
scheduleEditLighting:()=>scheduleEditLighting,
seed:()=>seed,
selected:()=>selected,
sensorCells:()=>sensorCells,
sensorFrequency:()=>sensorFrequency,
sensorUntil:()=>sensorUntil,
serializeVehicleEntities:()=>serializeVehicleEntities,
setBackgroundBlock:()=>setBackgroundBlock,
setBlock:()=>setBlock,
setBlockBatch:()=>setBlockBatch,
setChestLootTable:()=>setChestLootTable,
setLocal:()=>setLocal,
setSnowLayersMetadata:()=>setSnowLayersMetadata,
setText:()=>setText,
showToast:()=>showToast,
simulateOtherDimensions:()=>simulateOtherDimensions,
simulateVehicleDimension:()=>simulateVehicleDimension,
skyForDimension:()=>skyForDimension,
skyPalette:()=>skyPalette,
smooth:()=>smooth,
snowLayerCount:()=>snowLayerCount,
solid:()=>solid,
spawnPoint:()=>spawnPoint,
spreadCache:()=>spreadCache,
spreadMask:()=>spreadMask,
stampStructure:()=>stampStructure,
startMinecartFall:()=>startMinecartFall,
stepEntityTerrain:()=>stepEntityTerrain,
stepPortalPreview:()=>stepPortalPreview,
stepSoundTimer:()=>stepSoundTimer,
stream:()=>stream,
streamKey:()=>streamKey,
streamWanted:()=>streamWanted,
strongholdLocation:()=>strongholdLocation,
strongholdY:()=>strongholdY,
structureAssets:()=>structureAssets,
structureParts:()=>structureParts,
sun:()=>sun,
survival:()=>survival,
suspendedMeshing:()=>suspendedMeshing,
targetUntil:()=>targetUntil,
teleportTo:()=>teleportTo,
terrain:()=>terrain,
terrainCache:()=>terrainCache,
tick:()=>tick,
toastTimer:()=>toastTimer,
torchBurnedUntil:()=>torchBurnedUntil,
torchLights:()=>torchLights,
torchModelParts:()=>torchModelParts,
torchPending:()=>torchPending,
torchStates:()=>torchStates,
torchSwitches:()=>torchSwitches,
transferOne:()=>transferOne,
travelThroughEndPortal:()=>travelThroughEndPortal,
tripwirePower:()=>tripwirePower,
tripwireUntil:()=>tripwireUntil,
ui:()=>ui,
unlockSounds:()=>unlockSounds,
updateBlockModelImmediately:()=>updateBlockModelImmediately,
updateDoorModelImmediately:()=>updateDoorModelImmediately,
updateFallingBlocks:()=>updateFallingBlocks,
updateHoppers:()=>updateHoppers,
updateMinecartOffRail:()=>updateMinecartOffRail,
updateMinecarts:()=>updateMinecarts,
updatePiston:()=>updatePiston,
updatePortalExitLock:()=>updatePortalExitLock,
updateSnowAround:()=>updateSnowAround,
updateWeather:()=>updateWeather,
updateWorldLoading:()=>updateWorldLoading,
urgentFlowHead:()=>urgentFlowHead,
urgentFlowQueue:()=>urgentFlowQueue,
urgentFlowQueued:()=>urgentFlowQueued,
urgentGravityQueue:()=>urgentGravityQueue,
urgentGravityQueued:()=>urgentGravityQueued,
urgentMeshQueue:()=>urgentMeshQueue,
usesPortalWindow:()=>usesPortalWindow,
vehicle:()=>vehicle,
vehicleDimensions:()=>vehicleDimensions,
vehicleRaycaster:()=>vehicleRaycaster,
vehicleRecord:()=>vehicleRecord,
villageAt:()=>villageAt,
villageSite:()=>villageSite,
villageSites:()=>villageSites,
villageTemplates:()=>villageTemplates,
visiblePortalViews:()=>visiblePortalViews,
visiblePortals:()=>visiblePortals,
waitForNearbyWorld:()=>waitForNearbyWorld,
waterCurrent:()=>waterCurrent,
weatherCanvas:()=>weatherCanvas,
weatherCtx:()=>weatherCtx,
wireConnections:()=>wireConnections,
wireParts:()=>wireParts,
worldReadyWaiters:()=>worldReadyWaiters},{dimension:value=>dimension=value,
lightningFlash:value=>lightningFlash=value,
dirtySave:value=>dirtySave=value,
tick:value=>tick=value,
cachedNetherPortalSite:value=>cachedNetherPortalSite=value,
entityWorldContext:value=>entityWorldContext=value,
portalPreviewMode:value=>portalPreviewMode=value,
portalPreviewChunks:value=>portalPreviewChunks=value,
lightDay:value=>lightDay=value,
flowStep:value=>flowStep=value,
urgentFlowHead:value=>urgentFlowHead=value,
flowHead:value=>flowHead=value,
gravityHead:value=>gravityHead=value,
portalPreviewScene:value=>portalPreviewScene=value,
portalPreviewState:value=>portalPreviewState=value,
pendingEditLighting:value=>pendingEditLighting=value,
pendingMeshing:value=>pendingMeshing=value,
suspendedMeshing:value=>suspendedMeshing=value,
streamKey:value=>streamKey=value,
streamWanted:value=>streamWanted=value,
pendingGeneration:value=>pendingGeneration=value,
lodCheckAt:value=>lodCheckAt=value,
lastSensorStep:value=>lastSensorStep=value,
vehicle:value=>vehicle=value,
backgroundEntityTime:value=>backgroundEntityTime=value,
nearPortal:value=>nearPortal=value,
visiblePortalViews:value=>visiblePortalViews=value,
portalPreviewCursor:value=>portalPreviewCursor=value,
portalExitLock:value=>portalExitLock=value,
playing:value=>playing=value,
lastTime:value=>lastTime=value,
portalCooldown:value=>portalCooldown=value,
portalScanAt:value=>portalScanAt=value,
commandOpen:value=>commandOpen=value,
activeVehicleDimension:value=>activeVehicleDimension=value,
toastTimer:value=>toastTimer=value,
discAudio:value=>discAudio=value,
selected:value=>selected=value,
chatUntil:value=>chatUntil=value,
resuming:value=>resuming=value,
blocking:value=>blocking=value,
cartSoundTimer:value=>cartSoundTimer=value,
stepSoundTimer:value=>stepSoundTimer=value,
lightingBand:value=>lightingBand=value,
flowTimer:value=>flowTimer=value,
gravityTimer:value=>gravityTimer=value,
fireTimer:value=>fireTimer=value,
redstoneTimer:value=>redstoneTimer=value,
growthTimer:value=>growthTimer=value,
lightTimer:value=>lightTimer=value,
lookHit:value=>lookHit=value,
hudAt:value=>hudAt=value,
lightDisplay:value=>lightDisplay=value,
fpsTime:value=>fpsTime=value,
frames:value=>frames=value});
const {occludes,blockTexture,doorInfo,isDoor} = createBlockContentSystem($systemContext);
const {drawWeather,updateWeather,overworldSky,skyForDimension,applyAtmosphere} = createWeatherSystem($systemContext);
const {hash,hash3,smooth,noise,noise3,cacheSample,climate,biome,caveBiome,terrain,netherBiome,netherCeiling,netherPortalSite,endPillars,netherBase,isTree,spawnPoint,strongholdLocation,strongholdY,villageSite,villageAt,isVillageChest,isStrongholdFrame,villageTemplates,generateChunk,generate,stampStructure,setLocal,setSnowLayersMetadata,setChestLootTable} = createTerrainSystem($systemContext);
const {key,editKey,currentEdits,currentFluidStates,idx,skyExposed,getBlock,snowLayerCount,setSnowLayers,updateSnowAround,setBlock,setBlockBatch} = createWorldAccessSystem($systemContext);
const {getClientLightLevel,getBlockLightLevel,emittedLight,refreshEmissionChanges,updateLightingAt,applyGridLighting,computeLightingTask,computeLighting,refreshTorchLights,getLightLevel,solid,colorFor} = createLightingSystem($systemContext);
const {liquidLevel,fluidLevel,isSource,queueFlow,queueAround,flowPassable,canFlowSideways,flowDropDistance,spreadMask,waterCurrent,processFlow} = createFluidsSystem($systemContext);
const {queueGravity,fallingBlockMesh,processGravity,updateFallingBlocks,processFire,stopVineGrowth,growPlants} = createBlockPhysicsSystem($systemContext);
const {faceUV,partUV,rotateModelPoint,railSlopePoint,modelUV,curvedRailParts,wireConnections,wireParts,pistonDirection,mirrorModelZ,torchModelParts,cardinalName,blockParts,quadNormals,appendModelBox,modelVertexData} = createBlockModelsSystem($systemContext);
const {chunkLOD,patchModelBuffers,updateBlockModelImmediately,updateDoorModelImmediately,buildChunkTask,buildChunk,ensureChunk,scheduleChunkMesh,scheduleEditLighting,refreshEditedLighting,flushEditLighting,scheduleBlockMesh,flushChunkMesh,stream} = createChunksSystem($systemContext);
const {placeDirectional,placeTorch,placeDoorVariant,breakDoorPartner,bedState,placeBed,breakBedPartner,toggleDoor,sleepAtBed,respawnPlayer,clearChestLootReference,ensureChestLoot} = createBlockInteractionsSystem($systemContext);
const {notifyObservers,placeRedstoneComponent,placeDoor,useRedstoneControl,toggleLever,placePiston,railShape,pistonMoveable,pistonBreakable,updatePiston,containerSlotsAt,insertStack,transferOne,outputItem,activateRedstoneDevice,updateHoppers,playNote,closeRedstoneContainer,hitTarget,tripwirePower,processRedstone} = createRedstoneSystem($systemContext);
const {makePortalPreviewScene,entityWorldChunks,retainEntityTerrain,runEntityWorld,setBackgroundBlock,stepEntityTerrain,simulateVehicleDimension,simulateOtherDimensions,moveMobsThroughPortals,inDimension} = createDimensionsSystem($systemContext);
const {endEyeKey,hasEndEye,endPortalRingAt,insertEndEye,activateNetherPortal,portalInfoAt,visiblePortals,indexPortalCells,nearestPortal,portalDestination,portalUsesPreview,usesPortalWindow,portalDestinationAxis,destinationPortalCenter,disposePortalWorld,disposePreviewChunks,resetPortalPreview,preparePortalPreview,stepPortalPreview,updatePortalExitLock,parkSourceWorldForPortal,crossedPortal,endExitArrival,travelThroughEndPortal,crossExperimentalPortal,portalArrival,teleportTo} = createPortalsSystem($systemContext);
const {foregroundEntityDistance,hitVoxel,outlineGeometry,occupied,intersectsBody,intersects,moveAxis,assistWaterExit,move} = createPlayerPhysicsSystem($systemContext);
const {startMinecartFall,updateMinecartOffRail,updateMinecarts,vehicleRecord,parkVehicleDimension,loadVehicleSave,activateVehicleDimension,prepareVehicleDimension,serializeVehicleEntities,renderVehicleDimension,mountVehicle,dismountVehicle,boardVehicleAtCrosshair,punchMinecart,hitMinecartAtCrosshair,pushMinecartsByPlayer} = createVehiclesSystem($systemContext);
const {showToast,awardAdvancement,blockSoundMaterial,playSound,playDisc,updateHotbar,saveGame,dragonDefeated,addChatMessage,openCommand,closeCommand,nearbyWorldProgress,updateWorldLoading,waitForNearbyWorld,pause,resume,playerAction,setText,frame} = createGameUiSystem($systemContext);

const SIZE = 16, MIN_Y = -64, MAX_Y = 320, HEIGHT = MAX_Y-MIN_Y, SEA = 63, SAVE_KEY = sessionStorage.getItem('vf-mp-room')?'voxel-frontier-multiplayer-guest':'voxel-frontier-save-v1';
const {AIR,GRASS,DIRT,STONE,SAND,WOOD,LEAVES,WATER,COAL,IRON,BRICK,GLASS,TABLE,TORCH,PLANKS,FURNACE,TNT,STICK,PICKAXE,SWORD,RAW_MEAT,COOKED_MEAT,WOOL,WHEAT,BREAD,GUNPOWDER,DEEPSLATE,COPPER_ORE,GOLD_ORE,DIAMOND_ORE,REDSTONE_ORE,LAPIS_ORE,SNOW,CACTUS,GRAVEL,BEDROCK,SPRUCE_LOG,SPRUCE_LEAVES,OBSIDIAN,NETHERRACK,LAVA,NETHER_BRICKS,GLOWSTONE,SOUL_SAND,END_STONE,PURPUR,CHEST,STONE_BRICKS,MOSSY_BRICKS,NETHER_PORTAL,END_PORTAL,END_FRAME,STONE_PICKAXE,IRON_PICKAXE,DIAMOND_PICKAXE,WOOD_AXE,STONE_AXE,IRON_AXE,WOOD_SHOVEL,STONE_SHOVEL,IRON_SHOVEL,IRON_SWORD,DIAMOND_SWORD,RAW_IRON,IRON_INGOT,DIAMOND,GOLD_INGOT,REDSTONE_DUST,LAPIS_LAZULI,COPPER_INGOT,APPLE,CARROT,POTATO,ENDER_PEARL,BLAZE_ROD,EYE_OF_ENDER,FLINT_STEEL,FLINT,BLAZE_POWDER,BIRCH_LOG,BIRCH_LEAVES,SPRUCE_PLANKS,BIRCH_PLANKS,RED_SAND,SANDSTONE,FARMLAND,WHEAT_CROP,DEEPSLATE_COAL,DEEPSLATE_IRON,BOW,ARROW,STRING,BONE,ROTTEN_FLESH,BUCKET,WATER_BUCKET,LEATHER,PAPER,BOOK,EMERALD,RAW_CHICKEN,COOKED_CHICKEN,FIRE,BED,DOOR,DOOR_TOP,LADDER,SAPLING,CROP_0,CROP_1,CROP_2,CRIMSON_STEM,WARPED_STEM,SHROOMLIGHT,CRIMSON_ROOTS,WARPED_ROOTS,TWISTING_VINES,WEEPING_VINES,SOUL_SOIL,BONE_BLOCK,CRIMSON_FUNGUS,WARPED_FUNGUS,POLISHED_BASALT,WHEAT_SEEDS,WOOD_HOE,LAVA_BUCKET,SHIELD,IRON_HELMET,IRON_CHESTPLATE,IRON_LEGGINGS,IRON_BOOTS,REDSTONE_WIRE,LEVER,REDSTONE_LAMP,PISTON,ENCHANTING_TABLE,ANVIL,BREWING_STAND,RAIL,POWERED_RAIL,SPAWNER,ANCIENT_DEBRIS,SHULKER_BOX,BOOKSHELF,NETHER_WART_CROP,SMITHING_TABLE,STICKY_PISTON,REDSTONE_TORCH,REPEATER,COMPARATOR,STONE_BUTTON,STONE_PRESSURE_PLATE,OBSERVER,DETECTOR_RAIL,PISTON_HEAD,SLIME_BALL,DISPENSER,DROPPER,HOPPER,DAYLIGHT_DETECTOR,TARGET,TRAPPED_CHEST,NOTE_BLOCK,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE,LIGHT_WEIGHTED_PLATE,HEAVY_WEIGHTED_PLATE,COPPER_BULB,TRIPWIRE_HOOK,TRIPWIRE,SCULK_SENSOR,CALIBRATED_SCULK_SENSOR,CRAFTER,OAK_TRAPDOOR,IRON_TRAPDOOR,HAY_BALE,AMETHYST_SHARD,LIGHTNING_ROD,LECTERN,CHISELED_BOOKSHELF,ACTIVATOR_RAIL,FISHING_ROD,COD,BOAT,MINECART,ELYTRA,FIREWORK,SHULKER_SHELL,NETHERITE_SCRAP,NETHERITE_INGOT,NETHERITE_PICKAXE,NETHERITE_SWORD,NETHERITE_AXE,NETHERITE_SHOVEL,GLASS_BOTTLE,WATER_BOTTLE,AWKWARD_POTION,HEALING_POTION,SPEED_POTION,STRENGTH_POTION,NETHER_WART,GHAST_TEAR,SPIDER_EYE,UPGRADE_TEMPLATE,SUGAR,GLISTERING_MELON,REGENERATION_POTION,POISON_POTION,SHEARS,GOLD_HELMET,RAW_GOLD,RAW_COPPER,FEATHER,CHARCOAL,BRICK_ITEM,COAL_ITEM,QUARTZ_ITEM,GOLD_NUGGET,POWDER_SNOW,POINTED_DRIPSTONE_UP,POINTED_DRIPSTONE_DOWN,AZALEA,FLOWERING_AZALEA,GLOW_BERRIES,SPORE_BLOSSOM,BIG_DRIPLEAF,SMALL_DRIPLEAF,HANGING_ROOTS,MOSS_CARPET,BEE_NEST,POWDER_SNOW_BUCKET,MUSIC_DISC_OTHERSIDE,LEATHER_BOOTS,MEADOW_FLOWER,STONECUTTER,CUT_COPPER,JUKEBOX,SNOWBALL,BLOCKS,SHAPED_BLOCKS,EXTRA_BASE,extraId,REDSTONE_BLOCK,RAIL_TYPES,REDSTONE_COMPONENTS,BLOCK_PROPERTIES,ITEMS,HOTBAR,BLOCK_TEXTURES,structureItemNames,contentIds} = createContentCatalog();
const blockRegistry=createBlockRegistry(BLOCKS,new Set([...SHAPED_BLOCKS,PISTON,STICKY_PISTON,SPAWNER,TRAPPED_CHEST,GLASS,LEAVES,SPRUCE_LEAVES,BIRCH_LEAVES]));

applyItemIcons(ITEMS,BLOCKS,blockTexture);
const faces=[
  {d:[1,0,0],shade:.81,v:[[1,0,0],[1,1,0],[1,1,1],[1,0,1]]},
  {d:[-1,0,0],shade:.72,v:[[0,0,1],[0,1,1],[0,1,0],[0,0,0]]},
  {d:[0,1,0],shade:1.08,v:[[0,1,1],[1,1,1],[1,1,0],[0,1,0]]},
  {d:[0,-1,0],shade:.58,v:[[0,0,0],[1,0,0],[1,0,1],[0,0,1]]},
  {d:[0,0,1],shade:.92,v:[[1,0,1],[1,1,1],[0,1,1],[0,0,1]]},
  {d:[0,0,-1],shade:.76,v:[[0,0,0],[0,1,0],[1,1,0],[1,0,0]]},
];
const canvas=document.getElementById('world');
const renderer=new THREE.WebGLRenderer({canvas,antialias:false,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,matchMedia('(pointer: coarse)').matches?1:1.5));
renderer.setSize(innerWidth,innerHeight);
renderer.outputColorSpace=THREE.SRGBColorSpace;
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x99c7dd);
scene.fog=new THREE.Fog(0x99c7dd,35,86);
const camera=new THREE.PerspectiveCamera(73,innerWidth/innerHeight,.05,100);
camera.rotation.order='YXZ';
const ambient=new THREE.HemisphereLight(0xe5f3ff,0x75634f,.9);scene.add(ambient);
const sun=new THREE.DirectionalLight(0xffedcb,1.0);sun.position.set(35,55,25);scene.add(sun);
const cloudLayer=new THREE.InstancedMesh(new THREE.PlaneGeometry(1,1),new THREE.MeshBasicMaterial({color:0xf1f3f1,transparent:true,opacity:.42,depthWrite:false,fog:false,side:THREE.DoubleSide}),28);
const cloudCell=new THREE.Object3D();for(let i=0;i<28;i++){cloudCell.position.set(((i*97)%17-8)*24,0,((i*71)%13-6)*28);cloudCell.rotation.x=-Math.PI/2;cloudCell.scale.set(22+(i%4)*7,9+(i%3)*4,1);cloudCell.updateMatrix();cloudLayer.setMatrixAt(i,cloudCell.matrix)}cloudLayer.instanceMatrix.needsUpdate=true;cloudLayer.frustumCulled=false;scene.add(cloudLayer);
const torchLights=Array.from({length:6},()=>{const light=new THREE.PointLight(0xffbc65,2.4,9,1.5);light.visible=false;scene.add(light);return light});let lightTimer=0;
const materials={
  endPortal:createEndPortalMaterial(THREE),
  solid:new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.FrontSide,alphaTest:.25}),
  water:new THREE.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.68,depthWrite:false,side:THREE.DoubleSide}),
  glass:new THREE.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.53,depthWrite:false,side:THREE.DoubleSide}),
  lava:new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.DoubleSide}),
};
for(const name of ['solid','water','glass','lava'])installGridLightMaterial(materials[name],()=>lightDay);
new THREE.TextureLoader().load(blockAtlasUrl,texture=>{texture.magFilter=THREE.NearestFilter;texture.minFilter=THREE.NearestFilter;texture.generateMipmaps=false;texture.colorSpace=THREE.SRGBColorSpace;for(const m of Object.values(materials)){if(m.isShaderMaterial)continue;m.map=texture;m.needsUpdate=true}canvas.dataset.blockTextures='loaded'},undefined,()=>{canvas.dataset.blockTextures='failed';showToast('TEXTURE ATLAS COULD NOT LOAD')});
const chunks=new Map(),queue=[],queued=new Set(),firstMeshQueue=new Map(),meshRebuildQueue=new Map(),lightRebuildQueue=[],redstoneLevels=new Map(),redstoneByDimension=new Map(),redstoneCells=new Set(),pistonPowered=new Set(),redstoneDoorPowered=new Set();let pendingGeneration=null,pendingMeshing=null,lightingBand=15,redstoneTimer=0;

let portalPreviewScene=null,portalPreviewChunks=new Map();
const portalWindow=createPortalWindow(THREE,renderer,scene,camera);
let portalPreviewMode=false,portalPreviewState=null,portalScanAt=0,nearPortal=null;
const portalPreviewWorlds=new Map();
let portalPreviewCursor=0;
const dimensionVoxelCaches=new Map(),entityTerrainTasks=new Map();let entityWorldContext=null,backgroundEntityTime=0;

const portalCells=new Set();
let visiblePortalViews=[];
const buttonUntil=new Map(),observerUntil=new Map(),gateOutputs=new Map(),gatePending=new Map(),torchStates=new Map(),torchPending=new Map(),torchSwitches=new Map(),torchBurnedUntil=new Map();
const redstoneEdge=new Map(),sensorUntil=new Map(),sensorFrequency=new Map(),targetUntil=new Map(),tripwireUntil=new Map(),hopperAt=new Map();
const sensorCells=new Set();
let lastSensorStep=null;
const flowLevels=new Map(),flowSources=new Set(),flowFalling=new Set(),flowQueue=[],urgentFlowQueue=[],flowQueued=new Set(),urgentFlowQueued=new Set(),spreadCache=new Map();let flowTimer=0,flowHead=0,urgentFlowHead=0;
const growthCells=new Set();let growthTimer=0,blocking=false;
const gravityQueue=[],urgentGravityQueue=[],gravityQueued=new Set(),urgentGravityQueued=new Set();let gravityTimer=0,gravityHead=0;
const fallingBlocks=[];
const fireCells=new Map();let fireTimer=0;
let save;
try{save=window.vfLoadedWorld||JSON.parse(sessionStorage.getItem('vf-mp-room')?sessionStorage.getItem('vf-mp-world'):localStorage.getItem(SAVE_KEY))}catch{save=null}
if(!save||typeof save.seed!=='number'||!save.edits)save={seed:Math.floor(Math.random()*1e9),edits:{},player:null};
const legacyWorld=!!save.player&&!save.generatorVersion,upgradingWorld=!!save.player&&(save.generatorVersion||0)<4;
if(upgradingWorld)try{const original=localStorage.getItem(SAVE_KEY);if(original&&!localStorage.getItem(SAVE_KEY+'-pre-caves-cliffs'))localStorage.setItem(SAVE_KEY+'-pre-caves-cliffs',original)}catch{}
save.generatorVersion=6;
save.levers??={};save.pistonDirections??={};save.redstoneTorchSupports??={};save.railDirections??={};save.redstoneFacing??={};save.redstoneDelay??={};save.redstoneModes??={};save.redstoneExtra??={};save.growthStopped??={};save.snowLayers??={};save.fluidStates??={overworld:{},nether:{},end:{}};
save.redstoneExtra??={overworld:{},nether:{},end:{}};save.crafterDisabled??={};const redstoneData=()=>save.redstoneExtra[dimension]??(save.redstoneExtra[dimension]={});
if(save.testWorld){save.chests??={};save.redstoneExtra.overworld??={};save.levers??={};save.openDoors??={};save.entityStates??={};const items=Object.keys(ITEMS).map(Number).filter(id=>Number.isInteger(id)&&ITEMS[id]?.name).sort((a,b)=>a-b);for(let page=0;page<Math.ceil(items.length/27);page++){const x=-24+page*2,k=`overworld:${x},73,-32`;if(save.testItemGalleryVersion!==2||!Object.hasOwn(save.chests,k))save.chests[k]=items.slice(page*27,(page+1)*27).map(id=>({id,n:1}))}save.testItemGalleryVersion=2;const facings=[[0,-1],[1,0],[0,1],[-1,0]],supports=[[0,-1,0],[1,0,0],[-1,0,0],[0,1,0]];for(let n=0;n<4;n++){const x=16+n*2,doorKey=`${x},73,31`,lx=28+n*2,leverKey=`${lx},73,27`;save.redstoneExtra.overworld[doorKey]??={facing:facings[n],hinge:n>1?'right':'left'};save.redstoneExtra.overworld[leverKey]??={support:supports[n],facing:facings[n]};if(n%2)save.openDoors[doorKey]??=true;save.levers[leverKey]??=n===0||n===2}if(save.testMobGalleryVersion!==2){const previous=save.entityStates.overworld||{},mobs=(previous.mobs||[]).filter(m=>!m.state?.testDisplay&&!(m.x>=43&&m.x<=49&&m.z>=-18&&m.z<=-10));save.entityStates.overworld={...previous,mobs:[...mobs,...MOB_TYPES.map((type,index)=>({type,x:44+(index%4)*7,y:type==='dragon'?82:73,z:-20+Math.floor(index/4)*8,state:{noAI:true,testDisplay:true,aggro:false,dir:0}}))],drops:previous.drops||[],xp:previous.xp||[]};save.testMobGalleryVersion=2}}
save.endEyes??={};
save.advancements??={};save.jukeboxDiscs??={};
save.weather??={kind:'clear',remaining:420};
save.gamerules??={doDaylightCycle:true,doWeatherCycle:true};
save.inventory??={};save.hotbar??=HOTBAR.slice();save.mode??='survival';save.dayTime??=.28;save.dimension??='overworld';save.dimensionEdits??={nether:{},end:{}};save.positions??={};save.testWorld??=false;save.experiments??=false;save.portalLinks??={};
save.renderDistance=Math.max(2,Math.min(32,Math.round(Number(save.renderDistance)||2)));
camera.far=Math.max(100,save.renderDistance*SIZE+32);camera.updateProjectionMatrix();
if(!Array.isArray(save.slots)){
  save.slots=Array(36).fill(null);
  for(const [idText,total] of Object.entries(save.inventory)){const id=Number(idText);let remaining=Number(total)||0;if(!ITEMS[id])continue;const preferred=save.hotbar.indexOf(id);if(preferred>=0&&remaining){const n=Math.min(64,remaining);save.slots[27+preferred]={id,n};remaining-=n}for(let i=0;i<36&&remaining;i++){if(save.slots[i])continue;const n=Math.min(64,remaining);save.slots[i]={id,n};remaining-=n}}
}
for(const stack of save.slots)if(stack&&BLOCKS[stack.id]?.minecraftId==='grass_block')stack.id=GRASS;for(const slots of Object.values(save.chests||{}))if(Array.isArray(slots))for(const stack of slots)if(stack&&BLOCKS[stack.id]?.minecraftId==='grass_block')stack.id=GRASS;save.slots.length=36;for(let i=0;i<36;i++)save.slots[i]??=null;
let multiplayer=null,mobile=null;
let seed=save.seed, dirtySave=false,dimension=save.dimension,portalCooldown=0,portalExitLock=null,resettingWorld=false;if(save.testWorld)dirtySave=true;
function ensureSafeSpawn(position){return safeSpawn(position,{collides:intersectsBody,solid,minY:MIN_Y+1,maxY:MAX_Y-2})}
const player={x:0.5,y:25,z:0.5,vy:0,knockVx:0,knockVz:0,yaw:0,pitch:0,grounded:false,flight:false,gliding:false,rocketBoost:0,health:20,hunger:20,air:20};
let vehicle=null;const parkedVehicles=[],vehicleDimensions=new Map();let activeVehicleDimension=dimension;
const weatherCanvas=document.getElementById('weatherCanvas'),weatherCtx=weatherCanvas.getContext('2d');let lightningFlash=0;
const rainCount=420,rainPositions=new Float32Array(rainCount*6),rainDrops=Array.from({length:rainCount},()=>({x:0,y:-100,z:0,speed:0,ground:-100}));
const rainGeometry=new THREE.BufferGeometry();rainGeometry.setAttribute('position',new THREE.BufferAttribute(rainPositions,3).setUsage(THREE.DynamicDrawUsage));
const rainLines=new THREE.LineSegments(rainGeometry,new THREE.LineBasicMaterial({color:0xb8d4e9,transparent:true,opacity:.58,depthWrite:false,fog:true}));rainLines.frustumCulled=false;rainLines.visible=false;scene.add(rainLines);


const keys=new Set();
let selected=0,playing=false,lastTime=performance.now(),tick=save.dayTime*Math.PI*2,fpsTime=0,frames=0,lookHit=null,toastTimer,fallStart=0,lightDay=15,lightDisplay=15,stepSoundTimer=0,cartSoundTimer=0;
const mining={active:false,key:'',progress:0},miningTrack=document.getElementById('miningTrack'),miningFill=document.getElementById('miningFill');
let audioContext;
const ui={overlay:document.getElementById('overlay'),play:document.getElementById('playButton'),new:document.getElementById('newButton'),hotbar:document.getElementById('hotbar'),coords:document.getElementById('coords'),fps:document.getElementById('fps'),biome:document.getElementById('biome'),clock:document.getElementById('clock'),target:document.getElementById('targetLabel'),crosshair:document.getElementById('crosshair'),toast:document.getElementById('toast')};



const skyPalette=[[0,0xf4a56f],[.06,0x99badc],[.18,0x78a7ff],[.38,0x78a7ff],[.46,0xe99a78],[.52,0xa66984],[.6,0x37446b],[.72,0x111a36],[.82,0x17213e],[.92,0x68546e],[1,0xf4a56f]];


const noiseLattice=new Map();

const climateCache=new Map(),terrainCache=new Map();






const NETHER_FOG={nether_wastes:0x330808,crimson_forest:0x330303,warped_forest:0x1a051a,soul_sand_valley:0x1b4745,basalt_deltas:0x685f70};



let cachedNetherPortalSite=null;


const oreBands=Array.from({length:HEIGHT},(_,index)=>{const y=index+MIN_Y,tri=(middle,width)=>Math.max(0,1-Math.abs(y-middle)/width),ramp=(a,b)=>Math.max(0,Math.min(1,(y-a)/(b-a))),deep=y<0;
  return [[deep?extraId('deepslate_diamond_ore'):DIAMOND_ORE,y<16?.0001+.003*tri(-59,76):0],[deep?extraId('deepslate_gold_ore'):GOLD_ORE,y<32?.0005+.006*tri(-16,48)+(y<-48?.0015:0):0],[deep?extraId('deepslate_redstone_ore'):REDSTONE_ORE,y<16?.001+.007*(1-ramp(-64,-32)):0],[deep?extraId('deepslate_lapis_ore'):LAPIS_ORE,y<64?.0004+.006*tri(0,64):0],[deep?DEEPSLATE_IRON:IRON,.0005+.009*tri(16,64)+(y>80?.005*ramp(80,240):0)],[deep?extraId('deepslate_copper_ore'):COPPER_ORE,y>=0&&y<=96?.0003+.007*tri(48,52):0],[deep?DEEPSLATE_COAL:COAL,y>=0?.0006+.012*tri(96,128):0],[deep?extraId('deepslate_emerald_ore'):extraId('emerald_ore'),y>=-16?.003*ramp(-16,240):0]];
});









const villageSites=new Map();










const lightDirections=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];





















const fluidDirections=[[1,0],[-1,0],[0,1],[0,-1]];









let flowStep=0;




const meshColor=new THREE.Color(),atlasUVCache=new Map();



const default3dIds=new Map([[CHEST,'chest'],[TRAPPED_CHEST,'trapped_chest'],[END_FRAME,'end_portal_frame'],[CACTUS,'cactus'],[LADDER,'ladder'],[ENCHANTING_TABLE,'enchanting_table'],[BREWING_STAND,'brewing_stand'],[RAIL,'rail'],[POWERED_RAIL,'powered_rail'],[DETECTOR_RAIL,'detector_rail'],[ACTIVATOR_RAIL,'activator_rail'],[STONECUTTER,'stonecutter'],[AZALEA,'azalea'],[FLOWERING_AZALEA,'flowering_azalea'],[BEE_NEST,'bee_nest_empty'],[DOOR,'oak_door_bottom'],[DOOR_TOP,'oak_door_top'],[ANVIL,'template_anvil'],[LEVER,'lever'],[FARMLAND,'template_farmland'],[TORCH,'template_redstone_torch'],[REDSTONE_WIRE,'redstone_dust_dot'],[MEADOW_FLOWER,'flower']]);
const modelFaceNumbers={east:0,west:1,up:2,down:3,south:4,north:5};
const default3dParts=new Map(Object.entries(default3dModels).map(([name,elements])=>[name,elements.map(element=>({kind:'box',bounds:[...element.from,...element.to].map(value=>value/16),faces:Object.fromEntries(Object.entries(element.faces).map(([side,face])=>[modelFaceNumbers[side],face])),rotation:element.rotation?{...element.rotation,origin:element.rotation.origin.map(value=>value/16)}:null}))]));







const structureParts=new Map(structureAssets.blocks.map(block=>[block.id,block.parts.map(part=>({kind:'box',bounds:[...part.from.map(v=>v/16),...part.to.map(v=>v/16)],faces:Object.fromEntries(Object.entries(part.faces).map(([side,spec])=>[{east:0,west:1,up:2,down:3,south:4,north:5}[side],spec])),rotation:part.rotations.map(r=>({...r,origin:r.origin.map(v=>v/16)}))}))]));
const modelBlockTypes=new Set([...SHAPED_BLOCKS,...default3dIds.keys(),PISTON,STICKY_PISTON,OBSERVER,DISPENSER,DROPPER,CRAFTER,COPPER_BULB,CHISELED_BOOKSHELF]);













const instantModelTypes=new Set([CHEST,TRAPPED_CHEST,LEVER,DOOR,DOOR_TOP,...structureAssets.blocks.filter(b=>b.minecraftId.endsWith('_door')).map(b=>b.id)]);









const urgentMeshQueue=new Map(),editLightingQueue=new Map();let pendingEditLighting=null;




let suspendedMeshing=null;

let streamKey=null,streamWanted=[],lodCheckAt=0;





























































const foregroundRaycaster=new THREE.Raycaster();


const outlineCache=new Map(),outline=new THREE.LineSegments(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0xf5f2d2,transparent:true,opacity:.9,depthTest:true,depthWrite:false}));outline.visible=false;outline.renderOrder=10;scene.add(outline);


const blockCollisionCache=new Map();

















const vehicleRaycaster=new THREE.Raycaster();vehicleRaycaster.far=5;










let discAudio=null;




const EXPANSION_IDS={REDSTONE_WIRE,LEVER,REDSTONE_LAMP,PISTON,ENCHANTING_TABLE,ANVIL,BREWING_STAND,RAIL,POWERED_RAIL,SPAWNER,ANCIENT_DEBRIS,SHULKER_BOX,BOOKSHELF,NETHER_WART_CROP,SMITHING_TABLE,FISHING_ROD,COD,BOAT,MINECART,ELYTRA,FIREWORK,SHULKER_SHELL,NETHERITE_SCRAP,NETHERITE_INGOT,NETHERITE_PICKAXE,NETHERITE_SWORD,NETHERITE_AXE,NETHERITE_SHOVEL,GLASS_BOTTLE,WATER_BOTTLE,AWKWARD_POTION,HEALING_POTION,SPEED_POTION,STRENGTH_POTION,NETHER_WART,GHAST_TEAR,SPIDER_EYE,UPGRADE_TEMPLATE,SUGAR,GLISTERING_MELON,REGENERATION_POTION,POISON_POTION};
Object.assign(EXPANSION_IDS,{STICKY_PISTON,REDSTONE_TORCH,REPEATER,COMPARATOR,STONE_BUTTON,STONE_PRESSURE_PLATE,OBSERVER,DETECTOR_RAIL,PISTON_HEAD,SLIME_BALL,REDSTONE_BLOCK});
Object.assign(EXPANSION_IDS,{DISPENSER,DROPPER,HOPPER,DAYLIGHT_DETECTOR,TARGET,TRAPPED_CHEST,NOTE_BLOCK,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE,LIGHT_WEIGHTED_PLATE,HEAVY_WEIGHTED_PLATE,COPPER_BULB,TRIPWIRE_HOOK,TRIPWIRE,SCULK_SENSOR,CALIBRATED_SCULK_SENSOR,CRAFTER,OAK_TRAPDOOR,IRON_TRAPDOOR,HAY_BALE,AMETHYST_SHARD,LIGHTNING_ROD,LECTERN,CHISELED_BOOKSHELF,ACTIVATOR_RAIL});
const lootItemNames=new Map();
for(const [id,item] of Object.entries(ITEMS)){const name=item.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');if(!lootItemNames.has(name))lootItemNames.set(name,Number(id));if(item.icon&&!lootItemNames.has(item.icon))lootItemNames.set(item.icon,Number(id))}
for(const [name,id] of Object.entries({coal:COAL_ITEM,redstone:REDSTONE_DUST,oak_log:WOOD,oak_planks:PLANKS,beef:RAW_MEAT,cooked_beef:COOKED_MEAT,chicken:RAW_CHICKEN,cooked_chicken:COOKED_CHICKEN,wooden_pickaxe:PICKAXE,wooden_sword:SWORD,wheat:WHEAT}))lootItemNames.set(name,id);
const chestLoot=createChestLoot({resolveItem:name=>lootItemNames.get(name),stackSize:id=>ITEMS[id]?.stackSize||(/sword|pickaxe|shovel|axe|hoe|helmet|chestplate|leggings|boots|bow|elytra|shield/.test(ITEMS[id]?.name.toLowerCase()||'')?1:64)});


const survival=createSurvival({blockRegistry,THREE,renderer,scene,player,camera,save,ITEMS,BLOCK_PROPERTIES,ids:contentIds,extraId,getBlock,skyExposed,meleeBlockDistance:()=>{const hit=hitVoxel(5);return hit?hit.distance??Math.hypot(hit.x+.5-camera.position.x,hit.y+.5-camera.position.y,hit.z+.5-camera.position.z):Infinity},isChunkLoaded:(x,z)=>entityWorldChunks().has(key(Math.floor(x/SIZE),Math.floor(z/SIZE))),setBlock,setBlockBatch,snowLayerCount,setSnowLayers,activateNetherPortal,terrain,endPillars,spawnPoint,sea:SEA,getDimension:()=>dimension,getBlockLightLevel,getLightLevel,isSolidAt:solid,suffocatingAt:(x,y,z)=>occludes(getBlock(x,y,z)),intersectsBody,waterCurrent,ensureSafeSpawn,createFireVisual:()=>firstPerson.worldItem(FIRE),primeTNT:(...args)=>gameplayRepairs.prime(...args),tiltDripleaf:(...args)=>gameplayRepairs.tilt(...args),useEndGateway:(...args)=>gameplayRepairs.useGateway(...args),breakBedAny:(...args)=>gameplayRepairs.breakBed(...args),isRaining:(x,z)=>save.weather.kind!=='clear'&&biome(Math.floor(x),Math.floor(z))!=='snow',strongholdLocation,isVillageChest,villageAt,spawnEntity:(type,x,z,y)=>multiplayer?.active?multiplayer.spawnEntity(type,{x,y,z,dimension}):survival.spawnMob(type,x,z,y),insertEndEye,netherBiome,onDragonDefeated:dragonDefeated,itemForBlock:id=>BLOCKS[id]?.itemId??id,isBlock:id=>!!BLOCKS[id],isRedstoneComponent:id=>REDSTONE_COMPONENTS.has(id),isDoor,doorInfo,placeDirectional,placeDoorVariant,breakDoorPartner,placeTorch,isSolid:id=>!!BLOCKS[id]?.solid,showToast,playSound,playDisc,awardAdvancement,getBiome:biome,maxY:MAX_Y,isRemoteWorld:()=>!!sessionStorage.getItem('vf-mp-room'),networkDrop:(...args)=>multiplayer?.spawnDrop(args),hitRemoteProjectile:shot=>multiplayer?.hitProjectile(shot),markDirty:()=>{dirtySave=true},refreshHotbar:updateHotbar,getSelected:()=>selected,occupied,isPlaying:()=>playing||survival.isOpen(),isSprinting:()=>(keys.has('ShiftLeft')||keys.has('ShiftRight'))&&(save.mode==='creative'||player.hunger>6),isBlocking:()=>blocking,onChestView:(cell,open)=>{setChestOpen(cell,open);multiplayer?.chestView(cell,open)},onOpen:()=>{playing=false;keys.clear();blocking=false},onClose:()=>resume(),toggleDoor,placeDoor,placeBed,breakBedPartner,ensureChestLoot,clearChestLootReference,sleepAtBed,respawnPlayer,toggleLever,placePiston,placeRedstoneComponent,useRedstoneControl,closeRedstoneContainer,hitTarget,mountVehicle,stopVineGrowth});
const chestAnimation=createChestAnimation({dimension:()=>dimension,update:updateBlockModelImmediately,sound:playGameSound});
for(const [cell,open] of Object.entries(save.openChests||{}))if(open)chestAnimation.target(cell,true);
function setChestOpen(cell,open){save.openChests??={};save.openChests[cell]=open;chestAnimation.target(cell,open)}
BLOCKS[9990]={name:'End gateway',solid:false,color:0x152934,portalSurface:true};ITEMS[9990]={name:'End gateway',color:0x152934,icon:'end_portal_surface',iconURL:ITEMS[END_PORTAL]?.iconURL};BLOCK_TEXTURES[9990]=['end_portal_surface'];BLOCK_PROPERTIES[9990]={hardness:-1,resistance:3600000};
const firstPerson=createFirstPerson(THREE,{renderer,items:ITEMS,blocks:BLOCKS,selected:()=>survival.selectedId(),lightLevel:()=>getLightLevel(Math.floor(player.x),Math.floor(player.y+1),Math.floor(player.z)),bowTime:()=>survival.bowTime(),bowTexture:stage=>resourcePacks?.texture('item/bow_pulling_'+stage),atlas:()=>materials.solid.map,iconColor:(id,face,tile)=>new THREE.Color((BLOCKS[id]?.biomeTint||[LEAVES,SPRUCE_LEAVES,BIRCH_LEAVES].includes(id)||/leaves/.test(tile||''))?0x91bd59:id===GRASS&&face===2?0x91bd59:id===WATER?0x75a9c7:id===REDSTONE_WIRE?0x682020:0xffffff),partsData:(parts,id)=>{const data={p:[],c:[],u:[],i:[]};const recolor=(start,col)=>{for(let n=start;n<data.c.length;n+=3){data.c[n]=col.r;data.c[n+1]=col.g;data.c[n+2]=col.b;}};for(const part of parts){const start=data.c.length;if(part.kind==='box'){appendModelBox(data,STONE,0,0,0,...part.bounds,part.texture,part.faces,part.rotation);let offset=start;for(let face=0;face<6;face++){const spec=part.faces?.[face];if(part.faces&&!spec)continue;const tile=spec?.tile||part.texture||blockTexture(id,face),tinted=spec?.tintindex>=0||BLOCKS[id]?.biomeTint&&!/azalea_plant|oak_log/.test(tile)||/^(?:structure_block_|default3d_)?(?:.*_leaves|grass_block_top|short_grass|tall_grass_.*|fern.*|vine|sugar_cane|lily_pad|.*_stem)$/.test(tile);const color=new THREE.Color(tinted?0x91bd59:id===WATER?0x75a9c7:id===REDSTONE_WIRE?0x682020:0xffffff);for(let n=offset;n<offset+12;n+=3){data.c[n]=color.r;data.c[n+1]=color.g;data.c[n+2]=color.b;}offset+=12;}}else{const tile=part.texture||blockTexture(id,4),spec={tile,uv:[0,0,16,16]};for(const angle of [45,-45])appendModelBox(data,STONE,0,0,0,0,0,.5,1,part.height||1,.5,null,{4:spec,5:spec},{axis:'y',angle,origin:[.5,.5,.5]});recolor(start,new THREE.Color(BLOCKS[id]?.biomeTint?0x91bd59:0xffffff));}}return data;},blockParts,modelVertexData,faceUV,visible:()=>playing&&!survival.isOpen()&&!commandOpen&&save.mode!=='spectator',moving:()=>['KeyW','KeyA','KeyS','KeyD'].some(key=>keys.has(key))});
const gameplayRepairs=createGameplayRepairs(THREE,{ids:contentIds,blocks:BLOCKS,items:ITEMS,properties:Object.fromEntries(structureAssets.blocks.map(b=>[b.id,b.properties||{}])),ensure:(x,z)=>{const id=key(Math.floor(x/SIZE),Math.floor(z/SIZE));return chunks.get(id)||generate(Math.floor(x/SIZE),Math.floor(z/SIZE));},sleep:sleepAtBed,solid,occupied,has:id=>survival.count(id)>0,guest:()=>!!multiplayer?.guest,registry:blockRegistry,modelTypes:modelBlockTypes,instantTypes:instantModelTypes,redstoneData,key:editKey,dimension:()=>dimension,materials,atlas:atlasMap,packActive:()=>!!resourcePacks?.active(),simulationActive:()=>playing||!!multiplayer?.active,player,save,firstPerson,scene,setBlock,setBatch:setBlockBatch,block:getBlock,sound:playGameSound,explode:(...args)=>survival.explode(...args),inDimension,terrain,safe:ensureSafeSpawn,stream,updateModel:updateBlockModelImmediately,powered:k=>redstoneLevels.get(k)>0});
const natureSystem=createNatureSystem({blocks:BLOCKS,items:ITEMS,ids:contentIds,registry:blockRegistry,modelTypes:modelBlockTypes,block:getBlock,setBlock,setBatch:setBlockBatch,dimension:()=>dimension,save,SIZE,idx,terrain,biome,hash});
configureDynamicIcons(id=>firstPerson.icon(id),()=>!!materials.solid.map?.image,()=>{survival.refreshCatalog();survival.refresh();updateHotbar();});
if(window.__VF_TEST__){Object.assign(window.__VF_TEST__,{natureSystem,THREE,renderer,scene,materials,firstPerson,gameplayRepairs,save,player,camera,appendModelBox,modelVertexData,blockRegistry,getBlockLightLevel,emittedLight,updateLightingAt,computeLightingTask,flushEditLighting,refreshEditedLighting,applyGridLighting,flushChunkMesh,urgentMeshQueue,getPendingMesh:()=>pendingMeshing,getMultiplayer:()=>multiplayer,MIN_Y,MAX_Y,SEA,idx,caveBiome,getLightLevel,skyExposed,chunks,buildChunk,chunkLOD,stream,ids:EXPANSION_IDS,ITEMS,BLOCKS,BLOCK_PROPERTIES,atlasMap,faceUV,blockTexture,blockParts,updateHotbar,wireConnections,placeDirectional,outlineGeometry,outline,getBlock,setBlock,setBlockBatch,processRedstone,processFlow,processGravity,snowLayerCount,setSnowLayers,moveAxis,intersects,hitVoxel,updateFallingBlocks,fallingBlocks,redstoneLevels,observerUntil,gatePending,gateOutputs,torchStates,torchPending,torchBurnedUntil,redstoneData,redstoneEdge,sensorUntil,targetUntil,tripwireUntil,containerSlotsAt,hitTarget,closeRedstoneContainer,railShape,parkedVehicles,updateMinecarts,flowLevels,flowSources,toggleLever,useRedstoneControl,placeRedstoneComponent,terrain,biome,isTree,villageSite,netherBiome,endPillars,strongholdLocation,strongholdY,isStrongholdFrame,hasEndEye,insertEndEye,generate,teleportTo,survival,mountVehicle,boardVehicleAtCrosshair,dismountVehicle,punchMinecart,hitMinecartAtCrosshair,pushMinecartsByPlayer,getVehicle:()=>vehicle,portalInfoAt,mapPortalPoint,mapPortalYaw,nearestPortal,visiblePortals,portalCells,portalWindow,portalPreviewWorlds,preparePortalPreview,stepPortalPreview,crossedPortal,crossExperimentalPortal,getPortalPreviewState:()=>portalPreviewState,getDimension:()=>dimension,runEntityWorld,simulateOtherDimensions,dimensionVoxelCaches,move,assistWaterExit,moveMobsThroughPortals,setBlocking:value=>blocking=value});Object.defineProperty(window.__VF_TEST__,'portalPreviewChunks',{configurable:true,get:()=>portalPreviewChunks})}
const commandBar=document.getElementById('commandBar'),commandInput=document.getElementById('commandInput'),commandFeedback=document.getElementById('commandFeedback'),commandMode=document.getElementById('commandMode'),chatLog=document.getElementById('chatLog');let commandOpen=false,chatUntil=0;

const commands=createCommandRunner({items:ITEMS,blocks:BLOCKS,aliases:{grass_block:GRASS,oak_log:WOOD,oak_wood:WOOD,oak_planks:PLANKS,oak_leaves:LEAVES,spruce_log:SPRUCE_LOG,birch_log:BIRCH_LOG,spruce_planks:SPRUCE_PLANKS,birch_planks:BIRCH_PLANKS,crafting_table:TABLE,redstone:REDSTONE_DUST,coal:COAL_ITEM,cobblestone:extraId('cobblestone')},save,player,minY:MIN_Y,maxY:MAX_Y,mobTypes:MOB_TYPES,setMode:mode=>{save.mode=mode;modeInput.value=mode;player.flight=mode==='spectator'||mode==='creative'&&player.flight;survival.refresh();dirtySave=true},getTime:()=>tick,setTime:value=>{tick=value;dirtySave=true},markDirty:()=>{dirtySave=true},getBlock,setBlock,setBlockBatch,otherPlayers:()=>multiplayer?.playerStates()||[],getDimension:()=>dimension,entities:()=>survival.commandEntities(),killEntity:id=>multiplayer?.active?multiplayer.killEntity(id):survival.killCommandEntity(id),killPlayer:name=>multiplayer?.killPlayer(name),teleportPlayer:(name,pos)=>multiplayer?.teleportPlayer(name,pos),teleportEntity:(id,pos)=>multiplayer?.active?multiplayer.teleportEntity(id,pos):survival.teleportCommandEntity(id,pos),drop:survival.drop,refresh:survival.refresh,spawnMob:(type,x,z,y)=>multiplayer?.active?multiplayer.spawnEntity(type,{x,y,z,dimension}):survival.spawnMob(type,x,z,y),removeMobs:survival.removeMobs,hurt:survival.hurt,chat:message=>multiplayer?.chat(message),whisper:(target,message)=>multiplayer?.chat(message,target),players:()=>multiplayer?.players()||[],playerName:()=>multiplayer?.playerName?.()||sessionStorage.getItem('vf-mp-name')||'Player'});


commandInput.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();closeCommand()}else if(event.key==='Enter'){event.preventDefault();const text=commandInput.value.trim();if(text.startsWith('/')){const result=commands.run(text);if(!/^\/(say|me|tell|msg|w)\b/i.test(text))addChatMessage('',result)}else if(text){if(!multiplayer?.chat(text))addChatMessage('You',text)}closeCommand()}});
commandBar.addEventListener('submit',event=>event.preventDefault());
const loading=createLoadingScreen();let effectsPrepared=false,resuming=false;const worldReadyWaiters=[];
loading.begin('world',sessionStorage.getItem('vf-new-world')?'Creating world':sessionStorage.getItem('vf-mp-room')?'Joining world':'Loading world','Preparing nearby terrain',0,!sessionStorage.getItem('vf-new-world')&&!sessionStorage.getItem('vf-mp-room'));





ui.play.addEventListener('click',resume);
const seedInput=document.getElementById('seedInput'),modeInput=document.getElementById('modeInput'),experimentsToggle=document.getElementById('experimentsToggle'),renderDistanceInput=document.getElementById('renderDistanceInput'),renderDistanceValue=document.getElementById('renderDistanceValue');seedInput.placeholder=save.testWorld?'Current: testworld':`Current: ${seed}`;modeInput.value=save.mode;experimentsToggle.checked=save.experiments;
const renderDistanceWarning=document.getElementById('renderDistanceWarning');renderDistanceWarning.hidden=save.renderDistance<=16;renderDistanceInput.value=String(save.renderDistance);renderDistanceValue.value=`${save.renderDistance} CHUNKS`;
renderDistanceInput.addEventListener('input',()=>{save.renderDistance=Number(renderDistanceInput.value);renderDistanceWarning.hidden=save.renderDistance<=16;renderDistanceValue.value=`${save.renderDistance} CHUNKS`;camera.far=Math.max(100,save.renderDistance*SIZE+32);camera.updateProjectionMatrix();dirtySave=true;stream()});
experimentsToggle.addEventListener('change',()=>{save.experiments=experimentsToggle.checked;dirtySave=true;portalExitLock=null;resetPortalPreview();for(const chunk of chunks.values())scheduleChunkMesh(chunk);showToast(save.experiments?'PORTAL EXPERIMENT ENABLED':'PORTAL EXPERIMENT DISABLED')});
modeInput.addEventListener('change',()=>{const wasSpectator=save.mode==='spectator';save.mode=modeInput.value;player.flight=save.mode==='spectator'||save.mode==='creative'&&player.flight;if(wasSpectator&&save.mode!=='spectator'&&intersects(player.x,player.y,player.z))player.y=terrain(Math.floor(player.x),Math.floor(player.z))+3;player.vy=0;dirtySave=true;survival.refresh()});
ui.new.addEventListener('click',async()=>{if(multiplayer?.active||multiplayer?.guest){showToast('LEAVE MULTIPLAYER BEFORE CREATING A WORLD');return}if(!confirm('Create a new world? Your current world and all block edits will be deleted.'))return;resettingWorld=true;loading.begin('world','Creating world','Choosing seed and preparing terrain',0);sessionStorage.setItem('vf-new-world','1');await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));const value=seedInput.value.trim(),testWorld=value.toLowerCase()==='testworld';let nextSeed;if(!value){nextSeed=crypto.getRandomValues(new Uint32Array(1))[0]|0;if(nextSeed===seed)nextSeed=(nextSeed+1)|0}else if(/^-?\d+$/.test(value))nextSeed=Number(BigInt(value)&BigInt(0xffffffff))|0;else{nextSeed=0;for(let i=0;i<value.length;i++)nextSeed=(Math.imul(nextSeed,31)+value.charCodeAt(i))|0}
  const chests={},redstoneExtra={overworld:{}};let levers={},openDoors={};if(testWorld){const supplies=[[WATER_BUCKET,4],[LAVA_BUCKET,2],[BUCKET,4],[REDSTONE_WIRE,64],[LEVER,16],[REDSTONE_LAMP,16],[PISTON,16],[RAIL,64],[POWERED_RAIL,32],[MINECART,1],[IRON_PICKAXE,1],[DIAMOND_PICKAXE,1],[TORCH,64],[OBSIDIAN,32],[FLINT_STEEL,1],[EYE_OF_ENDER,16],[TABLE,4],[FURNACE,4],[SAPLING,16],[WHEAT_SEEDS,32],[BREAD,32],[IRON_INGOT,64],[DIAMOND,32],[WOOD,64],[SAND,64],[STONE,64],[CHEST,8],[BOW,2],[ARROW,64],[SHIELD,1],[REDSTONE_TORCH,16],[REPEATER,16],[COMPARATOR,16],[STICKY_PISTON,16],[OBSERVER,16],[SNOW,32],[POWDER_SNOW_BUCKET,2],[BREWING_STAND,2],[GLASS_BOTTLE,16],[LAVA_BUCKET,2]];chests['overworld:1,73,-4']=supplies.slice(0,27).map(([id,n])=>({id,n}));chests['overworld:3,73,-4']=supplies.slice(27).map(([id,n])=>({id,n}));const ids=Object.keys(ITEMS).map(Number).filter(id=>Number.isInteger(id)&&ITEMS[id]?.name).sort((a,b)=>a-b);for(let page=0;page<Math.ceil(ids.length/27);page++){const x=-24+page*2;chests[`overworld:${x},73,-32`]=ids.slice(page*27,(page+1)*27).map(id=>({id,n:1}))}const facings=[[0,-1],[1,0],[0,1],[-1,0]];for(let n=0;n<4;n++){const x=16+n*2;redstoneExtra.overworld[`${x},73,31`]={facing:facings[n],hinge:n>1?'right':'left'};if(n%2)openDoors[`${x},73,31`]=true;const lx=28+n*2,support=[[0,-1,0],[1,0,0],[-1,0,0],[0,1,0]][n];redstoneExtra.overworld[`${lx},73,27`]={support,facing:facings[n]};levers[`${lx},73,27`]=n===0||n===2}}
  resettingWorld=true;localStorage.setItem(SAVE_KEY,JSON.stringify({_savedAt:Date.now(),seed:nextSeed,testWorld,edits:{},snowLayers:{},fluidStates:{overworld:{},nether:{},end:{}},dimensionEdits:{nether:{},end:{}},chests,positions:{},dragonDefeated:false,destroyedEndCrystals:{},endEyes:{},redstoneExtra,levers,openDoors,durability:{},player:null,inventory:{},slots:Array(36).fill(null),mode:modeInput.value,experiments:experimentsToggle.checked,renderDistance:Number(renderDistanceInput.value),portalLinks:{},dimension:'overworld',dayTime:.28,tick:.28*Math.PI*2,generatorVersion:6}));location.reload()});
document.getElementById('exportSave').addEventListener('click',()=>{
  dirtySave=true;saveGame();
  const blob=new Blob([JSON.stringify({format:'voxel-frontier',version:1,savedAt:new Date().toISOString(),world:save})],{type:'application/json'});
  const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=`voxel-frontier-${seed}-${new Date().toISOString().slice(0,10)}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast('WORLD BACKUP DOWNLOADED');
});
const saveFile=document.getElementById('saveFile');
document.getElementById('importSave').addEventListener('click',()=>saveFile.click());
saveFile.addEventListener('change',async()=>{
  const file=saveFile.files[0];if(!file)return;
  try{if(file.size>20*1024*1024)throw new Error('Backup is too large');const data=JSON.parse(await file.text()),world=data.world;
    if(data.format!=='voxel-frontier'||data.version!==1||!world||!Number.isInteger(world.seed)||!Array.isArray(world.slots)||world.slots.length!==36||!['survival','creative','spectator'].includes(world.mode)||!['overworld','nether','end'].includes(world.dimension)||!world.edits||typeof world.edits!=='object')throw new Error('Not a valid Voxel Frontier backup');
    if(world.slots.some(slot=>slot!==null&&(!ITEMS[slot.id]||!Number.isInteger(slot.n)||slot.n<1||slot.n>64)))throw new Error('Invalid inventory in backup');
    if(!confirm('Restore this backup? It will replace the current world in this browser.'))return;
    world._savedAt=Date.now();localStorage.setItem(SAVE_KEY,JSON.stringify(world));resettingWorld=true;location.reload();
  }catch(error){showToast('RESTORE FAILED: '+error.message)}finally{saveFile.value=''}
});
window.addEventListener('blur',()=>{keys.clear();mining.active=false;blocking=false;if(playing)pause()});
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(playing)pause();dirtySave=true;saveGame()}});
document.getElementById('menuButton').addEventListener('click',pause);
document.addEventListener('pointerlockchange',()=>{if(document.pointerLockElement!==canvas&&playing&&!commandOpen&&!survival.isOpen()&&!mobile?.touch)pause()});
document.addEventListener('mousemove',e=>{if(!playing||commandOpen||survival.isOpen()||(document.pointerLockElement!==canvas&&!(pointerLockUnavailable()&&e.target===canvas&&(e.buttons&1))))return;player.yaw-=e.movementX*.0024;player.pitch=Math.max(-1.52,Math.min(1.52,player.pitch-e.movementY*.0024))});
document.addEventListener('keydown',e=>{if(commandOpen)return;if(e.target instanceof HTMLElement&&(e.target.closest('input, textarea, select, [contenteditable="true"]')))return;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)&&playing)e.preventDefault();if(survival.isOpen()){if(e.code==='KeyQ'&&!e.repeat){e.preventDefault();survival.dropInventory(null,e.ctrlKey);return}if(['Escape','KeyI','KeyE'].includes(e.code))survival.closeInventory();return}if(!playing)return;if(e.code==='Slash'&&!e.repeat){e.preventDefault();openCommand();return}if(e.code==='KeyT'&&!e.repeat){e.preventDefault();openCommand(true);return}if((e.code==='ShiftLeft'||e.code==='ShiftRight')&&vehicle){if(!e.repeat)dismountVehicle();return}keys.add(e.code);if(e.repeat)return;if(e.code==='KeyQ'){e.preventDefault();survival.dropInventory({kind:'slot',index:27+selected},e.ctrlKey);return;}if(e.code==='Escape')pause();if((e.code==='KeyE'||e.code==='KeyI')&&save.mode!=='spectator')survival.openInventory(false);if(e.code==='KeyC'&&save.mode!=='spectator'){if(survival.nearbyTable())survival.openInventory(true);else showToast('NO CRAFTING TABLE NEARBY')}if(e.code==='Space'&&!player.grounded&&player.vy<0&&save.armor?.chestplate===ELYTRA){player.gliding=true;showToast('ELYTRA GLIDING')}if(e.code==='KeyF'){if(save.mode!=='creative')showToast('FLIGHT REQUIRES CREATIVE MODE');else{player.flight=!player.flight;player.vy=0;showToast(player.flight?'FLIGHT ENABLED':'FLIGHT DISABLED')}}if(e.code.startsWith('Digit')){const n=Number(e.code.slice(5));if(n>=1&&n<=9){selected=n-1;updateHotbar()}}});
document.addEventListener('keyup',e=>keys.delete(e.code));
document.addEventListener('wheel',e=>{if(!playing)return;e.preventDefault();selected=(selected+(e.deltaY>0?1:8))%9;updateHotbar()},{passive:false});
canvas.addEventListener('contextmenu',e=>e.preventDefault());

canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('mousedown',e=>{if(!playing||mobile?.touch)return;if(document.pointerLockElement!==canvas&&!pointerLockUnavailable()){requestGamePointerLock(canvas);return}playerAction(e.button)});
document.addEventListener('pointerup',e=>{if(e.button===2){blocking=false;survival.releaseBow()}});
window.addEventListener('blur',()=>survival.releaseBow());
document.addEventListener('pointercancel',()=>survival.releaseBow());
document.addEventListener('mouseup',e=>{if(e.button===2){blocking=false;survival.releaseBow()};if(e.button===0){mining.active=false;mining.progress=0;miningTrack.classList.remove('active')}});
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,matchMedia('(pointer: coarse)').matches?1:1.5))});
window.addEventListener('beforeunload',()=>{if(!resettingWorld){dirtySave=true;saveGame()}});
setInterval(()=>{if(playing||survival.isOpen()){dirtySave=true;saveGame(true)}},5000);
if(save.player&&Number.isFinite(save.player.x)&&!legacyWorld){Object.assign(player,save.player);player.vy=0;if(upgradingWorld&&dimension==='overworld')player.y=Math.max(SEA+3,terrain(Math.floor(player.x),Math.floor(player.z))+3)}else Object.assign(player,spawnPoint());
if(save.mode!=='spectator')Object.assign(player,ensureSafeSpawn(player));
if(save.mode==='survival')player.flight=false;else if(save.mode==='spectator')player.flight=true;
survival.initializeFood();if(Number.isFinite(save.tick))tick=save.tick;
camera.position.set(player.x,player.y+1.57,player.z);camera.rotation.set(player.pitch,player.yaw,0);
survival.refresh();loadVehicleSave(dimension);
const playLabel=ui.play.innerHTML;ui.play.disabled=true;ui.play.textContent='PREPARING GAME…';const effectsReady=Promise.all([survival.prepareEffects(renderer,camera),prepareInteractionSounds()]).catch(error=>{console.warn('Effect preparation failed',error)}).finally(()=>{effectsPrepared=true;ui.play.innerHTML=playLabel;updateWorldLoading()});
multiplayer=createMultiplayer({mobTypes:MOB_TYPES,spawnEntity:(type,pos,dim)=>inDimension(dim,()=>survival.inStoredEntities(dim,()=>survival.spawnMob(type,pos.x,pos.z,pos.y))),killEntity:(id,dim)=>inDimension(dim,()=>survival.inStoredEntities(dim,()=>survival.killCommandEntity(id))),THREE,scene,player,save,loading,requestFullscreen:()=>mobile?.requestFullscreen(),guest:!!sessionStorage.getItem('vf-mp-room'),dimension:()=>dimension,
 hurt:survival.hurt,attackDamage:()=>survival.consumeAttack().damage,attackProfile:()=>survival.consumeAttack(),
 snapshot:()=>{survival.serializeEntities();serializeVehicleEntities();return ({...save,player:{x:player.x+2,y:player.y,z:player.z,yaw:player.yaw,pitch:player.pitch},dimension,tick})},
 selectedItem:()=>survival.selectedId(),itemModel:id=>firstPerson.worldItem(id),onChat:addChatMessage,chat:(message,target)=>multiplayer?.chat(message,target),whisper:(target,message)=>multiplayer?.chat(message,target),players:()=>multiplayer?.players()||[],playerName:()=>multiplayer?.playerName?.()||sessionStorage.getItem('vf-mp-name')||'Player',applySelfTeleport:pos=>{player.x=pos.x;player.y=pos.y;player.z=pos.z;player.vy=0;player.knockVx=player.knockVz=0;player.grounded=false;camera.position.set(player.x,player.y+1.57,player.z);dirtySave=true;},applyEntityTeleport:(id,pos)=>inDimension(pos.dimension||dimension,()=>survival.inStoredEntities(pos.dimension||dimension,()=>survival.teleportCommandEntity(id,pos))),onChestView:setChestOpen,sharedState:()=>({openChests:save.openChests||{},endGateways:save.endGateways||[],tick,weather:save.weather,dragonDefeated:save.dragonDefeated,endEyes:save.endEyes,destroyedEndCrystals:save.destroyedEndCrystals,dimension,redstone:[...redstoneLevels],redstoneByDimension:Object.fromEntries(redstoneByDimension),openDoors:save.openDoors||{},redstoneData:save.redstoneExtra||{}}),
 applyState:state=>{if(!state)return;if(state.openChests)for(const [cell,open] of Object.entries(state.openChests))if(!!save.openChests?.[cell]!==!!open)setChestOpen(cell,open);const previousDoors=save.openDoors||{};if(Number.isFinite(state.tick))tick=state.tick;for(const k of ['endGateways','weather','dragonDefeated','endEyes','destroyedEndCrystals','openDoors','redstoneExtra'])if(state[k]!==undefined)save[k]=state[k];if(state.openDoors){for(const cell of new Set([...Object.keys(previousDoors),...Object.keys(state.openDoors)]))if(!!previousDoors[cell]!==!!state.openDoors[cell])updateDoorModelImmediately(...cell.split(',').map(Number))}if(state.redstoneByDimension&&typeof state.redstoneByDimension==='object'){redstoneByDimension.clear();for(const [dim,entries] of Object.entries(state.redstoneByDimension))if(['overworld','nether','end'].includes(dim)&&Array.isArray(entries))redstoneByDimension.set(dim,entries.filter(([k,v])=>typeof k==='string'&&Number.isFinite(v)&&Math.abs(v)<=15));}if(state.dimension===dimension){const entries=Array.isArray(state.redstone)?state.redstone:redstoneByDimension.get(dimension);if(entries){const next=new Map(entries.filter(([k,v])=>typeof k==='string'&&Number.isFinite(v)&&Math.abs(v)<=15));const dirty=new Set([...redstoneLevels.keys(),...next.keys()].filter(k=>(redstoneLevels.get(k)||0)!==(next.get(k)||0)));redstoneLevels.clear();for(const [k,v] of next)redstoneLevels.set(k,v);for(const cell of dirty){const xyz=cell.split(',').map(Number);if(instantModelTypes.has(getBlock(...xyz))){updateBlockModelImmediately(...xyz);continue;}const [x,,z]=xyz;scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))),false)}}}survival.syncCrystals()},
 validBlock:id=>id===AIR||!!BLOCKS[id],
 fluidState:(dim,x,y,z)=>save.fluidStates[dim]?.[editKey(x,y,z)]??null,
 applyEdit:data=>{
  const {x,y,z,block}=data,k=editKey(x,y,z),local=data.dimension===dimension&&chunks.has(key(Math.floor(x/SIZE),Math.floor(z/SIZE)));
  if(local){if(getBlock(x,y,z)!==block)setBlock(x,y,z,block);}
  else{const target=data.dimension==='overworld'?save.edits:(save.dimensionEdits[data.dimension]??={});target[k]=block;}
  const states=save.fluidStates[data.dimension]??={};
  if(block===WATER||block===LAVA){const state=data.fluid??0;states[k]=state;if(local){flowSources.delete(k);flowLevels.delete(k);flowFalling.delete(k);if(state===0)flowSources.add(k);else{flowLevels.set(k,Math.min(8,state));if(state>8)flowFalling.add(k);}scheduleBlockMesh(x,y,z);}}
  else delete states[k];
 },
 metadata:()=>Object.fromEntries(['chests','machineSlots','machineJobs','machineFuel','machineBrewFuel','machineNames','endEyes','snowLayers','levers','pistonDirections','redstoneTorchSupports','railDirections','redstoneFacing','redstoneDelay','redstoneModes','redstoneExtra'].flatMap(namespace=>Object.entries(save[namespace]||{}).map(([k,value])=>[namespace+'|'+k,value]))),
 applyMetadata:(id,value)=>{const [namespace,k]=id.split('|');if(!['chests','machineSlots','machineJobs','machineFuel','machineBrewFuel','machineNames','endEyes','snowLayers','levers','pistonDirections','redstoneTorchSupports','railDirections','redstoneFacing','redstoneDelay','redstoneModes','redstoneExtra','fluidStates'].includes(namespace)||!k||['__proto__','constructor','prototype'].includes(k))return;save[namespace]??={};if(value===null)delete save[namespace][k];else save[namespace][k]=value;if(namespace==='fluidStates'&&k===dimension){for(const [cell,state] of Object.entries(value||{})){flowSources.delete(cell);flowLevels.delete(cell);flowFalling.delete(cell);if(state===0)flowSources.add(cell);else{flowLevels.set(cell,Math.min(8,state));if(state>8)flowFalling.add(cell)}scheduleBlockMesh(...cell.split(',').map(Number))}}const xyz=k.split(':').at(-1).split(',').map(Number);if(xyz.length===3&&xyz.every(Number.isFinite)){if(namespace==='levers')updateBlockModelImmediately(...xyz);else scheduleBlockMesh(...xyz)}},
 drops:()=>survival.networkDrops(),syncDrops:d=>survival.syncNetworkDrops(d),spawnDrop:(args,dim=dimension)=>inDimension(dim,()=>survival.inStoredEntities(dim,()=>survival.drop(...args))),collectDrop:(id,dim=dimension)=>inDimension(dim,()=>survival.inStoredEntities(dim,()=>survival.networkCollect(id))),takeDrops:()=>survival.networkPickupRequests(),grantDrop:data=>survival.networkGrant(data),
 dimensionEntities:()=>survival.dimensionSnapshots(),syncDimensionEntities:(dim,list)=>inDimension(dim,()=>survival.syncStoredDimension(dim,'mobs',list)),syncDimensionDrops:(dim,list)=>inDimension(dim,()=>survival.syncStoredDimension(dim,'drops',list)),entities:()=>survival.networkEntities(),syncEntities:entities=>survival.syncNetworkEntities(entities),entityHits:()=>survival.networkHits(),hitEntity:(hit,dim=dimension)=>inDimension(dim,()=>survival.inStoredEntities(dim,()=>survival.networkHit(hit)))
});
mobile=createMobileControls({canvas,keys,notify:showToast,releaseUse:()=>{blocking=false;survival.releaseBow()},playing:()=>playing,look:(dx,dy)=>{player.yaw-=dx;player.pitch=Math.max(-1.5,Math.min(1.5,player.pitch-dy))},mine:on=>{if(on)playerAction(0);else{mining.active=false;mining.progress=0;miningTrack.classList.remove('active')}},exitVehicle:()=>{if(vehicle)dismountVehicle()},action:action=>{if(action==='closeInventory')survival.closeInventory();else if(action==='pause')pause();else if(action==='inventory'&&save.mode!=='spectator')survival.openInventory(false);else if(action==='command')openCommand();else if(action==='use')playerAction(2);else if(action==='flight'&&save.mode==='creative'){player.flight=!player.flight;player.vy=0}}});

let hudAt=0;

const resourceNames=Object.fromEntries(Object.entries(contentIds).map(([name,id])=>[id,name.toLowerCase()]));
const resourceAliases={GRASS:'grass_block',WOOD:'oak_log',LEAVES:'oak_leaves',PLANKS:'oak_planks',TABLE:'crafting_table',COAL:'coal_ore',IRON:'iron_ore',BRICK:'bricks',PICKAXE:'wooden_pickaxe',SWORD:'wooden_sword',RAW_MEAT:'beef',COOKED_MEAT:'cooked_beef',WOOL:'white_wool',SNOW:'snow',MOSSY_BRICKS:'mossy_stone_bricks',END_FRAME:'end_portal_frame',PURPUR:'purpur_block',FLINT_STEEL:'flint_and_steel',BED:'red_bed',DOOR:'oak_door',DOOR_TOP:'oak_door',SAPLING:'oak_sapling',WHEAT_CROP:'wheat',REDSTONE_WIRE:'redstone_wire',COAL_ITEM:'coal',WOOD_AXE:'wooden_axe',WOOD_SHOVEL:'wooden_shovel',WOOD_HOE:'wooden_hoe'};
for(const [key,name] of Object.entries(resourceAliases))resourceNames[contentIds[key]]=name;
extraBlocks.forEach((name,index)=>resourceNames[EXTRA_BASE+index]=name);for(const b of structureAssets.blocks)resourceNames[b.id]=b.minecraftId;
const resourcePacks=createResourcePacks(THREE,{loading,pause,items:ITEMS,blocks:BLOCKS,names:resourceNames,properties:Object.fromEntries(structureAssets.blocks.map(b=>[b.id,b.properties||{}])),atlasMap,materials,registry:blockRegistry,modelTypes:modelBlockTypes,clearUV:()=>atlasUVCache.clear(),entityAppearance:survival.entityAppearance,setPlayerSkin:url=>setPlayerSkin(THREE,url),replaceSound,
state:(id,{x,y,z})=>{const k=editKey(x,y,z),state=redstoneData()[k]||{},facing=state.facing||[0,-1],name=cardinalName([facing[0],facing.length===3?facing[2]:facing[1]]),powered=!!redstoneLevels.get(k),support=state.support||[0,-1,0],info=doorInfo(id);return {facing:state.facing?name:structureAssets.blocks.find(b=>b.id===id)?.properties?.facing||'north',powered:String(!!(powered||id===LEVER&&save.levers[k])),lit:String(powered),open:String(!!save.openDoors?.[k]),face:support[1]===0?'wall':support[1]>0?'ceiling':'floor',hinge:state.hinge||'left',half:info?.half||'lower',layers:String(snowLayerCount(x,y,z)),axis:state.axis||'y',eye:String(hasEndEye(x,y,z)),part:id===BED?bedState(x,y,z).bedPart:'foot',...Object.fromEntries(Object.entries(wireConnections(x,y,z)))};},
refresh:async()=>{outlineCache.clear();firstPerson.invalidate();survival.refresh();updateHotbar();for(const chunk of chunks.values()){chunk.meshComplete=false;scheduleChunkMesh(chunk,false);}resetPortalPreview();invalidateDynamicIcons(ITEMS);firstPerson.invalidate();survival.refreshItemIcons();survival.refresh();updateHotbar();}
});
if(window.__VF_TEST__)window.__VF_TEST__.resourcePacks=resourcePacks;
resourcePacks.restore().finally(()=>requestAnimationFrame(frame));
