/** world access subsystem. Dependencies are injected at composition time. */
export function createWorldAccessSystem($context) {
function key(cx,cz){return cx+','+cz}

function editKey(x,y,z){return x+','+y+','+z}

function currentEdits(){return $context.dimension==='overworld'?$context.save.edits:($context.save.dimensionEdits[$context.dimension]??={})}

function currentFluidStates(){return $context.save.fluidStates[$context.dimension]??={}}

function idx(x,y,z){
    const {MIN_Y,SIZE} = $context;
return (y-MIN_Y)*SIZE*SIZE+z*SIZE+x}

function skyExposed(x,y,z){
    const {BLOCKS,MAX_Y,MIN_Y,SIZE,entityWorldChunks,getBlock,idx,key} = $context;

  const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=entityWorldChunks().get(key(cx,cz));
  if(!chunk){for(let yy=y;yy<MAX_Y;yy++)if(BLOCKS[getBlock(x,yy,z)]?.solid)return false;return true;}
  if(!chunk.skyColumns)chunk.skyColumns=new Int16Array(SIZE*SIZE).fill(-32768);
  const lx=x-cx*SIZE,lz=z-cz*SIZE,column=lz*SIZE+lx;
  let top=chunk.skyColumns[column];
  if(top===-32768){top=MIN_Y-1;for(let yy=Math.min(MAX_Y-1,chunk.topY);yy>=MIN_Y;yy--)if(BLOCKS[chunk.blocks[idx(lx,yy,lz)]]?.solid){top=yy;break;}chunk.skyColumns[column]=top;}
  return y>top;
}

function getBlock(x,y,z){
    const {AIR,BEDROCK,DEEPSLATE,DIRT,END_STONE,GRASS,MAX_Y,MIN_Y,SAND,SEA,SIZE,SNOW,STONE,WATER,biome,currentEdits,editKey,entityWorldChunks,idx,key,netherBase,netherBiome,netherCeiling,terrain} = $context;
if(y<MIN_Y)return $context.dimension==='end'?AIR:BEDROCK;if(y>=MAX_Y)return AIR;const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=entityWorldChunks().get(key(cx,cz));if(chunk)return chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)];const edited=currentEdits()[editKey(x,y,z)];if(edited!==undefined)return edited;const h=terrain(x,z);if($context.dimension==='end')return h>=0&&y<=h&&y>=h-13?END_STONE:AIR;if($context.dimension==='nether')return netherBase(x,y,z,h,netherBiome(x,z),netherCeiling(x,z));if(y===MIN_Y)return BEDROCK;const b=biome(x,z);if(y>h)return y<=SEA?WATER:y===h+1&&h>SEA+1&&['snow','snowy_slopes','frozen_peaks','grove'].includes(b)?SNOW:AIR;if(y===h)return b==='desert'||h<=SEA+1?SAND:['snowy_slopes','frozen_peaks','jagged_peaks','stony_peaks'].includes(b)?STONE:GRASS;if(y>h-4)return b==='desert'||h<=SEA+1?SAND:['snowy_slopes','frozen_peaks','jagged_peaks','stony_peaks'].includes(b)?STONE:DIRT;return y<0?DEEPSLATE:STONE}

function snowLayerCount(x,y,z){
    const {SNOW,editKey,getBlock} = $context;
return getBlock(x,y,z)===SNOW?Math.max(1,Math.min(8,$context.save.snowLayers[$context.dimension+':'+editKey(x,y,z)]||1)):0}

function setSnowLayers(x,y,z,layers){
    const {SIZE,SNOW,chunks,editKey,getBlock,key,scheduleChunkMesh} = $context;
if(getBlock(x,y,z)!==SNOW)return false;const count=Math.max(1,Math.min(8,layers)),k=$context.dimension+':'+editKey(x,y,z);if(count===1)delete $context.save.snowLayers[k];else $context.save.snowLayers[k]=count;scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))));$context.dirtySave=true;return true}

function updateSnowAround(x,y,z,type){
    const {AIR,FIRE,GLOWSTONE,LAVA,SNOW,TORCH,getBlock,occludes,setBlock} = $context;
if(!occludes(type)&&getBlock(x,y+1,z)===SNOW)setBlock(x,y+1,z,AIR);if(![TORCH,GLOWSTONE,LAVA,FIRE].includes(type))return;const range=type===TORCH?2:3;for(let dy=-range;dy<=range;dy++)for(let dz=-range;dz<=range;dz++)for(let dx=-range;dx<=range;dx++)if(Math.abs(dx)+Math.abs(dy)+Math.abs(dz)<=range&&getBlock(x+dx,y+dy,z+dz)===SNOW)setBlock(x+dx,y+dy,z+dz,AIR)}

function setBlock(x,y,z,type){
    const {AIR,CALIBRATED_SCULK_SENSOR,CROP_0,CROP_1,CROP_2,END_FRAME,END_PORTAL,FIRE,GLOW_BERRIES,LAVA,MAX_Y,MIN_Y,NETHER_PORTAL,PISTON,PISTON_HEAD,RAIL_TYPES,REDSTONE_COMPONENTS,REDSTONE_TORCH,SAPLING,SCULK_SENSOR,SIZE,STICKY_PISTON,TWISTING_VINES,WATER,WEEPING_VINES,chunks,currentEdits,currentFluidStates,editKey,fireCells,flowFalling,flowLevels,flowSources,getBlock,growthCells,hopperAt,idx,key,notifyObservers,pistonDirection,pistonPowered,player,portalCells,queueAround,queueGravity,redstoneCells,redstoneData,redstoneEdge,scheduleBlockMesh,scheduleEditLighting,sensorCells,sensorFrequency,sensorUntil,setBackgroundBlock,spreadCache,targetUntil,torchBurnedUntil,torchPending,torchStates,torchSwitches,tripwireUntil,updateSnowAround} = $context;
if($context.entityWorldContext)return setBackgroundBlock(x,y,z,type);if(y<MIN_Y+1||y>=MAX_Y)return false;const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=chunks.get(key(cx,cz));if(!chunk)return false;const k=editKey(x,y,z),old=getBlock(x,y,z);if(old!==type){if(old===END_FRAME){$context.save.endEyes[$context.dimension+':'+k]=false;if($context.dimension==='overworld')delete $context.save.endEyes[k]}delete redstoneData()[k];redstoneEdge.delete(k);sensorUntil.delete(k);sensorFrequency.delete(k);targetUntil.delete(k);tripwireUntil.delete(k);hopperAt.delete(k)}if(old!==type&&(old===PISTON||old===STICKY_PISTON)){const [dx,dy,dz]=pistonDirection(k);if(getBlock(x+dx,y+dy,z+dz)===PISTON_HEAD)setBlock(x+dx,y+dy,z+dz,AIR);delete $context.save.pistonDirections[k];pistonPowered.delete(k)}if(old!==type&&old===REDSTONE_TORCH){delete $context.save.redstoneTorchSupports[k];torchStates.delete(k);torchPending.delete(k);torchSwitches.delete(k);torchBurnedUntil.delete(k)}chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)]=type;if(type===NETHER_PORTAL||type===END_PORTAL)portalCells.add(k);else portalCells.delete(k);if(type!==AIR)chunk.topY=Math.max(chunk.topY,y+1);delete $context.save.snowLayers[$context.dimension+':'+k];if(RAIL_TYPES.has(type))$context.save.railDirections[$context.dimension+':'+k]=Math.abs(Math.sin(player.yaw))>Math.abs(Math.cos(player.yaw))?'x':'z';else delete $context.save.railDirections[$context.dimension+':'+k];flowLevels.delete(k);flowSources.delete(k);flowFalling.delete(k);spreadCache.clear();if(type===WATER||type===LAVA){flowSources.add(k);currentFluidStates()[k]=0}else delete currentFluidStates()[k];if(type===SAPLING||type===CROP_0||type===CROP_1||type===CROP_2||type===GLOW_BERRIES||type===TWISTING_VINES||type===WEEPING_VINES)growthCells.add(k);else growthCells.delete(k);if(type!==old)delete $context.save.growthStopped[k];if(type===FIRE&&old!==FIRE)fireCells.set(k,0);else if(type!==FIRE)fireCells.delete(k);currentEdits()[k]=type;if(REDSTONE_COMPONENTS.has(type))redstoneCells.add(k);else redstoneCells.delete(k);if(type===SCULK_SENSOR||type===CALIBRATED_SCULK_SENSOR)sensorCells.add(k);else sensorCells.delete(k);$context.dirtySave=true;scheduleBlockMesh(x,y,z);scheduleEditLighting(chunk);if(x-cx*SIZE===0)scheduleEditLighting(chunks.get(key(cx-1,cz)));if(x-cx*SIZE===SIZE-1)scheduleEditLighting(chunks.get(key(cx+1,cz)));if(z-cz*SIZE===0)scheduleEditLighting(chunks.get(key(cx,cz-1)));if(z-cz*SIZE===SIZE-1)scheduleEditLighting(chunks.get(key(cx,cz+1)));queueAround(x,y,z,true);queueGravity(x,y,z,true);queueGravity(x,y+1,z,true);updateSnowAround(x,y,z,type);if(type!==old){notifyObservers(x,y,z);$context.multiplayer?.publishEdit(x,y,z,type)}return true}

function setBlockBatch(edits){
    const {AIR,CALIBRATED_SCULK_SENSOR,CROP_0,CROP_1,CROP_2,END_PORTAL,GLOW_BERRIES,LAVA,MAX_Y,MIN_Y,NETHER_PORTAL,RAIL_TYPES,REDSTONE_COMPONENTS,REDSTONE_TORCH,SAPLING,SCULK_SENSOR,SIZE,TWISTING_VINES,WATER,WEEPING_VINES,chunks,currentEdits,currentFluidStates,editKey,flowFalling,flowLevels,flowSources,getBlock,growthCells,hopperAt,idx,key,notifyObservers,portalCells,queueAround,queueGravity,redstoneCells,redstoneData,redstoneEdge,scheduleBlockMesh,scheduleEditLighting,sensorCells,sensorFrequency,sensorUntil,setBackgroundBlock,spreadCache,targetUntil,torchBurnedUntil,torchPending,torchStates,torchSwitches,tripwireUntil} = $context;
if($context.entityWorldContext)return edits.reduce((n,args)=>n+Number(setBackgroundBlock(...args)),0);const affected=new Set();let count=0;for(const [x,y,z,type] of edits){if(y<MIN_Y+1||y>=MAX_Y)continue;const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=chunks.get(key(cx,cz));if(!chunk||getBlock(x,y,z)===type)continue;chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)]=type;const cell=editKey(x,y,z);if(type===NETHER_PORTAL||type===END_PORTAL)portalCells.add(cell);else portalCells.delete(cell);if(type!==AIR)chunk.topY=Math.max(chunk.topY,y+1);delete redstoneData()[cell];redstoneEdge.delete(cell);sensorUntil.delete(cell);sensorFrequency.delete(cell);targetUntil.delete(cell);tripwireUntil.delete(cell);hopperAt.delete(cell);if(type!==REDSTONE_TORCH&&$context.save.redstoneTorchSupports[cell]){delete $context.save.redstoneTorchSupports[cell];torchStates.delete(cell);torchPending.delete(cell);torchSwitches.delete(cell);torchBurnedUntil.delete(cell)}delete $context.save.snowLayers[$context.dimension+':'+cell];if(!RAIL_TYPES.has(type))delete $context.save.railDirections[$context.dimension+':'+cell];delete $context.save.growthStopped[cell];flowLevels.delete(cell);flowSources.delete(cell);flowFalling.delete(cell);spreadCache.clear();if(type===WATER||type===LAVA){flowSources.add(cell);currentFluidStates()[cell]=0}else delete currentFluidStates()[cell];if(type===SAPLING||type===CROP_0||type===CROP_1||type===CROP_2||type===GLOW_BERRIES||type===TWISTING_VINES||type===WEEPING_VINES)growthCells.add(cell);else growthCells.delete(cell);currentEdits()[cell]=type;if(REDSTONE_COMPONENTS.has(type))redstoneCells.add(cell);else redstoneCells.delete(cell);if(type===SCULK_SENSOR||type===CALIBRATED_SCULK_SENSOR)sensorCells.add(cell);else sensorCells.delete(cell);queueAround(x,y,z,true);queueGravity(x,y+1,z,true);affected.add(key(cx,cz));if(x-cx*SIZE===0)affected.add(key(cx-1,cz));if(x-cx*SIZE===SIZE-1)affected.add(key(cx+1,cz));if(z-cz*SIZE===0)affected.add(key(cx,cz-1));if(z-cz*SIZE===SIZE-1)affected.add(key(cx,cz+1));scheduleBlockMesh(x,y,z);$context.multiplayer?.publishEdit(x,y,z,type);notifyObservers(x,y,z);count++}for(const k of affected)scheduleEditLighting(chunks.get(k));if(count)$context.dirtySave=true;return count}
return {key,editKey,currentEdits,currentFluidStates,idx,skyExposed,getBlock,snowLayerCount,setSnowLayers,updateSnowAround,setBlock,setBlockBatch};
}
