/** Live bindings shared by subsystem factories. Never copy mutable world state. */
export function createSystemContext(readers, writers = {}) {
  const context = Object.create(null);
  for (const [name, get] of Object.entries(readers))
    Object.defineProperty(context, name, {get, set: writers[name], enumerable: true});
  return context;
}
