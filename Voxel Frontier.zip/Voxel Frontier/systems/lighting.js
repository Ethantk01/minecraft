/** lighting subsystem. Dependencies are injected at composition time. */
export function createLightingSystem($context) {
function* computeLightingTask(chunk,lowerBound=$context.MIN_Y,upperBound=$context.MAX_Y-1){
    const {BIRCH_LEAVES,COPPER_BULB,ENCHANTING_TABLE,FIRE,GLOWSTONE,GLOW_BERRIES,LAVA,LEAVES,MAX_Y,MIN_Y,REDSTONE_LAMP,REDSTONE_TORCH,SCULK_SENSOR,SHROOMLIGHT,SIZE,SPRUCE_LEAVES,TORCH,WATER,editKey,idx,lightDirections,occludes,redstoneData,redstoneLevels,sensorUntil,torchStates} = $context;

  const revision=chunk.lightingRevision||0,band=$context.dimension==='overworld'?$context.lightDay:0;
  const blocks=chunk.blocks,light=new Uint8Array(blocks.length),queue=[],top=Math.min(MAX_Y-1,chunk.topY+16);
  for(let z=0;z<SIZE;z++){for(let x=0;x<SIZE;x++){let sky=$context.dimension==='overworld'?$context.lightDay:0;for(let y=top;y>=lowerBound;y--){
    const i=idx(x,y,z),type=blocks[i];if(occludes(type))sky=0;else if(type===WATER||type===LEAVES||type===SPRUCE_LEAVES||type===BIRCH_LEAVES)sky=Math.max(0,sky-2);
    if(y>upperBound)continue;
    light[i]=sky;if(sky>1&&!occludes(type)&&y<=chunk.topY+2)queue.push(i);
    const emit=type===TORCH||type===GLOW_BERRIES?14:type===LAVA||type===GLOWSTONE||type===SHROOMLIGHT||type===FIRE?15:type===ENCHANTING_TABLE||type===REDSTONE_TORCH&&torchStates.get(editKey(chunk.cx*SIZE+x,y,chunk.cz*SIZE+z))!==false?7:type===REDSTONE_LAMP&&redstoneLevels.get(editKey(chunk.cx*SIZE+x,y,chunk.cz*SIZE+z))?15:type===COPPER_BULB&&redstoneData()[editKey(chunk.cx*SIZE+x,y,chunk.cz*SIZE+z)]?.lit?15:type===SCULK_SENSOR&&(sensorUntil.get(editKey(chunk.cx*SIZE+x,y,chunk.cz*SIZE+z))||0)>performance.now()?6:0;
    if(emit){light[i]=Math.max(light[i],emit);queue.push(i)}
  }}yield}
  for(let head=0;head<queue.length;head++){
    if((head&2047)===2047)yield;
    const at=queue[head],value=light[at];if(value<=1)continue;
    const row=Math.floor(at/(SIZE*SIZE)),y=row+MIN_Y,rem=at-row*SIZE*SIZE,z=Math.floor(rem/SIZE),x=rem-z*SIZE;
    for(const [dx,dy,dz] of lightDirections){const nx=x+dx,ny=y+dy,nz=z+dz;if(nx<0||nx>=SIZE||ny<lowerBound||ny>upperBound||nz<0||nz>=SIZE)continue;
      const ni=idx(nx,ny,nz);if(occludes(blocks[ni])||light[ni]>=value-1)continue;light[ni]=value-1;queue.push(ni)}
  }
  chunk.light=light;chunk.lightRevision=revision;chunk.lightBand=band;chunk.lightMinY=lowerBound;chunk.lightMaxY=upperBound;
}

function computeLighting(chunk,lowerBound=$context.MIN_Y,upperBound=$context.MAX_Y-1){
    const {computeLightingTask} = $context;
for(const _ of computeLightingTask(chunk,lowerBound,upperBound)){} }

function refreshTorchLights(){
    const {MAX_Y,MIN_Y,TORCH,getBlock,player,torchLights} = $context;
let found=0;const px=Math.floor(player.x),py=Math.floor(player.y),pz=Math.floor(player.z);for(let y=Math.max(MIN_Y,py-8);y<=Math.min(MAX_Y-1,py+8)&&found<torchLights.length;y++)for(let z=pz-10;z<=pz+10&&found<torchLights.length;z++)for(let x=px-10;x<=px+10&&found<torchLights.length;x++)if(getBlock(x,y,z)===TORCH){const light=torchLights[found++];light.position.set(x+.5,y+.7,z+.5);light.visible=true}for(let i=found;i<torchLights.length;i++)torchLights[i].visible=false}

function getLightLevel(x,y,z){
    const {MAX_Y,MIN_Y,SIZE,entityWorldChunks,idx,key,terrain} = $context;
if(y<MIN_Y||y>=MAX_Y)return 0;const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=entityWorldChunks().get(key(cx,cz));if(chunk&&y>chunk.topY+16)return $context.dimension==='overworld'?$context.lightDay:0;return chunk?.light?.[idx(x-cx*SIZE,y,z-cz*SIZE)]??($context.dimension==='overworld'&&y>terrain(x,z)?$context.lightDay:0)}

function solid(x,y,z){
    const {BLOCKS,LEATHER_BOOTS,POWDER_SNOW,SNOW,doorInfo,editKey,getBlock,isDoor,player,snowLayerCount} = $context;
const b=getBlock(x,y,z);if(b===$context.BIG_DRIPLEAF&&$context.gameplayRepairs?.leafAngle(x,y,z)>=60)return false;const custom=$context.blockRegistry.dispatch('collision',b,{x,y,z,player});if(custom.handled)return custom.value;if(isDoor(b))return !$context.save.openDoors?.[editKey(x,doorInfo(b).half==='upper'?y-1:y,z)];if(b===SNOW)return snowLayerCount(x,y,z)>1;if(b===POWDER_SNOW)return $context.save.armor?.boots===LEATHER_BOOTS&&player.y>=y+.9;return !!BLOCKS[b]?.solid}

function colorFor(type,face,x,y,z){
    const {BIRCH_LEAVES,BLOCKS,GRASS,LEAVES,REDSTONE_LAMP,REDSTONE_WIRE,SPRUCE_LEAVES,WATER,biome,editKey,faces,getLightLevel,hash,meshColor,redstoneLevels} = $context;

  const tinted=(type===GRASS||BLOCKS[type]?.minecraftId==='grass_block')&&face===2||type===LEAVES||type===SPRUCE_LEAVES||type===BIRCH_LEAVES||BLOCKS[type]?.minecraftId?.endsWith('_leaves'),b=tinted?biome(x,z):null,foliage=b==='desert'?0xffedc4:['snow','snowy_slopes','frozen_peaks','grove'].includes(b)?0xddfff0:b==='forest'?0xd6f8cc:['jagged_peaks','stony_peaks'].includes(b)?0xe1f4d3:b==='meadow'?0xd3f2a4:0xe6ffd6;
  const color=meshColor.setHex(tinted?foliage:type===WATER?0x75a9c7:0xffffff);
  if(type===REDSTONE_WIRE)color.setHex(redstoneLevels.get(editKey(x,y,z))?0xff5550:0x682020);
  if(type===REDSTONE_LAMP&&redstoneLevels.get(editKey(x,y,z)))color.multiplyScalar(1.65);
  const variation=.95+hash(x+y*7,z-y*3,44)*.09;
  const direction=faces[face].d,level=getLightLevel(x+direction[0],y+direction[1],z+direction[2]);
  color.multiplyScalar(faces[face].shade*variation*($context.dimension==='nether'?.82+.18*level/15:.18+.82*level/15));
  return color;
}
return {computeLightingTask,computeLighting,refreshTorchLights,getLightLevel,solid,colorFor};
}
