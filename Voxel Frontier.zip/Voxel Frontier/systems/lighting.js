import {blockEmission,isDynamicEmitter} from '../light-rules.js';
import structureAssets from '../structure-assets.json';
/** lighting subsystem. Dependencies are injected at composition time. */
export function createLightingSystem($context) {
const staticEmission=new Map(),dynamicEmitters=new Map(),propertyMap=new Map(structureAssets.blocks.map(block=>[block.id,block.properties||{}]));
function emittedLight(type,x,y,z){if(staticEmission.has(type))return staticEmission.get(type);const c=$context,k=c.editKey(x,y,z),name=(c.BLOCKS[type]?.minecraftId||c.BLOCKS[type]?.name?.toLowerCase().replaceAll(' ','_')||'').replace(/^minecraft:/,''),dynamic=isDynamicEmitter(name);if(!dynamic&&staticEmission.has(type))return staticEmission.get(type);
 const state={...propertyMap.get(type),...c.redstoneData()[k]},special={};
 if(type===c.REDSTONE_TORCH)special.lit=c.torchStates.get(k)!==false;
 if(type===c.REDSTONE_LAMP)special.lit=!!c.redstoneLevels.get(k);
 if(type===c.COPPER_BULB)special.lit=!!c.redstoneData()[k]?.lit;
 if(type===c.SCULK_SENSOR||type===c.CALIBRATED_SCULK_SENSOR)special.active=(c.sensorUntil.get(k)||0)>performance.now();
 if(['furnace','blast_furnace','smoker'].includes(name)){const machine=c.dimension+':'+k;if(c.save.machineFuel?.[machine]!==undefined)special.lit=c.save.machineFuel[machine]>0;}
 const value=blockEmission(name,{...state,...special});if(!dynamic)staticEmission.set(type,value);else dynamicEmitters.set(c.dimension+':'+k,{type,x,y,z,value,dimension:c.dimension});return value;
}
function refreshEmissionChanges(){const c=$context;for(const [key,entry]of dynamicEmitters){if(entry.dimension!==c.dimension)continue;const chunk=c.entityWorldChunks().get(c.key(Math.floor(entry.x/c.SIZE),Math.floor(entry.z/c.SIZE)));if(!chunk||c.getBlock(entry.x,entry.y,entry.z)!==entry.type){dynamicEmitters.delete(key);continue;}const value=emittedLight(entry.type,entry.x,entry.y,entry.z);if(value!==entry.value)updateLightingAt(entry.x,entry.y,entry.z);}}

// Relax only cells affected by an edit. Both increasing and decreasing light converge
// to direct sky/emission plus attenuated neighbors; no chunk scan or mesh rebuild.
function updateLightingAt(x,y,z){
 const c=$context,{SIZE,MIN_Y,MAX_Y,idx,key}=c,world=c.portalPreviewMode?c.portalPreviewChunks:c.entityWorldChunks();
 const cell=(x,y,z)=>{if(y<MIN_Y||y>=MAX_Y)return null;const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=world.get(key(cx,cz));return chunk?.directSkyLight?{chunk,at:idx(x-cx*SIZE,y,z-cz*SIZE)}:null;};
 const origin=cell(x,y,z);if(!origin)return false;
 const queue=[],queued=new Set(),affected=new Map(),directions=c.lightDirections,add=(x,y,z)=>{const k=c.editKey(x,y,z);if(!queued.has(k)&&cell(x,y,z)){queued.add(k);queue.push([x,y,z,k]);}};
 let sky=c.dimension==='overworld'?15:0;for(let py=MAX_Y-1;py>=MIN_Y;py--){const at=idx(x-origin.chunk.cx*SIZE,py,z-origin.chunk.cz*SIZE),type=origin.chunk.blocks[at];if(c.occludes(type))sky=0;else if(type===c.WATER||/leaves/i.test(c.BLOCKS[type]?.minecraftId||c.BLOCKS[type]?.name||''))sky=Math.max(0,sky-(type===c.WATER?2:1));if(origin.chunk.directSkyLight[at]!==sky){origin.chunk.directSkyLight[at]=sky;add(x,py,z);}}
 add(x,y,z);for(const [dx,dy,dz]of directions)add(x+dx,y+dy,z+dz);
 for(let head=0;head<queue.length;head++){const [px,py,pz,k]=queue[head];queued.delete(k);const current=cell(px,py,pz);if(!current)continue;const {chunk,at}=current,type=chunk.blocks[at],blocked=c.occludes(type),loss=type===c.WATER?2:1;let sky=chunk.directSkyLight[at],block=emittedLight(type,px,py,pz);if(!blocked)for(const [dx,dy,dz]of directions){const n=cell(px+dx,py+dy,pz+dz);if(n){sky=Math.max(sky,n.chunk.skyLight[n.at]-loss);block=Math.max(block,n.chunk.blockLight[n.at]-loss);}}else sky=0;
 if(sky===chunk.skyLight[at]&&block===chunk.blockLight[at])continue;chunk.skyLight[at]=sky;chunk.blockLight[at]=block;chunk.light[at]=Math.max(block,Math.max(0,sky-(15-(c.dimension==='overworld'?c.lightDay:0))));
 // Faces may belong to a neighboring chunk/section while sampling this cell.
 for(const [dx,dy,dz]of [[0,0,0],...directions]){const n=cell(px+dx,py+dy,pz+dz);if(n){if(!affected.has(n.chunk))affected.set(n.chunk,new Set());affected.get(n.chunk).add(Math.floor((py+dy)/16));}}
 for(const [dx,dy,dz]of directions)add(px+dx,py+dy,pz+dz);
 }
 for(const [chunk,sections]of affected)for(const mesh of chunk.meshes)if(sections.has(mesh.userData.sectionY))applyGridLighting(mesh.geometry);
 if(c.pendingEditLighting){const pending=c.pendingEditLighting.chunk;c.editLightingQueue?.set(key(pending.cx,pending.cz),pending);c.pendingEditLighting=null;}
 return true;
}

function* computeLightingTask(chunk,lowerBound=$context.MIN_Y,upperBound=$context.MAX_Y-1,regional=false){
 const {SIZE,MIN_Y,MAX_Y,idx,key,lightDirections,occludes,WATER}= $context;
 const world=$context.portalPreviewMode?$context.portalPreviewChunks:$context.entityWorldChunks(),cells=chunk.blocks.length,records=[],lookup=new Map(),blockedCache=new Map();
 const blocked=type=>{if(!blockedCache.has(type))blockedCache.set(type,occludes(type));return blockedCache.get(type);};
 for(let dz=regional?-1:0;dz<=(regional?1:0);dz++)for(let dx=regional?-1:0;dx<=(regional?1:0);dx++){const c=world.get(key(chunk.cx+dx,chunk.cz+dz));if(c){lookup.set(key(c.cx,c.cz),records.length);records.push({chunk:c,sky:new Uint8Array(cells),block:new Uint8Array(cells),revision:c.lightingRevision||0,oldSky:c.skyLight,oldBlock:c.blockLight});}}
 const skyQueue=[],blockQueue=[],band=$context.dimension==='overworld'?$context.lightDay:0;
 const emission=(type,x,y,z)=>emittedLight(type,x,y,z);
 for(let r=0;r<records.length;r++){const rec=records[r],c=rec.chunk,top=Math.min(MAX_Y-1,c.topY+16);if($context.dimension==='overworld')rec.sky.fill(15,Math.max(0,(top+1-MIN_Y)*SIZE*SIZE));
  for(let z=0;z<SIZE;z++){for(let x=0;x<SIZE;x++){let sky=$context.dimension==='overworld'?15:0;for(let y=top;y>=lowerBound;y--){const at=idx(x,y,z),type=c.blocks[at];if(blocked(type))sky=0;else if(type===WATER||/leaves/i.test($context.BLOCKS[type]?.minecraftId||$context.BLOCKS[type]?.name||''))sky=Math.max(0,sky-(type===WATER?2:1));if(y>upperBound)continue;rec.sky[at]=sky;const emit=emission(type,c.cx*SIZE+x,y,c.cz*SIZE+z);if(emit){rec.block[at]=emit;blockQueue.push(r*cells+at);}}}yield;}
 }
 for(const rec of records)rec.directSky=rec.sky.slice();
 // Resolve neighbors in the entire loaded region, rather than clipping at chunk edges.
 function neighbor(r,x,y,z){if(x>=0&&x<SIZE&&z>=0&&z<SIZE)return {r,at:idx(x,y,z)};const c=records[r].chunk,cx=c.cx+Math.floor(x/SIZE),cz=c.cz+Math.floor(z/SIZE),nr=lookup.get(key(cx,cz));return {r:nr,chunk:world.get(key(cx,cz)),at:idx((x+SIZE)%SIZE,y,(z+SIZE)%SIZE)};}
 for(let r=0;r<records.length;r++){const rec=records[r],c=rec.chunk,top=Math.min(MAX_Y-1,c.topY+16);for(let y=lowerBound;y<=Math.min(upperBound,top);y++){for(let z=0;z<SIZE;z++)for(let x=0;x<SIZE;x++){const at=idx(x,y,z),type=c.blocks[at];if(blocked(type)||(!rec.sky[at]&&x>0&&x<SIZE-1&&z>0&&z<SIZE-1))continue;let spread=false;for(const [dx,dy,dz]of lightDirections){const ny=y+dy;if(ny<lowerBound||ny>upperBound)continue;const n=neighbor(r,x+dx,ny,z+dz);if(n.r!==undefined){if(rec.sky[at]>records[n.r].sky[n.at]+1&&!blocked(records[n.r].chunk.blocks[n.at]))spread=true;}else if(n.chunk){const loss=type===WATER?2:1,sky=(n.chunk.skyLight?.[n.at]||0)-loss,block=(n.chunk.blockLight?.[n.at]||0)-loss;if(sky>rec.sky[at]){rec.sky[at]=sky;spread=true;}if(block>rec.block[at]){rec.block[at]=block;blockQueue.push(r*cells+at);}}}if(spread)skyQueue.push(r*cells+at);}if((y&7)===0)yield;}}
 function* propagate(queue,channel){for(let head=0;head<queue.length;head++){if((head&2047)===2047)yield;const encoded=queue[head],r=Math.floor(encoded/cells),at=encoded-r*cells,rec=records[r],value=rec[channel][at];if(value<=1)continue;const row=Math.floor(at/(SIZE*SIZE)),y=row+MIN_Y,rem=at-row*SIZE*SIZE,z=Math.floor(rem/SIZE),x=rem-z*SIZE;for(const [dx,dy,dz]of lightDirections){const ny=y+dy;if(ny<lowerBound||ny>upperBound)continue;const n=neighbor(r,x+dx,ny,z+dz);if(n.r===undefined)continue;const target=records[n.r],type=target.chunk.blocks[n.at],next=value-(type===WATER?2:1);if(blocked(type)||target[channel][n.at]>=next)continue;target[channel][n.at]=next;queue.push(n.r*cells+n.at);}}}
 yield* propagate(skyQueue,'sky');yield* propagate(blockQueue,'block');
 for(const rec of records){const c=rec.chunk;c.directSkyLight=rec.directSky;c.skyLight=rec.sky;c.blockLight=rec.block;c.light=new Uint8Array(cells);c.changedLightSections=new Set();for(let n=0;n<cells;n++){c.light[n]=Math.max(rec.block[n],Math.max(0,rec.sky[n]-(15-band)));if(rec.oldSky?.[n]!==rec.sky[n]||rec.oldBlock?.[n]!==rec.block[n])c.changedLightSections.add(Math.floor((Math.floor(n/(SIZE*SIZE))+MIN_Y)/16));}c.lightRevision=rec.revision;c.lightBand=band;c.lightMinY=lowerBound;c.lightMaxY=upperBound;}
 chunk.updatedLightChunks=records.map(rec=>rec.chunk);
 if(!regional&&$context.scheduleEditLighting){let seam=false;for(let y=lowerBound;y<=Math.min(upperBound,chunk.topY+16)&&!seam;y++)for(let i=0;i<SIZE&&!seam;i++)for(const [x,z,dx,dz]of [[0,i,-1,0],[SIZE-1,i,1,0],[i,0,0,-1],[i,SIZE-1,0,1]]){const n=world.get(key(chunk.cx+dx,chunk.cz+dz));if(!n?.skyLight)continue;const at=idx(x,y,z),na=idx((x+dx+SIZE)%SIZE,y,(z+dz+SIZE)%SIZE);if(!blocked(n.blocks[na])&&(chunk.blockLight[at]>(n.blockLight[na]||0)+1||chunk.skyLight[at]>n.skyLight[na]+1)){seam=true;break;}}if(seam)$context.scheduleEditLighting(chunk);}

}

function computeLighting(chunk,lowerBound=$context.MIN_Y,upperBound=$context.MAX_Y-1){
    const {computeLightingTask} = $context;
for(const _ of computeLightingTask(chunk,lowerBound,upperBound)){} }

function refreshTorchLights(){
    const {MAX_Y,MIN_Y,TORCH,getBlock,player,torchLights} = $context;
let found=0;const px=Math.floor(player.x),py=Math.floor(player.y),pz=Math.floor(player.z);for(let y=Math.max(MIN_Y,py-8);y<=Math.min(MAX_Y-1,py+8)&&found<torchLights.length;y++)for(let z=pz-10;z<=pz+10&&found<torchLights.length;z++)for(let x=px-10;x<=px+10&&found<torchLights.length;x++)if(getBlock(x,y,z)===TORCH){const light=torchLights[found++];light.position.set(x+.5,y+.7,z+.5);light.visible=true}for(let i=found;i<torchLights.length;i++)torchLights[i].visible=false}

function getClientLightLevel(x,y,z){const c=$context;if(y<c.MIN_Y||y>=c.MAX_Y)return 0;const cx=Math.floor(x/c.SIZE),cz=Math.floor(z/c.SIZE),chunk=c.entityWorldChunks().get(c.key(cx,cz)),at=c.idx(x-cx*c.SIZE,y,z-cz*c.SIZE);return Math.max(chunk?.skyLight?.[at]||0,chunk?.blockLight?.[at]||0);}

function getBlockLightLevel(x,y,z){const c=$context;if(y<c.MIN_Y||y>=c.MAX_Y)return 0;const cx=Math.floor(x/c.SIZE),cz=Math.floor(z/c.SIZE),chunk=c.entityWorldChunks().get(c.key(cx,cz));return chunk?.blockLight?.[c.idx(x-cx*c.SIZE,y,z-cz*c.SIZE)]||0;}

function getLightLevel(x,y,z){
    const {MAX_Y,MIN_Y,SIZE,entityWorldChunks,idx,key,terrain} = $context;
if(y<MIN_Y||y>=MAX_Y)return 0;const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=entityWorldChunks().get(key(cx,cz));if(chunk&&y>chunk.topY+16)return $context.dimension==='overworld'?$context.lightDay:0;return (chunk?.skyLight?Math.max(chunk.blockLight[idx(x-cx*SIZE,y,z-cz*SIZE)],Math.max(0,chunk.skyLight[idx(x-cx*SIZE,y,z-cz*SIZE)]-(15-($context.dimension==='overworld'?$context.lightDay:0)))):chunk?.light?.[idx(x-cx*SIZE,y,z-cz*SIZE)])??($context.dimension==='overworld'&&y>terrain(x,z)?$context.lightDay:0)}

function applyGridLighting(geometry){
 const {THREE,SIZE,MIN_Y,MAX_Y,key,idx,entityWorldChunks,terrain}=$context,world=$context.portalPreviewMode?$context.portalPreviewChunks:entityWorldChunks(),p=geometry.attributes.position,n=geometry.attributes.normal,values=geometry.attributes.gridLight?.array||new Float32Array(p.count*2);
 for(let start=0;start<p.count;start+=4){let x=0,y=0,z=0;for(let v=start;v<Math.min(start+4,p.count);v++){x+=p.getX(v)/4;y+=p.getY(v)/4;z+=p.getZ(v)/4;}x=Math.floor(x+(n?.getX(start)||0)*.02);y=Math.floor(y+(n?.getY(start)||0)*.02);z=Math.floor(z+(n?.getZ(start)||0)*.02);const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=world.get(key(cx,cz)),at=idx(x-cx*SIZE,y,z-cz*SIZE),valid=y>=MIN_Y&&y<MAX_Y;const sky=valid&&chunk?.skyLight?chunk.skyLight[at]:$context.dimension==='overworld'&&y>terrain(x,z)?15:0,block=valid&&chunk?.blockLight?chunk.blockLight[at]:0;for(let v=start;v<Math.min(start+4,p.count);v++){values[v*2]=sky;values[v*2+1]=block;}}
 if(geometry.attributes.gridLight)geometry.attributes.gridLight.needsUpdate=true;else geometry.setAttribute('gridLight',new THREE.BufferAttribute(values,2));
}

function solid(x,y,z){
    const {BLOCKS,LEATHER_BOOTS,POWDER_SNOW,SNOW,doorInfo,editKey,getBlock,isDoor,player,snowLayerCount} = $context;
const b=getBlock(x,y,z);if(b===$context.BIG_DRIPLEAF&&$context.gameplayRepairs?.leafAngle(x,y,z)>=60)return false;const custom=$context.blockRegistry.dispatch('collision',b,{x,y,z,player});if(custom.handled)return custom.value;if(isDoor(b))return !$context.save.openDoors?.[editKey(x,doorInfo(b).half==='upper'?y-1:y,z)];if(b===SNOW)return snowLayerCount(x,y,z)>1;if(b===POWDER_SNOW)return $context.save.armor?.boots===LEATHER_BOOTS&&player.y>=y+.9;return !!BLOCKS[b]?.solid}

function colorFor(type,face,x,y,z){
    const {BIRCH_LEAVES,BLOCKS,GRASS,LEAVES,REDSTONE_LAMP,REDSTONE_WIRE,SPRUCE_LEAVES,WATER,biome,editKey,faces,getLightLevel,hash,meshColor,redstoneLevels} = $context;

  const tinted=BLOCKS[type]?.biomeTint||(type===GRASS||BLOCKS[type]?.minecraftId==='grass_block')&&face===2||type===LEAVES||type===SPRUCE_LEAVES||type===BIRCH_LEAVES||BLOCKS[type]?.minecraftId?.endsWith('_leaves'),b=tinted?biome(x,z):null,foliage=b==='desert'?0xbfb755:['snow','snowy_slopes','frozen_peaks','grove'].includes(b)?0x80a755:b==='forest'?0x77ab2f:['jagged_peaks','stony_peaks'].includes(b)?0x8eb971:b==='meadow'?0x91bd59:0x91bd59;
  const color=meshColor.setHex(tinted?foliage:type===WATER?0x75a9c7:0xffffff);
  if(type===REDSTONE_WIRE)color.setHex(redstoneLevels.get(editKey(x,y,z))?0xff5550:0x682020);
  if(type===REDSTONE_LAMP&&redstoneLevels.get(editKey(x,y,z)))color.multiplyScalar(1.65);
  color.multiplyScalar(.82+.18*faces[face].shade);
  return color;
}
return {getClientLightLevel,getBlockLightLevel,emittedLight,refreshEmissionChanges,updateLightingAt,applyGridLighting,computeLightingTask,computeLighting,refreshTorchLights,getLightLevel,solid,colorFor};
}
