/** redstone subsystem. Dependencies are injected at composition time. */
export function createRedstoneSystem($context) {
function notifyObservers(x,y,z){
    const {CALIBRATED_SCULK_SENSOR,OBSERVER,SCULK_SENSOR,editKey,fluidDirections,getBlock,observerUntil,sensorCells,sensorFrequency,sensorUntil} = $context;
const now=performance.now();for(const cell of sensorCells){const [sx,sy,sz]=cell.split(',').map(Number),kind=getBlock(sx,sy,sz);if(kind!==SCULK_SENSOR&&kind!==CALIBRATED_SCULK_SENSOR||sx===x&&sy===y&&sz===z)continue;const range=kind===SCULK_SENSOR?8:16;if(Math.hypot(sx-x,sy-y,sz-z)>range||(sensorUntil.get(cell)||0)>now)continue;sensorFrequency.set(cell,12);sensorUntil.set(cell,now+(kind===SCULK_SENSOR?3000:1000))}for(const [dx,dz] of fluidDirections){const ox=x-dx,oz=z-dz,k=editKey(ox,y,oz);if(getBlock(ox,y,oz)!==OBSERVER)continue;const facing=$context.save.redstoneFacing[k]||[0,-1];if(facing[0]===dx&&facing[1]===dz)observerUntil.set(k,now+200)}}

function placeRedstoneComponent(x,y,z,type,hit){
    const {CALIBRATED_SCULK_SENSOR,COMPARATOR,CRAFTER,DISPENSER,DROPPER,HOPPER,LEVER,OBSERVER,PISTON,REDSTONE_COMPONENTS,REDSTONE_TORCH,REPEATER,SIZE,STICKY_PISTON,TRIPWIRE_HOOK,chunks,editKey,key,player,processRedstone,redstoneData,scheduleChunkMesh} = $context;
if(!REDSTONE_COMPONENTS.has(type))return;const k=editKey(x,y,z),toward=Math.abs(player.pitch)>Math.PI/4?[0,player.pitch<0?1:-1,0]:Math.abs(Math.sin(player.yaw))>Math.abs(Math.cos(player.yaw))?[Math.sign(Math.sin(player.yaw)),0,0]:[0,0,Math.sign(Math.cos(player.yaw))];if(type===LEVER){const support=hit&&Math.abs(hit.x-x)+Math.abs(hit.y-y)+Math.abs(hit.z-z)===1?[hit.x-x,hit.y-y,hit.z-z]:[0,-1,0],dx=-Math.sin(player.yaw),dz=-Math.cos(player.yaw),facing=Math.abs(dx)>Math.abs(dz)?[Math.sign(dx),0]:[0,Math.sign(dz)];redstoneData()[k]={...(redstoneData()[k]||{}),support,facing}}else if(type===REDSTONE_TORCH){$context.save.redstoneTorchSupports[k]=hit&&Math.abs(hit.x-x)+Math.abs(hit.y-y)+Math.abs(hit.z-z)===1?[hit.x-x,hit.y-y,hit.z-z]:[0,-1,0]}else if(type===PISTON||type===STICKY_PISTON)$context.save.pistonDirections[k]=toward;else if([DISPENSER,DROPPER,CRAFTER,HOPPER,TRIPWIRE_HOOK].includes(type)){const outward=type===HOPPER&&hit&&hit.y===y?[hit.x-x,0,hit.z-z]:type===HOPPER?[0,-1,0]:type===TRIPWIRE_HOOK&&hit?[x-hit.x,0,z-hit.z]:toward;redstoneData()[k]={...(redstoneData()[k]||{}),facing:outward}}else if([REPEATER,COMPARATOR,OBSERVER,CALIBRATED_SCULK_SENSOR].includes(type)){const facing=[-Math.sin(player.yaw),-Math.cos(player.yaw)],direction=Math.abs(facing[0])>Math.abs(facing[1])?[Math.sign(facing[0]),0]:[0,Math.sign(facing[1])];$context.save.redstoneFacing[k]=direction}$context.dirtySave=true;scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))));processRedstone()}

function placeDoor(x,y,z){
    const {SIZE,chunks,editKey,key,player,redstoneData,scheduleChunkMesh} = $context;
const k=editKey(x,y,z),dx=-Math.sin(player.yaw),dz=-Math.cos(player.yaw),facing=Math.abs(dx)>Math.abs(dz)?[Math.sign(dx),0]:[0,Math.sign(dz)];redstoneData()[k]={...(redstoneData()[k]||{}),facing,hinge:'left'};$context.dirtySave=true;scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))),false)}

function useRedstoneControl(hit){
    const {CHISELED_BOOKSHELF,COMPARATOR,DAYLIGHT_DETECTOR,IRON_TRAPDOOR,LECTERN,NOTE_BLOCK,OAK_TRAPDOOR,REPEATER,SIZE,STONE_BUTTON,TRAPPED_CHEST,WOODEN_BUTTON,buttonUntil,chunks,editKey,key,playNote,processRedstone,redstoneData,scheduleChunkMesh,showToast} = $context;
const k=editKey(hit.x,hit.y,hit.z),state=redstoneData()[k]??(redstoneData()[k]={}),chunk=chunks.get(key(Math.floor(hit.x/SIZE),Math.floor(hit.z/SIZE)));if([STONE_BUTTON,WOODEN_BUTTON].includes(hit.type)){buttonUntil.set(k,performance.now()+(hit.type===WOODEN_BUTTON?1500:1000));processRedstone();scheduleChunkMesh(chunk);showToast('BUTTON PRESSED');return true}if(hit.type===REPEATER){$context.save.redstoneDelay[k]=(($context.save.redstoneDelay[k]||1)%4)+1;$context.dirtySave=true;scheduleChunkMesh(chunk);showToast(`REPEATER DELAY ${$context.save.redstoneDelay[k]} TICKS`);return true}if(hit.type===COMPARATOR){$context.save.redstoneModes[k]=$context.save.redstoneModes[k]==='subtract'?'compare':'subtract';$context.dirtySave=true;scheduleChunkMesh(chunk);showToast(`COMPARATOR ${$context.save.redstoneModes[k].toUpperCase()}`);return true}if(hit.type===DAYLIGHT_DETECTOR){state.inverted=!state.inverted;$context.dirtySave=true;processRedstone();scheduleChunkMesh(chunk);showToast(state.inverted?'NIGHT MODE':'DAY MODE');return true}if(hit.type===NOTE_BLOCK){state.note=((state.note||0)+1)%25;$context.dirtySave=true;playNote(hit.x,hit.y,hit.z);showToast(`NOTE ${state.note+1}/25`);return true}if(hit.type===OAK_TRAPDOOR){state.open=!state.open;$context.dirtySave=true;scheduleChunkMesh(chunk);showToast(state.open?'TRAPDOOR OPEN':'TRAPDOOR CLOSED');return true}if(hit.type===IRON_TRAPDOOR){showToast('IRON TRAPDOOR NEEDS REDSTONE');return true}if(hit.type===TRAPPED_CHEST){state.open=true;$context.dirtySave=true;processRedstone();return true}if(hit.type===LECTERN){if(hit.addBook){state.book=true;state.page=0;$context.dirtySave=true;processRedstone();return true}if(state.book){state.page=((state.page||0)+1)%4;state.pulseUntil=performance.now()+200;$context.dirtySave=true;processRedstone();showToast(`LECTERN PAGE ${state.page+1}/4`)}else showToast('PLACE A BOOK ON THE LECTERN');return true}if(hit.type===CHISELED_BOOKSHELF){state.books??=Array(6).fill(false);state.books[hit.slot]=hit.put;state.lastSlot=hit.slot+1;$context.dirtySave=true;processRedstone();scheduleChunkMesh(chunk);return true}return false}

function toggleLever(hit){
    const {editKey,notifyObservers,playSound,processRedstone,showToast,updateBlockModelImmediately} = $context;
const k=editKey(hit.x,hit.y,hit.z);$context.save.levers[k]=!$context.save.levers[k];$context.dirtySave=true;updateBlockModelImmediately(hit.x,hit.y,hit.z);notifyObservers(hit.x,hit.y,hit.z);processRedstone();playSound('lever');showToast($context.save.levers[k]?'LEVER ON':'LEVER OFF')}

function placePiston(x,y,z){
    const {getBlock,placeRedstoneComponent} = $context;
placeRedstoneComponent(x,y,z,getBlock(x,y,z))}

function railShape(x,y,z){
    const {ACTIVATOR_RAIL,DETECTOR_RAIL,POWERED_RAIL,RAIL_TYPES,editKey,getBlock} = $context;

  const found=[];
  for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]])for(const dy of [0,1,-1]){
    if(RAIL_TYPES.has(getBlock(x+dx,y+dy,z+dz))){found.push([dx,dz,dy]);break}
  }
  let directions=found;
  if(found.length>2){const ew=found.filter(d=>d[0]),ns=found.filter(d=>d[1]);directions=ew.length===2?ew:ns.length===2?ns:found.slice(0,2)}
  if(!directions.length)directions=$context.save.railDirections[$context.dimension+':'+editKey(x,y,z)]==='z'?[[0,1,0],[0,-1,0]]:[[1,0,0],[-1,0,0]];
  else if(directions.length===1)directions=[directions[0],[-directions[0][0],-directions[0][1],0]];
  if([POWERED_RAIL,DETECTOR_RAIL,ACTIVATOR_RAIL].includes(getBlock(x,y,z))&&directions[0][0]!==directions[1][0]&&directions[0][1]!==directions[1][1])directions=[directions[0],[-directions[0][0],-directions[0][1],0]];
  return {directions,axis:directions.every(d=>d[0])?'x':directions.every(d=>d[1])?'z':'curve'}
}

function pistonMoveable(id){
    const {AIR,BEDROCK,CHEST,CRAFTER,DISPENSER,DROPPER,END_FRAME,END_PORTAL,HOPPER,NETHER_PORTAL,OBSIDIAN,PISTON,PISTON_HEAD,STICKY_PISTON,TRAPPED_CHEST,pistonBreakable} = $context;
return id!==AIR&&id!==BEDROCK&&id!==OBSIDIAN&&id!==END_FRAME&&id!==END_PORTAL&&id!==NETHER_PORTAL&&id!==CHEST&&id!==TRAPPED_CHEST&&id!==DISPENSER&&id!==DROPPER&&id!==HOPPER&&id!==CRAFTER&&id!==PISTON&&id!==STICKY_PISTON&&id!==PISTON_HEAD&&!pistonBreakable(id)}

function pistonBreakable(id){
    const {ACTIVATOR_RAIL,CALIBRATED_SCULK_SENSOR,COMPARATOR,CRIMSON_ROOTS,CROP_0,CROP_1,CROP_2,DAYLIGHT_DETECTOR,DETECTOR_RAIL,FIRE,HEAVY_WEIGHTED_PLATE,LAVA,LEVER,LIGHT_WEIGHTED_PLATE,MEADOW_FLOWER,POWERED_RAIL,RAIL,REDSTONE_TORCH,REDSTONE_WIRE,REPEATER,SAPLING,SCULK_SENSOR,SNOW,STONE_BUTTON,STONE_PRESSURE_PLATE,TORCH,TRIPWIRE,TRIPWIRE_HOOK,WARPED_ROOTS,WATER,WHEAT_CROP,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE} = $context;
return [WATER,LAVA,FIRE,TORCH,REDSTONE_TORCH,REDSTONE_WIRE,LEVER,STONE_BUTTON,STONE_PRESSURE_PLATE,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE,LIGHT_WEIGHTED_PLATE,HEAVY_WEIGHTED_PLATE,DAYLIGHT_DETECTOR,TRIPWIRE_HOOK,TRIPWIRE,SCULK_SENSOR,CALIBRATED_SCULK_SENSOR,REPEATER,COMPARATOR,RAIL,POWERED_RAIL,DETECTOR_RAIL,ACTIVATOR_RAIL,SAPLING,SNOW,WHEAT_CROP,CROP_0,CROP_1,CROP_2,MEADOW_FLOWER,CRIMSON_ROOTS,WARPED_ROOTS].includes(id)}

function updatePiston(x,y,z,id,powered){
    const {AIR,FIRE,ITEMS,LAVA,MAX_Y,MIN_Y,PISTON_HEAD,SIZE,STICKY_PISTON,WATER,chunks,editKey,getBlock,intersects,key,pistonBreakable,pistonDirection,pistonMoveable,pistonPowered,playSound,player,scheduleChunkMesh,setBlock,setBlockBatch,survival} = $context;

  const k=editKey(x,y,z),[dx,dy,dz]=pistonDirection(k),fx=x+dx,fy=y+dy,fz=z+dz,extended=getBlock(fx,fy,fz)===PISTON_HEAD;
  if(powered){
    if(extended){pistonPowered.add(k);return}
    const line=[];let destination=null,broken=0;
    for(let step=1;step<=13;step++){
      const bx=x+dx*step,by=y+dy*step,bz=z+dz*step;if(by<MIN_Y+1||by>=MAX_Y||!chunks.has(key(Math.floor(bx/SIZE),Math.floor(bz/SIZE))))return;
      const block=getBlock(bx,by,bz);if(block===AIR||pistonBreakable(block)){destination=[bx,by,bz];broken=block;break}
      if(step>12||!pistonMoveable(block))return;line.push([bx,by,bz,block]);
    }
    if(!destination)return;
    const edits=broken?[[...destination,AIR]]:[];
    for(let i=line.length-1;i>=0;i--){const [bx,by,bz,block]=line[i];edits.push([bx+dx,by+dy,bz+dz,block])}
    edits.push([fx,fy,fz,PISTON_HEAD]);setBlockBatch(edits);
    if(broken&&ITEMS[broken]&&![WATER,LAVA,FIRE].includes(broken)&&$context.save.mode==='survival')survival.drop(broken,destination[0]+.5,destination[1]+.5,destination[2]+.5);
    pistonPowered.add(k);playSound('piston_out');
    if(Math.abs(player.x-fx-.5)<.8&&Math.abs(player.z-fz-.5)<.8&&player.y<fy+1.7&&player.y+1.8>fy){const nx=player.x+dx,ny=player.y+dy,nz=player.z+dz;if(!intersects(nx,ny,nz)){player.x=nx;player.y=ny;player.z=nz;player.vy=Math.max(player.vy,dy>0?3:0)}}
    survival.pushEntitiesByPiston(fx,fy,fz,dx,dy,dz);
    scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))));return;
  }
  if(extended)setBlock(fx,fy,fz,AIR);
  if(id===STICKY_PISTON&&extended){const sx=fx+dx,sy=fy+dy,sz=fz+dz,block=getBlock(sx,sy,sz);if(pistonMoveable(block)&&getBlock(fx,fy,fz)===AIR)setBlockBatch([[fx,fy,fz,block],[sx,sy,sz,AIR]])}
  pistonPowered.delete(k);if(extended){playSound('piston_in');scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))))}
}

function containerSlotsAt(x,y,z){
    const {CHEST,CRAFTER,DISPENSER,DROPPER,HOPPER,SHULKER_BOX,TRAPPED_CHEST,editKey,getBlock} = $context;
const id=getBlock(x,y,z);if(![CHEST,TRAPPED_CHEST,SHULKER_BOX,DISPENSER,DROPPER,HOPPER,CRAFTER].includes(id))return null;const k=`${$context.dimension}:${editKey(x,y,z)}`,size=id===HOPPER?5:id===CHEST||id===TRAPPED_CHEST||id===SHULKER_BOX?27:9;$context.save.chests??={};const slots=$context.save.chests[k]??($context.save.chests[k]=Array(size).fill(null));if(id===CRAFTER)slots.blocked=$context.save.crafterDisabled[k]||[];return slots}

function insertStack(slots,stack){if(!slots||!stack)return false;let left=stack.n;for(let i=0;i<slots.length;i++){const slot=slots[i];if(slots.blocked?.[i]||slot?.id!==stack.id||slot.n>=64)continue;const amount=Math.min(left,64-slot.n);slot.n+=amount;left-=amount;if(!left)break}if(left)for(let i=0;i<slots.length;i++)if(!slots[i]&&!slots.blocked?.[i]){const amount=Math.min(64,left);slots[i]={id:stack.id,n:amount};left-=amount;if(!left)break}stack.n=left;if(left===0)$context.dirtySave=true;return left===0}

function transferOne(from,to){
    const {insertStack} = $context;
if(!from||!to)return false;for(let i=0;i<from.length;i++){const slot=from[i];if(!slot)continue;const item={id:slot.id,n:1};if(!insertStack(to,item))continue;if(--slot.n<=0)from[i]=null;$context.dirtySave=true;return true}return false}

function outputItem(x,y,z,facing,stack){
    const {containerSlotsAt,insertStack,survival} = $context;
const [dx,dy,dz]=facing,target=containerSlotsAt(x+dx,y+dy,z+dz);if(target&&insertStack(target,stack))return;survival.drop(stack.id,x+.5+dx*.65,y+.5+dy*.65,z+.5+dz*.65,stack.n)}

function activateRedstoneDevice(x,y,z,id){
    const {AIR,ARROW,BEDROCK,BUCKET,CRAFTER,DISPENSER,DROPPER,LAVA,LAVA_BUCKET,TNT,WATER,WATER_BUCKET,containerSlotsAt,editKey,getBlock,insertStack,outputItem,player,redstoneData,setBlock,survival} = $context;
const k=editKey(x,y,z),state=redstoneData()[k]||{},facing=state.facing||[0,0,-1],slots=containerSlotsAt(x,y,z);if(id===CRAFTER){const made=survival.autoCraft(slots);if(made)outputItem(x,y,z,facing,made);return}if(id===DISPENSER||id===DROPPER){const occupied=slots?.map((slot,index)=>slot?.n?index:-1).filter(index=>index>=0)||[];if(!occupied.length)return;const index=occupied[Math.floor(Math.random()*occupied.length)],slot=slots[index],item=slot.id,[dx,dy,dz]=facing,tx=x+dx,ty=y+dy,tz=z+dz;let used=false,replacement=0;if(id===DISPENSER){if(item===WATER_BUCKET||item===LAVA_BUCKET){if(item===WATER_BUCKET&&$context.dimension==='nether'){used=true;replacement=BUCKET}else if(getBlock(tx,ty,tz)===AIR&&setBlock(tx,ty,tz,item===WATER_BUCKET?WATER:LAVA)){used=true;replacement=BUCKET}}else if(item===BUCKET&&[WATER,LAVA].includes(getBlock(tx,ty,tz))){replacement=getBlock(tx,ty,tz)===WATER?WATER_BUCKET:LAVA_BUCKET;setBlock(tx,ty,tz,AIR);used=true}else if(item===TNT){used=true;$context.gameplayRepairs.prime(tx,ty,tz)}else if(item===ARROW){used=true;const along=(player.x-x-.5)*dx+(player.y+1-ty-.5)*dy+(player.z-z-.5)*dz;if(along>0&&along<8&&Math.hypot(player.x-(x+.5+dx*along),player.y+1-(y+.5+dy*along),player.z-(z+.5+dz*along))<.8)survival.hurt(4,'DISPENSER ARROW',{x:x+.5,z:z+.5});else survival.drop(ARROW,tx+.5,ty+.5,tz+.5)}}if(!used)outputItem(x,y,z,facing,{id:item,n:1});slot.n--;if(!slot.n)slots[index]=null;if(replacement)insertStack(slots,{id:replacement,n:1});$context.dirtySave=true}}

function updateHoppers(now){
    const {HOPPER,containerSlotsAt,getBlock,hopperAt,player,redstoneCells,redstoneData,redstoneLevels,survival,transferOne} = $context;
for(const k of redstoneCells){const [x,y,z]=k.split(',').map(Number);if(getBlock(x,y,z)!==HOPPER||Math.hypot(x-player.x,z-player.z)>28||now<(hopperAt.get(k)||0)||redstoneLevels.get(k))continue;const slots=containerSlotsAt(x,y,z),from=containerSlotsAt(x,y+1,z),direction=redstoneData()[k]?.facing||[0,-1,0],to=containerSlotsAt(x+direction[0],y+direction[1],z+direction[2]);const moved=transferOne(slots,to)||transferOne(from,slots)||survival.collectHopperDrop(x,y,z,slots);hopperAt.set(k,now+(moved?400:200))}}

function playNote(x,y,z){
    const {editKey,playGameSound,redstoneData} = $context;
const k=editKey(x,y,z),state=redstoneData()[k]??(redstoneData()[k]={}),pitch=state.note||0;playGameSound('note',.3,Math.pow(2,pitch/12))}

function closeRedstoneContainer(key){
    const {TRAPPED_CHEST,getBlock,processRedstone,redstoneData} = $context;
const [dim,coords]=key.split(':');if(dim!==$context.dimension)return;const [x,y,z]=coords.split(',').map(Number);if(getBlock(x,y,z)===TRAPPED_CHEST){redstoneData()[coords]={...(redstoneData()[coords]||{}),open:false};processRedstone()}}

function hitTarget(hit){
    const {THREE,camera,editKey,processRedstone,targetUntil} = $context;
const k=editKey(hit.x,hit.y,hit.z),direction=new THREE.Vector3();camera.getWorldDirection(direction);const point=camera.position.clone().addScaledVector(direction,hit.distance),offsets=[Math.abs(point.x-hit.x-.5),Math.abs(point.y-hit.y-.5),Math.abs(point.z-hit.z-.5)].sort((a,b)=>a-b),strength=Math.max(1,15-Math.round(Math.hypot(offsets[0],offsets[1])*20));targetUntil.set(k,{until:performance.now()+400,strength});processRedstone();return strength}

function tripwirePower(x,y,z,now){
    const {TRIPWIRE,TRIPWIRE_HOOK,editKey,getBlock,player,redstoneData,tripwireUntil} = $context;
const [dx,,dz]=redstoneData()[editKey(x,y,z)]?.facing||[0,0,-1];if(!dx&&!dz)return false;let tripped=false;for(let distance=1;distance<=40;distance++){const tx=x+dx*distance,tz=z+dz*distance,type=getBlock(tx,y,tz);if(type===TRIPWIRE_HOOK){const facing=redstoneData()[editKey(tx,y,tz)]?.facing||[0,0,-1];if(facing[0]!==-dx||facing[2]!==-dz)return false;if(tripped){tripwireUntil.set(editKey(x,y,z),now+1000);tripwireUntil.set(editKey(tx,y,tz),now+1000)}return (tripwireUntil.get(editKey(x,y,z))||0)>now}if(type!==TRIPWIRE)return false;if(Math.abs(player.x-tx-.5)<.42&&Math.abs(player.z-tz-.5)<.42&&player.y<y+.7&&player.y+1.7>y)tripped=true}return false}

function processRedstone(now=performance.now()){
    const {ACTIVATOR_RAIL,AIR,BLOCKS,CALIBRATED_SCULK_SENSOR,CHEST,CHISELED_BOOKSHELF,COMPARATOR,COPPER_BULB,CRAFTER,DAYLIGHT_DETECTOR,DETECTOR_RAIL,DISPENSER,DOOR,DROPPER,HEAVY_WEIGHTED_PLATE,HOPPER,IRON_TRAPDOOR,LECTERN,LEVER,LIGHTNING_ROD,LIGHT_WEIGHTED_PLATE,NOTE_BLOCK,OAK_TRAPDOOR,OBSERVER,PISTON,POWERED_RAIL,REDSTONE_BLOCK,REDSTONE_LAMP,REDSTONE_TORCH,REDSTONE_WIRE,REPEATER,SCULK_SENSOR,SHULKER_BOX,SIZE,STICKY_PISTON,STONE_BUTTON,STONE_PRESSURE_PLATE,TARGET,TNT,TRAPPED_CHEST,TRIPWIRE_HOOK,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE,activateRedstoneDevice,buttonUntil,chunks,containerSlotsAt,doorInfo,editKey,fluidDirections,gateOutputs,gatePending,getBlock,instantModelTypes,isDoor,key,observerUntil,occludes,parkedVehicles,pistonDirection,playNote,player,railShape,redstoneByDimension,redstoneCells,redstoneData,redstoneDoorPowered,redstoneEdge,redstoneLevels,scheduleChunkMesh,sensorCells,sensorFrequency,sensorUntil,setBlock,survival,targetUntil,torchBurnedUntil,torchPending,torchStates,torchSwitches,tripwirePower,updateDoorModelImmediately,updateHoppers,updatePiston,wireConnections} = $context;

  const next=new Map(),wireQueue=[],conductors=new Map(),sources=[],devices=[],rails=[],gates=[],directional=new Map();
  const neighbors=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],px=Math.floor(player.x),py=Math.floor(player.y),pz=Math.floor(player.z);
  if(!$context.lastSensorStep||Math.hypot(player.x-$context.lastSensorStep[0],player.z-$context.lastSensorStep[1])>.55){$context.lastSensorStep=[player.x,player.z];for(const cell of sensorCells){const [sx,sy,sz]=cell.split(',').map(Number),kind=getBlock(sx,sy,sz);if(kind!==SCULK_SENSOR&&kind!==CALIBRATED_SCULK_SENSOR)continue;const distance=Math.hypot(sx-player.x,sy-player.y,sz-player.z);if(distance>(kind===SCULK_SENSOR?8:16)||(sensorUntil.get(cell)||0)>now)continue;const [dx,dz]=$context.save.redstoneFacing[cell]||[0,-1],frequency=redstoneLevels.get(editKey(sx-dx,sy,sz-dz))||0;if(kind===CALIBRATED_SCULK_SENSOR&&frequency!==1)continue;sensorFrequency.set(cell,1);sensorUntil.set(cell,now+(kind===SCULK_SENSOR?3000:1000))}}
  const previousPower=(x,y,z,towardX=0,towardZ=0)=>{const id=getBlock(x,y,z);if([REPEATER,COMPARATOR,OBSERVER].includes(id)){const face=$context.save.redstoneFacing[editKey(x,y,z)]||[0,-1],sign=id===OBSERVER?-1:1;if(face[0]*sign!==towardX||face[1]*sign!==towardZ)return 0;}return id===REDSTONE_LAMP||id===PISTON||id===STICKY_PISTON||id===DOOR?0:redstoneLevels.get(editKey(x,y,z))||0};
  for(const k of redstoneCells){const [x,y,z]=k.split(',').map(Number);if(Math.abs(x-px)>28||Math.abs(y-py)>16||Math.abs(z-pz)>28)continue;const id=getBlock(x,y,z);
    if(id===REDSTONE_TORCH){const support=$context.save.redstoneTorchSupports[k]||[0,-1,0],sx=x+support[0],sy=y+support[1],sz=z+support[2];if(!BLOCKS[getBlock(sx,sy,sz)]?.solid){setBlock(x,y,z,AIR);if($context.save.mode==='survival')survival.drop(REDSTONE_TORCH,x+.5,y+.5,z+.5);torchStates.delete(k);torchPending.delete(k);continue}const desired=previousPower(sx,sy,sz)===0&&now>=(torchBurnedUntil.get(k)||0),current=torchStates.has(k)?torchStates.get(k):desired;if(!torchStates.has(k))torchStates.set(k,current);if(desired!==current){const pending=torchPending.get(k);if(!pending||pending.value!==desired)torchPending.set(k,{value:desired,at:now+100});else if(now>=pending.at){torchStates.set(k,desired);torchPending.delete(k);const toggles=(torchSwitches.get(k)||[]).filter(time=>now-time<3000);if(!desired)toggles.push(now);torchSwitches.set(k,toggles);if(toggles.length>=8){torchStates.set(k,false);torchBurnedUntil.set(k,now+8000);torchSwitches.set(k,[])}scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))))}}else torchPending.delete(k);if(torchStates.get(k))sources.push({x,y,z,id,power:15,support});continue}
    const onPlate=Math.abs(player.x-x-.5)<.46&&Math.abs(player.z-z-.5)<.46&&player.y>=y&&player.y<y+1.4,weight=survival.plateWeight(x,y,z)+(onPlate?1:0),target=targetUntil.get(k),daylight=Math.max(0,Math.round(15*Math.sin($context.tick))),sensor=(sensorUntil.get(k)||0)>now,calibration=$context.save.redstoneFacing[k]||[0,-1],calibratedInput=previousPower(x-calibration[0],y,z-calibration[1]);
    const sourcePower=id===REDSTONE_BLOCK?15:id===LEVER&&$context.save.levers[k]?15:[STONE_BUTTON,WOODEN_BUTTON].includes(id)&&(buttonUntil.get(k)||0)>now?15:id===STONE_PRESSURE_PLATE&&(onPlate||survival.isPlatePressed(x,y,z))?15:id===WOODEN_PRESSURE_PLATE&&weight?15:id===LIGHT_WEIGHTED_PLATE?Math.min(15,weight):id===HEAVY_WEIGHTED_PLATE?Math.min(15,Math.ceil(weight/10)):id===DETECTOR_RAIL&&parkedVehicles.some(cart=>cart.kind==='minecart'&&!cart.offRail&&cart.cell.x===x&&cart.cell.y===y&&cart.cell.z===z)?15:id===OBSERVER&&(observerUntil.get(k)||0)>now?15:id===DAYLIGHT_DETECTOR?(redstoneData()[k]?.inverted?15-daylight:daylight):id===TARGET&&target?.until>now?target.strength:id===TRAPPED_CHEST&&redstoneData()[k]?.open?15:id===TRIPWIRE_HOOK&&tripwirePower(x,y,z,now)?15:id===SCULK_SENSOR&&sensor?15:id===CALIBRATED_SCULK_SENSOR&&sensor&&calibratedInput===(sensorFrequency.get(k)||0)?15:id===LIGHTNING_ROD&&(redstoneData()[k]?.pulseUntil||0)>now?15:id===LECTERN&&(redstoneData()[k]?.pulseUntil||0)>now?15:0;
    if(sourcePower){const facing=id===OBSERVER?$context.save.redstoneFacing[k]||[0,-1]:null;sources.push({x,y,z,id,power:sourcePower,dir:facing?[-facing[0],-facing[1]]:null})}
    else if(id===REPEATER||id===COMPARATOR)gates.push([x,y,z,id]);
    else if(id===POWERED_RAIL||id===ACTIVATOR_RAIL)rails.push([x,y,z,id]);
    if(isDoor(id)&&doorInfo(id).half!=='upper'||[REDSTONE_LAMP,PISTON,STICKY_PISTON,DOOR,DISPENSER,DROPPER,CRAFTER,NOTE_BLOCK,COPPER_BULB,OAK_TRAPDOOR,IRON_TRAPDOOR,TNT,HOPPER].includes(id))devices.push([x,y,z,id]);
  }
  for(const [x,y,z,id] of gates){const k=editKey(x,y,z),[dx,dz]=$context.save.redstoneFacing[k]||[0,-1],bx=x-dx,bz=z-dz;let rear=previousPower(bx,y,bz,dx,dz);if(id===COMPARATOR){const back=getBlock(bx,y,bz);if([CHEST,TRAPPED_CHEST,SHULKER_BOX,HOPPER,DROPPER,DISPENSER,CRAFTER].includes(back)){const slots=containerSlotsAt(bx,y,bz),fullness=slots.reduce((sum,slot,index)=>sum+(slot||back===CRAFTER&&slots.blocked?.[index]?1:0),0);rear=back===CRAFTER?fullness:(fullness?Math.floor(slots.reduce((sum,slot)=>sum+(slot?Math.min(1,slot.n/64):0),0)/slots.length*14)+1:0)}else if(back===COPPER_BULB)rear=redstoneData()[editKey(bx,y,bz)]?.lit?15:0;else if(back===CHISELED_BOOKSHELF)rear=redstoneData()[editKey(bx,y,bz)]?.lastSlot||0;else if(back===LECTERN)rear=redstoneData()[editKey(bx,y,bz)]?.book?Math.min(15,Math.max(1,Math.ceil(((redstoneData()[editKey(bx,y,bz)].page||0)+1)*15/4))):0}const sideA=previousPower(x+dz,y,z-dx,-dz,dx),sideB=previousPower(x-dz,y,z+dx,dz,-dx),side=Math.max(sideA,sideB),desired=id===REPEATER?(rear?15:0):$context.save.redstoneModes[k]==='subtract'?Math.max(0,rear-side):rear>=side?rear:0,current=gateOutputs.get(k)||0,delay=(id===REPEATER?($context.save.redstoneDelay[k]||1):1)*100;
    const locked=id===REPEATER&&[[x+dz,z-dx],[x-dz,z+dx]].some(([sx,sz])=>[REPEATER,COMPARATOR].includes(getBlock(sx,y,sz))&&previousPower(sx,y,sz,x-sx,z-sz)>0);if(locked)gatePending.delete(k);else if(desired===current)gatePending.delete(k);else{const pending=gatePending.get(k);if(!pending||pending.value!==desired)gatePending.set(k,{value:desired,at:now+delay});else if(now>=pending.at){gateOutputs.set(k,desired);gatePending.delete(k)}}const power=gateOutputs.get(k)||0;if(power)sources.push({x,y,z,id,power,dir:[dx,dz]})
  }
  const offerWire=(x,y,z,power)=>{if(power>0&&getBlock(x,y,z)===REDSTONE_WIRE&&power>(next.get(editKey(x,y,z))||0))wireQueue.push([x,y,z,power])};
  const spreadWire=(x,y,z,power,excludeBelow=false)=>{for(const [dx,dz] of fluidDirections){const nx=x+dx,nz=z+dz;offerWire(nx,y,nz,power);if(occludes(getBlock(nx,y,nz))&&!occludes(getBlock(x,y+1,z)))offerWire(nx,y+1,nz,power);if(!occludes(getBlock(nx,y,nz)))offerWire(nx,y-1,nz,power)}if(getBlock(x,y,z)!==REDSTONE_WIRE){offerWire(x,y+1,z,power);if(!excludeBelow)offerWire(x,y-1,z,power)}};
  for(const source of sources){const {x,y,z,id,power,dir,support}=source,k=editKey(x,y,z);next.set(k,power);if(dir)directional.set(k,dir);if(dir){const nx=x+dir[0],nz=z+dir[1],target=getBlock(nx,y,nz);offerWire(nx,y,nz,power);if(occludes(target))conductors.set(editKey(nx,y,nz),Math.max(power,conductors.get(editKey(nx,y,nz))||0))}else{spreadWire(x,y,z,power,!!support&&support[1]<0);for(const [dx,dy,dz] of neighbors){if(support&&dx===support[0]&&dy===support[1]&&dz===support[2])continue;const nx=x+dx,ny=y+dy,nz=z+dz,target=getBlock(nx,ny,nz);if((id!==REDSTONE_TORCH||dy===1)&&occludes(target)&&target!==REDSTONE_LAMP&&target!==PISTON&&target!==STICKY_PISTON)conductors.set(editKey(nx,ny,nz),Math.max(power,conductors.get(editKey(nx,ny,nz))||0))}}}
  for(const [k,power] of conductors){const [x,y,z]=k.split(',').map(Number);next.set(k,Math.max(power,next.get(k)||0));spreadWire(x,y,z,power)}
  for(let head=0;head<wireQueue.length;head++){const [x,y,z,power]=wireQueue[head],k=editKey(x,y,z);if((next.get(k)||0)>=power)continue;next.set(k,power);if(power>1)spreadWire(x,y,z,power-1)}
  // Dust strongly powers its support and weakly powers connected horizontal faces.
  // These receiver signals cannot re-enter the wire flood fill and latch the circuit.
  for(const [cell,power] of [...next]){
    const [x,y,z]=cell.split(',').map(Number);if(getBlock(x,y,z)!==REDSTONE_WIRE)continue;
    const connections=wireConnections(x,y,z),dirs=[[1,0,'east'],[-1,0,'west'],[0,1,'south'],[0,-1,'north']];
    const targets=[[x,y-1,z],...dirs.filter(([dx,dz,name])=>connections[name]!=='none').map(([dx,dz])=>[x+dx,y,z+dz])];
    for(const [tx,ty,tz] of targets)if(occludes(getBlock(tx,ty,tz))&&![REDSTONE_LAMP,PISTON,STICKY_PISTON].includes(getBlock(tx,ty,tz))){const key=editKey(tx,ty,tz);next.set(key,Math.max(power,next.get(key)||0));}
  }
  const signalAt=(x,y,z,towardX=0,towardZ=0)=>{const id=getBlock(x,y,z);if(id===REDSTONE_LAMP||id===PISTON||id===STICKY_PISTON||id===DOOR||id===HOPPER)return 0;const k=editKey(x,y,z),face=directional.get(k);return face&&(face[0]!==towardX||face[1]!==towardZ)?0:next.get(k)||0};
  for(const [x,y,z,id] of devices){const piston=id===PISTON||id===STICKY_PISTON,face=piston?pistonDirection(editKey(x,y,z)):null,receives=(atY,skipFront)=>neighbors.some(([dx,dy,dz])=>(!skipFront||dx!==face[0]||dy!==face[1]||dz!==face[2])&&signalAt(x+dx,atY+dy,z+dz,-dx,-dz)>0),powered=receives(y,piston)||piston&&receives(y+1,false),k=editKey(x,y,z),was=redstoneEdge.get(k)||false;
    if(powered&&[REDSTONE_LAMP,PISTON,STICKY_PISTON,DOOR,HOPPER].includes(id))next.set(k,15);if(piston)updatePiston(x,y,z,id,powered);
    if(isDoor(id)&&powered!==redstoneDoorPowered.has(k)){if(powered)redstoneDoorPowered.add(k);else redstoneDoorPowered.delete(k);$context.save.openDoors[k]=powered;$context.dirtySave=true;updateDoorModelImmediately(x,y,z)}
    if([DISPENSER,DROPPER,CRAFTER].includes(id)&&powered&&!was)activateRedstoneDevice(x,y,z,id);
    if(id===NOTE_BLOCK&&powered&&!was)playNote(x,y,z);
    if(id===TNT&&powered&&!was){$context.gameplayRepairs.prime(x,y,z)}
    if(id===COPPER_BULB){const state=redstoneData()[k]??(redstoneData()[k]={});if(powered&&!was){state.lit=!state.lit;$context.dirtySave=true}if(state.powered!==powered||powered&&!was){state.powered=powered;scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))))}}
    if(id===OAK_TRAPDOOR||id===IRON_TRAPDOOR){const state=redstoneData()[k]??(redstoneData()[k]={});if(state.powered!==powered){state.powered=powered;state.open=powered;$context.dirtySave=true;scheduleChunkMesh(chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))))}}
    redstoneEdge.set(k,powered)
  }
  const railQueue=[];for(const [x,y,z,id] of rails)if(neighbors.some(([dx,dy,dz])=>signalAt(x+dx,y+dy,z+dz,-dx,-dz)>0)){const k=editKey(x,y,z);next.set(k,15);railQueue.push([x,y,z,0,id])}
  for(let head=0;head<railQueue.length;head++){const [x,y,z,distance,id]=railQueue[head];if(distance>=8)continue;for(const [dx,dz] of railShape(x,y,z).directions)for(const dy of [0,1,-1]){const nx=x+dx,ny=y+dy,nz=z+dz,nk=editKey(nx,ny,nz);if(getBlock(nx,ny,nz)!==id||next.has(nk)||!railShape(nx,ny,nz).directions.some(([rx,rz])=>rx===-dx&&rz===-dz))continue;next.set(nk,15);railQueue.push([nx,ny,nz,distance+1,id]);break}}
  const changed=new Set();for(const [k,value] of next)if(redstoneLevels.get(k)!==value&&!instantModelTypes.has(getBlock(...k.split(',').map(Number)))){const [x,,z]=k.split(',').map(Number);changed.add(key(Math.floor(x/SIZE),Math.floor(z/SIZE)))}for(const k of redstoneLevels.keys())if(!next.has(k)&&!instantModelTypes.has(getBlock(...k.split(',').map(Number)))){const [x,,z]=k.split(',').map(Number);changed.add(key(Math.floor(x/SIZE),Math.floor(z/SIZE)))}redstoneLevels.clear();for(const [k,value] of next)redstoneLevels.set(k,value);redstoneByDimension.set($context.dimension,[...next]);for(const k of changed)scheduleChunkMesh(chunks.get(k));updateHoppers(now)
}
return {notifyObservers,placeRedstoneComponent,placeDoor,useRedstoneControl,toggleLever,placePiston,railShape,pistonMoveable,pistonBreakable,updatePiston,containerSlotsAt,insertStack,transferOne,outputItem,activateRedstoneDevice,updateHoppers,playNote,closeRedstoneContainer,hitTarget,tripwirePower,processRedstone};
}
