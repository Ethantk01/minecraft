/** terrain subsystem. Dependencies are injected at composition time. */
export function createTerrainSystem($context) {
function hash(x,z,s=0){
    const {seed} = $context;
let n=Math.imul(x,374761393)+Math.imul(z,668265263)+Math.imul(seed+s,1442695041);n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295}

function hash3(x,y,z,s=0){
    const {seed} = $context;
let n=Math.imul(x,374761393)^Math.imul(y,1442695041)^Math.imul(z,668265263)^Math.imul(seed+s,1274126177);n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295}

function smooth(t){return t*t*(3-2*t)}

function noise(x,z,scale,s=0){
    const {hash,smooth} = $context;
x/=scale;z/=scale;const ix=Math.floor(x),iz=Math.floor(z),fx=smooth(x-ix),fz=smooth(z-iz);const a=hash(ix,iz,s),b=hash(ix+1,iz,s),c=hash(ix,iz+1,s),d=hash(ix+1,iz+1,s);return (a+(b-a)*fx)*(1-fz)+(c+(d-c)*fx)*fz}

function noise3(x,y,z,scale,s=0){
    const {hash3,noiseLattice,smooth} = $context;

  x/=scale;y/=scale;z/=scale;
  const ix=Math.floor(x),iy=Math.floor(y),iz=Math.floor(z),fx=smooth(x-ix),fy=smooth(y-iy),fz=smooth(z-iz);
  let field=noiseLattice.get(s);if(!field){field={x:NaN,y:NaN,z:NaN,corners:Array(8)};noiseLattice.set(s,field);}
  const corners=field.corners;
  if(field.x!==ix||field.y!==iy||field.z!==iz){field.x=ix;field.y=iy;field.z=iz;corners[0]=hash3(ix,iy,iz,s);corners[1]=hash3(ix+1,iy,iz,s);corners[2]=hash3(ix,iy+1,iz,s);corners[3]=hash3(ix+1,iy+1,iz,s);corners[4]=hash3(ix,iy,iz+1,s);corners[5]=hash3(ix+1,iy,iz+1,s);corners[6]=hash3(ix,iy+1,iz+1,s);corners[7]=hash3(ix+1,iy+1,iz+1,s);}
  const mix=(a,b,t)=>a+(b-a)*t;
  return mix(mix(mix(corners[0],corners[1],fx),mix(corners[2],corners[3],fx),fy),mix(mix(corners[4],corners[5],fx),mix(corners[6],corners[7],fx),fy),fz);
}

function cacheSample(cache,key,calculate){if(cache.has(key))return cache.get(key);const value=calculate();cache.set(key,value);if(cache.size>65536){let removed=0;for(const old of cache.keys()){cache.delete(old);if(++removed===8192)break}}return value}

function climate(x,z){
    const {cacheSample,climateCache,noise} = $context;
return cacheSample(climateCache,x+','+z,()=>{const temperature=noise(x,z,220,70),moisture=noise(x,z,190,71),rugged=noise(x,z,240,72);const type=temperature>.64&&moisture<.52?'desert':temperature<.35?'snow':moisture>.56?'forest':'plains';return {temperature,moisture,rugged,type}})}

function biome(x,z){
    const {SEA,climate,terrain} = $context;
if($context.save.testWorld&&$context.dimension==='overworld'&&Math.max(Math.abs(x),Math.abs(z))<60)return 'plains';const c=climate(x,z),h=terrain(x,z);if(h>SEA+22&&c.rugged>.56){if(h>SEA+43)return c.temperature>.58?'stony_peaks':c.temperature<.31?'frozen_peaks':'jagged_peaks';if(h>SEA+33)return c.temperature<.45?'snowy_slopes':'meadow';return c.temperature<.4?'grove':'meadow'}return c.type}

function caveBiome(x,y,z){
    const {noise3,terrain} = $context;
if($context.dimension!=='overworld'||y>terrain(x,z)-8)return null;const humid=noise3(x,y,z,82,801),thermal=noise3(x,y,z,95,802);return humid>.69?'lush_caves':thermal>.69?'dripstone_caves':null}

function terrain(x,z){
    const {SEA,cacheSample,climate,noise,smooth,terrainCache} = $context;
return cacheSample(terrainCache,$context.dimension+','+x+','+z,()=>{if($context.dimension==='nether')return Math.floor(17+noise(x,z,68,91)*27+noise(x,z,19,92)*10);if($context.dimension==='end'){const r=Math.hypot(x,z),island=r<104||r>1000&&noise(x,z,66,94)>.54;return island?Math.floor(46+noise(x,z,35,95)*7-(r<1000?Math.max(0,r-74)*.2:0)):-1}const c=climate(x,z),broad=noise(x,z,310,1),local=noise(x,z,86,2),detail=noise(x,z,21,3),ridge=1-Math.abs(noise(x,z,94,8)*2-1),mountain=smooth(Math.max(0,Math.min(1,(c.rugged-.57)/.2))),continental=noise(x,z,410,9);let h=SEA-27+broad*42+local*18+detail*4+(continental-.5)*25+mountain*(8+ridge*20);if(h>SEA+32)h=SEA+32+(h-SEA-32)*.4;if($context.save.testWorld){const r=Math.max(Math.abs(x),Math.abs(z)),blend=smooth(Math.max(0,Math.min(1,(r-135)/28)));h=72*(1-blend)+h*blend}return Math.max(-18,Math.min(SEA+54,Math.floor(h)))} )}

function netherBiome(x,z){
    const {noise} = $context;
const heat=noise(x,z,130,301),spirit=noise(x,z,115,302);if(heat<.34)return 'soul_sand_valley';if(heat>.68)return 'basalt_deltas';if(spirit>.57)return 'warped_forest';if(spirit<.43)return 'crimson_forest';return 'nether_wastes'}

function netherCeiling(x,z){
    const {noise} = $context;
return Math.floor(94+noise(x,z,47,303)*22+noise(x,z,13,304)*5)}

function netherPortalSite(){
    const {netherCeiling,terrain} = $context;

  if($context.cachedNetherPortalSite)return $context.cachedNetherPortalSite;
  let best=null;
  for(let radius=0;radius<=72;radius+=4){
    for(let z=-radius;z<=radius;z+=4)for(let x=-radius;x<=radius;x+=4){
      if(Math.max(Math.abs(x),Math.abs(z))!==radius)continue;
      let low=Infinity,high=-Infinity,roof=Infinity;
      for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=5;dx++){
        const wx=x+dx,wz=z+dz,h=terrain(wx,wz);
        low=Math.min(low,h);high=Math.max(high,h);roof=Math.min(roof,netherCeiling(wx,wz));
      }
      if(low<29||high-low>6||high+7>=roof)continue;
      best={x,z,by:high+1};break;
    }
    if(best)break;
  }
  return $context.cachedNetherPortalSite=best||{x:2,z:0,by:Math.max(32,terrain(2,0)+2)};
}

function endPillars(){
    const {hash,seed,terrain} = $context;
return Array.from({length:10},(_,i)=>{const angle=i*Math.PI/5,dist=32+(i%3)*3,x=Math.round(Math.cos(angle)*dist),z=Math.round(Math.sin(angle)*dist);return {x,z,radius:i%3===0?2:1,top:terrain(x,z)+16+Math.floor(hash(i,seed,702)*17)}})}

function netherBase(x,y,z,h,b,ceiling){
    const {AIR,ANCIENT_DEBRIS,BEDROCK,LAVA,NETHERRACK,SOUL_SAND,SOUL_SOIL,extraId,hash,hash3,noise3} = $context;

  if(y<0||y>=128)return AIR;
  if(y===0||y>=127)return BEDROCK;
  if(y<4||y>=124&&hash3(x,y,z,310)>.35)return BEDROCK;
  let mass=y<=h||y>=ceiling;
  if(mass&&y>7&&y<h-4&&noise3(x,y,z,17,305)>.69)mass=false;
  if(!mass&&y>28&&y<ceiling-4&&noise3(x,y,z,23,306)>.79)mass=true;
  if(!mass)return y<=26?LAVA:AIR;
  let type=NETHERRACK;
  if(y<=h&&y>=h-3){
    if(b==='crimson_forest')type=extraId('crimson_nylium');
    else if(b==='warped_forest')type=extraId('warped_nylium');
    else if(b==='soul_sand_valley')type=hash(x,z,307)<.6?SOUL_SAND:SOUL_SOIL;
    else if(b==='basalt_deltas')type=hash3(x,y,z,308)<.67?extraId('basalt_side'):extraId('blackstone');
  }else if(b==='basalt_deltas'&&noise3(x,y,z,14,311)>.55)type=extraId('blackstone');
  if(type===NETHERRACK&&y>6&&y<ceiling-3){const vein=hash3(Math.floor(x/3),Math.floor(y/3),Math.floor(z/3),312);if(vein>.983&&hash3(x,y,z,313)>.35)type=extraId('nether_quartz_ore');else if(vein<.012&&hash3(x,y,z,314)>.38)type=extraId('nether_gold_ore')}
  if(type===NETHERRACK&&y>=8&&y<=25&&hash3(Math.floor(x/2),Math.floor(y/2),Math.floor(z/2),510)>.9992&&hash3(x,y,z,511)>.42)type=ANCIENT_DEBRIS;
  return type;
}

function isTree(x,z){
    const {SEA,biome,hash,terrain} = $context;
if($context.save.testWorld&&$context.dimension==='overworld'&&Math.max(Math.abs(x),Math.abs(z))<125)return false;const b=biome(x,z),chance=b==='forest'?.035:b==='grove'?.026:b==='snow'?.019:b==='plains'?.007:b==='meadow'?.002:0;return chance>0&&terrain(x,z)>SEA+1&&hash(x,z,66)<chance}

function spawnPoint(){
    const {SEA,biome,isTree,netherPortalSite,terrain} = $context;
if($context.dimension==='nether'){const site=netherPortalSite();return {x:site.x+2.5,y:site.by+1,z:site.z+1.5}}if($context.dimension==='end')return {x:.5,y:terrain(0,0)+11,z:.5};if($context.save.testWorld)return {x:.5,y:74,z:.5};let best={x:0,z:0,h:terrain(0,0)},dry=null;for(let r=0;r<=256;r+=4)for(let z=-r;z<=r;z+=4)for(let x=-r;x<=r;x+=4){if(Math.max(Math.abs(x),Math.abs(z))!==r)continue;const h=terrain(x,z);if(h>best.h)best={x,z,h};if(h<=SEA+3||Math.abs(h-terrain(x+3,z))>3||Math.abs(h-terrain(x,z+3))>3)continue;let clear=true;for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=2;dx++)if(isTree(x+dx,z+dz))clear=false;if(!clear)continue;if(!dry)dry={x,z,h};if(['plains','forest'].includes(biome(x,z)))return {x:x+.5,y:h+2,z:z+.5}}const site=dry||best;return {x:site.x+.5,y:site.h+2,z:site.z+.5}}

function strongholdLocation(){
    const {seed} = $context;
return {x:112+Math.abs(seed%4)*24,z:112+Math.abs(Math.floor(seed/7)%4)*24}}

function strongholdY(){
    const {hash,strongholdLocation} = $context;
const site=strongholdLocation();return -30+Math.floor(hash(site.x,site.z,700)*35)}

function villageSite(vx,vz){
    const {SEA,biome,hash,key,terrain,villageSites} = $context;
const k=key(vx,vz);if(villageSites.has(k))return villageSites.get(k);if($context.save.testWorld&&$context.dimension==='overworld'&&vx===0&&vz===0){const site={x:72,z:-72,biome:'plains'};villageSites.set(k,site);return site}let site=null;for(let attempt=0;attempt<5;attempt++){const x=vx*192+54+Math.floor(hash(vx,vz,201+attempt*2)*72),z=vz*192+54+Math.floor(hash(vx,vz,202+attempt*2)*72),b=biome(x,z),heights=[terrain(x,z),terrain(x-10,z-7),terrain(x+9,z-7),terrain(x-9,z+9),terrain(x+10,z+9),terrain(x,z-15),terrain(x,z+15)];if(!['plains','snow','desert'].includes(b)||Math.min(...heights)<=SEA+2||Math.max(...heights)-Math.min(...heights)>6)continue;site={x,z,biome:b};break}villageSites.set(k,site);return site}

function villageAt(x,z){
    const {villageSite} = $context;
if($context.dimension!=='overworld')return null;for(let vz=Math.floor(z/192)-1;vz<=Math.floor(z/192)+1;vz++)for(let vx=Math.floor(x/192)-1;vx<=Math.floor(x/192)+1;vx++){const site=villageSite(vx,vz);if(site&&Math.abs(x-site.x)<=34&&Math.abs(z-site.z)<=34)return site}return null}

function isVillageChest(x,z){
    const {villageAt} = $context;
return !!villageAt(x,z)}

function isStrongholdFrame(x,y,z){
    const {strongholdLocation,strongholdY} = $context;
const site=strongholdLocation(),sy=strongholdY(),dx=x-site.x,dz=z-site.z;return y===sy&&(Math.abs(dx)===2&&Math.abs(dz)<=1||Math.abs(dz)===2&&Math.abs(dx)<=1)}

function villageTemplates(site){
    const {structureAssets} = $context;
const theme=site.biome==='snow'?'snowy':site.biome==='desert'?'desert':'plains',houses=Object.keys(structureAssets.templates).filter(name=>name.startsWith(`village/${theme}/houses/`)),center=Object.keys(structureAssets.templates).find(name=>name.startsWith(`village/${theme}/town_centers/`));return {houses,center}}

function* generateChunk(cx,cz){
    const {AIR,ANVIL,AZALEA,BEDROCK,BIG_DRIPLEAF,BIRCH_LEAVES,BIRCH_LOG,BLOCKS,BONE_BLOCK,BREWING_STAND,CACTUS,CALIBRATED_SCULK_SENSOR,CHEST,COMPARATOR,COPPER_ORE,CRIMSON_FUNGUS,CRIMSON_ROOTS,CRIMSON_STEM,CROP_0,CROP_1,CROP_2,DEEPSLATE,DEEPSLATE_IRON,DIRT,DOOR,DOOR_TOP,ENCHANTING_TABLE,END_FRAME,END_PORTAL,END_STONE,FARMLAND,FIRE,FLOWERING_AZALEA,FURNACE,GLOWSTONE,GLOW_BERRIES,GRASS,GRAVEL,HANGING_ROOTS,HEIGHT,ITEMS,JUKEBOX,LAVA,LEAVES,LEVER,MAX_Y,MEADOW_FLOWER,MIN_Y,MOSSY_BRICKS,MOSS_CARPET,NETHER_BRICKS,NETHER_PORTAL,NETHER_WART_CROP,OBSERVER,OBSIDIAN,PISTON,POINTED_DRIPSTONE_DOWN,POINTED_DRIPSTONE_UP,POLISHED_BASALT,POWDER_SNOW,POWERED_RAIL,RAIL,REDSTONE_COMPONENTS,REDSTONE_LAMP,REDSTONE_TORCH,REDSTONE_WIRE,REPEATER,SAND,SANDSTONE,SAPLING,SCULK_SENSOR,SEA,SHROOMLIGHT,SIZE,SMALL_DRIPLEAF,SMITHING_TABLE,SNOW,SOUL_SAND,SPAWNER,SPORE_BLOSSOM,SPRUCE_LEAVES,SPRUCE_LOG,STICKY_PISTON,STONE,STONE_BRICKS,TABLE,TWISTING_VINES,WARPED_FUNGUS,WARPED_ROOTS,WARPED_STEM,WATER,WEEPING_VINES,WHEAT_CROP,WOOD,biome,caveBiome,chunks,currentEdits,currentFluidStates,dimensionVoxelCaches,doorInfo,editKey,endPillars,extraId,flowFalling,flowLevels,flowSources,getBlock,growthCells,hash,hash3,idx,isDoor,isTree,key,netherBase,netherBiome,netherCeiling,netherPortalSite,noise,noise3,oreBands,portalCells,queueAround,queueGravity,redstoneCells,sensorCells,setChestLootTable,setLocal,stampStructure,strongholdLocation,strongholdY,structureAssets,terrain,villageSite,villageTemplates} = $context;

  const blocks=new Uint16Array(SIZE*SIZE*HEIGHT),ox=cx*SIZE,oz=cz*SIZE;
  const pillars=$context.dimension==='end'?endPillars():[];
  for(let z=0;z<SIZE;z++)for(let x=0;x<SIZE;x++){
    const wx=ox+x,wz=oz+z,h=terrain(wx,wz),b=$context.dimension==='nether'?netherBiome(wx,wz):biome(wx,wz),ceiling=$context.dimension==='nether'?netherCeiling(wx,wz):0,beach=h<=SEA+1;
    const sandy=b==='desert'||beach;
    const caveRoof=$context.dimension==='overworld'?Math.min(h,terrain(wx-5,wz),terrain(wx+5,wz),terrain(wx,wz-5),terrain(wx,wz+5),terrain(wx-4,wz-4),terrain(wx+4,wz-4),terrain(wx-4,wz+4),terrain(wx+4,wz+4))-(sandy?14:7):0;
    const top=$context.dimension==='overworld'?Math.max(h,SEA):95;
    for(let y=$context.dimension==='overworld'?MIN_Y:0;y<=top;y++){
      let type=AIR;
      if($context.dimension==='nether'){blocks[idx(x,y,z)]=netherBase(wx,y,wz,h,b,ceiling);continue}
      if($context.dimension==='end'){if(h>=0&&y<=h&&y>=h-13)type=END_STONE;for(const pillar of pillars){if(Math.abs(wx-pillar.x)>pillar.radius||Math.abs(wz-pillar.z)>pillar.radius)continue;if((wx-pillar.x)**2+(wz-pillar.z)**2>pillar.radius**2+1)continue;if(y>h&&y<pillar.top)type=OBSIDIAN;else if(y===pillar.top&&wx===pillar.x&&wz===pillar.z)type=BEDROCK;break}blocks[idx(x,y,z)]=type;continue}
      if(y<=h){
        if(y===MIN_Y||y<MIN_Y+5&&hash3(wx,y,wz,777)<(MIN_Y+5-y)/5)type=BEDROCK;
        else if(y===h)type=sandy?SAND:['snowy_slopes','frozen_peaks','jagged_peaks','stony_peaks'].includes(b)?STONE:GRASS;
        else if(y>h-4)type=sandy?SAND:['snowy_slopes','frozen_peaks','jagged_peaks','stony_peaks'].includes(b)?STONE:DIRT;
        else type=y<0?DEEPSLATE:y<8&&hash3(wx,y,wz,779)<(8-y)/8?DEEPSLATE:STONE;
        if(y>MIN_Y+5&&y<caveRoof){const cheese=noise3(wx,y,wz,29,17),spaghetti=Math.abs(noise3(wx,y*.82,wz,22,18)-.5),noodle=Math.abs(noise3(wx+91,y*1.3,wz-61,10,19)-.5),cave=cheese>.72||spaghetti<.025&&noise3(wx,y,wz,35,20)>.43||noodle<.01&&y<h-18;if(cave){
          // 1.18 aquifers use local fluid levels; underground aquifers can be lava below Y=0.
          // Keep the low-frequency field coherent so pools form in cave volumes instead of speckled voxels.
          const aquifer=noise3(wx,y,wz,64,109),waterline=Math.floor(SEA-14+(noise(wx,wz,100,110)-.5)*22),lavaLine=Math.floor(-48+(noise(wx,wz,86,112)-.5)*24),lavaAquifer=y<0&&aquifer<.27,waterAquifer=aquifer>.72;
          type=lavaAquifer&&y<=lavaLine?LAVA:waterAquifer&&y<=waterline?WATER:AIR
        }}
        if(type===STONE||type===DEEPSLATE){
          const copperVein=y>=0&&y<=50&&noise3(wx,y,wz,48,820)>.82,ironVein=y>=-60&&y<=-8&&noise3(wx,y,wz,48,821)>.82;
          if(copperVein)type=hash3(wx,y,wz,822)<.42?COPPER_ORE:extraId('granite');
          else if(ironVein)type=hash3(wx,y,wz,823)<.42?DEEPSLATE_IRON:extraId('tuff');
          else {const vx=Math.floor(wx/3),vy=Math.floor(y/3),vz=Math.floor(wz/3),ore=hash3(vx,vy,vz,31),shape=hash3(wx,y,wz,32)>.48;if(shape){let edge=0;for(const [id,chance] of oreBands[y-MIN_Y]){edge+=chance;if(ore<edge){if(id===extraId('emerald_ore')||id===extraId('deepslate_emerald_ore')){if(['grove','meadow','snowy_slopes','jagged_peaks','frozen_peaks','stony_peaks'].includes(b))type=id}else type=id;break}}}}
          if((type===STONE||type===DEEPSLATE)&&y<30&&hash3(Math.floor(wx/7),Math.floor(y/7),Math.floor(wz/7),825)>.9997){const shell=noise3(wx,y,wz,7,826);if(shell>.62)type=extraId('calcite');else if(shell>.55)type=extraId('amethyst_block')}
        }
      }else if(y<=SEA)type=WATER;
      blocks[idx(x,y,z)]=type;
    }
    yield;
  }
  if($context.dimension==='overworld')for(let z=0;z<SIZE;z++)for(let x=0;x<SIZE;x++){
    const wx=ox+x,wz=oz+z,h=terrain(wx,wz),surface=idx(x,h+1,z),b=biome(wx,wz);
    if(['snow','snowy_slopes','frozen_peaks','grove'].includes(b)&&h>SEA+1&&blocks[surface]===AIR)blocks[surface]=['snowy_slopes','grove'].includes(b)&&h>SEA+25&&hash(wx,wz,830)<.13?POWDER_SNOW:SNOW;
    if(b==='meadow'&&h>SEA+12&&blocks[surface]===AIR&&hash(wx,wz,831)<.06)blocks[surface]=MEADOW_FLOWER;
    if(h>SEA+2&&blocks[surface]===AIR&&caveBiome(wx,h-16,wz)==='lush_caves'&&hash(wx,wz,832)<.01)blocks[surface]=hash(wx,wz,834)<.3?FLOWERING_AZALEA:AZALEA;
    for(let y=MIN_Y+5;y<Math.min(h-8,SEA+28);y++){
      const at=idx(x,y,z);if(blocks[at]===WATER&&y<0&&hash3(wx,y,wz,836)<.006&&[STONE,DEEPSLATE].includes(blocks[idx(x,y-1,z)])){blocks[idx(x,y-1,z)]=extraId('magma');continue}if(blocks[at]!==AIR)continue;
      const floor=blocks[idx(x,y-1,z)],ceiling=blocks[idx(x,y+1,z)],region=caveBiome(wx,y,wz),roll=hash3(wx,y,wz,833);
      if(region==='lush_caves'){
        if((floor===STONE||floor===DEEPSLATE||floor===DIRT)&&roll<.29){blocks[idx(x,y-1,z)]=extraId('moss_block');if(roll<.045)blocks[at]=roll<.012?BIG_DRIPLEAF:roll<.025?SMALL_DRIPLEAF:MOSS_CARPET}
        else if((ceiling===STONE||ceiling===DEEPSLATE)&&roll<.075)blocks[at]=roll<.009?SPORE_BLOSSOM:roll<.04?GLOW_BERRIES:HANGING_ROOTS;
      }else if(region==='dripstone_caves'){
        if((floor===STONE||floor===DEEPSLATE)&&roll<.045){blocks[idx(x,y-1,z)]=extraId('dripstone_block');blocks[at]=POINTED_DRIPSTONE_UP}
        else if((ceiling===STONE||ceiling===DEEPSLATE)&&roll>.95){blocks[idx(x,y+1,z)]=extraId('dripstone_block');blocks[at]=POINTED_DRIPSTONE_DOWN}
      }
    }
    yield;
  }
  if($context.dimension==='overworld')for(let tz=oz-2;tz<oz+SIZE+2;tz++)for(let tx=ox-2;tx<ox+SIZE+2;tx++){
    const h=terrain(tx,tz),b=biome(tx,tz);
    if(b==='desert'&&h>SEA+1&&hash(tx,tz,68)<.012){for(let y=h+1;y<=h+2+Math.floor(hash(tx,tz,69)*2);y++)setLocal(blocks,cx,cz,tx,y,tz,CACTUS)}
    if(!isTree(tx,tz)||h>=MAX_Y-8)continue;
    const spruce=b==='snow'||b==='grove',birch=b==='forest'&&hash(tx,tz,73)>.68,trunk=spruce?SPRUCE_LOG:birch?BIRCH_LOG:WOOD,leaf=spruce?SPRUCE_LEAVES:birch?BIRCH_LEAVES:LEAVES,treeH=(spruce?6:4)+Math.floor(hash(tx,tz,67)*3);
    // The trunk replaces the thin snow layer above the ground.
    const trunkBase=h+1,treeTop=trunkBase+treeH-1;
    for(let y=trunkBase;y<=treeTop;y++)setLocal(blocks,cx,cz,tx,y,tz,trunk);
    for(let dy=(spruce?-treeH+3:-2);dy<=2;dy++)for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=2;dx++){
      const radius=spruce?(dy===2?0:dy>=0?1:dy%2===0?1:2):(dy>=1?1:dy>=-1?2:1);
      if(Math.abs(dx)>radius||Math.abs(dz)>radius||radius===2&&Math.abs(dx)===2&&Math.abs(dz)===2&&hash(tx+dx,tz+dz,100)>.42)continue;
      const px=tx+dx,py=treeTop+dy,pz=tz+dz;
      if(py<MIN_Y||py>=MAX_Y||px<ox||px>=ox+SIZE||pz<oz||pz>=oz+SIZE)continue;
      const at=idx(px-ox,py,pz-oz);if(blocks[at]===AIR)blocks[at]=leaf;
    }
    yield;
  }
  if($context.dimension==='overworld'){
    for(let vz=Math.floor(oz/192)-1;vz<=Math.floor(oz/192)+1;vz++)for(let vx=Math.floor(ox/192)-1;vx<=Math.floor(ox/192)+1;vx++){
      const site=villageSite(vx,vz);if(!site)continue;const centerX=site.x,centerZ=site.z;
      if(centerX<ox-42||centerX>ox+SIZE+42||centerZ<oz-42||centerZ>oz+SIZE+42)continue;
      const templates=villageTemplates(site),offsets=[[-15,-12],[15,-12],[-15,12],[15,12],[0,24]];
      for(let hi=0;hi<templates.houses.length;hi++){const name=templates.houses[hi],template=structureAssets.templates[name],[dx,dz]=offsets[hi],hx=centerX+dx-Math.floor(template.size[0]/2),hz=centerZ+dz-Math.floor(template.size[2]/2),base=terrain(centerX+dx,centerZ+dz);
        for(let zz=0;zz<template.size[2];zz++)for(let xx=0;xx<template.size[0];xx++)for(let yy=base+1;yy<=base+template.size[1];yy++)setLocal(blocks,cx,cz,hx+xx,yy,hz+zz,AIR);
        stampStructure(blocks,cx,cz,name,hx,base,hz);
      }
      const centerTemplate=structureAssets.templates[templates.center];stampStructure(blocks,cx,cz,templates.center,centerX-Math.floor(centerTemplate.size[0]/2),terrain(centerX,centerZ),centerZ-Math.floor(centerTemplate.size[2]/2));
      const path=site.biome==='desert'?SANDSTONE:extraId('coarse_dirt');for(let t=-16;t<=16;t++){setLocal(blocks,cx,cz,centerX+t,terrain(centerX+t,centerZ),centerZ,path);setLocal(blocks,cx,cz,centerX,terrain(centerX,centerZ+t),centerZ+t,path)}
      for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=2;dx++){const x=centerX+dx,z=centerZ+13+dz,h=terrain(x,z);setLocal(blocks,cx,cz,x,h,z,dx===0&&dz===0?WATER:FARMLAND);if((dx!==0||dz!==0)&&(dx+dz)%2===0)setLocal(blocks,cx,cz,x,h+1,z,WHEAT_CROP)}
    }
  }
  if($context.dimension==='overworld'){
    const site=strongholdLocation(),sy=strongholdY();
    if(Math.abs(cx*SIZE-site.x)<SIZE+22&&Math.abs(cz*SIZE-site.z)<SIZE+22){
      for(let dz=-7;dz<=7;dz++)for(let dx=-7;dx<=7;dx++)for(let dy=-1;dy<=5;dy++){
        const x=site.x+dx,y=sy+dy,z=site.z+dz,wall=Math.abs(dx)===7||Math.abs(dz)===7,entry=dz===7&&Math.abs(dx)<=1&&dy>=0&&dy<=3,type=entry?AIR:dy===-1||dy===5||wall?(hash(x,z,113)<.22?MOSSY_BRICKS:STONE_BRICKS):AIR;
        setLocal(blocks,cx,cz,x,y,z,type);
      }
      for(let dz=7;dz<=20;dz++)for(let dx=-2;dx<=2;dx++)for(let dy=-1;dy<=4;dy++){const wall=Math.abs(dx)===2||dy===-1||dy===4,end=dz===20&&dy>=0&&dy<=3;setLocal(blocks,cx,cz,site.x+dx,sy+dy,site.z+dz,wall||end?hash(dx+site.x,dz+site.z,117)<.18?MOSSY_BRICKS:STONE_BRICKS:AIR)}
      for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=2;dx++)setLocal(blocks,cx,cz,site.x+dx,sy,site.z+dz,Math.abs(dx)===2&&Math.abs(dz)<=1||Math.abs(dz)===2&&Math.abs(dx)<=1?END_FRAME:Math.abs(dx)===2&&Math.abs(dz)===2?STONE_BRICKS:AIR);
      for(let dz=-2;dz<=2;dz++)for(const dx of [-4,4])setLocal(blocks,cx,cz,site.x+dx,sy,site.z+dz,LAVA);
      for(let dz=-3;dz<=3;dz++)for(const dx of [-5,-3,3,5])setLocal(blocks,cx,cz,site.x+dx,sy,site.z+dz,STONE_BRICKS);
      for(const dz of [-3,3])for(const dx of [-4,4])setLocal(blocks,cx,cz,site.x+dx,sy,site.z+dz,STONE_BRICKS);
      setLocal(blocks,cx,cz,site.x,sy,site.z+5,SPAWNER);
      setLocal(blocks,cx,cz,site.x+5,sy,site.z+4,CHEST);setChestLootTable(site.x+5,sy,site.z+4,'chests/stronghold_corridor');
    }
  }
  if($context.dimension==='overworld')for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){
    const dcx=cx+dx,dcz=cz+dz;if(hash(dcx,dcz,612)>.012)continue;
    const sx=dcx*SIZE+8,sz=dcz*SIZE+8,sy=Math.max(8,Math.min(29,terrain(sx,sz)-13));
    if(sx<ox-4||sx>ox+SIZE+4||sz<oz-4||sz>oz+SIZE+4)continue;
    for(let zz=-4;zz<=4;zz++)for(let xx=-4;xx<=4;xx++)for(let yy=0;yy<=4;yy++){
      const wall=Math.abs(xx)===4||Math.abs(zz)===4||yy===0||yy===4;
      setLocal(blocks,cx,cz,sx+xx,sy+yy,sz+zz,wall?(hash3(sx+xx,sy+yy,sz+zz,614)<.3?extraId('mossy_cobblestone'):extraId('cobblestone')):AIR);
    }
    setLocal(blocks,cx,cz,sx,sy+1,sz,SPAWNER);setLocal(blocks,cx,cz,sx+2,sy+1,sz+2,CHEST);setChestLootTable(sx+2,sy+1,sz+2,'chests/simple_dungeon');
  }
  if($context.dimension==='overworld'&&$context.save.testWorld&&ox<32&&ox+SIZE>-32&&oz<32&&oz+SIZE>-32){
    const put=(x,y,z,id)=>setLocal(blocks,cx,cz,x,y,z,id),floor=72,clear=(x,z,top=79)=>{for(let y=73;y<=top;y++)put(x,y,z,AIR)};
    for(let z=-26;z<=26;z++)for(let x=-30;x<=30;x++){if(Math.abs(x)<=2||Math.abs(z)<=2){put(x,floor,z,STONE_BRICKS);clear(x,z,77)}}
    for(let z=-18;z<=-7;z++)for(let x=-25;x<=-10;x++){put(x,floor,z,SANDSTONE);clear(x,z);if(x===-25||x===-10||z===-18||z===-7)put(x,73,z,SANDSTONE)}
    put(-22,73,-13,WATER);put(-21,73,-13,WATER);put(-22,73,-12,WATER);put(-21,73,-12,WATER);
    for(let y=69;y<=72;y++)put(-13,y,-13,AIR);put(-13,68,-13,STONE_BRICKS);
    for(let z=-19;z<=-9;z++)for(let x=9;x<=19;x++){put(x,floor,z,STONE_BRICKS);clear(x,z,76);if(x===9||x===19||z===-19||z===-9)put(x,73,z,NETHER_BRICKS)}put(14,73,-14,LAVA);
    for(let x=-18;x<=-4;x++){put(x,72,6,STONE_BRICKS);clear(x,6,74);put(x,73,6,x===-18?LEVER:x===-4?REDSTONE_LAMP:REDSTONE_WIRE)}
    for(let z=12;z<=24;z++)for(let x=-23;x<=23;x++)if((z===12||z===24)&&x>=-22&&x<=22||(x===-22||x===22)&&z>=12&&z<=24){put(x,72,z,STONE_BRICKS);clear(x,z,75);const powered=(z===12||z===24)&&[-16,-8,0,8,16].includes(x);put(x,73,z,powered?POWERED_RAIL:RAIL);if(powered){const lz=z===12?11:25;put(x,72,lz,STONE_BRICKS);put(x,73,lz,LEVER)}}
    for(const [x,z,id] of [[1,-4,CHEST],[3,-4,CHEST],[-2,-4,TABLE],[-4,-4,FURNACE],[4,-4,ANVIL],[6,-4,SMITHING_TABLE],[8,-4,ENCHANTING_TABLE],[10,-4,BREWING_STAND],[12,-4,JUKEBOX]]){put(x,72,z,STONE_BRICKS);clear(x,z,76);put(x,73,z,id)}
    for(const [x,id] of [[-8,PISTON],[-7,STICKY_PISTON],[-6,OBSERVER],[-5,REPEATER],[-4,COMPARATOR],[-3,REDSTONE_TORCH]]){put(x,72,9,STONE_BRICKS);clear(x,9,76);put(x,73,9,id)}
    for(let x=5;x<=12;x++){put(x,72,9,STONE_BRICKS);clear(x,9,76);put(x,73,9,x===5?SNOW:x===12?POWDER_SNOW:SAND)}
    for(let a=0;a<4;a++)for(let b=0;b<5;b++)put(-9+a,73+b,-4,a===0||a===3||b===0||b===4?OBSIDIAN:NETHER_PORTAL);
  }
  if($context.dimension==='overworld'&&$context.save.testWorld&&ox<40&&ox+SIZE>-40&&oz<108&&oz+SIZE>-44){
    const put=(x,y,z,id)=>setLocal(blocks,cx,cz,x,y,z,id),clear=(x,z,top=78)=>{for(let y=73;y<=top;y++)put(x,y,z,AIR)};
    // A spaced catalogue lets players inspect and mine every registered block.
    const catalog=Object.keys(BLOCKS).map(Number).filter(id=>Number.isInteger(id)&&id!==AIR&&BLOCKS[id]?.name).sort((a,b)=>a-b);
    for(let i=0;i<catalog.length;i++){const x=-31+(i%32)*2,z=38+Math.floor(i/32)*2;put(x,72,z,STONE_BRICKS);clear(x,z);put(x,73,z,catalog[i])}
    // Chest row: every registered item appears at least once, split into ordinary 27-slot pages.
    const itemIds=Object.keys(ITEMS).map(Number).filter(id=>Number.isInteger(id)&&ITEMS[id]?.name).sort((a,b)=>a-b),pageCount=Math.ceil(itemIds.length/27);
    for(let page=0;page<pageCount;page++){const x=-24+page*2,z=-32;put(x,72,z,STONE_BRICKS);clear(x,z);put(x,73,z,CHEST)}
    // Four door facings and four lever mounts/facings make placement-state models easy to inspect.
    for(let n=0;n<4;n++){const x=16+n*2,z=31;put(x,72,z,STONE_BRICKS);clear(x,z);put(x,73,z,DOOR);put(x,74,z,DOOR_TOP)}
    const leverSamples=[{x:28,z:27,support:[0,-1,0]},{x:30,z:27,support:[1,0,0]},{x:32,z:27,support:[-1,0,0]},{x:34,z:27,support:[0,1,0]}];
    for(const sample of leverSamples){const {x,z,support}=sample;if(support[1]===-1)put(x,72,z,STONE_BRICKS);else if(support[1]===1)put(x,74,z,STONE_BRICKS);else put(x+support[0],73,z,STONE_BRICKS);put(x,73,z,LEVER)}
  }
  if($context.dimension==='nether'){
    for(let tz=oz-4;tz<oz+SIZE+4;tz++)for(let tx=ox-4;tx<ox+SIZE+4;tx++){
      const surface=terrain(tx,tz),ceiling=netherCeiling(tx,tz),region=netherBiome(tx,tz),chance=hash(tx,tz,401);
      if(tx>=ox&&tx<ox+SIZE&&tz>=oz&&tz<oz+SIZE&&surface+1<ceiling){
        if(region==='crimson_forest'||region==='warped_forest'){
          const roots=region==='crimson_forest'?CRIMSON_ROOTS:WARPED_ROOTS,fungus=region==='crimson_forest'?CRIMSON_FUNGUS:WARPED_FUNGUS;
          if(chance<.12)setLocal(blocks,cx,cz,tx,surface+1,tz,chance<.025?fungus:roots);
          if(region==='warped_forest'&&hash(tx,tz,402)<.032)for(let j=1;j<=1+Math.floor(hash(tx,tz,403)*3);j++)setLocal(blocks,cx,cz,tx,surface+j,tz,TWISTING_VINES);
        }else if(region==='nether_wastes'&&chance<.011)setLocal(blocks,cx,cz,tx,surface+1,tz,FIRE);
      }
      if(region==='basalt_deltas'&&chance<.024){const length=3+Math.floor(hash(tx,tz,404)*9);for(let j=1;j<=length&&surface+j<ceiling-2;j++)setLocal(blocks,cx,cz,tx,surface+j,tz,j%3===0?POLISHED_BASALT:extraId('basalt_side'))}
      if(region==='soul_sand_valley'&&chance<.008){const height=3+Math.floor(hash(tx,tz,405)*4);for(let j=1;j<=height&&surface+j<ceiling-2;j++)setLocal(blocks,cx,cz,tx,surface+j,tz,BONE_BLOCK)}
      if((region==='crimson_forest'||region==='warped_forest')&&surface>27&&surface+10<ceiling&&chance>.986){
        const stem=region==='crimson_forest'?CRIMSON_STEM:WARPED_STEM,cap=extraId(region==='crimson_forest'?'nether_wart_block':'warped_wart_block'),height=4+Math.floor(hash(tx,tz,406)*4);
        for(let j=1;j<=height;j++)setLocal(blocks,cx,cz,tx,surface+j,tz,stem);
        for(let dy=-1;dy<=2;dy++)for(let dz=-3;dz<=3;dz++)for(let dx=-3;dx<=3;dx++){
          const radius=dy===2?1:dy===1?2:3;if(Math.abs(dx)>radius||Math.abs(dz)>radius||Math.abs(dx)===radius&&Math.abs(dz)===radius&&hash(tx+dx,tz+dz,407)>.4)continue;
          const x=tx+dx,y=surface+height+dy,z=tz+dz;if(y<ceiling-1)setLocal(blocks,cx,cz,x,y,z,hash3(x,y,z,408)>.955?SHROOMLIGHT:cap);
          if(dy===-1&&Math.abs(dx)+Math.abs(dz)>=3&&hash3(x,y,z,409)>.88)for(let v=1;v<=2;v++)setLocal(blocks,cx,cz,x,y-v,z,WEEPING_VINES);
        }
      }
      if(hash(tx,tz,410)<.018){const length=2+Math.floor(hash(tx,tz,411)*4);for(let j=1;j<=length;j++)setLocal(blocks,cx,cz,tx,ceiling-j,tz,GLOWSTONE)}
    }
    const portalSite=netherPortalSite(),by=portalSite.by;
    for(let dx=-2;dx<=5;dx++)for(let dz=-2;dz<=2;dz++){
      const x=portalSite.x+dx,z=portalSite.z+dz;
      for(let y=by;y<=by+5;y++)setLocal(blocks,cx,cz,x,y,z,AIR);
      setLocal(blocks,cx,cz,x,by-1,z,NETHER_BRICKS);
    }
    for(let a=0;a<4;a++)for(let b=0;b<5;b++)setLocal(blocks,cx,cz,portalSite.x+a,by+b,portalSite.z,a===0||a===3||b===0||b===4?OBSIDIAN:NETHER_PORTAL);
    const fortY=terrain(62,0)+4;
    if(ox<99&&ox+SIZE>55&&oz<14&&oz+SIZE>-7){
    for(let x=56;x<=98;x++)for(let z=-2;z<=2;z++)setLocal(blocks,cx,cz,x,fortY,z,NETHER_BRICKS);
    for(let x=56;x<=98;x++)for(const z of [-3,3]){setLocal(blocks,cx,cz,x,fortY,z,NETHER_BRICKS);if(x%3!==0)setLocal(blocks,cx,cz,x,fortY+1,z,NETHER_BRICKS)}
    for(let x=58;x<=98;x+=8)for(const z of [-2,2])for(let y=terrain(x,z)+1;y<fortY;y++)setLocal(blocks,cx,cz,x,y,z,NETHER_BRICKS);
    for(let x=60;x<=72;x++)for(let z=-6;z<=6;z++){setLocal(blocks,cx,cz,x,fortY,z,NETHER_BRICKS);setLocal(blocks,cx,cz,x,fortY+5,z,NETHER_BRICKS);for(let dy=1;dy<=4;dy++){const edge=x===60||x===72||Math.abs(z)===6,entrance=(x===60||x===72)&&Math.abs(z)<=1&&dy<=3,window=dy===3&&(x===60||x===72)&&Math.abs(z)===3;setLocal(blocks,cx,cz,x,fortY+dy,z,edge&&!entrance&&!window?NETHER_BRICKS:AIR)}}
    for(const tx of [61,71])for(const tz of [-5,5])for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)for(let dy=1;dy<=10;dy++){const rim=Math.abs(dx)===1||Math.abs(dz)===1,roof=dy===10,battlement=dy===9&&(dx+dz)%2===0,window=dy>=4&&dy<=6&&(dx===0||dz===0);setLocal(blocks,cx,cz,tx+dx,fortY+dy,tz+dz,rim&&dy<=8&&!window||roof||battlement?NETHER_BRICKS:AIR)}
    for(let x=75;x<=89;x++)for(let z=-5;z<=5;z++){const landing=x>=79&&x<=87&&Math.abs(z)<=4;if(landing)setLocal(blocks,cx,cz,x,fortY+4,z,NETHER_BRICKS);if(landing&&(x===79||x===87||Math.abs(z)===4))setLocal(blocks,cx,cz,x,fortY+5,z,NETHER_BRICKS)}
    for(let x=74;x<=81;x++)for(let z=-1;z<=1;z++)setLocal(blocks,cx,cz,x,fortY+Math.floor((x-74)/2),z,NETHER_BRICKS);
    setLocal(blocks,cx,cz,83,fortY+5,0,SPAWNER);
    setLocal(blocks,cx,cz,64,fortY+1,0,CHEST);setChestLootTable(64,fortY+1,0,'chests/nether_bridge');
    for(let x=62;x<=68;x++)for(let z=7;z<=13;z++){setLocal(blocks,cx,cz,x,fortY,z,NETHER_BRICKS);for(let dy=1;dy<=3;dy++)setLocal(blocks,cx,cz,x,fortY+dy,z,x===62||x===68||z===13?NETHER_BRICKS:AIR);setLocal(blocks,cx,cz,x,fortY+4,z,NETHER_BRICKS);if(x>62&&x<68&&z>7&&z<13&&hash(x,z,515)<.7){setLocal(blocks,cx,cz,x,fortY,z,SOUL_SAND);setLocal(blocks,cx,cz,x,fortY+1,z,NETHER_WART_CROP)}}
    }
    const bastionY=Math.max(30,terrain(-72,0)+2),blackstone=extraId('polished_blackstone_bricks');
    if(ox<-63&&ox+SIZE>-89&&oz<9&&oz+SIZE>-9){
    for(let z=-8;z<=8;z++)for(let x=-80;x<=-64;x++)for(let dy=0;dy<=14;dy++){const edge=x===-80||x===-64||Math.abs(z)===8,ground=dy===0||dy===5||dy===10,broken=hash3(x,dy,z,517)<.15,corner=(x===-80||x===-64)&&Math.abs(z)===8;if(ground&&!(dy>0&&broken)||edge&&dy<=13&&(!broken||corner))setLocal(blocks,cx,cz,x,bastionY+dy,z,dy%5===0?blackstone:extraId('blackstone'))}
    for(let x=-88;x<=-80;x++)for(let z=-2;z<=2;z++){setLocal(blocks,cx,cz,x,bastionY+5,z,blackstone);if(Math.abs(z)===2&&x%3!==0)setLocal(blocks,cx,cz,x,bastionY+6,z,blackstone)}
    for(let dy=1;dy<=3;dy++)for(let x=-75;x<=-69;x++)for(let z=-3;z<=3;z++)if(Math.abs(x+72)+Math.abs(z)<4-dy)setLocal(blocks,cx,cz,x,bastionY+dy,z,extraId('gold_block'));
    setLocal(blocks,cx,cz,-72,bastionY+6,0,CHEST);setChestLootTable(-72,bastionY+6,0,'chests/bastion_treasure');
    }
  }
  if($context.dimension==='end'&&ox<205&&ox+SIZE>120&&oz<40&&oz+SIZE>-30){
    const base=Math.max(47,terrain(144,0));for(let zz=-26;zz<=30;zz++)for(let xx=122;xx<=196;xx++)if(Math.hypot((xx-159)*.6,zz)<29)for(let yy=base-5;yy<=base;yy++)setLocal(blocks,cx,cz,xx,yy,zz,END_STONE);
    for(const [name,x,y,z] of [['base_floor',139,base, -5],['second_floor_1',138,base+3,-6],['third_floor_1',137,base+10,-7],['third_roof',136,base+17,-8],['tower_base',141,base+18,-3],['tower_piece',141,base+24,-3],['tower_piece',141,base+28,-3],['tower_top',140,base+32,-4],['ship',177,base+17,-13]])stampStructure(blocks,cx,cz,'end_city/'+name,x,y,z);
    for(let z=4;z<24;z+=4)stampStructure(blocks,cx,cz,'end_city/bridge_piece',142,base+24,z);
  }
  if($context.dimension==='end'){
    const y=terrain(0,0)+1;
    for(let x=-2;x<=2;x++)for(let z=-2;z<=2;z++){
      setLocal(blocks,cx,cz,x,y-1,z,BEDROCK);
      const rim=Math.abs(x)===2||Math.abs(z)===2;
      setLocal(blocks,cx,cz,x,y,z,rim||x===0&&z===0?BEDROCK:$context.save.dragonDefeated?END_PORTAL:AIR);
    }
    for(let level=1;level<=3;level++)setLocal(blocks,cx,cz,0,y+level,0,BEDROCK);
  }
  const changedCells=[];
  for(const [k,v] of Object.entries(currentEdits())){
    const [x,y,z]=k.split(',').map(Number);
    if(x>=ox&&x<ox+SIZE&&z>=oz&&z<oz+SIZE&&y>=MIN_Y&&y<MAX_Y){blocks[idx(x-ox,y,z-oz)]=v;changedCells.push([x,y,z])}
  }
  const topY=$context.dimension==='overworld'?Math.min(MAX_Y-1,(Math.max(SEA+2,...Array.from({length:SIZE*SIZE},(_,i)=>terrain(ox+i%SIZE,oz+Math.floor(i/SIZE))))+20)):$context.dimension==='nether'?127:95;
  const chunk={cx,cz,blocks,meshes:[],topY:Math.max(topY,...changedCells.map(cell=>cell[1]+1))},fluidStarts=[],gravityStarts=[],newGrowth=[],newRedstone=[],newSensors=[];
  if($context.entityWorldContext){$context.entityWorldContext.chunks.set(key(cx,cz),chunk);dimensionVoxelCaches.get($context.dimension)?.set(key(cx,cz),chunk);return chunk}
  if($context.portalPreviewMode){$context.portalPreviewChunks.set(key(cx,cz),chunk);return chunk}
  const localBlock=(x,y,z)=>x>=0&&x<SIZE&&z>=0&&z<SIZE?blocks[idx(x,y,z)]:getBlock(ox+x,y,oz+z);
  for(let z=0;z<SIZE;z++)for(let x=0;x<SIZE;x++){for(let y=MIN_Y+1;y<=chunk.topY;y++){
    const type=blocks[idx(x,y,z)],wx=ox+x,wz=oz+z;
    if(type===NETHER_PORTAL||type===END_PORTAL)portalCells.add(editKey(wx,y,wz));
    if((type===SAND||type===GRAVEL)&&blocks[idx(x,y-1,z)]===AIR)gravityStarts.push([wx,y,wz]);
    else if(type===WATER||type===LAVA){if(localBlock(x,y-1,z)===AIR||[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dz])=>{const b=localBlock(x+dx,y,z+dz);return b===AIR||b===WATER&&type===LAVA||b===LAVA&&type===WATER}))fluidStarts.push([wx,y,wz])}
    else if(type===SAPLING||type===CROP_0||type===CROP_1||type===CROP_2||type===GLOW_BERRIES||type===TWISTING_VINES||type===WEEPING_VINES)newGrowth.push(editKey(wx,y,wz));
    if(REDSTONE_COMPONENTS.has(type)||isDoor(type)&&doorInfo(type).half!=='upper')newRedstone.push(editKey(wx,y,wz));if(type===SCULK_SENSOR||type===CALIBRATED_SCULK_SENSOR)newSensors.push(editKey(wx,y,wz));
  }yield}
  chunks.set(key(cx,cz),chunk);
  for(const [x,y,z] of changedCells){const k=editKey(x,y,z),type=blocks[idx(x-ox,y,z-oz)],state=currentFluidStates()[k];if(type===WATER||type===LAVA){if(state===undefined||state===0)flowSources.add(k);else{flowLevels.set(k,Math.min(8,state));if(state>8)flowFalling.add(k)}}queueAround(x,y,z);queueGravity(x,y+1,z)}
  for(const [x,y,z] of gravityStarts)queueGravity(x,y,z);
  for(const [x,y,z] of fluidStarts)queueAround(x,y,z);
  for(const k of newGrowth)growthCells.add(k);
  for(const k of newRedstone)redstoneCells.add(k);for(const k of newSensors)sensorCells.add(k);
  return chunk;
}

function generate(cx,cz){
    const {generateChunk} = $context;
const task=generateChunk(cx,cz);let result;do{result=task.next()}while(!result.done);return result.value}

function stampStructure(blocks,cx,cz,name,x,y,z){
    const {BED,CHEST,LAVA,SIZE,SNOW,TRAPPED_CHEST,WATER,currentEdits,currentFluidStates,editKey,isDoor,redstoneData,setChestLootTable,setLocal,setSnowLayersMetadata,structureAssets} = $context;

  const template=structureAssets.templates[name];if(!template)return;
  const ox=cx*SIZE,oz=cz*SIZE;if(x+template.size[0]<=ox||x>=ox+SIZE||z+template.size[2]<=oz||z>=oz+SIZE)return;
  for(const [dx,dy,dz,index] of template.blocks){const entry=template.palette[index],wx=x+dx,wy=y+dy,wz=z+dz;if(entry.id<0||wx<ox||wx>=ox+SIZE||wz<oz||wz>=oz+SIZE)continue;setLocal(blocks,cx,cz,wx,wy,wz,entry.id);
    const props=entry.props,k=editKey(wx,wy,wz),facing={north:[0,-1],south:[0,1],west:[-1,0],east:[1,0]}[props.facing];
    if((isDoor(entry.id)||[CHEST,TRAPPED_CHEST].includes(entry.id))&&facing){const data=redstoneData();data[k]??={facing,hinge:props.hinge||'left'};if(isDoor(entry.id)&&props.half!=='upper'&&props.open==='true')$context.save.openDoors[k]??=true}
    if(entry.id===CHEST&&name.startsWith('village/')){const theme=name.split('/')[1];setChestLootTable(wx,wy,wz,`chests/village/village_${theme}_house`)}
    if(entry.id===BED&&facing){redstoneData()[k]??={bedPart:props.part||'head',facing}}
    if((entry.id===WATER||entry.id===LAVA)&&currentEdits()[k]===undefined){const level=Number(props.level||0);currentFluidStates()[k]=level===0?0:level>=8?16:8-level}
    if(entry.name==='wall_torch'&&facing)redstoneData()[k]={support:[-facing[0],0,-facing[1]]};
    if(entry.id===SNOW&&props.layers)setSnowLayersMetadata(k,Number(props.layers));
  }
  for(const [dx,dy,dz,table] of template.loot||[]){const wx=x+dx,wz=z+dz;if(wx>=ox&&wx<ox+SIZE&&wz>=oz&&wz<oz+SIZE)setChestLootTable(wx,y+dy,wz,table)}
}

function setLocal(blocks,cx,cz,x,y,z,id){
    const {MAX_Y,MIN_Y,SIZE,idx} = $context;
if(y<MIN_Y||y>=MAX_Y||x<cx*SIZE||x>=cx*SIZE+SIZE||z<cz*SIZE||z>=cz*SIZE+SIZE)return;blocks[idx(x-cx*SIZE,y,z-cz*SIZE)]=id}

function setSnowLayersMetadata(k,layers){$context.save.snowLayers[$context.dimension+':'+k]??=layers}

function setChestLootTable(x,y,z,table){
    const {editKey} = $context;
const k=$context.dimension+':'+editKey(x,y,z);$context.save.chestLootTables??={};$context.save.chestLootTables[k]??=table}
return {hash,hash3,smooth,noise,noise3,cacheSample,climate,biome,caveBiome,terrain,netherBiome,netherCeiling,netherPortalSite,endPillars,netherBase,isTree,spawnPoint,strongholdLocation,strongholdY,villageSite,villageAt,isVillageChest,isStrongholdFrame,villageTemplates,generateChunk,generate,stampStructure,setLocal,setSnowLayersMetadata,setChestLootTable};
}
