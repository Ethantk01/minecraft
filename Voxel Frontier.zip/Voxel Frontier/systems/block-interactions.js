/** block interactions subsystem. Dependencies are injected at composition time. */
export function createBlockInteractionsSystem($context) {
function placeDirectional(x,y,z,type){
 const {structureAssets,player,redstoneData,editKey,setBlock,updateBlockModelImmediately}= $context;
 const source=structureAssets.blocks.find(b=>b.id===type),props=source?.properties||{};
 if(!setBlock(x,y,z,type))return false;
 if(props.facing||props.axis){const dx=-Math.sin(player.yaw),dz=-Math.cos(player.yaw),facing=Math.abs(dx)>Math.abs(dz)?[Math.sign(dx),0]:[0,Math.sign(dz)];redstoneData()[editKey(x,y,z)]={facing,axis:Math.abs(dx)>Math.abs(dz)?'x':'z'};updateBlockModelImmediately(x,y,z);}
 return true;
}
function placeTorch(x,y,z,type,hit){
    const {BLOCKS,REDSTONE_TORCH,editKey,getBlock,processRedstone,redstoneData,setBlock} = $context;
const support=hit&&Math.abs(hit.x-x)+Math.abs(hit.y-y)+Math.abs(hit.z-z)===1?[hit.x-x,hit.y-y,hit.z-z]:[0,-1,0];if(support[1]>0||!BLOCKS[getBlock(x+support[0],y+support[1],z+support[2])]?.solid)return false;if(type===REDSTONE_TORCH)$context.save.redstoneTorchSupports[editKey(x,y,z)]=support;else redstoneData()[editKey(x,y,z)]={support};if(!setBlock(x,y,z,type))return false;if(type===REDSTONE_TORCH)processRedstone();return true}

function placeDoorVariant(x,y,z,type){
    const {AIR,doorInfo,getBlock,occupied,placeDoor,setBlockBatch,solid,structureAssets} = $context;
const info=doorInfo(type);if(!info)return false;const partner=structureAssets.blocks.find(b=>b.minecraftId===info.name&&b.properties.half==='upper')?.id;if(!partner||getBlock(x,y,z)!==AIR||getBlock(x,y+1,z)!==AIR||occupied(x,y,z)||occupied(x,y+1,z)||!solid(x,y-1,z))return false;const lower=info.half==='lower'?type:structureAssets.blocks.find(b=>b.minecraftId===info.name&&b.properties.half==='lower')?.id;if(!lower)return false;placeDoor(x,y,z);setBlockBatch([[x,y,z,lower],[x,y+1,z,partner]]);return true}

function breakDoorPartner(x,y,z,type){
    const {AIR,DOOR,DOOR_TOP,doorInfo,editKey,getBlock,redstoneData,setBlock} = $context;
const info=doorInfo(type);if(!info||type===DOOR||type===DOOR_TOP)return;const py=info.half==='upper'?y-1:y+1;if(doorInfo(getBlock(x,py,z))?.name===info.name)setBlock(x,py,z,AIR);const lowerY=info.half==='upper'?y-1:y;delete $context.save.openDoors[editKey(x,lowerY,z)];delete redstoneData()[editKey(x,lowerY,z)]}

function bedState(x,y,z){
    const {BED,editKey,getBlock,redstoneData} = $context;

  const data=redstoneData(),k=editKey(x,y,z);if(data[k]?.bedPart)return data[k];
  // Older generated beds had no half/facing metadata: recover a pair once.
  for(const [dx,dz] of [[-1,0],[0,-1],[1,0],[0,1]])if(getBlock(x+dx,y,z+dz)===BED){const head=dx<0||dz<0,face=head?[dx,dz]:[-dx,-dz];return {bedPart:head?'foot':'head',facing:face}}
  return {bedPart:'head',facing:[0,-1]};
}

function placeBed(x,y,z){
    const {AIR,BED,editKey,getBlock,occupied,player,redstoneData,setBlockBatch,showToast,solid} = $context;

  const dx=-Math.sin(player.yaw),dz=-Math.cos(player.yaw),facing=Math.abs(dx)>Math.abs(dz)?[Math.sign(dx),0]:[0,Math.sign(dz)],hx=x+facing[0],hz=z+facing[1];
  if(getBlock(x,y,z)!==AIR||getBlock(hx,y,hz)!==AIR||occupied(x,y,z)||occupied(hx,y,hz)||!solid(x,y-1,z)||!solid(hx,y-1,hz)){showToast('BED NEEDS TWO CLEAR, SUPPORTED BLOCKS');return false}
  setBlockBatch([[x,y,z,BED],[hx,y,hz,BED]]);const data=redstoneData();data[editKey(x,y,z)]={bedPart:'foot',facing};data[editKey(hx,y,hz)]={bedPart:'head',facing};$context.dirtySave=true;return true;
}

function breakBedPartner(x,y,z){
    const {AIR,BED,bedState,editKey,getBlock,redstoneData,setBlock} = $context;
const state=bedState(x,y,z),sign=state.bedPart==='foot'?1:-1,[dx,dz]=state.facing,nx=x+dx*sign,nz=z+dz*sign;if(getBlock(nx,y,nz)===BED){setBlock(nx,y,nz,AIR);delete redstoneData()[editKey(nx,y,nz)]}delete redstoneData()[editKey(x,y,z)]}

function toggleDoor(hit){
    const {doorInfo,editKey,playSound,showToast,updateDoorModelImmediately} = $context;
if(doorInfo(hit.type)?.name==='iron_door'){showToast('IRON DOOR NEEDS REDSTONE');return}const y=doorInfo(hit.type)?.half==='upper'?hit.y-1:hit.y,k=editKey(hit.x,y,hit.z);$context.save.openDoors??={};$context.save.openDoors[k]=!$context.save.openDoors[k];updateDoorModelImmediately(hit.x,y,hit.z);$context.dirtySave=true;playSound($context.save.openDoors[k]?'door_open':'door_close');showToast($context.save.openDoors[k]?'DOOR OPENED':'DOOR CLOSED')}

function sleepAtBed(){
    const {showToast} = $context;
const phase=(($context.tick/(Math.PI*2))%1+1)%1;if(phase>.52||phase<.03){$context.tick=(Math.floor($context.tick/(Math.PI*2))+1)*Math.PI*2+.12*Math.PI;if($context.save.weather.kind!=='clear'){$context.save.weather.kind='clear';$context.save.weather.remaining=360+Math.random()*550}$context.player.sleepingUntil=performance.now()+1800;$context.player.fireTime=0;$context.dirtySave=true;showToast('SLEPT UNTIL MORNING')}else showToast('RESPAWN POINT SET')}

function respawnPlayer(){
    const {BLOCKS,BED,currentEdits,editKey,getBlock,player,spawnPoint,teleportTo} = $context;
if($context.dimension!=='overworld')teleportTo('overworld');const bed=$context.save.bedSpawn;if(bed&&(/ bed$/i.test(BLOCKS[getBlock(bed.x,bed.y,bed.z)]?.name||''))){player.x=bed.x+.5;player.y=bed.y+1;player.z=bed.z+.5}else Object.assign(player,spawnPoint());Object.assign(player,$context.ensureSafeSpawn(player));player.fireTime=0;player.vy=0;player.knockVx=player.knockVz=0;player.grounded=false;$context.dirtySave=true}

function clearChestLootReference(hit){
    const {editKey} = $context;
if($context.save.chestLootTables)delete $context.save.chestLootTables[$context.dimension+':'+editKey(hit.x,hit.y,hit.z)]}

function ensureChestLoot(hit){
    const {SPAWNER,chestLoot,chestRandom,editKey,getBlock,isVillageChest,strongholdLocation,villageAt} = $context;
const cell=$context.dimension+':'+editKey(hit.x,hit.y,hit.z);$context.save.chests??={};if($context.save.chests[cell])return $context.save.chests[cell];let table=$context.save.chestLootTables?.[cell];
  if(!table){if($context.dimension==='end'&&Math.hypot(hit.x-144,hit.z)<50)table='chests/end_city_treasure';else if($context.dimension==='nether'&&Math.abs(hit.x+72)<15)table='chests/bastion_treasure';else if($context.dimension==='nether'&&Math.abs(hit.x-64)<40)table='chests/nether_bridge';else if($context.dimension==='overworld'&&isVillageChest(hit.x,hit.z)){const site=villageAt(hit.x,hit.z);table=`chests/village/village_${site?.biome==='snow'?'snowy':site?.biome==='desert'?'desert':'plains'}_house`}else if($context.dimension==='overworld'){const site=strongholdLocation();if(Math.abs(hit.x-site.x)<12&&Math.abs(hit.z-site.z)<24)table='chests/stronghold_corridor';else for(let dz=-4;dz<=4&&!table;dz++)for(let dx=-4;dx<=4;dx++)if(getBlock(hit.x+dx,hit.y,hit.z+dz)===SPAWNER){table='chests/simple_dungeon';break}}}
  $context.save.chests[cell]=table?chestLoot.generate(table,chestRandom($context.save.seed,$context.dimension,hit.x,hit.y,hit.z)):Array(27).fill(null);$context.dirtySave=true;return $context.save.chests[cell];
}
return {placeDirectional,placeTorch,placeDoorVariant,breakDoorPartner,bedState,placeBed,breakBedPartner,toggleDoor,sleepAtBed,respawnPlayer,clearChestLootReference,ensureChestLoot};
}
