/** fluids subsystem. Dependencies are injected at composition time. */
export function createFluidsSystem($context) {
function liquidLevel(x,y,z,type){
    const {currentFluidStates,editKey,flowLevels,getBlock} = $context;
if(getBlock(x,y,z)!==type)return 0;const k=editKey(x,y,z),state=currentFluidStates()[k];return flowLevels.get(k)||(state?Math.min(8,state):8)}

function fluidLevel(x,y,z){
    const {WATER,liquidLevel} = $context;
return liquidLevel(x,y,z,WATER)}

function isSource(x,y,z){
    const {LAVA,SIZE,WATER,chunks,currentEdits,currentFluidStates,editKey,flowLevels,flowSources,getBlock,key} = $context;
const type=getBlock(x,y,z);if(type!==WATER&&type!==LAVA)return false;const k=editKey(x,y,z);const state=currentFluidStates()[k];return state!==undefined?state===0:flowSources.has(k)||!flowLevels.has(k)&&currentEdits()[k]===undefined&&chunks.has(key(Math.floor(x/SIZE),Math.floor(z/SIZE)))}

function queueFlow(x,y,z,urgent=false){
    const {MAX_Y,MIN_Y,SIZE,chunks,editKey,flowQueue,flowQueued,key,urgentFlowQueue,urgentFlowQueued} = $context;
if(y<MIN_Y||y>=MAX_Y||!chunks.has(key(Math.floor(x/SIZE),Math.floor(z/SIZE))))return;const k=editKey(x,y,z);if(urgent){if(!urgentFlowQueued.has(k)){urgentFlowQueued.add(k);urgentFlowQueue.push([x,y,z]);flowQueued.add(k)}}else if(!flowQueued.has(k)){flowQueued.add(k);flowQueue.push([x,y,z])}}

function queueAround(x,y,z,urgent=false){
    const {faces,queueFlow} = $context;
queueFlow(x,y,z,urgent);for(const f of faces)queueFlow(x+f.d[0],y+f.d[1],z+f.d[2],urgent)}

function flowPassable(x,y,z,type){
    const {AIR,getBlock,isSource} = $context;
const block=getBlock(x,y,z);return block===AIR||block===type&&!isSource(x,y,z)}

function canFlowSideways(x,y,z,type){
    const {flowPassable,fluidDirections,getBlock,isSource} = $context;
return !flowPassable(x,y-1,z,type)||fluidDirections.reduce((n,[dx,dz])=>n+Number(getBlock(x+dx,y,z+dz)===type&&isSource(x+dx,y,z+dz)),0)>=3}

function flowDropDistance(x,y,z,dx,dz,type,maxDistance){
    const {flowPassable,fluidDirections} = $context;
const startX=x+dx,startZ=z+dz;if(flowPassable(startX,y-1,startZ,type))return 0;const queue=[[startX,startZ,0]],seen=new Set([startX+','+startZ]);for(let head=0;head<queue.length;head++){const [cx,cz,distance]=queue[head];if(distance>=maxDistance)continue;for(const [sx,sz] of fluidDirections){const nx=cx+sx,nz=cz+sz,k=nx+','+nz;if(nx===x&&nz===z||seen.has(k)||!flowPassable(nx,y,nz,type))continue;if(flowPassable(nx,y-1,nz,type))return distance+1;seen.add(k);queue.push([nx,nz,distance+1])}}return Infinity}

function spreadMask(x,y,z,type){
    const {WATER,editKey,flowDropDistance,flowPassable,fluidDirections,spreadCache} = $context;
const cacheKey=type+':'+editKey(x,y,z);if(spreadCache.has(cacheKey))return spreadCache.get(cacheKey);let open=0,best=Infinity,preferred=0;const maxDistance=type===WATER||$context.dimension==='nether'?4:2;for(let i=0;i<4;i++){const [dx,dz]=fluidDirections[i];if(!flowPassable(x+dx,y,z+dz,type))continue;open|=1<<i;const distance=flowDropDistance(x,y,z,dx,dz,type,maxDistance);if(distance<best){best=distance;preferred=1<<i}else if(distance===best)preferred|=1<<i}const mask=best===Infinity?open:preferred;spreadCache.set(cacheKey,mask);return mask}

function waterCurrent(x,y,z){
    const {AIR,WATER,fluidDirections,getBlock,isSource,liquidLevel,spreadMask} = $context;
if(getBlock(x,y,z)!==WATER)return {x:0,y:0,z:0};const level=liquidLevel(x,y,z,WATER),mask=spreadMask(x,y,z,WATER);let vx=0,vz=0;for(let i=0;i<4;i++){if(!(mask&(1<<i)))continue;const [dx,dz]=fluidDirections[i],neighbor=getBlock(x+dx,y,z+dz);if(neighbor!==AIR&&neighbor!==WATER)continue;const fall=neighbor===WATER?Math.max(0,level-liquidLevel(x+dx,y,z+dz,WATER)):level;vx+=dx*fall;vz+=dz*fall}const length=Math.hypot(vx,vz);return {x:length?vx/length:0,z:length?vz/length:0,y:!isSource(x,y,z)&&getBlock(x,y+1,z)===WATER?-1:0}}

function processFlow(){
    const {AIR,LAVA,OBSIDIAN,SIZE,WATER,canFlowSideways,chunks,currentEdits,currentFluidStates,editKey,extraId,flowFalling,flowLevels,flowQueue,flowQueued,flowSources,fluidDirections,getBlock,idx,isSource,key,liquidLevel,queueAround,queueGravity,scheduleBlockMesh,scheduleEditLighting,solid,spreadCache,spreadMask,urgentFlowQueue,urgentFlowQueued} = $context;

  $context.flowStep++;spreadCache.clear();const changed=new Set(),batch=[],updates=[];let budget=320;
  while(budget--&&($context.urgentFlowHead<urgentFlowQueue.length||$context.flowHead<flowQueue.length))batch.push($context.urgentFlowHead<urgentFlowQueue.length?urgentFlowQueue[$context.urgentFlowHead++]:flowQueue[$context.flowHead++]);
  for(const [x,y,z] of batch){const k=editKey(x,y,z);if(!flowQueued.has(k))continue;flowQueued.delete(k);urgentFlowQueued.delete(k);const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=chunks.get(key(cx,cz));if(!chunk)continue;const old=getBlock(x,y,z);if(old!==AIR&&old!==WATER&&old!==LAVA)continue;
    if(old===LAVA&&fluidDirections.some(([dx,dz])=>getBlock(x+dx,y,z+dz)===WATER)){chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)]=isSource(x,y,z)?OBSIDIAN:extraId('cobblestone');currentEdits()[k]=chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)];delete currentFluidStates()[k];flowLevels.delete(k);flowSources.delete(k);flowFalling.delete(k);scheduleBlockMesh(x,y,z);changed.add(key(cx,cz));spreadCache.clear();queueAround(x,y,z);$context.multiplayer?.publishEdit(x,y,z,currentEdits()[k]);continue}
    const source=isSource(x,y,z);let desired=source?8:0,nextType=source?old:AIR,falling=false;for(const type of [WATER,LAVA]){const above=liquidLevel(x,y+1,z,type);let level=above?8:0;if(level<8)for(let i=0;i<4;i++){const [dx,dz]=fluidDirections[i],nx=x+dx,nz=z+dz,donor=liquidLevel(nx,y,nz,type),support=getBlock(nx,y-1,nz);if(donor&&canFlowSideways(nx,y,nz,type)&&(spreadMask(nx,y,nz,type)&(1<<(i^1))))level=Math.max(level,donor-(type===LAVA&&$context.dimension!=='nether'?2:1))}if(level>desired||level===desired&&type===WATER&&nextType===LAVA){desired=level;nextType=type;falling=!!above&&!source}}
    if(!source&&nextType===WATER&&(solid(x,y-1,z)||getBlock(x,y-1,z)===WATER&&isSource(x,y-1,z))&&fluidDirections.reduce((n,[dx,dz])=>n+Number(getBlock(x+dx,y,z+dz)===WATER&&isSource(x+dx,y,z+dz)),0)>=2){updates.push(()=>{flowSources.add(k);flowLevels.delete(k);flowFalling.delete(k);currentFluidStates()[k]=0;$context.dirtySave=true;});desired=8;falling=false}
    if((old===LAVA||nextType===LAVA)&&$context.flowStep%($context.dimension==='nether'?2:4)!==0){urgentFlowQueue.push([x,y,z]);urgentFlowQueued.add(k);flowQueued.add(k);continue}
    if(old===LAVA&&nextType===WATER){chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)]=isSource(x,y,z)?OBSIDIAN:extraId('cobblestone');currentEdits()[k]=chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)];delete currentFluidStates()[k];flowLevels.delete(k);flowSources.delete(k);flowFalling.delete(k);scheduleBlockMesh(x,y,z);changed.add(key(cx,cz));spreadCache.clear();queueAround(x,y,z);$context.multiplayer?.publishEdit(x,y,z,currentEdits()[k]);continue}
    const oldLevel=old!==AIR?(flowLevels.get(k)||8):0;if(oldLevel===desired&&old===nextType&&flowFalling.has(k)===falling)continue;
    updates.push(()=>{
    chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)]=desired?nextType:AIR;currentEdits()[k]=desired?nextType:AIR;$context.dirtySave=true;
    if(desired){if(flowSources.has(k)){flowLevels.delete(k);flowFalling.delete(k);currentFluidStates()[k]=0}else{flowLevels.set(k,desired);if(falling)flowFalling.add(k);else flowFalling.delete(k);currentFluidStates()[k]=desired+(falling?8:0)}}else{flowLevels.delete(k);flowSources.delete(k);flowFalling.delete(k);delete currentFluidStates()[k]}
    spreadCache.clear();$context.multiplayer?.publishEdit(x,y,z,desired?nextType:AIR);scheduleBlockMesh(x,y,z);changed.add(key(cx,cz));if(x%SIZE===0)changed.add(key(cx-1,cz));if(x%SIZE===SIZE-1)changed.add(key(cx+1,cz));if(z%SIZE===0)changed.add(key(cx,cz-1));if(z%SIZE===SIZE-1)changed.add(key(cx,cz+1));queueAround(x,y,z,true);queueGravity(x,y+1,z,true);
    });
  }
  for(const apply of updates)apply();
  if($context.flowHead>2048&&$context.flowHead*2>flowQueue.length){flowQueue.splice(0,$context.flowHead);$context.flowHead=0}
  if($context.urgentFlowHead>2048&&$context.urgentFlowHead*2>urgentFlowQueue.length){urgentFlowQueue.splice(0,$context.urgentFlowHead);$context.urgentFlowHead=0}
  for(const k of changed)scheduleEditLighting(chunks.get(k))
}
return {liquidLevel,fluidLevel,isSource,queueFlow,queueAround,flowPassable,canFlowSideways,flowDropDistance,spreadMask,waterCurrent,processFlow};
}
