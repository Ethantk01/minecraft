/** vehicles subsystem. Dependencies are injected at composition time. */
export function createVehiclesSystem($context) {
function startMinecartFall(cart){
  cart.offRail=true;cart.railCooldown=.12;cart.departedRail={...cart.cell};
  const launchSpeed=Math.min(4,cart.speed);
  cart.vx=cart.dir[0]*launchSpeed;cart.vz=cart.dir[1]*launchSpeed;cart.vy=cart.slopeVelocity||0;
  cart.progress=0;cart.previous=null;
}

function updateMinecartOffRail(cart,dt){
    const {RAIL_TYPES,getBlock,railShape,solid} = $context;

  const mesh=cart.mesh,substeps=Math.max(1,Math.ceil(dt/.025));
  for(let step=0;step<substeps;step++){
    const h=dt/substeps;cart.railCooldown=Math.max(0,(cart.railCooldown||0)-h);
    const oldY=mesh.position.y;cart.vy=Math.max(-32,cart.vy-24*h);
    const nx=mesh.position.x+cart.vx*h,nz=mesh.position.z+cart.vz*h;
    const blocked=(px,pz)=>{for(const ox of [-.36,.36])for(const oz of [-.36,.36])for(const oy of [.08,.3])if(solid(Math.floor(px+ox),Math.floor(oldY+oy),Math.floor(pz+oz)))return true;return false};
    if(blocked(nx,mesh.position.z))cart.vx=0;else mesh.position.x=nx;
    if(blocked(mesh.position.x,nz))cart.vz=0;else mesh.position.z=nz;
    const cx=Math.floor(mesh.position.x),cz=Math.floor(mesh.position.z),railY=Math.floor(oldY-.01);
    if(!cart.railCooldown&&cart.vy<=0){
      for(const ry of [railY,railY-1]){
        if(!RAIL_TYPES.has(getBlock(cx,ry,cz))||cart.departedRail?.x===cx&&cart.departedRail?.y===ry&&cart.departedRail?.z===cz||oldY<ry+.04||oldY>ry+.52)continue;
        const shape=railShape(cx,ry,cz),offset=shape.axis==='x'?Math.abs(mesh.position.z-cz-.5):shape.axis==='z'?Math.abs(mesh.position.x-cx-.5):Math.hypot(mesh.position.x-cx-.5,mesh.position.z-cz-.5);
        if(offset>.24)continue;
        cart.offRail=false;cart.cell={x:cx,y:ry,z:cz};cart.previous=null;cart.progress=0;cart.speed=Math.hypot(cart.vx,cart.vz);
        cart.entryOffsetX=mesh.position.x-cx-.5;cart.entryOffsetZ=mesh.position.z-cz-.5;
        cart.dir=shape.directions.map(([dx,dz])=>[dx,dz]).sort((a,b)=>b[0]*cart.vx+b[1]*cart.vz-a[0]*cart.vx-a[1]*cart.vz)[0];
        mesh.position.y=ry+.05;mesh.rotation.x=0;return;
      }
    }
    const nextY=oldY+cart.vy*h;
    if(cart.vy<0){
      let support=-Infinity;
      for(const ox of [-.3,.3])for(const oz of [-.3,.3]){
        const bx=Math.floor(mesh.position.x+ox),bz=Math.floor(mesh.position.z+oz),by=Math.floor(nextY-.06);
        if(solid(bx,by,bz))support=Math.max(support,by+1+.05);
      }
      if(support>-Infinity&&nextY<=support){mesh.position.y=support;cart.vy=0;cart.vx*=Math.max(0,1-.8*h);cart.vz*=Math.max(0,1-.8*h)}
      else mesh.position.y=nextY;
    }else mesh.position.y=nextY;
    const drag=Math.max(0,1-3*h);cart.vx*=drag;cart.vz*=drag;
    if(Math.hypot(cart.vx,cart.vz)>.05)mesh.rotation.y=Math.atan2(cart.vx,cart.vz);
    mesh.rotation.x=Math.max(-.35,Math.min(.35,-cart.vy*.025));
  }
  cart.speed=Math.hypot(cart.vx,cart.vz);
}

function updateMinecarts(dt){
    const {ACTIVATOR_RAIL,POWERED_RAIL,RAIL_TYPES,SIZE,dismountVehicle,editKey,entityWorldChunks,getBlock,key,keys,parkedVehicles,player,railShape,redstoneLevels,startMinecartFall,updateMinecartOffRail} = $context;

  for(const cart of parkedVehicles){
    if($context.entityWorldContext&&!entityWorldChunks().has(key(Math.floor(cart.mesh.position.x/SIZE),Math.floor(cart.mesh.position.z/SIZE))))continue;if(cart.kind!=='minecart')continue;
    let {x,y,z}=cart.cell;if(!cart.offRail&&!RAIL_TYPES.has(getBlock(x,y,z)))startMinecartFall(cart);
    if(cart.offRail){updateMinecartOffRail(cart,dt);if($context.vehicle===cart){player.x=cart.mesh.position.x;player.y=cart.mesh.position.y+.33;player.z=cart.mesh.position.z;player.vy=0}continue}
    const railType=getBlock(x,y,z),powered=railType===POWERED_RAIL,active=!!($context.entityWorldContext?.power||redstoneLevels).get(editKey(x,y,z));if(railType===ACTIVATOR_RAIL&&active&&$context.vehicle===cart)dismountVehicle();
    if(powered)cart.speed=active&&cart.speed>0?Math.min(8,cart.speed+5*dt):active?0:Math.max(0,cart.speed-9*dt);
    else cart.speed=Math.max(0,cart.speed-($context.vehicle===cart?.65:.18)*dt);
    if($context.vehicle===cart&&keys.has('KeyW'))cart.speed=Math.min(8,cart.speed+2.8*dt);
    if($context.vehicle===cart&&keys.has('KeyS'))cart.speed=Math.max(0,cart.speed-5*dt);
    let distance=cart.speed*dt,steps=0;
    while(distance>0&&steps++<4){
      const shape=railShape(x,y,z),choices=shape.directions.map(([dx,dz,dy])=>({x:x+dx,y:y+dy,z:z+dz,dx,dz})).filter(p=>RAIL_TYPES.has(getBlock(p.x,p.y,p.z)));
      let next=choices.find(p=>p.dx===cart.dir[0]&&p.dz===cart.dir[1]);
      if(!next&&cart.previous)next=choices.find(p=>p.x!==cart.previous.x||p.y!==cart.previous.y||p.z!==cart.previous.z);
      if(!next){const travel=Math.min(distance,Math.max(0,.5-cart.progress));cart.progress+=travel;distance-=travel;cart.mesh.position.set(x+.5+cart.dir[0]*cart.progress,y+.05,z+.5+cart.dir[1]*cart.progress);if(cart.progress>=.499){startMinecartFall(cart);updateMinecartOffRail(cart,Math.min(dt,distance/Math.max(cart.speed,.001)))}break}
      const remaining=1-cart.progress,travel=Math.min(distance,remaining);cart.progress+=travel;distance-=travel;
      const t=cart.progress,px=x+.5+(cart.entryOffsetX||0)*(1-t)+(next.x-x)*t,py=y+.18+(next.y-y)*t,pz=z+.5+(cart.entryOffsetZ||0)*(1-t)+(next.z-z)*t;
      cart.mesh.position.set(px,py-.13,pz);cart.mesh.rotation.y=Math.atan2(next.x-x,next.z-z);
      if(cart.progress>=.999){cart.previous={x,y,z};cart.cell={x:next.x,y:next.y,z:next.z};cart.dir=[next.dx,next.dz];cart.slopeVelocity=(next.y-y)*cart.speed;cart.progress=0;cart.entryOffsetX=0;cart.entryOffsetZ=0;x=next.x;y=next.y;z=next.z}
      else break;
    }
    if($context.vehicle===cart){player.x=cart.mesh.position.x;player.y=cart.mesh.position.y+.33;player.z=cart.mesh.position.z;player.vy=0}
  }
}

function vehicleRecord(){
    const {fallingBlocks,parkedVehicles} = $context;
return {vehicles:parkedVehicles,falling:fallingBlocks};}

function parkVehicleDimension(){
    const {fallingBlocks,parkedVehicles,redstoneLevels,vehicleDimensions} = $context;
const record={vehicles:parkedVehicles.splice(0),falling:fallingBlocks.splice(0),power:new Map(redstoneLevels)};for(const entity of [...record.vehicles,...record.falling])entity.mesh.removeFromParent();vehicleDimensions.set($context.activeVehicleDimension,record);$context.vehicle=null;}

function loadVehicleSave(target){
    const {BLOCKS,fallingBlockMesh,fallingBlocks,mountVehicle,parkedVehicles} = $context;
const record=$context.save.vehicleStates?.[target];if(!record)return;for(const data of (record.vehicles||[]).slice(0,256)){if(!['boat','minecart'].includes(data.kind)||!data.position?.every(Number.isFinite))continue;mountVehicle(data.kind,...data.position);const cart=parkedVehicles.at(-1);Object.assign(cart,data.state);cart.mesh.position.fromArray(data.position);cart.mesh.rotation.fromArray(data.rotation);}
 for(const data of (record.falling||[]).slice(0,256))if(BLOCKS[data.type]&&[data.x,data.y,data.z].every(Number.isFinite))fallingBlocks.push({...data,mesh:fallingBlockMesh(data.type,data.x,data.y,data.z)});
}

function activateVehicleDimension(target){
    const {fallingBlocks,loadVehicleSave,parkedVehicles,scene,vehicleDimensions} = $context;
$context.activeVehicleDimension=target;const record=vehicleDimensions.get(target);vehicleDimensions.delete(target);if(record){parkedVehicles.push(...record.vehicles);fallingBlocks.push(...record.falling);}else loadVehicleSave(target);for(const entity of [...parkedVehicles,...fallingBlocks])scene.add(entity.mesh);}

function prepareVehicleDimension(target){
    const {activateVehicleDimension,parkVehicleDimension,vehicleDimensions} = $context;
if(target===$context.activeVehicleDimension||vehicleDimensions.has(target))return;const previous=$context.activeVehicleDimension;parkVehicleDimension();activateVehicleDimension(target);parkVehicleDimension();activateVehicleDimension(previous);}

function serializeVehicleEntities(){
    const {vehicleDimensions,vehicleRecord} = $context;
const records=new Map(vehicleDimensions);records.set($context.activeVehicleDimension,vehicleRecord());$context.save.vehicleStates=Object.fromEntries([...records].map(([target,record])=>[target,{vehicles:record.vehicles.map(({mesh,...state})=>({kind:state.kind,state,position:mesh.position.toArray(),rotation:mesh.rotation.toArray()})),falling:record.falling.map(({mesh,...state})=>state)}]));}

function renderVehicleDimension(target,destination,render){
    const {vehicleDimensions,vehicleRecord} = $context;
const record=target===$context.activeVehicleDimension?vehicleRecord():vehicleDimensions.get(target);if(!record)return render();const objects=[...record.vehicles,...record.falling].map(entity=>entity.mesh),parents=objects.map(object=>object.parent);try{for(const object of objects)destination.add(object);return render();}finally{objects.forEach((object,index)=>parents[index]?parents[index].add(object):object.removeFromParent());}}

function mountVehicle(kind,x,y,z){
    const {THREE,parkedVehicles,player,railShape,scene} = $context;
const group=new THREE.Group(),wood=new THREE.MeshLambertMaterial({color:kind==='boat'?0x9d6f42:0x828d91}),box=(sx,sy,sz,px,py,pz)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),wood);m.position.set(px,py,pz);group.add(m)};
  if(kind==='boat'){box(1.25,.13,1.85,0,0,0);box(.14,.4,1.85,-.56,.19,0);box(.14,.4,1.85,.56,.19,0);box(1.25,.35,.14,0,.18,-.84);box(1.25,.35,.14,0,.18,.84)}
  else{box(.85,.12,.95,0,0,0);box(.12,.34,.95,-.42,.17,0);box(.12,.34,.95,.42,.17,0);box(.85,.34,.12,0,.17,-.47);box(.85,.34,.12,0,.17,.47)}
  group.position.set(x,y-.4,z);scene.add(group);const cart={kind,mesh:group};if(kind==='minecart'){const rx=Math.floor(x),ry=Math.floor(y),rz=Math.floor(z),shape=railShape(rx,ry,rz),facing=[-Math.sin(player.yaw),-Math.cos(player.yaw)];cart.cell={x:rx,y:ry,z:rz};cart.previous=null;cart.progress=0;cart.speed=0;cart.dir=shape.directions.map(d=>[d[0],d[1]]).sort((a,b)=>(b[0]*facing[0]+b[1]*facing[1])-(a[0]*facing[0]+a[1]*facing[1]))[0];group.position.set(rx+.5,ry+.05,rz+.5);group.rotation.y=Math.atan2(cart.dir[0],cart.dir[1])}parkedVehicles.push(cart);$context.dirtySave=true;
}

function dismountVehicle(){
    const {camera,intersects,player,showToast} = $context;
if(!$context.vehicle)return false;const ridden=$context.vehicle,baseY=Math.floor(ridden.mesh.position.y)+.08;$context.vehicle=null;for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const x=ridden.mesh.position.x+dx,z=ridden.mesh.position.z+dz;if(!intersects(x,baseY,z)){player.x=x;player.y=baseY;player.z=z;player.vy=0;camera.position.set(player.x,player.y+1.57,player.z);showToast('DISMOUNTED');return true}}$context.vehicle=ridden;showToast('NO SPACE TO DISMOUNT');return false}

function boardVehicleAtCrosshair(hit){
    const {THREE,camera,parkedVehicles,player,showToast,vehicleRaycaster} = $context;
if($context.vehicle||$context.save.mode==='spectator')return false;vehicleRaycaster.setFromCamera(new THREE.Vector2(0,0),camera);let best=null,distance=5;for(const candidate of parkedVehicles){candidate.mesh.updateMatrixWorld(true);const seen=vehicleRaycaster.intersectObject(candidate.mesh,true)[0];if(seen&&seen.distance<distance){best=candidate;distance=seen.distance}}if(!best)return false;if(hit&&Math.hypot(hit.x+.5-camera.position.x,hit.y+.5-camera.position.y,hit.z+.5-camera.position.z)+.4<distance)return false;$context.vehicle=best;player.x=best.mesh.position.x;player.y=best.mesh.position.y+.4;player.z=best.mesh.position.z;player.vy=0;showToast('BOARDED '+best.kind.toUpperCase()+' · SHIFT TO EXIT');return true}

function punchMinecart(cart,now=performance.now()){
    const {MINECART,parkedVehicles,playSound,player,railShape,scene,showToast,survival} = $context;
if(cart.kind!=='minecart'||$context.vehicle===cart)return false;cart.punches=now-(cart.lastPunch||0)<2200?(cart.punches||0)+1:1;cart.lastPunch=now;cart.hitWobble=.2;const toward=[cart.mesh.position.x-player.x,cart.mesh.position.z-player.z],length=Math.hypot(...toward)||1;if(cart.offRail){cart.vx=(cart.vx||0)+toward[0]/length*1.1;cart.vz=(cart.vz||0)+toward[1]/length*1.1}else{const shape=railShape(cart.cell.x,cart.cell.y,cart.cell.z),direction=shape.directions.map(d=>[d[0],d[1]]).sort((a,b)=>b[0]*toward[0]+b[1]*toward[1]-a[0]*toward[0]-a[1]*toward[1])[0];if(direction){cart.dir=direction;cart.speed=Math.max(cart.speed,1.1)}}if(cart.punches<2){playSound(false);return true}scene.remove(cart.mesh);const index=parkedVehicles.indexOf(cart);if(index>=0)parkedVehicles.splice(index,1);if($context.save.mode==='survival')survival.drop(MINECART,cart.mesh.position.x,cart.mesh.position.y+.35,cart.mesh.position.z);$context.dirtySave=true;playSound(false);showToast('MINECART BROKEN');return true}

function hitMinecartAtCrosshair(hit){
    const {THREE,camera,parkedVehicles,punchMinecart,vehicleRaycaster} = $context;
vehicleRaycaster.setFromCamera(new THREE.Vector2(0,0),camera);let best=null,distance=4.5;for(const candidate of parkedVehicles){if(candidate.kind!=='minecart'||candidate===$context.vehicle)continue;candidate.mesh.updateMatrixWorld(true);const seen=vehicleRaycaster.intersectObject(candidate.mesh,true)[0];if(seen&&seen.distance<distance){best=candidate;distance=seen.distance}}if(!best||hit&&Math.hypot(hit.x+.5-camera.position.x,hit.y+.5-camera.position.y,hit.z+.5-camera.position.z)+.4<distance)return false;return punchMinecart(best)}

function pushMinecartsByPlayer(dx,dz){
    const {parkedVehicles,player,railShape} = $context;
if($context.vehicle||$context.save.mode==='spectator'||Math.hypot(dx,dz)<.0001)return;for(const cart of parkedVehicles){if(cart.kind!=='minecart')continue;const cx=cart.mesh.position.x-player.x,cz=cart.mesh.position.z-player.z,distance=Math.hypot(cx,cz);if(distance>.76||distance<.01||Math.abs(cart.mesh.position.y-player.y)>.9||dx*cx+dz*cz<=0)continue;if(cart.offRail){cart.vx=(cart.vx||0)+dx/Math.hypot(dx,dz)*.3;cart.vz=(cart.vz||0)+dz/Math.hypot(dx,dz)*.3}else{const shape=railShape(cart.cell.x,cart.cell.y,cart.cell.z),direction=shape.directions.map(d=>[d[0],d[1]]).sort((a,b)=>b[0]*dx+b[1]*dz-a[0]*dx-a[1]*dz)[0];if(direction&&direction[0]*dx+direction[1]*dz>0){cart.dir=direction;cart.speed=Math.max(cart.speed,2.6)}}}}
return {startMinecartFall,updateMinecartOffRail,updateMinecarts,vehicleRecord,parkVehicleDimension,loadVehicleSave,activateVehicleDimension,prepareVehicleDimension,serializeVehicleEntities,renderVehicleDimension,mountVehicle,dismountVehicle,boardVehicleAtCrosshair,punchMinecart,hitMinecartAtCrosshair,pushMinecartsByPlayer};
}
