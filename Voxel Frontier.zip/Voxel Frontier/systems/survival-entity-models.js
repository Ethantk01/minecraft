import {createCemAnimator} from '../cem-expressions.js';
/** survival entity models subsystem. Dependencies are injected at composition time. */
export function createSurvivalEntityModelsSystem($context) {
function releaseEntity(group){group.removeFromParent();group.traverse(part=>{if(part.geometry&&!part.geometry.userData.shared)part.geometry.dispose()});}

function ka(f) {
    const {Nl,e} = $context;

    return Nl.has(f) || Nl.set(f, new e.MeshLambertMaterial({ color: f })), Nl.get(f);
  }

function df(f, b, R) {
    const {$p,Nl,PI,e} = $context;

    let v = f + "_" + b;
    if (!Nl.has(v)) {
      let N = new e.MeshLambertMaterial({ color: R, side: e.DoubleSide });
      Nl.set(v, N), PI.mobs[v] && $p.load(PI.mobs[v], (V) => {
        V.magFilter = e.NearestFilter, V.minFilter = e.NearestFilter, V.colorSpace = e.SRGBColorSpace, N.color.setHex(16777215), N.map = V, N.needsUpdate = true;
      });
    }
    return Nl.get(v);
  }

function jr(f, b, R) {
    const {df} = $context;

    return ["right", "left", "top", "bottom", "back", "front"].map((v) => df(f, b + "_" + v, R));
  }

function Yb(f,texture=null) {
    const {$p,Ga,Uw,e,em} = $context;

    const materialKey=texture?f+texture:f;
    if (!em.has(materialKey)) {
      let b = new e.MeshLambertMaterial({ side: e.DoubleSide, alphaTest: 0.1 });
      em.set(materialKey, b), $p.load(texture||Ga[f]?.texture||Uw[f], (R) => {
        R.magFilter = e.NearestFilter, R.minFilter = e.NearestFilter, R.generateMipmaps = false, R.colorSpace = e.SRGBColorSpace, b.map = R, b.needsUpdate = true;
      });
    }
    return em.get(materialKey);
  }

function Hb(f, b, R = false) {
    const {Ga,e,kI,tm} = $context;

    let [, , , v, N, V] = b.coordinates, [L, z] = b.textureOffset || [0, 0], H = b.sizeAdd || 0, q = (Ga[f]?.model||kI[f]).textureSize, Ue = [f, v, N, V, L, z, H, R,JSON.stringify(b)].join(":");
    if (tm.has(Ue)) return tm.get(Ue);
    let Ye = new e.BoxGeometry(Math.max(3e-3, (v + 2 * H) / 16), Math.max(3e-3, (N + 2 * H) / 16), Math.max(3e-3, (V + 2 * H) / 16)), Se = Ye.getAttribute("uv"), ue = [[L, z + V, V, N], [L + v + V, z + V, V, N], [L + V, z, v, V], [L + V + v, z, v, V], [L + v + 2 * V, z + V, v, N], [L + V, z + V, v, N]];
    for (let qe = 0; qe < 6; qe++) {
      let [ze, tn, vn, Mn] = ue[qe];const explicit=b[['uvEast','uvWest','uvUp','uvDown','uvSouth','uvNorth'][qe]];if(explicit){[ze,tn]=explicit;vn=explicit[2]-ze;Mn=explicit[3]-tn;}
      for (let ro = 0; ro < 4; ro++) {
        let Ft = qe * 4 + ro, bn = Se.getX(Ft), za = Se.getY(Ft), Te = R ? 1 - bn : bn;
        Se.setXY(Ft, (ze + Te * vn) / q[0], 1 - (tn + (1 - za) * Mn) / q[1]);
      }
    }
    return Ye.userData.shared=true,Se.needsUpdate = true, tm.set(Ue, Ye), Ye;
  }

function Kb(f) {
    const {Ga,Hb,Yb,e,kI,ka,entityRegistry} = $context;

    const custom=entityRegistry.dispatch('visual',f,{THREE:e});if(custom.handled)return custom.value;
    let b = Ga[f]?.model;
    if (!b) return null;
    let R = new e.Group(), v = new e.Group(), N = new e.Group(), V = [], L = [], z = [], H = /* @__PURE__ */ new Map(), q = null;
    function Ue(Se, ue, qe, ze = true) {
      let tn = Se.part || Se.id || "", vn = Se.translate || [0, 0, 0], Mn = new e.Group();
      Mn.position.set(-vn[0] / 16, -vn[1] / 16, -vn[2] / 16), Se.rotate && Mn.rotation.set(...Se.rotate.map((bn) => bn * Math.PI / 180)), qe.add(Mn);
      function ro(bn, za, Te) {
        for (let Ke of bn.boxes || []) {
          let [Vt, Qt, hn, Kn, Ho, Gi] = Ke.coordinates, mf = new e.Mesh(Hb(ue, Ke, (bn.mirrorTexture || Se.mirrorTexture || "").includes("u")), Yb(ue,bn.packTexture||Se.packTexture));
          mf.userData.dragonPart=bn.id||tn;
          mf.position.set((Vt + Kn / 2 + Te[0]) / 16, (Qt + Ho / 2 + Te[1]) / 16, (hn + Gi / 2 + Te[2]) / 16), za.add(mf);
        }
      }
      ro(Se, Mn, vn), Se.id&&Se.id!==tn&&H.set(Se.id,[{pivot:Mn,rotation:Mn.rotation.clone(),position:Mn.position.clone()}]), H.has(tn) || H.set(tn, []), H.get(tn).push({ pivot: Mn, rotation: Mn.rotation.clone(), position: Mn.position.clone() });
      function Ft(bn, za) {
        let Te = new e.Group(), Ke = bn.translate || [0, 0, 0];
        Te.position.set(Ke[0] / 16, Ke[1] / 16, Ke[2] / 16), bn.rotate && Te.rotation.set(...bn.rotate.map((Vt) => Vt * Math.PI / 180)), za.add(Te), ro(bn, Te, [0, 0, 0]);
        if(bn.id)H.set(bn.id,[{pivot:Te,rotation:Te.rotation.clone(),position:Te.position.clone()}]);for (let Vt of bn.submodels || []) Ft(Vt, Te);
      }
      if (Se.submodels?.length) {
        let bn = new e.Group();
        bn.position.set(vn[0] / 16, vn[1] / 16, vn[2] / 16), Mn.add(bn);
        for (let za of Se.submodels) Ft(za, bn);
      }
      if (ze && (/^(leg\d+|.*_leg|.*_arm)$/.test(tn) || f === "spider" && tn.startsWith("leg"))) {
        let bn = /leg[24]$|left_leg|right_arm/.test(tn) ? Math.PI : 0;
        V.push({ pivot: Mn, phase: bn, baseRotation: Mn.rotation.x });
      }
      ze && f === "dragon" && /^(left|right)_wing$/.test(tn) && L.push({ pivot: Mn, side: tn.startsWith("left") ? -1 : 1 });
    }
    for (let Se of b.models) Ue(Se, f, v), /headwear|sleeve|pants|mole|wing_tip|tentacle|stick\d+/.test(Se.part || "") || Ue(Se, f, N, false);
    if(f==='dragon'){
      for(let i=0;i<5;i++)if(H.has('neck'+(i+1)))H.set('dragon_neck_'+i,H.get('neck'+(i+1)));for(let i=0;i<12;i++)if(H.has('tail'+(i+1)))H.set('dragon_tail_'+i,H.get('tail'+(i+1)));
      const attach=(parentName,childName)=>{
        const parent=H.get(parentName)?.[0]?.pivot,child=H.get(childName)?.[0]?.pivot;
        if(!parent||!child)return;
        const worldPosition=child.getWorldPosition(new e.Vector3());
        parent.add(child);child.position.copy(parent.worldToLocal(worldPosition));
      };
      attach('head','jaw');
      for(const side of ['left','right']){
        attach('body',`${side}_wing`);
        attach('body',`front_${side}_leg`);
        attach('body',`back_${side}_leg`);
        attach(`${side}_wing`,`${side}_wing_tip`);
        for(const pair of [['front','front'],['back','back']]){
          const prefix=`${pair[0]}_${side}`;
          attach(`${prefix}_leg`,`${prefix}_shin`);attach(`${prefix}_shin`,`${prefix}_foot`);
        }
      }
      const spine=b.models.find(model=>model.part==='spine');
      if(spine){
        // The template's single spine is a source cuboid; vanilla draws the
        // five neck and twelve tail copies instead of an extra center piece.
        H.get('spine')?.forEach(entry=>entry.pivot.visible=false);
        // The installed 1.21.10 client has five neck and twelve tail sections.
        for(let index=0;index<5;index++){
          const part=`dragon_neck_${index}`;Ue({...spine,part},f,v,false);
          H.get(part)[0].pivot.position.set(0,.3125,-.75-index*.625);
        }
        for(let index=0;index<12;index++){
          const part=`dragon_tail_${index}`;Ue({...spine,part},f,v,false);
          H.get(part)[0].pivot.position.set(0,.9375,3.75+index*.625);
        }
      }
      const head=H.get('head')?.[0]?.pivot;if(head)head.position.z=-3.875;
    }
    if(f==='witch'){const head=H.get('head')?.[0]?.pivot;if(head)for(const name of ['headwear','headwear2','nose','mole'])for(const entry of H.get(name)||[])head.attach(entry.pivot);}
    if(f==='skeleton'){
      const arm=H.get('right_arm')?.[0]?.pivot;
      if(arm){const bow=new e.Group(),wood=ka(0x78502d),string=ka(0xd7d0b6);
        const segment=(x,y,dx,dy,material,width=.035)=>{const length=Math.hypot(dx,dy),mesh=new e.Mesh(new e.BoxGeometry(width,length,.035),material);mesh.position.set(x+dx/2,y+dy/2,0);mesh.rotation.z=-Math.atan2(dx,dy);bow.add(mesh)};
        segment(0,-.3,-.11,.21,wood);segment(-.11,-.09,.11,.21,wood);segment(0,.12,.11,.21,wood);segment(.11,.33,-.11,.21,wood);segment(0,-.3,0,.84,string,.012);
        bow.position.set(0,-.55,-.14);bow.rotation.y=Math.PI/2;arm.add(bow)
      }
    }
    let Ye = new e.LOD();
    Ye.addLevel(v,0,0.12);
    if(f!=='dragon')Ye.addLevel(N,30,0.12);
    if (R.add(Ye), f === "sheep") {
      q = new e.Group();
      for (let Se of kI.sheep_wool.models) Ue(Se, "sheep_wool", q, false);
      R.add(q);
    }
    return f === "dragon" && R.scale.setScalar(1.35), f === "ghast" && R.scale.setScalar(4), { group: R, joints: V, wings: L, rods: z, fleece: q, parts: H,packAnimate:b.packAnimations?createCemAnimator(b,H):null };
  }

function animateVanillaDragon(f){
    // Port of EnderDragonModel.setupAnim from the installed 1.21.10 client.
    // ModelPart Y points down; the CEM mesh uses Three's upward Y axis.
    const part=name=>f.parts.get(name)?.[0]?.pivot,deg=Math.PI/180;
    const phase=(f.flapTime||0)*Math.PI*2,flap=Math.sin(phase),wave=Math.sin(phase-1)+1;
    const bob=(wave*wave+2*wave)*.05;
    const history=f.dragonHistory||[{yaw:0,y:f.group.position.y}];
    const sample=index=>history[Math.min(index,history.length-1)];
    const wrap=angle=>((angle+180)%360+360)%360-180;
    const yaw5=sample(5).yaw,yaw10=sample(10).yaw,yaw6=sample(6).yaw;
    const yawBend=wrap(yaw5-yaw10),yawMid=wrap(yaw5+yawBend*.5);
    const vertical=(index,base,point)=>{
      if(f.dragonPhase==='landing'||f.dragonPhase==='takeoff')return index/Math.max(Math.hypot(f.x,f.z)/4,1);
      if(f.dragonPhase==='perched'||f.dragonPhase==='roar'||f.dragonPhase==='breath')return index;
      return index===6?0:point.y-base.y;
    };
    const modelY=y=>1.5625-y/16;
    const body=part('body');if(body){body.position.y=1.25-bob;body.rotation.x=bob*2*deg;body.rotation.z=-yawBend*1.5*deg}
    const jaw=part('jaw');if(jaw)jaw.rotation.x=(flap+1)*.2;
    let px=0,py=20,pz=-12;
    for(let index=0;index<5;index++){
      const neck=part(`dragon_neck_${index}`),point=sample(5-index);
      const pitch=Math.cos(index*.45+phase)*.15+vertical(index,sample(6),point)*deg*1.5*5;
      const yaw=wrap(point.yaw-yaw6)*deg*1.5;
      const roll=-wrap(point.yaw-yawMid)*deg*1.5;
      if(neck){neck.position.set(px/16,modelY(py),pz/16);neck.rotation.set(-pitch,yaw,roll)}
      px-=Math.sin(yaw)*Math.cos(pitch)*10;py+=Math.sin(pitch)*10;pz-=Math.cos(yaw)*Math.cos(pitch)*10;
    }
    const head=part('head');if(head){
      const point=sample(0);
      head.position.set(px/16,modelY(py),pz/16);
      head.rotation.set(-vertical(6,sample(6),point)*deg*1.5*5,wrap(point.yaw-yaw6)*deg,-wrap(point.yaw-yawMid)*deg);
    }
    px=0;py=10;pz=60;let tailWave=0;const tailBase=sample(11);
    for(let index=0;index<12;index++){
      const tail=part(`dragon_tail_${index}`),point=sample(12+index);
      tailWave+=Math.sin(index*.45+phase)*.05;
      const yaw=(wrap(point.yaw-tailBase.yaw)*1.5+180)*deg;
      const pitch=tailWave+(point.y-tailBase.y)*deg*1.5*5;
      const roll=wrap(point.yaw-yawMid)*deg*1.5;
      if(tail){tail.position.set(px/16,modelY(py),pz/16);tail.rotation.set(-pitch,yaw,roll)}
      py+=Math.sin(pitch)*10;pz-=Math.cos(yaw)*Math.cos(pitch)*10;px-=Math.sin(yaw)*Math.cos(pitch)*10;
    }
    const leftWing=part('left_wing'),rightWing=part('right_wing');
    if(leftWing)leftWing.rotation.set(.125-Math.cos(phase)*.2,-.25,-(flap+.125)*.8);
    if(rightWing)rightWing.rotation.set(.125-Math.cos(phase)*.2,.25,(flap+.125)*.8);
    const leftTip=part('left_wing_tip'),rightTip=part('right_wing_tip');
    if(leftTip)leftTip.rotation.z=(Math.sin(phase+2)+.5)*.75;
    if(rightTip)rightTip.rotation.z=-(Math.sin(phase+2)+.5)*.75;
    for(const side of ['left','right']){
      const front=part(`front_${side}_leg`),frontShin=part(`front_${side}_shin`),frontFoot=part(`front_${side}_foot`);
      const back=part(`back_${side}_leg`),backShin=part(`back_${side}_shin`),backFoot=part(`back_${side}_foot`);
      // Vanilla ModelPart Y points down. Negate the X angles for our Y-up model
      // so the nested shin and foot fold under the body instead of projecting forward.
      if(front)front.rotation.x=-(1.3+bob*.1);if(frontShin)frontShin.rotation.x=.5+bob*.1;if(frontFoot)frontFoot.rotation.x=-(.75+bob*.1);
      if(back)back.rotation.x=-(1+bob*.1);if(backShin)backShin.rotation.x=-(.5+bob*.1);if(backFoot)backFoot.rotation.x=-(.75+bob*.1);
    }
  }

function Ty(f, b) {
    const {Ga,animateVanillaDragon} = $context;

    if (!f.parts) return;
    f.animTime = (f.animTime || 0) + b;
    let R = f.animTime, v = f.walkPhase, N = Math.hypot(f.vx, f.vz), V = Math.min((f.flee||0)>0?1.25:1, N / Math.max(0.5, Ga[f.type].speed)), L = Math.sin(v) * V, z = Math.sin(v + Math.PI) * V, H = Math.sin(R * 1.6 + f.dir) * 0.035, q = (ue, qe = 0, ze = 0, tn = 0, vn = 0, Mn = 0, ro = 0) => {
      for (let Ft of f.parts.get(ue) || []) Ft.pivot.rotation.set(Ft.rotation.x + qe, Ft.rotation.y + ze, Ft.rotation.z + tn), Ft.pivot.position.set(Ft.position.x + vn, Ft.position.y + Mn, Ft.position.z + ro);
    }, Ue = !$context.backgroundEntities && (f.aggro || f.type === "cow" || f.type === "sheep" || f.type === "villager"), Ye = 0;
    if (Ue) {
      let ue = Math.atan2($context.n.z - f.z, $context.n.x - f.x), qe = Math.atan2(Math.sin(ue - f.dir), Math.cos(ue - f.dir));
      Math.hypot($context.n.x - f.x, $context.n.z - f.z) < 9 && (Ye = Math.max(-0.48, Math.min(0.48, -qe * 0.55)));
    }
    let Se = (ue = 0) => {
      q("head", ue, Ye, H), f.type!=="witch"&&(q("headwear", ue, Ye, H), q("headwear2", ue, Ye, H), q("nose", ue, Ye, H), q("mole", ue, Ye, H));
    };
    switch (f.type) {
      case "cow":
      case "sheep": {
        let ue = Math.max(0, f.grazeTime || 0);
        f.grazeTime = Math.max(0, ue - b), Se(ue ? 0.7 + Math.sin(R * 2) * 0.025 : Math.sin(R * 1.7) * 0.045), q("body", Math.sin(v * 2) * 0.018 * V, 0, H * 0.4);
        for (let qe = 1; qe <= 4; qe++) q("leg" + qe, (qe === 1 || qe === 4 ? L : z) * 0.46);
        break;
      }
      case "creeper": {
        Se(Math.sin(R * 1.3) * 0.04), q("body", Math.sin(v * 2) * 0.025 * V, 0, H * 0.7, 0, Math.sin(R * 2) * 0.012, 0);
        for (let ue = 1; ue <= 4; ue++) q("leg" + ue, (ue === 1 || ue === 4 ? L : z) * 0.48);
        break;
      }
      case "spider": {
        Se(Math.sin(R * 1.5) * 0.035), q("body", 0, 0, Math.sin(v * 2) * 0.025 * V);
        for (let ue = 1; ue <= 8; ue++) {
          let qe = ue <= 4 ? -1 : 1, ze = (ue - 1) % 4 * Math.PI / 2, tn = Math.sin(v + ze) * V;
          q("leg" + ue, tn * 0.22, qe * (tn * 0.2 + Math.sin(R * 2 + ue) * 0.025), qe * Math.abs(tn) * 0.18);
        }
        break;
      }
      case "blaze": {
        Se(Math.sin(R * 2) * 0.05);
        for (let ue = 1; ue <= 12; ue++) {
          let qe = Math.floor((ue - 1) / 4), ze = R * (qe === 1 ? -0.9 : 0.9) + ue % 4 * Math.PI / 2 + qe * 0.55;
          q("stick" + ue, 0, ze * 0.2, Math.sin(ze) * 0.15, Math.cos(ze) * 0.045, Math.sin(R * 2 + ue) * 0.045, Math.sin(ze) * 0.045);
        }
        break;
      }
      case "ghast": {
        q("body", Math.sin(R * 0.8) * 0.035, Math.sin(R * 0.45) * 0.055, Math.sin(R * 0.7) * 0.03, 0, Math.sin(R * 1.2) * 0.045, 0);
        for (let ue = 1; ue <= 9; ue++) q("tentacle" + ue, Math.sin(R * 1.8 + ue * 0.8) * 0.13, 0, Math.sin(R * 1.4 + ue) * 0.09);
        break;
      }
      case "shulker": {
        let ue = Math.max(0, f.lidOpen || 0);
        f.lidOpen = Math.max(0, ue - b), q("lid", 0, Math.sin(R * 1.5) * 0.025, 0, 0, ue > 0 ? Math.min(0.32, ue * 0.7) : 0, 0), q("head", 0, Math.sin(R * 0.9) * 0.3, 0);
        break;
      }
      case "dragon": {
        animateVanillaDragon(f);
        break;
      }
      default: {
        let ue = Ga[f.type].hostile, qe = ue && f.aggro && f.attack > 0.55, ze = qe ? -0.85 : 0;
        Se(Math.sin(R * 1.7) * 0.025), q("body", Math.sin(v * 2) * 0.018 * V, 0, H * 0.5), q("bodywear", Math.sin(v * 2) * 0.018 * V, 0, H * 0.5), q("right_leg", L * 0.5), q("left_leg", z * 0.5), q("right_pants", L * 0.5), q("left_pants", z * 0.5), q("right_arm", ze + z * 0.35), q("left_arm", ze + L * 0.35), q("right_sleeve", ze + z * 0.35), q("left_sleeve", ze + L * 0.35), q("arms", Math.sin(R * 1.5) * 0.025);
        break;
      }
    }
    f.packAnimate?.(f,b);
  }
return {releaseEntity,ka,df,jr,Yb,Hb,Kb,animateVanillaDragon,Ty};
}
