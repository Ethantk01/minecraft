import {sweepActorAxis,applyGravity,applyFluidVertical,fallDamage} from '../actor-physics.js';
/** player physics subsystem. Dependencies are injected at composition time. */
export function createPlayerPhysicsSystem($context) {
function foregroundEntityDistance(origin,dir,maxDist){
    const {fallingBlocks,foregroundRaycaster,parkedVehicles,survival} = $context;
let best=survival.nearestEntityDistance(origin,dir,maxDist);foregroundRaycaster.set(origin,dir);foregroundRaycaster.far=Math.min(best,maxDist);for(const cart of parkedVehicles){if(Math.hypot(cart.mesh.position.x-origin.x,cart.mesh.position.y-origin.y,cart.mesh.position.z-origin.z)>maxDist+2)continue;cart.mesh.updateMatrixWorld(true);const hit=foregroundRaycaster.intersectObject(cart.mesh,true)[0];if(hit&&hit.distance<best){best=hit.distance;foregroundRaycaster.far=best}}for(const block of fallingBlocks){if(Math.hypot(block.mesh.position.x-origin.x,block.mesh.position.y-origin.y,block.mesh.position.z-origin.z)>maxDist+2)continue;block.mesh.updateMatrixWorld(true);const hit=foregroundRaycaster.intersectObject(block.mesh,true)[0];if(hit&&hit.distance<best){best=hit.distance;foregroundRaycaster.far=best}}return best}

function hitVoxel(maxDist=7,includeWater=false){
    const {AIR,END_PORTAL,NETHER_PORTAL,SNOW,THREE,WATER,camera,foregroundEntityDistance,getBlock,snowLayerCount} = $context;

  const origin=camera.position,dir=new THREE.Vector3();camera.getWorldDirection(dir);
  const entityDistance=foregroundEntityDistance(origin,dir,maxDist);
  const hitsSnow=(x,y,z)=>{let entry=0,exit=maxDist;const bounds=[[x,x+1,origin.x,dir.x],[y,y+snowLayerCount(x,y,z)/8,origin.y,dir.y],[z,z+1,origin.z,dir.z]];for(const [min,max,start,velocity] of bounds){if(Math.abs(velocity)<1e-8){if(start<min||start>max)return false;continue}const a=(min-start)/velocity,b=(max-start)/velocity;entry=Math.max(entry,Math.min(a,b));exit=Math.min(exit,Math.max(a,b));if(entry>exit)return false}return exit>=0};
  let x=Math.floor(origin.x),y=Math.floor(origin.y),z=Math.floor(origin.z);
  const sx=Math.sign(dir.x),sy=Math.sign(dir.y),sz=Math.sign(dir.z);
  const dx=dir.x?Math.abs(1/dir.x):Infinity,dy=dir.y?Math.abs(1/dir.y):Infinity,dz=dir.z?Math.abs(1/dir.z):Infinity;
  let tx=dir.x?((sx>0?x+1:x)-origin.x)/dir.x:Infinity,ty=dir.y?((sy>0?y+1:y)-origin.y)/dir.y:Infinity,tz=dir.z?((sz>0?z+1:z)-origin.z)/dir.z:Infinity;
  let previous=null,distance=0;
  for(let i=0;i<40&&distance<=maxDist;i++){
    const type=getBlock(x,y,z);
    if($context.save.experiments&&(type===NETHER_PORTAL||type===END_PORTAL))return null;
    if(type!==AIR&&(includeWater||type!==WATER)&&(type!==SNOW||hitsSnow(x,y,z)))return entityDistance<distance-.001?null:{x,y,z,type,previous,distance};
    previous={x,y,z};
    if(tx<ty&&tx<tz){x+=sx;distance=tx;tx+=dx}else if(ty<tz){y+=sy;distance=ty;ty+=dy}else{z+=sz;distance=tz;tz+=dz}
  }
  return null;
}

function outlineGeometry(type,x,y,z){
    const {LAVA,THREE,WATER,blockParts,liquidLevel,outlineCache,railSlopePoint,rotateModelPoint} = $context;
let parts=$context.BLOCKS[type]?.selectionBoxes?.map(bounds=>({kind:'box',bounds}))||blockParts(type,x,y,z);if(!parts){const top=type===WATER||type===LAVA?Math.min(1,.14+liquidLevel(x,y,z,type)*.86/8):1;parts=[{kind:'box',bounds:[0,0,0,1,top,1]}]}
  const signature=parts.map(part=>part.kind==='box'?'b'+part.bounds.join(',')+JSON.stringify(part.rotation||null)+JSON.stringify(part.slope||null):'c'+part.height).join('|');if(outlineCache.has(signature))return outlineCache.get(signature);
  const vertices=[];
  for(const part of parts){const edge=(a,b)=>vertices.push(...railSlopePoint(rotateModelPoint(a,part.rotation),part.slope),...railSlopePoint(rotateModelPoint(b,part.rotation),part.slope));if(part.kind==='box'){const [x0,y0,z0,x1,y1,z1]=part.bounds;for(const yy of [y0,y1]){edge([x0,yy,z0],[x1,yy,z0]);edge([x1,yy,z0],[x1,yy,z1]);edge([x1,yy,z1],[x0,yy,z1]);edge([x0,yy,z1],[x0,yy,z0])}for(const xx of [x0,x1])for(const zz of [z0,z1])edge([xx,y0,zz],[xx,y1,zz])}else{const h=part.height,planes=[[[.08,0,.08],[.92,0,.92],[.92,h,.92],[.08,h,.08]],[[.92,0,.08],[.08,0,.92],[.08,h,.92],[.92,h,.08]]];for(const plane of planes)for(let i=0;i<4;i++)edge(plane[i],plane[(i+1)%4])}}
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));outlineCache.set(signature,geometry);return geometry;
}

function occupied(x,y,z){
    const {player} = $context;
const r=.29;return x<player.x+r&&x+1>player.x-r&&z<player.z+r&&z+1>player.z-r&&y<player.y+1.7&&y+1>player.y+.05}

function intersectsBody(px,py,pz,radius=.29,height=1.69){
    const {SNOW,blockCollisionCache,blockParts,getBlock,isDoor,rotateModelPoint,snowLayerCount,solid} = $context;

  for(let y=Math.floor(py+.001);y<=Math.floor(py+height-.001);y++)for(let z=Math.floor(pz-radius);z<=Math.floor(pz+radius);z++)for(let x=Math.floor(px-radius);x<=Math.floor(px+radius);x++){
    const type=getBlock(x,y,z);if(type===SNOW){const h=(snowLayerCount(x,y,z)-1)/8;if(h>0&&py+.001<y+h)return true;continue}
    if(!isDoor(type)&&!solid(x,y,z))continue;
    const parts=blockParts(type,x,y,z,0);if(!parts){return true}
    for(const part of parts){if(part.kind!=='box'||part.collision===false)continue;const key=JSON.stringify([part.bounds,part.rotation]);let bounds=blockCollisionCache.get(key);if(!bounds){const points=Array.from({length:8},(_,i)=>rotateModelPoint([part.bounds[i&1?3:0],part.bounds[i&2?4:1],part.bounds[i&4?5:2]],part.rotation));bounds=[...Array.from({length:3},(_,a)=>Math.min(...points.map(p=>p[a]))),...Array.from({length:3},(_,a)=>Math.max(...points.map(p=>p[a])))];if(blockCollisionCache.size>1024)blockCollisionCache.clear();blockCollisionCache.set(key,bounds)}
      if(px+radius>x+bounds[0]+.001&&px-radius<x+bounds[3]-.001&&py+height>y+bounds[1]+.001&&py<y+bounds[4]-.001&&pz+radius>z+bounds[2]+.001&&pz-radius<z+bounds[5]-.001)return true;
    }
  }return false;
}

function intersects(px,py,pz){
    const {intersectsBody} = $context;
return intersectsBody(px,py,pz)}

const playerSweep={stepSize:.16,
  collides(x,y,z,axis){const {intersects,survival}= $context;return intersects(x,y,z)||$context.multiplayer?.collides(x,y,z)||axis!=='y'&&survival.collidesPlayer(x,y,z);},
  tryStep(x,y,z,axis){const {player,intersects}=$context;if(axis==='y'||!player.grounded||player.flight||player.vy>0)return false;
    for(let rise=1/16;rise<=.6001;rise+=1/16){const top=player.y+rise+.002;if(!intersects(player.x,top,player.z)&&!intersects(x,top,z)&&!$context.multiplayer?.collides(x,top,z)&&!$context.survival.collidesPlayer(x,top,z)){player.y=top;player.vy=0;player.grounded=true;return true;}}return false;
  },
  onBlocked(axis,step){if(axis==='y'){if(step<0)$context.player.grounded=true;$context.player.vy=0;}}
};
function moveAxis(axis,delta){return sweepActorAxis($context.player,axis,delta,playerSweep);}


function assistWaterExit(vx,vz){
    const {keys,player,solid} = $context;

  if(!keys.has('Space'))return;
  const distance=Math.hypot(vx,vz);if(distance<.0001)return;
  const aheadX=player.x+vx/distance*.48,aheadZ=player.z+vz/distance*.48,footY=Math.floor(player.y+.08);
  if(!solid(Math.floor(aheadX),footY,Math.floor(aheadZ))||solid(Math.floor(aheadX),footY+1,Math.floor(aheadZ)))return;
  if(!solid(Math.floor(player.x),footY+2,Math.floor(player.z)))player.vy=Math.max(player.vy,7.2);
}

function move(dt){
    const {LADDER,MIN_Y,POWDER_SNOW,POWERED_RAIL,RAIL_TYPES,THREE,WATER,assistWaterExit,camera,getBlock,keys,moveAxis,player,pushMinecartsByPlayer,showToast,survival,terrain,waterCurrent} = $context;

  if(!$context.playing||survival.isOpen()||$context.commandOpen||player.sleepingUntil>performance.now())return;
  if($context.save.mode==='spectator'){
    const forward=(keys.has('KeyW')?1:0)-(keys.has('KeyS')?1:0),side=(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0),vertical=(keys.has('Space')?1:0)-(keys.has('ControlLeft')||keys.has('ControlRight')?1:0),length=Math.hypot(forward,side,vertical)||1,speed=keys.has('ShiftLeft')||keys.has('ShiftRight')?20:10;
    player.x+=(-Math.sin(player.yaw)*forward+Math.cos(player.yaw)*side)*speed*dt/length;player.z+=(-Math.cos(player.yaw)*forward-Math.sin(player.yaw)*side)*speed*dt/length;player.y+=vertical*speed*dt/length;player.vy=0;player.knockVx=0;player.knockVz=0;player.grounded=false;camera.position.set(player.x,player.y+1.57,player.z);camera.rotation.set(player.pitch,player.yaw,0);return
  }
  if($context.vehicle?.kind==='minecart'){player.x=$context.vehicle.mesh.position.x;player.y=$context.vehicle.mesh.position.y+.33;player.z=$context.vehicle.mesh.position.z;camera.position.set(player.x,player.y+1.57,player.z);camera.rotation.set(player.pitch,player.yaw,0);return}
  if($context.vehicle){const forward=(keys.has('KeyW')?1:0)-(keys.has('KeyS')?1:0),side=(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0),speed=$context.vehicle.kind==='boat'?6:8;
    const vx=(-Math.sin(player.yaw)*forward+Math.cos(player.yaw)*side)*speed*dt,vz=(-Math.cos(player.yaw)*forward-Math.sin(player.yaw)*side)*speed*dt,nx=player.x+vx,nz=player.z+vz;
    if($context.vehicle.kind==='boat'){if(getBlock(Math.floor(nx),Math.floor(player.y-.5),Math.floor(nz))===WATER){player.x=nx;player.z=nz;player.y=Math.floor(player.y-.5)+1}else showToast('BOAT NEEDS WATER')}
    else if(RAIL_TYPES.has(getBlock(Math.floor(nx),Math.floor(player.y),Math.floor(nz)))){player.x=nx;player.z=nz;if(getBlock(Math.floor(nx),Math.floor(player.y),Math.floor(nz))===POWERED_RAIL)$context.vehicle.boost=1.5}
    $context.vehicle.mesh.position.set(player.x,player.y-.4,player.z);$context.vehicle.mesh.rotation.y=player.yaw;camera.position.set(player.x,player.y+1.57,player.z);camera.rotation.set(player.pitch,player.yaw,0);return}
  let forward=(keys.has('KeyW')?1:0)-(keys.has('KeyS')?1:0),side=(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0);
  const len=Math.hypot(forward,side)||1;forward/=len;side/=len;
  const inWater=getBlock(Math.floor(player.x),Math.floor(player.y+.15),Math.floor(player.z))===WATER;
  const sprinting=(keys.has('ShiftLeft')||keys.has('ShiftRight'))&&($context.save.mode==='creative'||player.hunger>6);
  const inPowderSnow=getBlock(Math.floor(player.x),Math.floor(player.y+.5),Math.floor(player.z))===POWDER_SNOW;
  const speed=(player.flight?9:player.gliding?(player.rocketBoost>0?18:10):inWater?2.5:inPowderSnow?1.6:sprinting?7.2:4.8)*($context.save.effects?.speed?1.25:1);
  const sin=Math.sin(player.yaw),cos=Math.cos(player.yaw);
  const vx=((-sin*forward+cos*side)*speed+player.knockVx)*dt,vz=((-cos*forward-sin*side)*speed+player.knockVz)*dt;
  const knockFriction=Math.exp(-dt*5);player.knockVx*=knockFriction;player.knockVz*=knockFriction;
  const beforeX=player.x,beforeZ=player.z;moveAxis('x',vx);moveAxis('z',vz);
  if(player.flight){player.vy=0;moveAxis('y',((keys.has('Space')?1:0)-(keys.has('KeyX')||keys.has('ControlLeft')?1:0))*speed*dt)}
  else if(getBlock(Math.floor(player.x),Math.floor(player.y+.8),Math.floor(player.z))===LADDER){player.vy=keys.has('Space')?3.5:keys.has('KeyX')?-3:-.6;moveAxis('y',player.vy*dt)}
  else if(inWater){const current=waterCurrent(Math.floor(player.x),Math.floor(player.y+.15),Math.floor(player.z));applyFluidVertical(player,dt,{lift:(keys.has('Space')?19:0)-(keys.has('KeyX')?10:3.8),currentY:current.y});assistWaterExit(vx,vz);player.grounded=false;moveAxis('y',player.vy*dt);moveAxis('x',current.x*1.6*dt);moveAxis('z',current.z*1.6*dt)}
  else if(inPowderSnow){player.vy=Math.max(-1.3,Math.min(3,player.vy*.9+(keys.has('Space')?13:-4)*dt));player.grounded=false;moveAxis('y',player.vy*dt)}
  else{const falling=player.vy<0?player.vy:0;if(player.gliding){const direction=new THREE.Vector3();camera.getWorldDirection(direction);player.rocketBoost=Math.max(0,player.rocketBoost-dt);player.vy=Math.max(-5,Math.min(6,player.vy+direction.y*7*dt-4*dt+(player.rocketBoost>0?4*dt:0)))}else applyGravity(player,dt);player.grounded=false;moveAxis('y',player.vy*dt);if(player.grounded){player.gliding=false;if(falling<-13&&$context.save.mode==='survival')survival.hurt(fallDamage(falling),'FALL DAMAGE')}if(keys.has('Space')&&player.grounded){player.vy=8.5;player.grounded=false;survival.addExhaustion(sprinting?.2:.05)}}
  if(player.y<MIN_Y-64){if($context.save.mode==='survival')survival.hurt(1000,'FELL OUT OF THE WORLD');else $context.respawnPlayer();}
  if(!player.flight&&!player.gliding)survival.addExhaustion(Math.min(speed*dt,Math.hypot(player.x-beforeX,player.z-beforeZ))*(inWater?.01:sprinting?.1:0));
  pushMinecartsByPlayer(player.x-beforeX,player.z-beforeZ);
  camera.position.set(player.x,player.y+1.57,player.z);camera.rotation.set(player.pitch,player.yaw,0);
}
return {foregroundEntityDistance,hitVoxel,outlineGeometry,occupied,intersectsBody,intersects,moveAxis,assistWaterExit,move};
}
