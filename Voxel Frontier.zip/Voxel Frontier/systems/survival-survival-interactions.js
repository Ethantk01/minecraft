/** survival survival interactions subsystem. Dependencies are injected at composition time. */
export function createSurvivalSurvivalInteractionsSystem($context) {
function gy(f) {
    const {$h,$r,A,Be,CE,Dp,EE,En,Fp,Hh,Hn,Hp,I,Kh,Kp,Ks,Le,Ll,Lp,Lt,ME,Np,Op,Pc,Pi,Pp,QE,Qp,S,Sl,Vp,Xh,Yh,Yn,Zh,_E,_b,a,aE,ae,af,ao,ce,dy,ef,es,fE,hE,hf,i,iE,itemRegistry,jh,l,mE,mt,nf,oE,oa,pE,qh,r,rf,sE,tE,tf,ts,vE,ve,vo,wE,wn,yt} = $context;

    let b = Hn();

    if(itemRegistry.use(b,{hit:f,spawn:i.spawnEntity||ts,consume:mt,markDirty:i.markDirty}))return true;
    if(f){const custom=i.blockRegistry?.dispatch('interact',f.type,{hit:f,item:b,api:i});if(custom?.handled)return custom.value;}
    if (f?.type === _E && (b === ve || b === Pi) && (b !== ve || a.mode === "creative" || wn(Le) > 0)) {
      b === ve && a.mode !== "creative" ? mt(Le) : b === Pi && mt(Pi);
      let v = i.hitTarget(f);
      return $context.p(`TARGET HIT \xB7 POWER ${v}/15`), true;
    }
    if (b === oa && f?.previous && f.type !== oa) {
      let v = f.previous, N = a.slots[27 + i.getSelected()];
      return i.occupied(v.x, v.y, v.z) || l(v.x, v.y, v.z, oa) && (a.chests[`${i.getDimension()}:${v.x},${v.y},${v.z}`] = N?.data?.slots || Array(27).fill(null), mt(oa), $context.p("SHULKER BOX PLACED")), true;
    }
    if(f?.type===Be){QE(f.x,f.z);i.ensureChestLoot?.(f);}
    if (f?.type === Pc) {
      let v = a.redstoneExtra?.[i.getDimension()]?.[`${f.x},${f.y},${f.z}`];
      return b === Lt && !v?.book && mt(Lt) ? (i.useRedstoneControl({ ...f, type: Pc, addBook: true }), $context.p("BOOK PLACED ON LECTERN"), true) : i.useRedstoneControl(f);
    }
    if (f?.type === Hp) {
      let v = `${f.x},${f.y},${f.z}`, N = a.redstoneExtra?.[i.getDimension()]?.[v] || {}, V = N.books || Array(6).fill(false), L = b === Lt, z = L ? V.findIndex((H) => !H) : V.findLastIndex(Boolean);
      return z < 0 ? ($context.p(L ? "BOOKSHELF FULL" : "BOOKSHELF EMPTY"), true) : (L && !mt(Lt) || (!L && En(Lt) < 1 && Yn(Lt, f.x + 0.5, f.y + 0.5, f.z + 0.5), i.useRedstoneControl({ ...f, slot: z, put: L }), $context.p(L ? "BOOK STORED" : "BOOK REMOVED")), true);
    }
    if (f?.type === rf) {
      let v = vo(f), N = a.jukeboxDiscs[v];
      return N ? (delete a.jukeboxDiscs[v], i.playDisc(false), En(N) < 1 && Yn(N, f.x + 0.5, f.y + 1, f.z + 0.5), $context.p("MUSIC DISC EJECTED")) : b === af && mt(b) ? (a.jukeboxDiscs[v] = b, i.playDisc(true), $context.p("PLAYING OTHERSIDE"), i.getBiome(f.x, f.z) === "meadow" && i.awardAdvancement("sound_of_music", "Sound of Music")) : $context.p("INSERT A MUSIC DISC"), I(), true;
    }


    if (f?.type === tE) return i.toggleLever(f), true;
    if (f && [CE, vE, hE, fE, mE, EE, wE, ME].includes(f.type)) return i.useRedstoneControl(f);
    if (f && [Qp, ef, tf, nf, Ks].includes(f.type)) {
      let v = vo(f);
      return a.chests ??= {}, a.chests[v] ??= Array(f.type === tf ? 5 : f.type === nf ? 27 : 9).fill(null), Ll(false, v), i.useRedstoneControl(f), true;
    }




    if (f?.type === oa) return Ll(false, vo(f)), true;
    if (b === Lp && f?.type === S) return mt(b) && (En(Fp), $context.p("FILLED WATER BOTTLE")), true;
    if ([Xh, Zh, jh, qh, $h].includes(b)) return mt(b) && (En(Lp), b === Xh ? $context.n.health = Math.min(20, $context.n.health + 8) : a.effects[b === Zh ? "speed" : b === jh ? "strength" : b === qh ? "regeneration" : "poison"] = b === $h ? 30 : 180, $context.p(`${r[b].name.toUpperCase()} USED`), ao()), true;
    if (b === Sl) return a.mode !== "creative" && !mt(Sl) || (a.armor.chestplate && En(a.armor.chestplate), a.armor.chestplate = Sl, $context.p("ELYTRA EQUIPPED \xB7 JUMP WHILE FALLING TO GLIDE"), I()), true;
    if (b === Pp && $context.n.gliding) return mt(Pp) && ($context.n.rocketBoost = 2, $context.p("FIREWORK BOOST")), true;
    if (b === Yh) {
      if ($context.hr) {
        if ($context.hr.ready) {
          let v = Math.random() < 0.82 ? _b : Math.random() < 0.65 ? yt : Lt;
          En(v), hf(1 + Math.floor(Math.random() * 6)), $context.p(`CAUGHT ${r[v].name.toUpperCase()}`);
        } else $context.p("REELED IN TOO EARLY");
        $context.hr = null, es(Yh);
      } else {
        if (f?.type !== S) return $context.p("AIM AT WATER TO CAST"), true;
        $context.hr = { x: f.x + 0.5, y: f.y + 1, z: f.z + 0.5, wait: 5 + Math.random() * 18, ready: false }, $context.p("FISHING LINE CAST");
      }
      return true;
    }
    if (b === Hh) {
      let v = f?.type === S ? f : f?.previous;
      return !v || A(v.x, v.y, v.z) !== S ? ($context.p("PLACE THE BOAT ON WATER"), true) : (mt(Hh) && (i.mountVehicle("boat", v.x + 0.5, v.y + 1, v.z + 0.5), $context.p("BOAT PLACED \xB7 RIGHT CLICK TO BOARD")), true);
    }
    if (b === Kh) {
      let v = f && [oE, aE, pE].includes(f.type) ? f : null;
      return v ? (mt(Kh) && (i.mountVehicle("minecart", v.x + 0.5, v.y + 0.2, v.z + 0.5), $context.p("MINECART PLACED \xB7 RIGHT CLICK TO BOARD")), true) : ($context.p("PLACE THE MINECART ON RAILS"), true);
    }
    if (b === Vp && f?.type === ce && f.previous) {
      let v = f.previous;
      return l(v.x, v.y, v.z, sE) && (mt(b), $context.p("PLANTED NETHER WART")), true;
    }
    let R = dy(f);
    return i.isRedstoneComponent(b) && f?.previous && A(f.previous.x, f.previous.y, f.previous.z) === b && i.placeRedstoneComponent(f.previous.x, f.previous.y, f.previous.z, b, f), R;
  }

function cy(f, b) {
    const {A,Bl,C,E,Ei,En,Gc,I,Nt,Oc,Q,Qn,RE,Tl,Wr,Z,_,a,bl,ee,es,et,gi,i,ii,kc,l,mt,no,of,pn,r,s,st,yE,zs} = $context;

    if (b === Tl && f && [yE, s.TWISTING_VINES, s.WEEPING_VINES].includes(f.type)) return i.stopVineGrowth(f) && (es(Tl), $context.p("VINE GROWTH STOPPED")), true;
    if (b === st && f?.type === kc) return l(f.x, f.y, f.z, E) && (mt(st), En(of), $context.p("FILLED POWDER SNOW BUCKET")), true;
    if (b === of && f?.previous) {
      let R = f.previous;
      return l(R.x, R.y, R.z, kc) && (mt(of), En(st), $context.p("POURED POWDER SNOW")), true;
    }
    if (b === st && f?.type === Q) return l(f.x, f.y, f.z, E) && (mt(st), En(ii), $context.p("FILLED LAVA BUCKET")), true;
    if (b === ii && f?.previous) {
      let R = f.previous;
      return l(R.x, R.y, R.z, Q) && (mt(ii), En(st), $context.p("POURED LAVA")), true;
    }
    if (b === Qn && f && [C, _].includes(f.type)) return l(f.x, f.y, f.z, et) && (es(b), $context.p("TILLED SOIL")), true;
    if (b === Ei && f?.type === et) {
      let R = f.y + 1;
      return A(f.x, R, f.z) === E && l(f.x, R, f.z, Wr) && (mt(b), $context.p("PLANTED WHEAT SEEDS")), true;
    }
    if(b===s.SPORE_BLOSSOM&&f?.previous&&!i.isSolid(A(f.previous.x,f.previous.y+1,f.previous.z))){$context.p('SPORE BLOSSOM NEEDS A CEILING');return true;}
    if (b === s.BIG_DRIPLEAF && f?.previous) {
      let R = f.previous, v = A(R.x, R.y - 1, R.z);
      if (![RE, C, _, et, i.extraId("moss_block"), i.extraId("rooted_dirt"), i.extraId("podzol_top"), i.extraId("mycelium_top")].includes(v)) return $context.p("BIG DRIPLEAF NEEDS SOIL"), true;
    }
    if (b === Z && f?.type === ee) return i.insertEndEye(f) && mt(b), true;
    if ([no, Bl, zs, bl, Oc, Gc].includes(b)) {
      let R = b === no || b === Bl ? "helmet" : b === zs ? "chestplate" : b === bl ? "leggings" : "boots";
      return a.armor ??= {}, a.mode !== "creative" && !mt(b) || (a.armor[R] && En(a.armor[R]), a.armor[R] = b, I(),$context.m('click'), $context.p(`EQUIPPED ${r[b].name.toUpperCase()}`)), true;
    }
    if (f&&(f.type===Nt||f.type===gi||i.isDoor?.(f.type))) return i.toggleDoor(f), true;
    if(f?.type===pn&&i.getDimension()!=='overworld'){i.breakBedPartner(f.x,f.y,f.z);l(f.x,f.y,f.z,E);$context.Qc(f.x,f.y,f.z,5);return true;}
    if (f?.type === pn) return a.bedSpawn = { x: f.x, y: f.y, z: f.z }, i.sleepAtBed(), I(), true;
    if (b === Nt && f?.previous) {
      let R = f.previous;
      return R.y + 1 >= 320 || A(R.x, R.y + 1, R.z) !== E || i.occupied(R.x, R.y, R.z) || l(R.x, R.y, R.z, Nt) && (l(R.x, R.y + 1, R.z, gi), i.placeDoor?.(R.x,R.y,R.z), mt(Nt), $context.p("PLACED OAK DOOR")), true;
    }
    return false;
  }

function dy(f) {
    const {$,$e,$r,A,At,Be,E,En,Et,G,HE,Hn,Hs,Ie,Ll,Nt,Pi,Qc,S,W,Z,a,ae,c,cy,dn,es,foodValues,gi,i,l,ly,mt,ne,oe,pn,r,re,rt,st,te,vo,vt,wn,y} = $context;

    let b = Hn();

    if (b === Pi) return wn(Pi) > 0 && !HE() && (mt(Pi), $context.p("SNOWBALL THROWN")), true;
    if (b === Et && f?.type === Et) {
      let v = i.snowLayerCount(f.x, f.y, f.z);
      if (v < 8) return a.mode === "survival" && wn(Et) < 1 || (i.setSnowLayers(f.x, f.y, f.z, v + 1), mt(Et), $context.m(true), $context.p("SNOW LAYERS " + (v + 1) + "/8")), true;
    }
    if (cy(f, b)) return true;
    if (b === st && f?.type === S) return l(f.x, f.y, f.z, E) && (mt(st), En(At),$context.m('water'), $context.p("FILLED WATER BUCKET")), true;
    if(b===ne&&f?.type===te){i.primeTNT(f.x,f.y,f.z);es(b);return true;}
    if (b === At && f?.previous) {
      if(i.getDimension()==='nether'){mt(At);En(st);$context.m('fire');$context.p('WATER EVAPORATED');return true;}
      let v = f.previous;
      return l(v.x, v.y, v.z, S) && (mt(At), En(st),$context.m('water'), $context.p("POURED WATER")), true;
    }
    if(b===ne&&f){if(f.type===vt&&c(f)){es(b);return true;}if(f.previous&&A(f.previous.x,f.previous.y,f.previous.z)===E&&i.isSolid(A(f.previous.x,f.previous.y-1,f.previous.z))&&l(f.previous.x,f.previous.y,f.previous.z,Ie)){$context.m('fire');es(b);}return true;}
    if (b === Z && i.getDimension() === "overworld") {
      let v = i.strongholdLocation(), N = Math.atan2(v.z - $context.n.z, v.x - $context.n.x) * 180 / Math.PI;
      return $context.p("STRONGHOLD: " + v.x + ", " + v.z + " \xB7 BEARING " + Math.round(N) + "\xB0"), true;
    }
    if(f?.type===Be){const key=vo(f);i.ensureChestLoot?.(f);a.chests??={};a.chests[key]??=Array(27).fill(null);return Ll(false,key),true;}
    if (f?.type === W) return Ll(true), true;
    if (f?.type === te) return Qc(f.x, f.y, f.z), true;

    if (foodValues(r[b]?.name||'')) return ly(b);
    if (!f || !f.previous) return false;
    if (!r[b] || !i.isBlock(b)) return $context.p("SELECT A PLACEABLE BLOCK"), true;
    if (a.mode === "survival" && wn(b) < 1) return $context.p("NO " + r[b].name.toUpperCase() + " IN PACK"), true;
    let R = f.previous;
    if(b!==Nt&&b!==gi&&i.isDoor?.(b)&&i.placeDoorVariant)return i.placeDoorVariant(R.x,R.y,R.z,b)&&(mt(b),$context.m('place',b)),true;
    if((b===$||b===Hs)&&i.placeTorch)return i.placeTorch(R.x,R.y,R.z,b,f)&&(mt(b),$context.m('place',b)),true;
    if(b===pn&&i.placeBed)return i.placeBed(R.x,R.y,R.z)&&(mt(b),$context.m('place',b)),true;
    return i.occupied(R.x, R.y, R.z) ? true : b === Et && !i.isSolid(A(R.x, R.y - 1, R.z)) ? ($context.p("SNOW NEEDS SUPPORT"), true) : ((i.placeDirectional?i.placeDirectional(R.x,R.y,R.z,b):l(R.x,R.y,R.z,b)) && (b===Be&&(a.chests[vo(R)]=Array(27).fill(null)),mt(b), $context.m('place',b), $context.p("PLACED " + r[b].name.toUpperCase())), true);
  }

function py() {
    const {$r,De,Hn,In,Pe,Tl,Yn,Zt,e,es,hf,mt,o,ts} = $context;

    let f = new e.Vector3();
    o.getWorldDirection(f);
    let b = null, R = 4.2;
    for (let N of Zt) {
      if (!["cow", "sheep", "villager", "piglin"].includes(N.type)) continue;
      let V = new e.Vector3(N.x - $context.n.x, N.group.position.y + 1 - o.position.y, N.z - $context.n.z), L = V.length();
      L < R && V.normalize().dot(f) > 0.9 && (R = L, b = N);
    }
    if (!b) return false;
    const custom=b.definition?.onInteract?.(b,{item:Hn(),player:$context.n});if(custom!==undefined)return !!custom;
    if (b.type === "villager") return $r("trade", null, b), true;
    if (b.type === "piglin") return Hn() !== In ? false : (mt(In) && (b.barterTime = 6, b.aggro = false, $context.p("PIGLIN INSPECTING GOLD")), true);
    if (b.type === "sheep" && Hn() === Tl) return !b.sheared && !b.babyAge && (b.sheared = true, b.fleece && (b.fleece.visible = false), Yn(De, b.x, b.group.position.y + 1, b.z, 1 + Math.floor(Math.random() * 3)), es(Tl), $context.m('sheep_shear'),$context.p("SHEEP SHEARED")), true;
    if (Hn() !== Pe) return false;
    if ((b.breedCooldown || 0) > 0) return $context.p("THIS ANIMAL IS NOT READY TO BREED"), true;
    if (!mt(Pe)) return true;
    b.love = 30, b.breedCooldown = 300, $context.p(`${b.type.toUpperCase()} FED`);
    let v = Zt.find((N) => N !== b && N.type === b.type && N.love > 0 && Math.hypot(N.x - b.x, N.z - b.z) < 7);
    if (v) {
      let N = ts(b.type, (v.x + b.x) / 2, (v.z + b.z) / 2), V = Zt[Zt.length - 1];
      V.group.scale.setScalar(0.55), V.babyAge = 240, b.love = 0, v.love = 0, hf(2), $context.p(`BABY ${b.type.toUpperCase()} BORN`);
    }
    return true;
  }

function my() {
    const {A,W} = $context;

    for (let f = Math.floor($context.n.y) - 2; f <= Math.floor($context.n.y) + 2; f++) for (let b = Math.floor($context.n.x) - 3; b <= Math.floor($context.n.x) + 3; b++) for (let R = Math.floor($context.n.z) - 3; R <= Math.floor($context.n.z) + 3; R++) if (A(b, f, R) === W) return true;
    return false;
  }

function yy(f) {
    const {I,am,ki} = $context;

    let b = Array.from({ length: 9 }, (q, Ue) => f[Ue]?.id || 0), R = [], v = 3, N = -1, V = 3, L = -1;
    for (let q = 0; q < 3; q++) for (let Ue = 0; Ue < 3; Ue++) b[q * 3 + Ue] && (v = Math.min(v, Ue), N = Math.max(N, Ue), V = Math.min(V, q), L = Math.max(L, q));
    if (N < 0) return null;
    let z = [];
    for (let q = V; q <= L; q++) {
      let Ue = [];
      for (let Ye = v; Ye <= N; Ye++) {
        let Se = q * 3 + Ye;
        Ue.push(b[Se]), b[Se] && R.push(Se);
      }
      z.push(Ue);
    }
    let H = ki.find((q) => q.pattern.length === z.length && q.pattern.every((Ue, Ye) => Ue.length === z[Ye].length && Ue.every((Se, ue) => am(Se, z[Ye][ue]))));
    if (!H) return null;
    for (let q of R) --f[q].n <= 0 && (f[q] = null);
    return I(), { id: H.out, n: H.count || 1 };
  }
return {gy,cy,dy,py,my,yy};
}
