import {createInstantBlockEdits} from '../instant-block-edits.js';
/** chunks subsystem. Dependencies are injected at composition time. */
export function createChunksSystem($context) {
const instantEdits=createInstantBlockEdits($context);
function chunkLOD(chunk){
    const {SIZE,player} = $context;

  const distance=Math.hypot((chunk.cx+.5)*SIZE-player.x,(chunk.cz+.5)*SIZE-player.z);
  const current=chunk.lod??(distance<26?0:distance<42?1:2);
  if(current===0)return distance>29?distance>45?2:1:0;
  if(current===1)return distance<23?0:distance>45?2:1;
  return distance<39?distance<23?0:1:2;
}

function patchModelBuffers(target,range,data){
    const {quadNormals} = $context;

  if(data.p.length!==range.count*3)return false;
  const normal=quadNormals(data.p);
  for(const [name,values,size] of [['position',data.p,3],['normal',normal,3],['uv',data.u,2]]){
    const attribute=target.getAttribute(name),offset=range.start*size;
    attribute.array.set(values,offset);attribute.addUpdateRange(offset,values.length);attribute.needsUpdate=true;
  }
  return true;
}

function updateBlockModelImmediately(x,y,z){
    const {SIZE,chunks,editKey,getBlock,instantModelTypes,key,modelVertexData,patchModelBuffers,urgentMeshQueue} = $context;

  const chunk=chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))),type=getBlock(x,y,z),cell=editKey(x,y,z);
  if(!chunk||!instantModelTypes.has(type))return false;
  const mesh=chunk.meshes.find(mesh=>mesh.userData.modelRanges?.has(cell)),range=mesh?.userData.modelRanges.get(cell);
  if(range&&range.type===type&&patchModelBuffers(mesh.geometry,range,modelVertexData(type,x,y,z,chunk.lod))){
    // The conservative section bounds remain valid for either door orientation.
    return true;
  }
  const id=key(chunk.cx,chunk.cz),section=Math.floor(y/16);
  urgentMeshQueue.set(id+':'+section,{id,chunk,section});return false;
}

function updateDoorModelImmediately(x,y,z){
    const {updateBlockModelImmediately} = $context;
updateBlockModelImmediately(x,y,z);updateBlockModelImmediately(x,y+1,z)}

function* buildChunkTask(chunk,lod=chunk.lod??0,section=null){
    const {END_PORTAL,AIR,BEDROCK,BIRCH_LEAVES,FIRE,GLASS,LAVA,LEAVES,LEVER,MAX_Y,MIN_Y,POWERED_RAIL,RAIL,REDSTONE_WIRE,SIZE,SPRUCE_LEAVES,THREE,TORCH,WATER,appendModelBox,blockParts,chunks,colorFor,computeLightingTask,editKey,faceUV,faces,flowLevels,idx,instantModelTypes,key,materials,modelVertexData,occludes,player,portalUsesPreview,quadNormals,scene,terrain} = $context;

  const targetScene=$context.portalPreviewMode?$context.portalPreviewScene:scene;
  chunk.lod=lod;if(section===null)chunk.meshComplete=false;
  if(section!==null){}
  else {
    const lower=MIN_Y,upper=MAX_Y-1;
    if(!chunk.light||chunk.lightRevision!==(chunk.lightingRevision||0)||chunk.lightMinY>lower||chunk.lightMaxY<upper)yield* computeLightingTask(chunk,lower,upper);
  }
  let buckets,sectionRevision=0;
  const freshBuckets=()=>Array.from({length:5},()=>({p:[],c:[],u:[],i:[],models:new Map(),blocks:new Map()}));
  const ox=chunk.cx*SIZE,oz=chunk.cz*SIZE;
  const worldChunks=$context.portalPreviewMode?$context.portalPreviewChunks:chunks;
  const neighbors=[worldChunks.get(key(chunk.cx+1,chunk.cz)),worldChunks.get(key(chunk.cx-1,chunk.cz)),null,null,worldChunks.get(key(chunk.cx,chunk.cz+1)),worldChunks.get(key(chunk.cx,chunk.cz-1))];
  function neighborBlock(x,y,z,face){
    const d=faces[face].d,nx=x+d[0],ny=y+d[1],nz=z+d[2];
    if(ny<MIN_Y)return $context.dimension==='end'?AIR:BEDROCK;
    if(ny>=MAX_Y)return AIR;
    if(nx>=0&&nx<SIZE&&nz>=0&&nz<SIZE)return chunk.blocks[idx(nx,ny,nz)];
    const adjacent=neighbors[face];return adjacent?adjacent.blocks[idx((nx+SIZE)%SIZE,ny,(nz+SIZE)%SIZE)]:AIR;
  }
  const buriedBelow=lod&&$context.dimension==='overworld'?Array.from({length:SIZE*SIZE},(_,i)=>{const wx=ox+i%SIZE,wz=oz+Math.floor(i/SIZE);return Math.min(terrain(wx,wz),terrain(wx+1,wz),terrain(wx-1,wz),terrain(wx,wz+1),terrain(wx,wz-1))-4}):null;
  const box=appendModelBox;
  function cross(bucket,type,wx,y,wz,height=1){const uv=faceUV(type,4,wx,wz,y),col=colorFor(type,4,wx,y,wz),planes=[[[.08,0,.08],[.92,0,.92],[.92,height,.92],[.08,height,.08]],[[.92,0,.08],[.08,0,.92],[.08,height,.92],[.92,height,.08]]];for(const verts of planes)for(const reverse of [false,true]){const q=bucket.p.length/3;for(const v of reverse?[...verts].reverse():verts){bucket.p.push(wx+v[0],y+v[1],wz+v[2]);bucket.c.push(col.r,col.g,col.b);const horizontal=Math.abs(v[0]-verts[0][0])/.84,vertical=v[1]/height;bucket.u.push(uv[0]+(uv[2]-uv[0])*horizontal,uv[1]+(uv[3]-uv[1])*vertical)}bucket.i.push(q,q+1,q+2,q,q+2,q+3)}}
  const previewY=$context.portalPreviewState?.center.y??player.y;
  const meshMinY=section!==null?Math.max(MIN_Y,section*16):MIN_Y;
  const meshMaxY=section!==null?Math.min(MAX_Y-1,section*16+15):chunk.topY;
  for(let sectionY=Math.floor(Math.min(MAX_Y-1,meshMaxY)/16);sectionY>=Math.floor(meshMinY/16);sectionY--)for(let y=Math.max(meshMinY,sectionY*16);y<=Math.min(MAX_Y-1,meshMaxY,sectionY*16+15);y++){if(y===meshMinY||y%16===0){buckets=freshBuckets();sectionRevision=chunk.visualRevision||0;}for(let z=0;z<SIZE;z++){for(let x=0;x<SIZE;x++){
    const type=chunk.blocks[idx(x,y,z)];if(type===AIR||$context.save.experiments&&portalUsesPreview(type))continue;
    if(lod&&$context.dimension==='overworld'&&y<buriedBelow[z*SIZE+x]&&Math.abs(y-player.y)>(lod===2?24:40))continue;
    const wx=ox+x,wz=oz+z,bucket=buckets[(type===END_PORTAL||type===9990)?4:type===WATER?1:type===GLASS?2:type===LAVA?3:0];
    if(! $context.modelBlockTypes.has(type)&&occludes(type)&&[0,1,2,3,4,5].every(f=>occludes(neighborBlock(x,y,z,f))))continue;
    const blockStart=bucket.p.length/3;const parts=blockParts(type,wx,y,wz,lod);if(parts){const start=bucket.p.length/3;for(const part of parts)if(part.kind==='box')box(bucket,type,wx,y,wz,...part.bounds,part.texture,part.faces,part.rotation,part.slope);else cross(bucket,part.texture||type,wx,y,wz,part.height);if(instantModelTypes.has(type))bucket.models.set(editKey(wx,y,wz),{start,count:bucket.p.length/3-start,type,x:wx,y,z:wz});if(bucket.p.length/3>blockStart)bucket.blocks.set(editKey(wx,y,wz),{start:blockStart,count:bucket.p.length/3-blockStart});continue}
    const liquid=type===WATER||type===LAVA,level=liquid?(flowLevels.get(editKey(wx,y,wz))||8):0,top=liquid?Math.min(1,.14+level*.86/8):1;
    for(let f=0;f<6;f++){
      const face=faces[f],nx=wx+face.d[0],ny=y+face.d[1],nz=wz+face.d[2],neighbor=neighborBlock(x,y,z,f);
      
      if(type===WATER||type===LAVA){if(neighbor===type||occludes(neighbor))continue}
      else if(type===GLASS){if(neighbor===GLASS||occludes(neighbor))continue}
      else if(occludes(neighbor))continue;
      const base=bucket.p.length/3,col=colorFor(type,f,wx,y,wz),uv=faceUV(type,f,wx,wz,y);
      for(const v of face.v){bucket.p.push(wx+v[0],y+(liquid&&v[1]===1?top:v[1]),wz+v[2]);bucket.c.push(col.r,col.g,col.b)}
      bucket.u.push(uv[0],uv[1],uv[0],uv[3],uv[2],uv[3],uv[2],uv[1]);
      bucket.i.push(base,base+1,base+2,base,base+2,base+3);
    }
    if(bucket.p.length/3>blockStart)bucket.blocks.set(editKey(wx,y,wz),{start:blockStart,count:bucket.p.length/3-blockStart});
  }yield;}
  if((y+1)%16===0||y===Math.min(MAX_Y-1,meshMaxY)){
    const sectionY=Math.floor(y/16);
    for(let i=chunk.meshes.length-1;i>=0;i--){const mesh=chunk.meshes[i];if(mesh.userData.sectionY===sectionY){mesh.removeFromParent();mesh.geometry.dispose();chunk.meshes.splice(i,1)}}
  buckets.forEach((b,i)=>{if(!b.p.length)return;for(const range of b.models.values()){const current=modelVertexData(range.type,range.x,range.y,range.z,lod);if(current.p.length===range.count*3){for(let n=0;n<current.p.length;n++)b.p[range.start*3+n]=current.p[n];for(let n=0;n<current.u.length;n++)b.u[range.start*2+n]=current.u[n]}}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(b.p,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(b.c,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(b.u,2));geo.setIndex(b.i);geo.setAttribute('normal',new THREE.BufferAttribute(quadNormals(b.p),3));$context.applyGridLighting(geo);const mesh=new THREE.Mesh(geo,[materials.solid,materials.water,materials.glass,materials.lava,materials.endPortal][i]);const meshDimension=$context.dimension;mesh.onBeforeRender=(_r,_s,_c,_g,m)=>m.userData.updateGridLight?.(meshDimension);mesh.matrixAutoUpdate=false;mesh.matrixWorldAutoUpdate=false;mesh.updateMatrix();mesh.frustumCulled=true;mesh.userData.sectionY=Math.floor(y/16);mesh.userData.modelRanges=b.models;mesh.userData.blockRanges=b.blocks;geo.boundingBox=new THREE.Box3(new THREE.Vector3(ox-1,sectionY*16-1,oz-1),new THREE.Vector3(ox+SIZE+1,sectionY*16+17,oz+SIZE+1));geo.boundingSphere=new THREE.Sphere();geo.boundingBox.getBoundingSphere(geo.boundingSphere);targetScene.add(mesh);chunk.meshes.push(mesh)});
  if(!$context.portalPreviewMode)instantEdits.commit(chunk,sectionY,sectionRevision);
  }
  yield;
  }
  if(section===null)chunk.meshComplete=true;
  return chunk;
}

function buildChunk(chunk,lod=chunk.lod??0){
    const {buildChunkTask} = $context;
const task=buildChunkTask(chunk,lod);while(!task.next().done){}return chunk}

function ensureChunk(cx,cz){
    const {chunks,key,queue,queued} = $context;
const k=key(cx,cz);if(chunks.has(k)||queued.has(k))return;queued.add(k);queue.push([cx,cz])}

function scheduleChunkMesh(chunk,relight=true){
    const {chunks,firstMeshQueue,key,meshRebuildQueue} = $context;
if(relight&&chunk)chunk.lightingRevision=(chunk.lightingRevision||0)+1;if(chunk&&chunks.get(key(chunk.cx,chunk.cz))===chunk){const id=key(chunk.cx,chunk.cz);(chunk.meshComplete?meshRebuildQueue:firstMeshQueue).set(id,chunk)}}

function scheduleEditLighting(chunk,alreadyUpdated=false){
    const {editLightingQueue,key} = $context;
if(alreadyUpdated)return;if(chunk){chunk.lightingRevision=(chunk.lightingRevision||0)+1;editLightingQueue.set(key(chunk.cx,chunk.cz),chunk)}}

function* refreshEditedLighting(chunk){
 yield* $context.computeLightingTask(chunk,$context.MIN_Y,$context.MAX_Y-1,true);
 // Lighting changes only upload a vertex attribute. They never rebuild block geometry.
 for(const changed of chunk.updatedLightChunks||[chunk]){for(const mesh of changed.meshes)if(changed.changedLightSections.has(mesh.userData.sectionY)||changed.changedLightSections.has(mesh.userData.sectionY-1)||changed.changedLightSections.has(mesh.userData.sectionY+1))$context.applyGridLighting(mesh.geometry);if(changed.lightRevision===(changed.lightingRevision||0))$context.editLightingQueue.delete($context.key(changed.cx,changed.cz));yield;}
}

function flushEditLighting(){
 $context.refreshEmissionChanges();
 const {chunks,editLightingQueue,refreshEditedLighting}=$context;
 if(!$context.pendingEditLighting){const next=editLightingQueue.entries().next();if(next.done)return;const [id,chunk]=next.value;editLightingQueue.delete(id);if(chunks.get(id)!==chunk)return;$context.pendingEditLighting={chunk,task:refreshEditedLighting(chunk)};}
 const start=performance.now();do{if($context.pendingEditLighting.task.next().done){$context.pendingEditLighting=null;break;}}while(performance.now()-start<5);
}

function scheduleBlockMesh(x,y,z,immediate=false){
    const {MAX_Y,MIN_Y,SIZE,chunks,key,urgentMeshQueue} = $context;

  const lightingReady=immediate&&$context.updateLightingAt(x,y,z);if(immediate)instantEdits.edit(x,y,z);
  const ownCX=Math.floor(x/SIZE),ownCZ=Math.floor(z/SIZE),own=chunks.get(key(ownCX,ownCZ));if(own?.skyColumns)own.skyColumns[(z-ownCZ*SIZE)*SIZE+x-ownCX*SIZE]=-32768;
  for(const [dx,dy,dz] of [[0,0,0],[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){
    const cx=Math.floor((x+dx)/SIZE),cz=Math.floor((z+dz)/SIZE),id=key(cx,cz),chunk=chunks.get(id),section=Math.floor((y+dy)/16);
    if(chunk&&y+dy>=MIN_Y&&y+dy<MAX_Y){chunk.visualRevision=(chunk.visualRevision||0)+1;urgentMeshQueue.set(id+':'+section,{id,chunk,section});}
  }
  return lightingReady;
}

function flushChunkMesh(){
    instantEdits.sync();
    const {buildChunkTask,chunkLOD,chunks,firstMeshQueue,meshRebuildQueue,urgentMeshQueue} = $context;

  if(urgentMeshQueue.size&&$context.pendingMeshing&&!$context.pendingMeshing.urgent){$context.suspendedMeshing=$context.pendingMeshing;$context.pendingMeshing=null}
  if(!$context.pendingMeshing&&urgentMeshQueue.size){const [queueId,value]=urgentMeshQueue.entries().next().value;urgentMeshQueue.delete(queueId);if(chunks.get(value.id)===value.chunk)$context.pendingMeshing={...value,urgent:true,task:buildChunkTask(value.chunk,chunkLOD(value.chunk),value.section)}}
  if(!$context.pendingMeshing&&$context.suspendedMeshing){if(chunks.get($context.suspendedMeshing.id)===$context.suspendedMeshing.chunk)$context.pendingMeshing=$context.suspendedMeshing;$context.suspendedMeshing=null}
  if(!$context.pendingMeshing){const selected=firstMeshQueue.size?firstMeshQueue:meshRebuildQueue,next=selected.entries().next();if(next.done)return false;let [id,chunk]=next.value;if(selected===firstMeshQueue){let best=Infinity;for(const [candidate,value] of selected){const distance=$context.streamPriority?.(value.cx,value.cz)??((value.cx+.5-$context.player.x/$context.SIZE)**2+(value.cz+.5-$context.player.z/$context.SIZE)**2);if(distance<best){best=distance;id=candidate;chunk=value;}}}selected.delete(id);if(chunks.get(id)!==chunk)return true;$context.pendingMeshing={id,chunk,task:buildChunkTask(chunk,chunkLOD(chunk))}}
  const start=performance.now();do{const result=$context.pendingMeshing.task.next();if(result.done){$context.pendingMeshing=null;break}}while(performance.now()-start<3);
  if($context.suspendedMeshing){const task=$context.suspendedMeshing,start=performance.now();if(chunks.get(task.id)!==task.chunk)$context.suspendedMeshing=null;else do{if(task.task.next().done){$context.suspendedMeshing=null;break}}while(performance.now()-start<1)}
  return true;
}

function stream(){
    const {SIZE,buttonUntil,chunkLOD,chunks,editLightingQueue,ensureChunk,fireCells,firstMeshQueue,flowFalling,flowLevels,flowSources,flushChunkMesh,flushEditLighting,gateOutputs,gatePending,generateChunk,gravityQueued,growthCells,hopperAt,key,loading,meshRebuildQueue,observerUntil,pistonPowered,player,portalCells,queue,queued,redstoneCells,redstoneDoorPowered,redstoneEdge,scene,scheduleChunkMesh,sensorCells,sensorFrequency,sensorUntil,targetUntil,torchBurnedUntil,torchPending,torchStates,torchSwitches,tripwireUntil,urgentGravityQueued,urgentMeshQueue} = $context;

  const now=performance.now(),previous=$context.streamMotion,elapsed=previous?Math.max(.01,(now-previous.time)/1000):1,dx=previous?(player.x-previous.x)/elapsed:0,dz=previous?(player.z-previous.z)/elapsed:0,speed=Math.min(48,Math.hypot(dx,dz));
  $context.streamMotion={x:player.x,z:player.z,time:now};
  const moving=speed>.5,ux=moving?dx/Math.max(.001,Math.hypot(dx,dz)):-Math.sin(player.yaw),uz=moving?dz/Math.max(.001,Math.hypot(dx,dz)):-Math.cos(player.yaw),lead=Math.min(12,Math.max(3,Math.ceil(speed*6/SIZE)));
  const cx=Math.floor(player.x/SIZE),cz=Math.floor(player.z/SIZE),radius=$context.save.renderDistance+2,heading=Math.round(Math.atan2(ux,uz)/(Math.PI/8)),currentKey=$context.dimension+':'+cx+','+cz+':'+radius+':'+heading+':'+lead;
  const score=(x,z)=>{const rx=x+.5-player.x/SIZE,rz=z+.5-player.z/SIZE,forward=rx*ux+rz*uz,lateral=Math.abs(rx*uz-rz*ux);return rx*rx+rz*rz-Math.max(0,forward)*Math.min(3,lead)*Math.max(0,1-lateral/3);};
  $context.streamPriority=score;
  const centerChanged=$context.streamKey!==currentKey;
  if(centerChanged){$context.streamKey=currentKey;$context.streamWanted=[];const wantedKeys=new Set();const add=(x,z)=>{const id=key(x,z);if(wantedKeys.has(id))return;wantedKeys.add(id);$context.streamWanted.push([x,z,score(x,z)]);};
    for(let dz=-radius;dz<=radius;dz++)for(let dx=-radius;dx<=radius;dx++)add(cx+dx,cz+dz);
    // Prefetch a narrow corridor using actual movement, including strafing/backwards flight.
    for(let step=1;step<=lead;step++){const ax=Math.floor(player.x/SIZE+ux*step),az=Math.floor(player.z/SIZE+uz*step);for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=2;dx++)add(ax+dx,az+dz);}
    $context.streamKeep=wantedKeys;$context.streamWanted.sort((a,b)=>score(a[0],a[1])-score(b[0],b[1]));for(const [x,z]of $context.streamWanted)ensureChunk(x,z);queue.sort((a,b)=>score(a[0],a[1])-score(b[0],b[1]));
  }
  const wanted=$context.streamWanted;
  if(centerChanged){
    const evicted=new Set();
    for(const [id,chunk] of chunks){
      if($context.streamKeep?.has(id)||Math.abs(chunk.cx-cx)<=radius+1&&Math.abs(chunk.cz-cz)<=radius+1)continue;
      for(const mesh of chunk.meshes){scene.remove(mesh);mesh.geometry.dispose();}
      evicted.add(id);chunks.delete(id);firstMeshQueue.delete(id);meshRebuildQueue.delete(id);editLightingQueue.delete(id);
      if($context.pendingMeshing?.id===id)$context.pendingMeshing=null;if($context.pendingEditLighting?.chunk===chunk)$context.pendingEditLighting=null;
    }
    // Visit each runtime collection once, rather than once per evicted chunk.
    if(evicted.size){
      for(const collection of [portalCells,flowLevels,flowSources,flowFalling,redstoneCells,sensorCells,pistonPowered,redstoneDoorPowered,growthCells,fireCells,gravityQueued,urgentGravityQueued,buttonUntil,observerUntil,gateOutputs,gatePending,torchStates,torchPending,torchSwitches,torchBurnedUntil,redstoneEdge,sensorUntil,sensorFrequency,targetUntil,tripwireUntil,hopperAt]){
        for(const cell of collection.keys()){const x=parseInt(cell,10),z=Number(cell.slice(cell.lastIndexOf(',')+1));if(evicted.has(key(Math.floor(x/SIZE),Math.floor(z/SIZE))))collection.delete(cell);}
      }
      for(const [id,entry] of urgentMeshQueue)if(evicted.has(entry.id))urgentMeshQueue.delete(id);
    }
  }
  if($context.pendingGeneration&&(!$context.streamKeep?.has(key($context.pendingGeneration.cx,$context.pendingGeneration.cz))||$context.pendingGeneration.dimension!==$context.dimension)){queued.delete(key($context.pendingGeneration.cx,$context.pendingGeneration.cz));$context.pendingGeneration=null}
  if(!$context.pendingGeneration)while(queue.length){const [x,z]=queue.shift(),k=key(x,z);if(chunks.has(k)||!$context.streamKeep?.has(k)){queued.delete(k);continue}$context.pendingGeneration={cx:x,cz:z,dimension: $context.dimension,task:generateChunk(x,z)};break}
  if(centerChanged||performance.now()-$context.lodCheckAt>100){$context.lodCheckAt=performance.now();for(const [x,z] of wanted){const chunk=chunks.get(key(x,z));if(chunk&&(chunkLOD(chunk)!==chunk.lod||!chunk.meshComplete&&!firstMeshQueue.has(key(x,z))&&$context.pendingMeshing?.chunk!==chunk&&$context.suspendedMeshing?.chunk!==chunk))scheduleChunkMesh(chunk,false)}}
  const closeMissing=wanted.some(([x,z])=>Math.abs(x-cx)<=2&&Math.abs(z-cz)<=2&&!chunks.get(key(x,z))?.meshComplete),meshStart=performance.now(),loadingTerrain=!$context.playing&&!$context.portalPreviewMode||loading.has('world')||loading.has('enter');do{if(!flushChunkMesh())break;}while((loadingTerrain||closeMissing)&&performance.now()-meshStart<(loadingTerrain?14:9));flushEditLighting();
  const start=performance.now();
  const generationBudget=(!$context.playing&&!$context.portalPreviewMode||loading.has('world')||loading.has('enter'))?14:closeMissing?8:4;
  while(performance.now()-start<generationBudget){
    if(!$context.pendingGeneration){while(queue.length){const [x,z]=queue.shift(),id=key(x,z);if(chunks.has(id)||!$context.streamKeep?.has(id)){queued.delete(id);continue;}$context.pendingGeneration={cx:x,cz:z,dimension: $context.dimension,task:generateChunk(x,z)};break;}if(!$context.pendingGeneration)break;}
    const result=$context.pendingGeneration.task.next();if(!result.done)continue;
    const {cx:x,cz:z}=$context.pendingGeneration;queued.delete(key(x,z));$context.pendingGeneration=null;scheduleChunkMesh(result.value);
    // A neighbor may have meshed while this chunk was only partly generated.
    // Rebuild all shared edges once this chunk's block data is complete.
    for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]])scheduleChunkMesh(chunks.get(key(x+dx,z+dz)),false);
  }
}
return {chunkLOD,patchModelBuffers,updateBlockModelImmediately,updateDoorModelImmediately,buildChunkTask,buildChunk,ensureChunk,scheduleChunkMesh,scheduleEditLighting,refreshEditedLighting,flushEditLighting,scheduleBlockMesh,flushChunkMesh,stream};
}
