/** chunks subsystem. Dependencies are injected at composition time. */
export function createChunksSystem($context) {
function chunkLOD(chunk){
    const {SIZE,player} = $context;

  const distance=Math.hypot((chunk.cx+.5)*SIZE-player.x,(chunk.cz+.5)*SIZE-player.z);
  const current=chunk.lod??(distance<26?0:distance<42?1:2);
  if(current===0)return distance>29?distance>45?2:1:0;
  if(current===1)return distance<23?0:distance>45?2:1;
  return distance<39?distance<23?0:1:2;
}

function patchModelBuffers(target,range,data){
    const {quadNormals} = $context;

  if(data.p.length!==range.count*3)return false;
  const normal=quadNormals(data.p);
  for(const [name,values,size] of [['position',data.p,3],['normal',normal,3],['uv',data.u,2]]){
    const attribute=target.getAttribute(name),offset=range.start*size;
    attribute.array.set(values,offset);attribute.addUpdateRange(offset,values.length);attribute.needsUpdate=true;
  }
  return true;
}

function updateBlockModelImmediately(x,y,z){
    const {SIZE,chunks,editKey,getBlock,instantModelTypes,key,modelVertexData,patchModelBuffers,urgentMeshQueue} = $context;

  const chunk=chunks.get(key(Math.floor(x/SIZE),Math.floor(z/SIZE))),type=getBlock(x,y,z),cell=editKey(x,y,z);
  if(!chunk||!instantModelTypes.has(type))return false;
  const mesh=chunk.meshes.find(mesh=>mesh.userData.modelRanges?.has(cell)),range=mesh?.userData.modelRanges.get(cell);
  if(range&&range.type===type&&patchModelBuffers(mesh.geometry,range,modelVertexData(type,x,y,z,chunk.lod))){
    // The conservative section bounds remain valid for either door orientation.
    return true;
  }
  const id=key(chunk.cx,chunk.cz),section=Math.floor(y/16);
  urgentMeshQueue.set(id+':'+section,{id,chunk,section});return false;
}

function updateDoorModelImmediately(x,y,z){
    const {updateBlockModelImmediately} = $context;
updateBlockModelImmediately(x,y,z);updateBlockModelImmediately(x,y+1,z)}

function* buildChunkTask(chunk,lod=chunk.lod??0,section=null){
    const {END_PORTAL,AIR,BEDROCK,BIRCH_LEAVES,FIRE,GLASS,LAVA,LEAVES,LEVER,MAX_Y,MIN_Y,POWERED_RAIL,RAIL,REDSTONE_WIRE,SIZE,SPRUCE_LEAVES,THREE,TORCH,WATER,appendModelBox,blockParts,chunks,colorFor,computeLightingTask,editKey,faceUV,faces,flowLevels,idx,instantModelTypes,key,materials,modelVertexData,occludes,player,portalUsesPreview,quadNormals,scene,terrain} = $context;

  const targetScene=$context.portalPreviewMode?$context.portalPreviewScene:scene;
  chunk.lod=lod;if(section===null)chunk.meshComplete=false;
  if(section!==null){}
  else {
    const lower=MIN_Y,upper=MAX_Y-1;
    if(!chunk.light||chunk.lightRevision!==(chunk.lightingRevision||0)||chunk.lightBand!==($context.dimension==='overworld'?$context.lightDay:0)||chunk.lightMinY>lower||chunk.lightMaxY<upper)yield* computeLightingTask(chunk,lower,upper);
  }
  let buckets;
  const freshBuckets=()=>Array.from({length:5},()=>({p:[],c:[],u:[],i:[],models:new Map()}));
  const ox=chunk.cx*SIZE,oz=chunk.cz*SIZE;
  const worldChunks=$context.portalPreviewMode?$context.portalPreviewChunks:chunks;
  const neighbors=[worldChunks.get(key(chunk.cx+1,chunk.cz)),worldChunks.get(key(chunk.cx-1,chunk.cz)),null,null,worldChunks.get(key(chunk.cx,chunk.cz+1)),worldChunks.get(key(chunk.cx,chunk.cz-1))];
  function neighborBlock(x,y,z,face){
    const d=faces[face].d,nx=x+d[0],ny=y+d[1],nz=z+d[2];
    if(ny<MIN_Y)return $context.dimension==='end'?AIR:BEDROCK;
    if(ny>=MAX_Y)return AIR;
    if(nx>=0&&nx<SIZE&&nz>=0&&nz<SIZE)return chunk.blocks[idx(nx,ny,nz)];
    const adjacent=neighbors[face];return adjacent?adjacent.blocks[idx((nx+SIZE)%SIZE,ny,(nz+SIZE)%SIZE)]:AIR;
  }
  const buriedBelow=lod&&$context.dimension==='overworld'?Array.from({length:SIZE*SIZE},(_,i)=>{const wx=ox+i%SIZE,wz=oz+Math.floor(i/SIZE);return Math.min(terrain(wx,wz),terrain(wx+1,wz),terrain(wx-1,wz),terrain(wx,wz+1),terrain(wx,wz-1))-4}):null;
  const box=appendModelBox;
  function cross(bucket,type,wx,y,wz,height=1){const uv=faceUV(type,4,wx,wz,y),col=colorFor(type,4,wx,y,wz),planes=[[[.08,0,.08],[.92,0,.92],[.92,height,.92],[.08,height,.08]],[[.92,0,.08],[.08,0,.92],[.08,height,.92],[.92,height,.08]]];for(const verts of planes)for(const reverse of [false,true]){const q=bucket.p.length/3;for(const v of reverse?[...verts].reverse():verts){bucket.p.push(wx+v[0],y+v[1],wz+v[2]);bucket.c.push(col.r,col.g,col.b);const horizontal=Math.abs(v[0]-verts[0][0])/.84,vertical=v[1]/height;bucket.u.push(uv[0]+(uv[2]-uv[0])*horizontal,uv[1]+(uv[3]-uv[1])*vertical)}bucket.i.push(q,q+1,q+2,q,q+2,q+3)}}
  const previewY=$context.portalPreviewState?.center.y??player.y;
  const meshMinY=section!==null?Math.max(MIN_Y,section*16):MIN_Y;
  const meshMaxY=section!==null?Math.min(MAX_Y-1,section*16+15):chunk.topY;
  for(let sectionY=Math.floor(Math.min(MAX_Y-1,meshMaxY)/16);sectionY>=Math.floor(meshMinY/16);sectionY--)for(let y=Math.max(meshMinY,sectionY*16);y<=Math.min(MAX_Y-1,meshMaxY,sectionY*16+15);y++){if(y===meshMinY||y%16===0)buckets=freshBuckets();for(let z=0;z<SIZE;z++){for(let x=0;x<SIZE;x++){
    const type=chunk.blocks[idx(x,y,z)];if(type===AIR||$context.save.experiments&&portalUsesPreview(type))continue;
    if(lod&&$context.dimension==='overworld'&&y<buriedBelow[z*SIZE+x]&&Math.abs(y-player.y)>(lod===2?24:40))continue;
    const wx=ox+x,wz=oz+z,bucket=buckets[(type===END_PORTAL||type===9990)?4:type===WATER?1:type===GLASS?2:type===LAVA?3:0];
    const parts=blockParts(type,wx,y,wz,lod);if(parts){if(lod===2&&(parts.every(part=>part.kind==='cross')||[TORCH,FIRE,RAIL,POWERED_RAIL,REDSTONE_WIRE,LEVER].includes(type)))continue;const start=bucket.p.length/3;for(const part of parts)if(part.kind==='box')box(bucket,type,wx,y,wz,...part.bounds,part.texture,part.faces,part.rotation,part.slope);else cross(bucket,part.texture||type,wx,y,wz,part.height);if(instantModelTypes.has(type))bucket.models.set(editKey(wx,y,wz),{start,count:bucket.p.length/3-start,type,x:wx,y,z:wz});continue}
    const liquid=type===WATER||type===LAVA,level=liquid?(flowLevels.get(editKey(wx,y,wz))||8):0,top=liquid?Math.min(1,.14+level*.86/8):1;
    for(let f=0;f<6;f++){
      const face=faces[f],nx=wx+face.d[0],ny=y+face.d[1],nz=wz+face.d[2],neighbor=neighborBlock(x,y,z,f);
      if(lod>0&&[LEAVES,SPRUCE_LEAVES,BIRCH_LEAVES].includes(type)&&neighbor===type)continue;
      if(type===WATER||type===LAVA){if(neighbor===type||occludes(neighbor))continue}
      else if(type===GLASS){if(neighbor===GLASS||occludes(neighbor))continue}
      else if(occludes(neighbor))continue;
      const base=bucket.p.length/3,col=colorFor(type,f,wx,y,wz),uv=faceUV(type,f,wx,wz,y);
      for(const v of face.v){bucket.p.push(wx+v[0],y+(liquid&&v[1]===1?top:v[1]),wz+v[2]);bucket.c.push(col.r,col.g,col.b)}
      bucket.u.push(uv[0],uv[1],uv[0],uv[3],uv[2],uv[3],uv[2],uv[1]);
      bucket.i.push(base,base+1,base+2,base,base+2,base+3);
    }
  }yield;}
  if((y+1)%16===0||y===Math.min(MAX_Y-1,meshMaxY)){
    const sectionY=Math.floor(y/16);
    for(let i=chunk.meshes.length-1;i>=0;i--){const mesh=chunk.meshes[i];if(mesh.userData.sectionY===sectionY){mesh.removeFromParent();mesh.geometry.dispose();chunk.meshes.splice(i,1)}}
  buckets.forEach((b,i)=>{if(!b.p.length)return;for(const range of b.models.values()){const current=modelVertexData(range.type,range.x,range.y,range.z,lod);if(current.p.length===range.count*3){for(let n=0;n<current.p.length;n++)b.p[range.start*3+n]=current.p[n];for(let n=0;n<current.u.length;n++)b.u[range.start*2+n]=current.u[n]}}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(b.p,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(b.c,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(b.u,2));geo.setIndex(b.i);geo.setAttribute('normal',new THREE.BufferAttribute(quadNormals(b.p),3));const mesh=new THREE.Mesh(geo,[materials.solid,materials.water,materials.glass,materials.lava,materials.endPortal][i]);mesh.matrixAutoUpdate=false;mesh.matrixWorldAutoUpdate=false;mesh.updateMatrix();mesh.frustumCulled=true;mesh.userData.sectionY=Math.floor(y/16);mesh.userData.modelRanges=b.models;geo.boundingBox=new THREE.Box3(new THREE.Vector3(ox-1,sectionY*16-1,oz-1),new THREE.Vector3(ox+SIZE+1,sectionY*16+17,oz+SIZE+1));geo.boundingSphere=new THREE.Sphere();geo.boundingBox.getBoundingSphere(geo.boundingSphere);targetScene.add(mesh);chunk.meshes.push(mesh)});
  }
  yield;
  }
  if(section===null)chunk.meshComplete=true;
  return chunk;
}

function buildChunk(chunk,lod=chunk.lod??0){
    const {buildChunkTask} = $context;
const task=buildChunkTask(chunk,lod);while(!task.next().done){}return chunk}

function ensureChunk(cx,cz){
    const {chunks,key,queue,queued} = $context;
const k=key(cx,cz);if(chunks.has(k)||queued.has(k))return;queued.add(k);queue.push([cx,cz])}

function scheduleChunkMesh(chunk,relight=true){
    const {chunks,firstMeshQueue,key,meshRebuildQueue} = $context;
if(relight&&chunk)chunk.lightingRevision=(chunk.lightingRevision||0)+1;if(chunk&&chunks.get(key(chunk.cx,chunk.cz))===chunk){const id=key(chunk.cx,chunk.cz);(chunk.meshComplete?meshRebuildQueue:firstMeshQueue).set(id,chunk)}}

function scheduleEditLighting(chunk){
    const {editLightingQueue,key} = $context;
if(chunk){chunk.lightingRevision=(chunk.lightingRevision||0)+1;editLightingQueue.set(key(chunk.cx,chunk.cz),chunk)}}

function* refreshEditedLighting(chunk){
    const {MAX_Y,MIN_Y,SIZE,computeLightingTask,idx,key,urgentMeshQueue} = $context;
const previous=chunk.light;yield* computeLightingTask(chunk);if(!previous)return;for(let section=Math.floor(MIN_Y/16);section<MAX_Y/16;section++){let changed=false;for(let y=section*16;y<section*16+16&&!changed;y++){for(let z=0;z<SIZE&&!changed;z++)for(let x=0;x<SIZE;x++){const at=idx(x,y,z);if(previous[at]!==chunk.light[at]){changed=true;break}}yield;}if(changed)urgentMeshQueue.set(key(chunk.cx,chunk.cz)+':'+section,{id:key(chunk.cx,chunk.cz),chunk,section})}}

function flushEditLighting(){
    const {chunks,editLightingQueue,refreshEditedLighting} = $context;
if(!$context.pendingEditLighting){const next=editLightingQueue.entries().next();if(next.done)return;const [id,chunk]=next.value;editLightingQueue.delete(id);if(chunks.get(id)!==chunk)return;$context.pendingEditLighting={chunk,task:refreshEditedLighting(chunk)}}const start=performance.now();do{if($context.pendingEditLighting.task.next().done){$context.pendingEditLighting=null;break}}while(performance.now()-start<1)}

function scheduleBlockMesh(x,y,z){
    const {MAX_Y,MIN_Y,SIZE,chunks,key,urgentMeshQueue} = $context;

  const ownCX=Math.floor(x/SIZE),ownCZ=Math.floor(z/SIZE),own=chunks.get(key(ownCX,ownCZ));if(own?.skyColumns)own.skyColumns[(z-ownCZ*SIZE)*SIZE+x-ownCX*SIZE]=-32768;
  for(const [dx,dy,dz] of [[0,0,0],[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){
    const cx=Math.floor((x+dx)/SIZE),cz=Math.floor((z+dz)/SIZE),id=key(cx,cz),chunk=chunks.get(id),section=Math.floor((y+dy)/16);
    if(chunk&&y+dy>=MIN_Y&&y+dy<MAX_Y)urgentMeshQueue.set(id+':'+section,{id,chunk,section});
  }
}

function flushChunkMesh(){
    const {buildChunkTask,chunkLOD,chunks,firstMeshQueue,meshRebuildQueue,urgentMeshQueue} = $context;

  if(urgentMeshQueue.size&&$context.pendingMeshing&&!$context.pendingMeshing.urgent){$context.suspendedMeshing=$context.pendingMeshing;$context.pendingMeshing=null}
  if(!$context.pendingMeshing&&urgentMeshQueue.size){const [queueId,value]=urgentMeshQueue.entries().next().value;urgentMeshQueue.delete(queueId);if(chunks.get(value.id)===value.chunk)$context.pendingMeshing={...value,urgent:true,task:buildChunkTask(value.chunk,chunkLOD(value.chunk),value.section)}}
  if(!$context.pendingMeshing&&$context.suspendedMeshing){if(chunks.get($context.suspendedMeshing.id)===$context.suspendedMeshing.chunk)$context.pendingMeshing=$context.suspendedMeshing;$context.suspendedMeshing=null}
  if(!$context.pendingMeshing){const selected=firstMeshQueue.size?firstMeshQueue:meshRebuildQueue,next=selected.entries().next();if(next.done)return false;const [id,chunk]=next.value;selected.delete(id);if(chunks.get(id)!==chunk)return true;$context.pendingMeshing={id,chunk,task:buildChunkTask(chunk,chunkLOD(chunk))}}
  const start=performance.now();do{const result=$context.pendingMeshing.task.next();if(result.done){$context.pendingMeshing=null;break}}while(performance.now()-start<3);
  if($context.suspendedMeshing){const task=$context.suspendedMeshing,start=performance.now();if(chunks.get(task.id)!==task.chunk)$context.suspendedMeshing=null;else do{if(task.task.next().done){$context.suspendedMeshing=null;break}}while(performance.now()-start<1)}
  return true;
}

function stream(){
    const {SIZE,buttonUntil,chunkLOD,chunks,editLightingQueue,ensureChunk,fireCells,firstMeshQueue,flowFalling,flowLevels,flowSources,flushChunkMesh,flushEditLighting,gateOutputs,gatePending,generateChunk,gravityQueued,growthCells,hopperAt,key,loading,meshRebuildQueue,observerUntil,pistonPowered,player,portalCells,queue,queued,redstoneCells,redstoneDoorPowered,redstoneEdge,scene,scheduleChunkMesh,sensorCells,sensorFrequency,sensorUntil,targetUntil,torchBurnedUntil,torchPending,torchStates,torchSwitches,tripwireUntil,urgentGravityQueued,urgentMeshQueue} = $context;

  const cx=Math.floor(player.x/SIZE),cz=Math.floor(player.z/SIZE),radius=$context.save.renderDistance,currentKey=$context.dimension+':'+cx+','+cz+':'+radius;
  const centerChanged=$context.streamKey!==currentKey;
  if(centerChanged){$context.streamKey=currentKey;$context.streamWanted=[];
    for(let dz=-radius;dz<=radius;dz++)for(let dx=-radius;dx<=radius;dx++)$context.streamWanted.push([cx+dx,cz+dz,dx*dx+dz*dz]);
    $context.streamWanted.sort((a,b)=>a[2]-b[2]);for(const [x,z] of $context.streamWanted)ensureChunk(x,z);queue.sort((a,b)=>(a[0]-cx)**2+(a[1]-cz)**2-((b[0]-cx)**2+(b[1]-cz)**2));
  }
  const wanted=$context.streamWanted;
  if(centerChanged){
    const evicted=new Set();
    for(const [id,chunk] of chunks){
      if(Math.abs(chunk.cx-cx)<=radius+1&&Math.abs(chunk.cz-cz)<=radius+1)continue;
      for(const mesh of chunk.meshes){scene.remove(mesh);mesh.geometry.dispose();}
      evicted.add(id);chunks.delete(id);firstMeshQueue.delete(id);meshRebuildQueue.delete(id);editLightingQueue.delete(id);
      if($context.pendingMeshing?.id===id)$context.pendingMeshing=null;if($context.pendingEditLighting?.chunk===chunk)$context.pendingEditLighting=null;
    }
    // Visit each runtime collection once, rather than once per evicted chunk.
    if(evicted.size){
      for(const collection of [portalCells,flowLevels,flowSources,flowFalling,redstoneCells,sensorCells,pistonPowered,redstoneDoorPowered,growthCells,fireCells,gravityQueued,urgentGravityQueued,buttonUntil,observerUntil,gateOutputs,gatePending,torchStates,torchPending,torchSwitches,torchBurnedUntil,redstoneEdge,sensorUntil,sensorFrequency,targetUntil,tripwireUntil,hopperAt]){
        for(const cell of collection.keys()){const x=parseInt(cell,10),z=Number(cell.slice(cell.lastIndexOf(',')+1));if(evicted.has(key(Math.floor(x/SIZE),Math.floor(z/SIZE))))collection.delete(cell);}
      }
      for(const [id,entry] of urgentMeshQueue)if(evicted.has(entry.id))urgentMeshQueue.delete(id);
    }
  }
  if($context.pendingGeneration&&(Math.abs($context.pendingGeneration.cx-cx)>radius+1||Math.abs($context.pendingGeneration.cz-cz)>radius+1||$context.pendingGeneration.dimension!==$context.dimension)){queued.delete(key($context.pendingGeneration.cx,$context.pendingGeneration.cz));$context.pendingGeneration=null}
  if(!$context.pendingGeneration)while(queue.length){const [x,z]=queue.shift(),k=key(x,z);if(chunks.has(k)||Math.abs(x-cx)>radius+1||Math.abs(z-cz)>radius+1){queued.delete(k);continue}$context.pendingGeneration={cx:x,cz:z,dimension: $context.dimension,task:generateChunk(x,z)};break}
  if(centerChanged||performance.now()-$context.lodCheckAt>100){$context.lodCheckAt=performance.now();for(const [x,z] of wanted){const chunk=chunks.get(key(x,z));if(chunk&&(chunkLOD(chunk)!==chunk.lod||!chunk.meshComplete&&!firstMeshQueue.has(key(x,z))&&$context.pendingMeshing?.chunk!==chunk&&$context.suspendedMeshing?.chunk!==chunk))scheduleChunkMesh(chunk,false)}}
  flushChunkMesh();if(!urgentMeshQueue.size&&!$context.pendingMeshing?.urgent)flushEditLighting();
  const start=performance.now();
  const generationBudget=loading.has('world')?8:3.5;
  while(performance.now()-start<generationBudget){
    if(!$context.pendingGeneration){while(queue.length){const [x,z]=queue.shift(),id=key(x,z);if(chunks.has(id)||Math.abs(x-cx)>radius+1||Math.abs(z-cz)>radius+1){queued.delete(id);continue;}$context.pendingGeneration={cx:x,cz:z,dimension: $context.dimension,task:generateChunk(x,z)};break;}if(!$context.pendingGeneration)break;}
    const result=$context.pendingGeneration.task.next();if(!result.done)continue;
    const {cx:x,cz:z}=$context.pendingGeneration;queued.delete(key(x,z));$context.pendingGeneration=null;scheduleChunkMesh(result.value);
    // A neighbor may have meshed while this chunk was only partly generated.
    // Rebuild all shared edges once this chunk's block data is complete.
    for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]])scheduleChunkMesh(chunks.get(key(x+dx,z+dz)),false);
  }
}
return {chunkLOD,patchModelBuffers,updateBlockModelImmediately,updateDoorModelImmediately,buildChunkTask,buildChunk,ensureChunk,scheduleChunkMesh,scheduleEditLighting,refreshEditedLighting,flushEditLighting,scheduleBlockMesh,flushChunkMesh,stream};
}
