/** weather subsystem. Dependencies are injected at composition time. */
export function createWeatherSystem($context) {
function drawWeather(dt){
    const {biome,player,rainCount,rainDrops,rainGeometry,rainLines,rainPositions,terrain,weatherCanvas,weatherCtx} = $context;

  const raining=$context.dimension==='overworld'&&$context.save.weather.kind!=='clear',snowing=raining&&biome(Math.floor(player.x),Math.floor(player.z))==='snow';
  rainLines.visible=raining;
  if(raining){
    rainLines.material.color.setHex(snowing?0xf1f7ff:0xb8d4e9);rainLines.material.opacity=snowing?.8:.58;
    for(let i=0;i<rainCount;i++){
      const drop=rainDrops[i];drop.y-=drop.speed*dt;
      if(drop.y<Math.max(player.y-12,drop.ground)||Math.abs(drop.x-player.x)>17||Math.abs(drop.z-player.z)>17){drop.x=player.x+(Math.random()-.5)*30;drop.z=player.z+(Math.random()-.5)*30;drop.y=player.y+4+Math.random()*15;drop.speed=(snowing?1.7:14)+Math.random()*(snowing?2:8);drop.ground=terrain(Math.floor(drop.x),Math.floor(drop.z))+.1}
      const ground=drop.ground,visible=drop.y>ground;
      const offset=i*6,tail=snowing?.12:.8;
      rainPositions[offset]=drop.x;rainPositions[offset+1]=visible?drop.y:-100;rainPositions[offset+2]=drop.z;
      rainPositions[offset+3]=drop.x+(snowing?.04:-.12);rainPositions[offset+4]=visible?Math.max(ground,drop.y-tail):-100;rainPositions[offset+5]=drop.z;
    }
    rainGeometry.attributes.position.needsUpdate=true;
  }
  if($context.lightningFlash>0){const w=innerWidth,h=innerHeight;if(weatherCanvas.width!==w||weatherCanvas.height!==h){weatherCanvas.width=w;weatherCanvas.height=h}weatherCtx.clearRect(0,0,w,h);weatherCtx.fillStyle=`rgba(245,251,255,${$context.lightningFlash*.6})`;weatherCtx.fillRect(0,0,w,h);$context.lightningFlash=Math.max(0,$context.lightningFlash-dt*3)}else if(weatherCanvas.width||weatherCanvas.height){weatherCtx.clearRect(0,0,weatherCanvas.width,weatherCanvas.height)}
}

function updateWeather(dt){
    const {AIR,FIRE,LIGHTNING_ROD,getBlock,player,processRedstone,redstoneCells,redstoneData,setBlock,showToast,survival,terrain} = $context;
if($context.dimension!=='overworld')return;if($context.save.gamerules.doWeatherCycle!==false)$context.save.weather.remaining-=dt;if($context.save.weather.remaining<=0){$context.save.weather.kind=$context.save.weather.kind==='clear'?(Math.random()<.25?'thunder':'rain'):'clear';$context.save.weather.remaining=$context.save.weather.kind==='clear'?360+Math.random()*550:110+Math.random()*210;$context.dirtySave=true;showToast($context.save.weather.kind==='clear'?'THE SKY CLEARED':$context.save.weather.kind==='thunder'?'THUNDERSTORM':'RAIN BEGINS')}
  if($context.save.weather.kind==='thunder'&&Math.random()<dt*.015){$context.lightningFlash=1;let x=Math.floor(player.x+(Math.random()-.5)*30),z=Math.floor(player.z+(Math.random()-.5)*30),y=terrain(x,z)+1;const rods=[...redstoneCells].filter(k=>{const [rx,ry,rz]=k.split(',').map(Number);return getBlock(rx,ry,rz)===LIGHTNING_ROD&&Math.hypot(rx-x,rz-z)<8&&ry>=y-2});if(rods.length){const k=rods[Math.floor(Math.random()*rods.length)];[x,y,z]=k.split(',').map(Number);const state=redstoneData()[k]??(redstoneData()[k]={});state.pulseUntil=performance.now()+400;processRedstone()}else if(getBlock(x,y,z)===AIR)setBlock(x,y,z,FIRE);if(Math.hypot(x-player.x,z-player.z)<4)survival.hurt(4,'STRUCK BY LIGHTNING')}
}

function overworldSky(phase){
    const {THREE,skyPalette,smooth} = $context;
for(let i=1;i<skyPalette.length;i++)if(phase<=skyPalette[i][0]){const [a,from]=skyPalette[i-1],[b,to]=skyPalette[i],t=smooth((phase-a)/(b-a));return new THREE.Color(from).lerp(new THREE.Color(to),t)}return new THREE.Color(skyPalette[0][1])}

function skyForDimension(target,x,z){
    const {NETHER_FOG,THREE,netherBiome,overworldSky} = $context;

  if(target==='nether')return new THREE.Color(NETHER_FOG[netherBiome(Math.floor(x),Math.floor(z))]);
  if(target==='end')return new THREE.Color(0x15111e);
  return overworldSky((($context.tick/(Math.PI*2))%1+1)%1);
}

function applyAtmosphere(worldScene,target,x,z,daylight,underground,underwater,hemisphere,directional){
    const {SIZE,THREE,skyForDimension} = $context;

  const sky=underwater?new THREE.Color(0x287092):skyForDimension(target,x,z);
  worldScene.background.copy(sky);
  worldScene.fog.color.copy(sky);
  worldScene.fog.near=underwater?3:target==='nether'?9:35;
  worldScene.fog.far=underwater?22:target==='nether'?Math.max(70,$context.save.renderDistance*SIZE+12):Math.max(86,$context.save.renderDistance*SIZE+24);
  hemisphere.intensity=target==='overworld'?( .18+daylight*.8)*(underground?.48:1):target==='nether'?.9:.42;
  directional.intensity=target==='overworld'?( .07+daylight*.95)*(underground?.25:1):.12;
  directional.position.set(Math.cos($context.tick)*45,Math.sin($context.tick)*50,25);
}
return {drawWeather,updateWeather,overworldSky,skyForDimension,applyAtmosphere};
}
