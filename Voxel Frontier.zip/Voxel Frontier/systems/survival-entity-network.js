/** survival entity network subsystem. Dependencies are injected at composition time. */
export function createSurvivalEntityNetworkSystem($context) {
function commandEntities(){
    const {Zt,dragonCrystals,oo} = $context;
return [...Zt.map(mob=>({id:mob.networkId||(mob.networkId='m'+crypto.randomUUID()),type:mob.type==='dragon'?'ender_dragon':mob.type,x:mob.x,y:mob.group.position.y,z:mob.z})),...oo.map(drop=>({id:drop.networkId||(drop.networkId='d'+crypto.randomUUID()),type:'item',x:drop.x,y:drop.y,z:drop.z})),...dragonCrystals.map(crystal=>({id:'crystal:'+crystal.index,type:'end_crystal',x:crystal.x,y:crystal.y,z:crystal.z}))];}

function killCommandEntity(id){
    const {Zt,destroyCrystal,dragonCrystals,oo,releaseEntity} = $context;
const index=Zt.findIndex(mob=>mob.networkId===id);if(index>=0){const mob=Zt[index];mob.health=0;if(mob.noAI){releaseEntity(mob.group);Zt.splice(index,1)}return true}const at=oo.findIndex(drop=>drop.networkId===id);if(at>=0){$context.t.remove(oo[at].mesh);oo.splice(at,1);return true}const crystal=dragonCrystals.find(c=>'crystal:'+c.index===id);if(crystal){destroyCrystal(crystal,true);return true}return false;}

function teleportCommandEntity(id,pos){
    const {Zt,dragonCrystals,oo} = $context;
if(![pos?.x,pos?.y,pos?.z].every(Number.isFinite))return false;const mob=Zt.find(item=>item.networkId===id);if(mob){mob.x=pos.x;mob.z=pos.z;mob.vx=mob.vy=mob.vz=0;mob.grounded=false;mob.path=[];mob.pathTimer=0;mob.group.position.set(pos.x,pos.y,pos.z);return true;}const drop=oo.find(item=>item.networkId===id);if(drop){drop.x=pos.x;drop.y=pos.y;drop.z=pos.z;drop.vx=drop.vy=drop.vz=0;drop.mesh.position.set(pos.x,pos.y,pos.z);return true;}const crystal=/^crystal:(\d+)$/.exec(id||'');if(crystal){const item=dragonCrystals.find(value=>value.index===Number(crystal[1]));if(item){item.x=pos.x;item.y=pos.y;item.z=pos.z;item.mesh.position.set(pos.x,pos.y,pos.z);return true;}}return false;}

function networkEntities(list=$context.Zt){return list.map(m=>({id:m.networkId||(m.networkId='m'+crypto.randomUUID()),type:m.type,x:m.x,y:m.group.position.y,z:m.z,dir:m.dir,health:m.health,noAI:!!m.noAI,aggro:m.aggro,provoked:m.provoked,vx:m.vx,vy:m.vy,vz:m.vz,walkPhase:m.walkPhase,animTime:m.animTime,dragonPhase:m.dragonPhase,dragonPhaseTime:m.dragonPhaseTime,grazeTime:m.grazeTime,lidOpen:m.lidOpen,sheared:!!m.sheared}))}

function syncNetworkEntities(list){
    const {Ga,Zt,releaseEntity,ts} = $context;
if(!Array.isArray(list)||list.length>200)return;const ids=new Set(),byId=new Map(Zt.map(mob=>[mob.networkId,mob]));for(const data of list){if(!Ga[data.type]||![data.x,data.y,data.z,data.dir,data.health].every(Number.isFinite))continue;ids.add(data.id);let mob=byId.get(data.id);if(!mob){mob=ts(data.type,data.x,data.z,data.y);if(!mob)continue;mob.networkId=data.id;byId.set(data.id,mob)}mob.x=data.x;mob.z=data.z;mob.dir=data.dir;mob.health=data.health;mob.noAI=!!data.noAI;mob.aggro=!!data.aggro;mob.provoked=!!data.provoked;for(const key of ['vx','vy','vz','walkPhase','animTime','dragonPhaseTime','grazeTime','lidOpen'])if(Number.isFinite(data[key]))mob[key]=data[key];if(typeof data.dragonPhase==='string')mob.dragonPhase=data.dragonPhase;mob.sheared=!!data.sheared;if(mob.fleece)mob.fleece.visible=!mob.sheared;mob.networkTarget={x:data.x,y:data.y,z:data.z,dir:data.dir};}for(let k=Zt.length-1;k>=0;k--)if(!ids.has(Zt[k].networkId)){releaseEntity(Zt[k].group);Zt.splice(k,1)}}

function networkDrops(list=$context.oo){return list.map(drop=>({networkId:drop.networkId||(drop.networkId='d'+crypto.randomUUID()),id:drop.id,n:drop.n,data:drop.data,x:drop.x,y:drop.y,z:drop.z}))}

function syncNetworkDrops(list){
    const {Yn,oo,r} = $context;
if(!Array.isArray(list)||list.length>1000)return;const ids=new Set(),byId=new Map(oo.map(drop=>[drop.networkId,drop]));for(const data of list){if(!r[data.id]||![data.x,data.y,data.z,data.n].every(Number.isFinite))continue;ids.add(data.networkId);let drop=byId.get(data.networkId);if(!drop){Yn(data.id,data.x,data.y,data.z,data.n,data.data,true);drop=oo.at(-1);drop.networkId=data.networkId;drop.networkDrop=true;byId.set(data.networkId,drop)}Object.assign(drop,{x:data.x,y:data.y,z:data.z,n:data.n});drop.mesh.position.set(data.x,data.y,data.z)}for(let j=oo.length-1;j>=0;j--)if(oo[j].networkDrop&&!ids.has(oo[j].networkId)){$context.t.remove(oo[j].mesh);oo.splice(j,1)}}

function networkCollect(id){
    const {oo} = $context;
const index=oo.findIndex(d=>d.networkId===id);if(index<0)return null;const drop=oo[index];$context.t.remove(drop.mesh);oo.splice(index,1);return {id:drop.id,n:drop.n,data:drop.data}}

function networkPickupRequests(){
    const {networkPickupQueue} = $context;
return networkPickupQueue.splice(0)}

function networkGrant(data){
    const {En,r} = $context;
if(r[data?.id]&&Number.isInteger(data.n)&&data.n>0&&data.n<=64){En(data.id,data.n,data.data);$context.m('pickup')}}

function networkHits(){
    const {networkAttackQueue} = $context;
return networkAttackQueue.splice(0)}

function networkHit(hit){
    const {Zt,damageMob,destroyCrystal,dragonCrystals,i} = $context;
if(Number.isInteger(hit?.crystal)&&i.getDimension()==='end'){const target=dragonCrystals.find(c=>c.index===hit.crystal);if(target&&[hit.x,hit.y,hit.z].every(Number.isFinite)&&Math.hypot(target.x-hit.x,target.y-hit.y,target.z-hit.z)<=96)destroyCrystal(target,true);return;}const mob=Zt.find(m=>m.networkId===hit?.id);if(!mob||!Number.isFinite(hit.damage)||!Number.isFinite(hit.x)||!Number.isFinite(hit.z)||Math.hypot(mob.x-hit.x,mob.z-hit.z)>(hit.projectile?96:4))return;damageMob(mob,Math.max(0,Math.min(30,hit.damage)),hit,Math.min(1.5,hit.knockback||1));}
return {commandEntities,killCommandEntity,teleportCommandEntity,networkEntities,syncNetworkEntities,networkDrops,syncNetworkDrops,networkCollect,networkPickupRequests,networkGrant,networkHits,networkHit};
}
