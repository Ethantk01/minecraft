import {isSuffocating} from '../suffocation.js';
import {itemIconURL} from '../item-icons.js';
/** survival entity effects subsystem. Dependencies are injected at composition time. */
export function createSurvivalEntityEffectsSystem($context) {
function refreshXP(items=$context.Xr){
    const {e,xpGeometry,xpMaterial} = $context;

    if(items.length>$context.xpCapacity){$context.t.remove($context.xpBatch);$context.xpBatch.dispose();while($context.xpCapacity<items.length)$context.xpCapacity*=2;$context.xpBatch=new e.InstancedMesh(xpGeometry,xpMaterial,$context.xpCapacity);$context.xpBatch.frustumCulled=false;$context.xpBatch.instanceMatrix.setUsage(e.DynamicDrawUsage);$context.t.add($context.xpBatch);}
    $context.xpBatch.count=items.length;for(let j=0;j<items.length;j++){const object=items[j].mesh;object.updateMatrix();$context.xpBatch.setMatrixAt(j,object.matrix);}if(items.length)$context.xpBatch.instanceMatrix.needsUpdate=true;
  }

async function prepareEffects(renderer,camera){
    const {Bp,De,Di,Ei,Fs,Gt,Hr,Ht,K,Ml,Mt,O,Pe,Wb,Wh,Xe,_,e,eo,gE,je,le,r,wl,xpGeometry,xpMaterial} = $context;

    const common=[_,Mt,Bp,Hr,De,K,le,O,Ml,je,Xe,gE,Wh,Gt,eo,Ht,Fs,Pe,Ei,Di,wl],materials=common.filter(id=>r[id]).map(Wb);
    await Promise.all(materials.map(material=>material.userData.ready));
    const preview=new e.Group();for(const material of materials)preview.add(new e.Sprite(material));preview.add(new e.InstancedMesh(xpGeometry,xpMaterial,1));
    const direction=new e.Vector3();camera.getWorldDirection(direction);preview.position.copy(camera.position).addScaledVector(direction,2);$context.t.add(preview);
    const previousTarget=renderer.getRenderTarget(),target=new e.WebGLRenderTarget(8,8);
    try{await renderer.compileAsync($context.t,camera);renderer.setRenderTarget(target);renderer.render($context.t,camera);renderer.getContext().finish()}finally{renderer.setRenderTarget(previousTarget);$context.t.remove(preview);target.dispose()}
  }

function Wb(f) {
    const {$p,Be,PI,e,i,itemWhiteTexture,qp,r} = $context;

    if (!qp.has(f)) {
      let b = new e.SpriteMaterial({ color: 16777215, map:itemWhiteTexture, transparent: true });
      qp.set(f, b);
      let R = r[f].icon, v = itemIconURL(r[f]);
      b.userData.ready=new Promise(resolve=>$p.load(v, (N) => {
        N.magFilter=e.NearestFilter;N.minFilter=e.NearestFilter;N.colorSpace=e.SRGBColorSpace;b.map=N;i.renderer?.initTexture(N);resolve();
      },void 0,()=>{b.color.setHex(r[f].color);resolve()}));
    }
    return qp.get(f);
  }

function La(f) {
    const {$h,Fp,Hh,Kh,Xh,Ys,Zh,af,jh,oa,of,qh,r,vi} = $context;

    if(Number.isInteger(r[f]?.stackSize))return Math.max(1,Math.min(64,r[f].stackSize));
    return vi[f] || [Hh, Kh, oa, of, af, Fp, Ys, Xh, Zh, jh, qh, $h].includes(f) ? 1 : 64;
  }

function Pl(f) {
    const {uf} = $context;

    let b = 0, R = Math.max(0, f);
    for (; R >= uf(b); ) R -= uf(b), b++;
    return { level: b, remaining: R, needed: uf(b) };
  }

function uf(f) {
    return f < 16 ? 2 * f + 7 : f < 31 ? 5 * f - 38 : 9 * f - 158;
  }

function Jb(f) {
    const {uf} = $context;

    let b = 0;
    for (let R = 0; R < f; R++) b += uf(R);
    return b;
  }

function hf(f) {
    const {I,Pl,a,ao} = $context;

    if (a.mode !== "survival" || f <= 0) return;
    let b = Pl(a.xp).level;
    a.xp += f, Pl(a.xp).level > b && $context.p(`LEVEL ${Pl(a.xp).level}`), I(), ao(false);
  }

function nm(f) {
    const {I,Jb,Pl,a,ao} = $context;

    let b = Pl(a.xp).level;
    return b < f && a.mode !== "creative" ? false : (a.mode !== "creative" && (a.xp = Jb(b - f)), I(), ao(false), true);
  }

function Yn(f, b, R, v, N = 1, V = null, remoteSync=false) {
    const {I,Wb,e,i,oo,r} = $context;

    if(i.isRemoteWorld?.()&&!remoteSync){i.networkDrop?.(f,b,R,v,N,V);return;}
    if (!r[f]) return;
    let L = new e.Sprite(Wb(f));
    L.scale.set(0.46, 0.46, 1), L.position.set(b, R, v), $context.t.add(L), oo.push({ id: f, n: N, data: V, x: b, y: R, z: v, vx: (Math.random() - 0.5) * 1.4, vy: 2 + Math.random(), vz: (Math.random() - 0.5) * 1.4, mesh: L, age: 0 }), I();
  }

function pf(f, b, R, v) {
    const {Xr,a,e,refreshXP,xpGeometry,xpMaterial} = $context;

    if (a.mode !== "survival") return;
    let N = new e.Mesh(xpGeometry,xpMaterial);
    N.position.set(f, b, R), Xr.push({ x: f, y: b, z: R, n: v, mesh: N, age: 0 });if($context.backgroundEntities)return;if(Xr.length>$context.xpCapacity)refreshXP();else{N.updateMatrix();$context.xpBatch.setMatrixAt(Xr.length-1,N.matrix);$context.xpBatch.count=Xr.length;$context.xpBatch.instanceMatrix.needsUpdate=true;}
  }

function qE(f) {
    const {A,En,S,a,i,networkPickupQueue,oo,r} = $context;

    let b = i.isSolidAt || ((R, v, N) => i.isSolid(A(R, v, N)));
    for (let R = oo.length - 1; R >= 0; R--) {
      let v = oo[R];
      if(i.isChunkLoaded&&!i.isChunkLoaded(v.x,v.z))continue;
      if(v.networkDrop){if(a.mode!=="spectator"&&Math.hypot(v.x-$context.n.x,v.y-$context.n.y-1,v.z-$context.n.z)<1.45&&!v.pickupPending){v.pickupPending=true;networkPickupQueue.push(v.networkId)}continue}
      v.age += f;
      let N = Math.floor(v.x), V = Math.floor(v.y), L = Math.floor(v.z), z = A(N, V, L) === S, H = z ? i.waterCurrent(N, V, L) : { x: 0, y: 0, z: 0 };
      v.vx = (v.vx + H.x * f * 2) * Math.exp(-f * (z ? 2 : 5)), v.vz = (v.vz + H.z * f * 2) * Math.exp(-f * (z ? 2 : 5)), v.vy = z ? Math.max(-2, Math.min(2, v.vy * 0.88 + (2 + H.y * 5) * f)) : Math.max(-24, v.vy - 25 * f);
      let q = Math.max(1, Math.ceil(Math.max(Math.abs(v.vx), Math.abs(v.vy), Math.abs(v.vz)) * f / 0.14));
      for (let Ye = 0; Ye < q; Ye++) {
        let Se = v.x + v.vx * f / q, ue = v.z + v.vz * f / q, qe = v.y + v.vy * f / q;
        b(Math.floor(Se), Math.floor(v.y), Math.floor(v.z)) ? v.vx = 0 : v.x = Se, b(Math.floor(v.x), Math.floor(v.y), Math.floor(ue)) ? v.vz = 0 : v.z = ue, b(Math.floor(v.x), Math.floor(qe - 0.2), Math.floor(v.z)) ? v.vy = 0 : v.y = qe;
      }
      v.mesh.position.set(v.x, v.y + Math.sin(v.age * 3) * 0.07, v.z);
      let Ue = Math.hypot(v.x - $context.n.x, v.y - $context.n.y - 1, v.z - $context.n.z);
      if (!$context.backgroundEntities && a.mode !== "spectator" && Ue < 1.45 && v.age > 0.25) {
        let Ye = En(v.id, v.n, v.data);
        v.n -= Ye, Ye && ($context.m('pickup'),$context.p(`PICKED UP ${Ye} ${r[v.id].name.toUpperCase()}`)), v.n || ($context.t.remove(v.mesh), oo.splice(R, 1));
      } else v.age > 180 && ($context.t.remove(v.mesh), oo.splice(R, 1));
    }
  }

function By(f) {
    const {Xr,a,hf,refreshXP} = $context;

    for (let b = Xr.length - 1; b >= 0; b--) {
      let R = Xr[b];
      R.age += f;
      let v = Math.hypot(R.x - $context.n.x, R.y - $context.n.y - 1, R.z - $context.n.z);
      if (v < 5) {
        let N = Math.min(1, f * 5 / (v + 0.3));
        R.x += ($context.n.x - R.x) * N, R.y += ($context.n.y + 1 - R.y) * N, R.z += ($context.n.z - R.z) * N;
      }
      R.mesh.position.set(R.x, R.y + Math.sin(R.age * 4) * 0.08, R.z), a.mode !== "spectator" && v < 0.55 && (hf(R.n),$context.m('xp'),$context.t.remove(R.mesh), Xr.splice(b, 1));
    }
    refreshXP();
  }

function addExhaustion(amount){
    const {a,exhaust} = $context;
if(a.mode==='survival'&&!$context.backgroundEntities)exhaust($context.n,amount);}

function ly(f) {
    const {An,I,a,ao,eatFood,foodValues,ht,mt,r} = $context;

    const values=foodValues(r[f]?.name||'');if(!values)return false;
    if($context.n.hunger<20&&mt(f)){eatFood($context.n,...values);if((f===ht||f===An)&&Math.random()<(f===ht?.8:.3))a.effects.hunger=30;$context.m('eat');$context.p(`ATE ${r[f].name.toUpperCase()}`);I();ao();}return true;
  }

function Uy(f, b) {
    const {A,By,En,Ey,Ga,Gc,I,Ie,KE,Q,S,Ty,VE,Zt,_y,a,addExhaustion,ao,dragonCrystals,e,ensureDragonCrystals,foodTick,fr,i,jE,kc,qE,r,tickCombat,updateDragonBreathClouds,xi,xy} = $context;

    if (!i.isPlaying()) return;
    if(i.isRemoteWorld?.())for(const mob of Zt){const target=mob.networkTarget;if(target){mob.group.position.lerp(new e.Vector3(target.x,target.y,target.z),1-Math.exp(-f*15));mob.group.rotation.y=-target.dir-Math.PI/2;if(!mob.noAI){mob.walkPhase+=f*Ga[mob.type].speed*7;Ty(mob,f);}}}
    if(i.isRemoteWorld?.())for(const mob of Zt){mob.attack-=f;if(mob.definition.meleeRange&&mob.aggro&&mob.attack<=0&&Math.hypot(mob.x-$context.n.x,mob.z-$context.n.z)<mob.definition.meleeRange&&fr(mob)){xi(Ga[mob.type].damage,`ATTACKED BY A ${mob.type.toUpperCase()}`,mob);mob.attack=mob.definition.attackCooldown||1;}}
    tickCombat(f);
    $context.cf = b, $context.Yo = Math.max(0, $context.Yo - f), ensureDragonCrystals(), _y(f), Ey(f), (i.isRemoteWorld?.() ? void 0 : jE(f)), xy(f), KE(f), updateDragonBreathClouds(f), qE(f), By(f), $context.hr && ($context.hr.wait -= f, $context.hr.wait <= 0 && !$context.hr.ready && ($context.hr.ready = true, $context.p("A FISH BITES! RIGHT CLICK TO REEL IN")));
    for(const crystal of dragonCrystals)crystal.mesh.rotation.y+=f*.8;
    const boss=document.getElementById('dragonBoss'),dragon=Zt.find(mob=>mob.type==='dragon');
    if(boss){boss.hidden=i.getDimension()!=='end'||!dragon;if(dragon)document.getElementById('dragonBossHealth').style.width=`${Math.max(0,Math.min(100,dragon.health/Ga.dragon.health*100))}%`}
    for (let L of Object.keys(a.effects)) a.effects[L] -= f, a.effects[L] <= 0 && delete a.effects[L];
    a.effects.poison && $context.Yo <= 0 && xi(1, "POISONED"), a.effects.burning && $context.Yo <= 0 && xi(1, "BURNING"), a.effects.levitation && ($context.n.vy = Math.max($context.n.vy, 2.5));
    for (let L of Object.keys(a.furnaceFuel)) a.furnaceFuel[L] = Math.max(0, a.furnaceFuel[L] - f);
    for (let [L, z] of Object.entries(a.furnaceJobs)) if (!((a.furnaceFuel[L] || 0) <= 0) && (z.left -= f, z.left <= 0)) {
      let H = a.furnaceOutputs[L];
      H?.id === z.out ? H.n++ : a.furnaceOutputs[L] = { id: z.out, n: 1 }, delete a.furnaceJobs[L], I(), $context.p(`SMELTED ${r[z.out].name.toUpperCase()}`);
    }
    for (let [L, z] of Object.entries(a.brewJobs)) z.left -= f, z.left <= 0 && (En(z.out), delete a.brewJobs[L], $context.p(`BREWED ${r[z.out].name.toUpperCase()}`));
    if ($context.Jr && ["brew", "furnace"].includes($context.ci?.kind) && VE(), a.mode === "spectator") return;
    if(a.mode==='survival'){
      if(a.effects.hunger)addExhaustion(f*.1);
      $context.foodAccumulator+=f;while($context.foodAccumulator>=.05){$context.foodAccumulator-=.05;const before=[$context.n.hunger,$context.n.saturation,$context.n.exhaustion,$context.n.health,$context.n.foodTimer];if(foodTick($context.n,{difficulty:a.difficulty||'normal',naturalRegeneration:a.gamerules?.naturalRegeneration!==false}))xi(1,'STARVING');if(before.some((v,k)=>v!==[$context.n.hunger,$context.n.saturation,$context.n.exhaustion,$context.n.health,$context.n.foodTimer][k])){I();ao(false);}}
    }
     a.effects.regeneration && $context.n.health < 20 && ($context.n.health = Math.min(20, $context.n.health + f * 0.6), ao(false));
    let R = Math.floor($context.n.x), v = Math.floor($context.n.z), N = A(R, Math.floor($context.n.y + 1.55), v), V = A(R, Math.floor($context.n.y + 0.5), v);
    if(a.mode==='survival'&&isSuffocating($context.n,i.suffocatingAt)&&$context.Yo<=0)xi(1,'SUFFOCATING');
    if(a.mode==='survival'&&(N===Q||V===Q||N===Ie||V===Ie))$context.n.fireTime=Math.max($context.n.fireTime||0,N===Q||V===Q?15:8);
    if(a.mode!=='survival'||N===S||V===S||i.isRaining?.($context.n.x,$context.n.z))$context.n.fireTime=0;else $context.n.fireTime=Math.max(0,($context.n.fireTime||0)-f);
    $context.n.burnTick=($context.n.burnTick||0)+f;if($context.n.fireTime>0&&$context.n.burnTick>=1){$context.n.burnTick=0;if(N!==Q&&V!==Q&&$context.Yo<=0)xi(1,'ON FIRE');}
    (N === Q || V === Q) && $context.Yo <= 0 ? xi(4, "BURNED BY LAVA") : (N === Ie || V === Ie) && $context.Yo <= 0 && xi(2, "CAUGHT FIRE"), N === S && !$context.n.flight ? ($context.zc += f, $context.n.air = Math.max(0, 20 - $context.zc), $context.n.air <= 0 && $context.Yo <= 0 && xi(2, "DROWNING")) : ($context.zc = Math.max(0, $context.zc - f * 4), $context.n.air = 20 - $context.zc), (N === S || $context.n.air < 20) && ao(false), $context.gf = V === kc || N === kc ? Math.min(12, $context.gf + f) : Math.max(0, $context.gf - f * 2), $context.gf > 7 && a.armor?.boots !== Gc && $context.Yo <= 0 && xi(1, "FREEZING");
  }
return {refreshXP,prepareEffects,Wb,La,Pl,uf,Jb,hf,nm,Yn,pf,qE,By,addExhaustion,ly,Uy};
}
