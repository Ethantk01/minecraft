/** survival entity dimensions subsystem. Dependencies are injected at composition time. */
export function createSurvivalEntityDimensionsSystem($context) {
function entityObjects(record){
    const {entityObject} = $context;
const objects=[];for(const [kind,list] of Object.entries(record))if(Array.isArray(list)&&kind!=='xp')for(const entity of list)objects.push(entityObject(kind,entity));return objects;}

function activeEntityRecord(){
    const {entityArrays} = $context;
return {...entityArrays(),spawnTimer:$context.Xp,extraSpawnTimer:$context.dm};}

function parkDimension(){
    const {entityArrays,entityDimensions,entityObjects} = $context;

    const record={spawnTimer:$context.Xp,extraSpawnTimer:$context.dm};for(const [kind,list] of Object.entries(entityArrays())){record[kind]=list.splice(0);}
    for(const object of entityObjects(record))object.removeFromParent();$context.xpBatch.count=0;entityDimensions.set($context.activeEntityDimension,record);
  }

function restoreEntitySave(dim){
    const {Ga,Xr,Yn,a,e,i,oo,r,ts,xpGeometry,xpMaterial} = $context;

    const stored=a.entityStates?.[dim];if(!stored)return;
    for(const data of (stored.mobs||[]).slice(0,128)){
      if(!Ga[data.type]||![data.x,data.y,data.z].every(Number.isFinite)||data.type==='dragon'&&a.dragonDefeated)continue;
      const mob=ts(data.type,data.x,data.z,data.y);if(!mob)continue;
      for(const [key,value] of Object.entries(data.state||{}))if(!['__proto__','constructor','prototype','group','parts','joints','wings','rods','fleece'].includes(key))mob[key]=value;
      if(data.scale)mob.group.scale.fromArray(data.scale);if(data.rotation)mob.group.rotation.fromArray(data.rotation);
      if(mob.fleece)mob.fleece.visible=!mob.sheared;
    }
    for(const data of (stored.drops||[]).slice(0,2000)){if(!r[data.id]||![data.x,data.y,data.z,data.n].every(Number.isFinite))continue;Yn(data.id,data.x,data.y,data.z,data.n,data.data,true);Object.assign(oo.at(-1),{vx:data.vx||0,vy:data.vy||0,vz:data.vz||0,age:data.age||0,pickupDelay:Math.max(0,Math.min(2,Number(data.pickupDelay)||0)),networkId:data.networkId,networkDrop:!!i.isRemoteWorld?.()});}
    for(const data of (stored.xp||[]).slice(0,1024))if([data.x,data.y,data.z,data.n].every(Number.isFinite)){const mesh=new e.Mesh(xpGeometry,xpMaterial);mesh.position.set(data.x,data.y,data.z);Xr.push({...data,mesh});}
  }

function activateDimension(dim){
    const {activeEntityRecord,entityArrays,entityDimensions,entityObjects,refreshXP,restoreEntitySave} = $context;

    $context.activeEntityDimension=dim;const record=entityDimensions.get(dim);entityDimensions.delete(dim);
    if(record){for(const [kind,list] of Object.entries(entityArrays()))list.push(...record[kind]);$context.Xp=record.spawnTimer;$context.dm=record.extraSpawnTimer;}else restoreEntitySave(dim);
    for(const object of entityObjects(activeEntityRecord()))$context.t.add(object);refreshXP();
  }

function prepareDimension(dim){
    const {Zt,a,activateDimension,d,ensureDragonCrystals,entityDimensions,parkDimension,ts} = $context;

    if(dim===$context.activeEntityDimension||entityDimensions.has(dim))return;
    const previous=$context.activeEntityDimension;parkDimension();activateDimension(dim);
    if(dim==='end'){$context._y(0);ensureDragonCrystals();if(!a.dragonDefeated&&!Zt.some(mob=>mob.type==='dragon'))ts('dragon',.5,7.5,d(0,0)+13);}
    parkDimension();activateDimension(previous);
  }

function renderDimension(dim,destination,render){
    const {activeEntityRecord,entityDimensions,entityObjects,refreshXP} = $context;

    const record=dim===$context.activeEntityDimension?activeEntityRecord():entityDimensions.get(dim);if(!record)return render();
    const objects=entityObjects(record),parents=objects.map(object=>object.parent),xpParent=$context.xpBatch.parent;
    try{for(const object of objects)destination.add(object);refreshXP(record.xp);destination.add($context.xpBatch);return render();}
    finally{objects.forEach((object,index)=>parents[index]?parents[index].add(object):object.removeFromParent());if(xpParent)xpParent.add($context.xpBatch);else $context.xpBatch.removeFromParent();refreshXP();}
  }

function simulateDimension(dim,dt,daylight,runContext){
    const {KE,Xr,a,dragonCrystals,e,ensureDragonCrystals,entityArrays,entityDimensions,entityObjects,jE,qE,updateDragonBreathClouds,xy} = $context;

    const record=entityDimensions.get(dim);if(!record||dim===$context.activeEntityDimension)return;
    const arrays=entityArrays(),current={};for(const [kind,list] of Object.entries(arrays)){current[kind]=list.splice(0);list.push(...record[kind]);}
    const previous={n: $context.n,t: $context.t,m: $context.m,p: $context.p,cf: $context.cf};$context.backgroundEntities=true;
    $context.n={...$context.n,x:1e8,z:1e8,y:a.positions?.[dim]?.y||0};
    $context.t=record.simulationScene ||= new e.Scene();$context.m=()=>{};$context.p=()=>{};
    for(const object of entityObjects(record))$context.t.add(object);
    try{runContext(()=>{
      $context.cf=daylight;ensureDragonCrystals();jE(dt);xy(dt);KE(dt);updateDragonBreathClouds(dt);qE(dt);
      for(const orb of Xr){orb.age+=dt;orb.mesh.position.set(orb.x,orb.y+Math.sin(orb.age*4)*.08,orb.z);}
      for(const crystal of dragonCrystals)crystal.mesh.rotation.y+=dt*.8;
    });}finally{
      for(const [kind,list] of Object.entries(arrays)){record[kind]=list.splice(0);list.push(...current[kind]);}
      ({n: $context.n,t: $context.t,m: $context.m,p: $context.p,cf: $context.cf}=previous);$context.backgroundEntities=false;
    }
  }

function dimensionIds(){
    const {entityDimensions} = $context;
return [...entityDimensions.keys()];}

function entityPositions(dim=$context.activeEntityDimension){
    const {activeEntityRecord,entityDimensions} = $context;
const record=dim===$context.activeEntityDimension?activeEntityRecord():entityDimensions.get(dim);return record?[...record.mobs.map(mob=>[mob.x,mob.z]),...record.drops.map(drop=>[drop.x,drop.z])]:[];}

function mobStates(dim=$context.activeEntityDimension){
    const {Zt,entityDimensions} = $context;
return [...(dim===$context.activeEntityDimension?Zt:entityDimensions.get(dim)?.mobs||[])];}

function transferMob(mob,source,target,arrival){
    const {I,Zt,e,entityDimensions,prepareDimension} = $context;

    prepareDimension(target);
    const sourceList=source===$context.activeEntityDimension?Zt:entityDimensions.get(source)?.mobs,targetRecord=target===$context.activeEntityDimension?null:entityDimensions.get(target),targetList=targetRecord?.mobs||Zt;
    const index=sourceList?.indexOf(mob)??-1;if(index<0)return false;sourceList.splice(index,1);targetList.push(mob);
    mob.x=arrival.x;mob.z=arrival.z;mob.group.position.set(arrival.x,arrival.y,arrival.z);mob.homeY=arrival.y;mob.dir=arrival.dir;mob.vx=arrival.vx;mob.vz=arrival.vz;mob.path=[];mob.pathTimer=0;mob.portalCooldown=15;
    mob.group.removeFromParent();if(target===$context.activeEntityDimension)$context.t.add(mob.group);else{targetRecord.simulationScene??=new e.Scene();targetRecord.simulationScene.add(mob.group);}I();return true;
  }

function dimensionSnapshots(){
    const {activeEntityRecord,entityDimensions,networkDrops,networkEntities} = $context;
const records=new Map(entityDimensions);records.set($context.activeEntityDimension,activeEntityRecord());return [...records].map(([dimension,record])=>({dimension,entities:networkEntities(record.mobs),drops:networkDrops(record.drops)}));}

function inStoredEntities(dim,fn){
    const {e,entityArrays,entityDimensions,entityObjects,prepareDimension} = $context;

    if(!['overworld','nether','end'].includes(dim))return;
    if(dim===$context.activeEntityDimension)return fn();
    prepareDimension(dim);const record=entityDimensions.get(dim),arrays=entityArrays(),current={};
    for(const [key,items] of Object.entries(arrays)){current[key]=items.splice(0);items.push(...record[key]);}
    const previousScene=$context.t;$context.t=record.simulationScene ||= new e.Scene();
    for(const object of entityObjects(record))$context.t.add(object);
    try{return fn();}
    finally{for(const [key,items] of Object.entries(arrays)){record[key]=items.splice(0);items.push(...current[key]);}$context.t=previousScene;}
  }

function syncStoredDimension(dim,kind,list){
    const {Ga,Ty,Zt,inStoredEntities,syncNetworkDrops,syncNetworkEntities} = $context;

    return inStoredEntities(dim,()=>{if(kind==='mobs'){syncNetworkEntities(list);if(dim!==$context.activeEntityDimension)for(const mob of Zt)if(mob.networkTarget){const target=mob.networkTarget;mob.group.position.set(target.x,target.y,target.z);mob.group.rotation.y=-target.dir-Math.PI/2;if(!mob.noAI){mob.walkPhase+=.1*Ga[mob.type].speed*7;Ty(mob,.1);}}}else syncNetworkDrops(list);});
  }

function serializeEntities(){
    const {a,activeEntityRecord,entityDimensions} = $context;

    const states={};const records=new Map(entityDimensions);records.set($context.activeEntityDimension,activeEntityRecord());
    for(const [dim,record] of records){states[dim]={mobs:record.mobs.map(mob=>{
      mob.networkId ||= 'm'+crypto.randomUUID();
      const state={};for(const [key,value] of Object.entries(mob))if(value===null||['number','string','boolean'].includes(typeof value))state[key]=value;
      return {type:mob.type,x:mob.x,y:mob.group.position.y,z:mob.z,scale:mob.group.scale.toArray(),rotation:mob.group.rotation.toArray(),state};
    }),drops:record.drops.map(drop=>{drop.networkId ||= 'd'+crypto.randomUUID();const {id,n,data,x,y,z,vx,vy,vz,age,pickupDelay,networkId}=drop;return {id,n,data,x,y,z,vx,vy,vz,age,pickupDelay,networkId};}),xp:record.xp.map(({x,y,z,n,age})=>({x,y,z,n,age}))};}
    a.entityStates=states;return states;
  }
return {entityObjects,activeEntityRecord,parkDimension,restoreEntitySave,activateDimension,prepareDimension,renderDimension,simulateDimension,dimensionIds,entityPositions,mobStates,transferMob,dimensionSnapshots,inStoredEntities,syncStoredDimension,serializeEntities};
}
