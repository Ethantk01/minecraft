import {sweepActorAxis,applyGravity,applyFluidVertical,fallDamage,approachesActor} from '../actor-physics.js';
/** survival entity physics subsystem. Dependencies are injected at composition time. */
export function createSurvivalEntityPhysicsSystem($context) {
function xy(f) {
    const {Fl,Zt,fr,xi} = $context;

    for (let b of Zt) {
      b.breedCooldown = Math.max(0, (b.breedCooldown || 0) - f), b.love = Math.max(0, (b.love || 0) - f), b.babyAge && (b.babyAge -= f, b.babyAge <= 0 && b.group.scale.setScalar(1));
      let R = Math.hypot(b.x - $context.n.x, b.z - $context.n.z);
      if(b.noAI)continue;
      const definition=b.definition, ranged=definition.ranged, contact=definition.contactAttack;
      if(ranged && R<ranged.range && b.attack<=0 && fr(b)){Fl(b,ranged.projectile);b.attack=ranged.cooldown;}
      if(contact && b.aggro && R<contact.range && b.attack<=0 && fr(b)){xi(contact.damage,contact.message,b);b.attack=contact.cooldown;}

    }
  }

function Yc(f) {
    const b=f.babyAge?.55:1, {radius:v=.3,height:N=2.05}=f.definition?.collider||{};
    return { radius: v * b, height: N * b };
  }

function dragonBodyClearance(mob,x,y,z){
    const {e} = $context;

    const body=mob.parts?.get('body')?.[0]?.pivot?.children.find(child=>child.isMesh);
    if(!body)return Infinity;
    if(!body.geometry.boundingBox)body.geometry.computeBoundingBox();body.updateWorldMatrix(true,false);
    const inverse=new e.Matrix4().copy(body.matrixWorld).invert();
    const feet=new e.Vector3(x,y+.05,z).applyMatrix4(inverse),head=new e.Vector3(x,y+1.7,z).applyMatrix4(inverse);
    const bounds=body.geometry.boundingBox,radius=.29/mob.group.scale.x;
    if(Math.max(feet.y,head.y)<bounds.min.y||Math.min(feet.y,head.y)>bounds.max.y)return Infinity;
    const minX=bounds.min.x-radius,maxX=bounds.max.x+radius,minZ=bounds.min.z-radius,maxZ=bounds.max.z+radius;
    const dx=Math.max(minX-feet.x,0,feet.x-maxX),dz=Math.max(minZ-feet.z,0,feet.z-maxZ);
    return dx||dz?Math.hypot(dx,dz):-Math.min(feet.x-minX,maxX-feet.x,feet.z-minZ,maxZ-feet.z);
  }

function wy(f, b, R) {
    const {Yc,Zt,a,dragonBodyClearance} = $context;

    if (a.mode === "spectator") return false;
    for (let v of Zt) {
      if(v.type==='dragon'&&v.parts?.has('body')){
        const next=dragonBodyClearance(v,f,b,R);
        if(next<0&&next<dragonBodyClearance(v,$context.n.x,$context.n.y,$context.n.z)-1e-5)return true;
        continue;
      }
      if(approachesActor($context.n,f,b,R,v,undefined,Yc(v)))return true;
    }
    return false;
  }

function WE(f, b, R) {
    const {Zt} = $context;

    return Zt.some((v) => Math.abs(v.x - f - 0.5) < 0.48 && Math.abs(v.z - R - 0.5) < 0.48 && Math.abs(v.group.position.y - (b + 0.0625)) < 0.35);
  }

function My(f, b, R) {
    const {WE,oo} = $context;

    let v = WE(f, b, R) ? 1 : 0;
    for (let N of oo) Math.abs(N.x - f - 0.5) < 0.48 && Math.abs(N.z - R - 0.5) < 0.48 && Math.abs(N.y - (b + 0.15)) < 0.4 && v++;
    return v;
  }

function by(f, b, R, v) {
    const {I,oo} = $context;

    for (let N = oo.length - 1; N >= 0; N--) {
      let V = oo[N];
      if (Math.abs(V.x - f - 0.5) > 0.55 || Math.abs(V.z - R - 0.5) > 0.55 || V.y < b + 0.55 || V.y > b + 1.5) continue;
      let L = v.find((H) => H?.id === V.id && H.n < 64), z = L ? null : v.findIndex((H) => !H);
      if (!(!L && z < 0)) return L ? L.n++ : v[z] = { id: V.id, n: 1 }, V.n--, V.n <= 0 && ($context.t.remove(V.mesh), oo.splice(N, 1)), I(), true;
    }
    return false;
  }

const actorSweeps=new WeakMap();
function Vl(actor,axis,delta){
  if(!actorSweeps.has(actor)){
    const {JE,Sy}=$context;
    actorSweeps.set(actor,{
      collides:(x,y,z,axis)=>JE(actor,x,y,z)||axis!=='y'&&Sy(actor,x,y,z),
      sync:axis=>actor.group.position[axis]=actor[axis],
      onBlocked(axis,step){
        if(axis==='y'){if(step<0)actor.grounded=true;actor.vy=0;}
        else {actor[axis==='x'?'vx':'vz']=0;if(actor.grounded&&actor.definition?.canStep!==false&&!JE(actor,actor.x,actor.y+1,actor.z)){actor.vy=Math.max(actor.vy,7.5);actor.grounded=false;}actor.pathTimer=0;}
      }
    });
  }
  return sweepActorAxis(actor,axis,delta,actorSweeps.get(actor));
}


function um(f, b, R, v) {
    const {A,S,Vl,i} = $context;

    let N = Math.floor(f.group.position.y + 0.7), V = A(Math.floor(f.x), N, Math.floor(f.z)) === S, L = V ? i.waterCurrent(Math.floor(f.x), N, Math.floor(f.z)) : { x: 0, y: 0, z: 0 }, z = Math.min(1, v * (f.grounded ? 7 : V ? 3 : 2));
    f.hitStun = Math.max(0, (f.hitStun || 0) - v), f.hitStun > 0 && (b = 0, R = 0), f.vx += (b + L.x * 1.6 - f.vx) * z, f.vz += (R + L.z * 1.6 - f.vz) * z, V ? applyFluidVertical(f,v,{lift:2.5,currentY:L.y,max:4.5}) : applyGravity(f,v);
    let H = f.vy;
    Vl(f, "x", f.vx * v), Vl(f, "z", f.vz * v), f.grounded = false, Vl(f, "y", f.vy * v), f.grounded && H < -13 && (f.health -= fallDamage(H)), f.group.position.y < (i.getDimension() === "overworld" ? -68 : -5) && (f.health = 0);
  }

function XE(f, b, R, v, N) {
    const {Vl} = $context;

    let V = Math.min(1, N * 2.4);
    f.vx += (b - f.vx) * V, f.vz += (R - f.vz) * V, f.vy = Math.max(-5, Math.min(5, f.vy + (v - f.group.position.y) * N * 3)), f.vy *= Math.exp(-N * 0.9), f.definition?.terrainCollision===false ? (f.x += f.vx * N, f.z += f.vz * N, f.group.position.set(f.x, f.group.position.y + f.vy * N, f.z)) : (Vl(f, "x", f.vx * N), Vl(f, "z", f.vz * N), Vl(f, "y", f.vy * N));
  }

function fr(f) {
    const {A,a,i} = $context;

    if($context.backgroundEntities)return false;
    if (a.mode === "spectator") return false;
    let b = f.group.position.y + (f.definition?.eyeHeight||1.5), R = $context.n.x - f.x, v = $context.n.y + 1.5 - b, N = $context.n.z - f.z, V = Math.ceil(Math.hypot(R, v, N) * 2);
    for (let L = 1; L < V; L++) {
      let z = L / V, H = Math.floor(f.x + R * z), q = Math.floor(b + v * z), Ue = Math.floor(f.z + N * z);
      if (i.isSolid(A(H, q, Ue))) return false;
    }
    return true;
  }

function hm(f) {
    const {A,i} = $context;

    if(i.skyExposed)return i.skyExposed(Math.floor(f.x),Math.floor(f.group.position.y+2),Math.floor(f.z));
    let b = Math.floor(f.x), R = Math.floor(f.z);
    for (let v = Math.floor(f.group.position.y + 2); v < 320; v++) if (i.isSolid(A(b, v, R))) return false;
    return true;
  }

function Hc(f) {
    const {A,Q,S,ZE,i} = $context;

    for (let b = 0; b < 32; b++) {
      let R = Math.random() * Math.PI * 2, v = 3 + Math.random() * 21, N = f.x + Math.cos(R) * v, V = f.z + Math.sin(R) * v, L = ZE(N, V, f.group.position.y);
      if (L === null) continue;
      let z = Math.floor(N), H = Math.floor(L), q = Math.floor(V);
      if (![0, 1, 2].some((Ue) => A(z, H + Ue, q) === S || A(z, H + Ue, q) === Q || i.isSolid(A(z, H + Ue, q)))) return f.x = N, f.z = V, f.vx = 0, f.vy = 0, f.vz = 0, f.grounded = false, f.group.position.set(N, L, V), f.path.length = 0, f.pathTimer = 0, $context.m('enderman_teleport'),true;
    }
    return false;
  }
return {xy,Yc,dragonBodyClearance,wy,WE,My,by,Vl,um,XE,fr,hm,Hc};
}
