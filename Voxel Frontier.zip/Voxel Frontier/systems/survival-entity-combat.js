import {entityDrops} from '../entity-registry.js';
import {applyKnockback} from '../actor-physics.js';
/** survival entity combat subsystem. Dependencies are injected at composition time. */
export function createSurvivalEntityCombatSystem($context) {
function damageMob(mob,amount,origin=null,knockback=1){
    const {Ga,YE,Yn,Zt,acceptDamage,armorDamage,i,pf,releaseEntity} = $context;

    const custom=mob.definition?.onDamage?.(mob,amount,origin);if(custom===false)return false;if(Number.isFinite(custom))amount=custom;
    const repeated=(mob.hurtRemaining||0)>.5;const damage=acceptDamage(mob,amount);if(!damage)return false;
    const adjusted=mob.type==='dragon'&&!/head|jaw/.test(origin?.part||mob.hitPart||'')?damage/4+Math.min(damage,1):damage;
    mob.health-=armorDamage(adjusted,mob.type==='shulker'&&!(mob.lidOpen>0)?20:Ga[mob.type].armor||0);
    if(origin&&!repeated)YE(mob,origin.x,origin.z,knockback);
    mob.aggro=!!Ga[mob.type].hostile;mob.provoked=true;
    if(!Ga[mob.type].hostile){mob.flee=5;mob.panicOrigin=origin?{x:origin.x,z:origin.z}:null;mob.path=[];mob.pathTimer=0;if(origin)mob.dir=Math.atan2(mob.z-origin.z,mob.x-origin.x);}
    $context.m(`${mob.type}_hurt`);
    if(mob.health<=0){const data=Ga[mob.type];$context.m(`${mob.type}_death`);if(mob.type==='dragon')i.onDragonDefeated?.();else for(const drop of entityDrops(mob))Yn(drop.id,mob.x,mob.group.position.y+.6,mob.z,drop.n);pf(mob.x,mob.group.position.y+.7,mob.z,mob.type==='dragon'?100:['cow','sheep'].includes(mob.type)?1+Math.floor(Math.random()*3):5);releaseEntity(mob.group);Zt.splice(Zt.indexOf(mob),1);}
    return true;
  }

function Qc(f, b, R, power=4, excluded=null) {
    const {A,E,Yc,Zt,blockProperty,damageMob,g,i,xi} = $context;

    const affected = /* @__PURE__ */ new Set(), ox = f + 0.5, oy2 = b + 0.5, oz = R + 0.5;
    for (let ix = 0; ix < 16; ix++) for (let iy2 = 0; iy2 < 16; iy2++) for (let iz = 0; iz < 16; iz++) {
      if (ix !== 0 && ix !== 15 && iy2 !== 0 && iy2 !== 15 && iz !== 0 && iz !== 15) continue;
      let dx = ix / 15 * 2 - 1, dy2 = iy2 / 15 * 2 - 1, dz = iz / 15 * 2 - 1, length = Math.hypot(dx, dy2, dz);
      dx /= length;
      dy2 /= length;
      dz /= length;
      let strength = power * (0.7 + Math.random() * 0.6), x2 = ox, y2 = oy2, z = oz;
      while (strength > 0) {
        let bx = Math.floor(x2), by2 = Math.floor(y2), bz = Math.floor(z), id = A(bx, by2, bz);
        if (id !== E) strength -= (blockProperty(id).resistance + 0.3) * 0.3;
        if (strength > 0 && id !== E) affected.add(`${bx},${by2},${bz}`);
        x2 += dx * 0.3;
        y2 += dy2 * 0.3;
        z += dz * 0.3;
        strength -= 0.225;
      }
    }
    const changed = [];
    for (const key of affected) {
      let [x2, y2, z] = key.split(",").map(Number);
      changed.push([x2, y2, z, E]);
    }
    // Sample exposure before removing cover. Explosion range is twice power.
    const damageAt=(x,y,z,radius,height)=>{
      const distance=Math.hypot(x-ox,y+height*.5-oy2,z-oz)/(power*2);if(distance>1)return 0;
      let clear=0,total=0;
      for(const dx of [-radius,0,radius])for(const dy of [.1,height*.5,height-.1])for(const dz of [-radius,0,radius]){
        total++;const length=Math.hypot(x+dx-ox,y+dy-oy2,z+dz-oz);let blocked=false;
        for(let step=.3;step<length;step+=.3){const t=step/length;if(i.isSolid(A(Math.floor(ox+(x+dx-ox)*t),Math.floor(oy2+(y+dy-oy2)*t),Math.floor(oz+(z+dz-oz)*t)))){blocked=true;break;}}
        if(!blocked)clear++;
      }
      const impact=(1-distance)*clear/total;return Math.floor((impact*impact+impact)*.5*7*(power*2)+1);
    };
    xi(damageAt($context.n.x,$context.n.y,$context.n.z,.3,1.8),'EXPLOSION',{x:ox,z:oz});
    for(const mob of [...Zt])if(mob!==excluded){const shape=Yc(mob);damageMob(mob,damageAt(mob.x,mob.group.position.y,mob.z,shape.radius,shape.height),{x:ox,z:oz},1.5);}
    g(changed);
    $context.p("BOOM!");
    $context.m('explosion');
  }

function xi(f, b, R = null) {
    const {Hn,I,Ni,Yn,a,acceptDamage,addExhaustion,ao,e,equipmentValues,i,o,playerDamageState,r} = $context;

    if ($context.backgroundEntities || a.mode === "creative" || a.mode === "spectator") return;
    if(/POISON/.test(b))f=Math.min(f,Math.max(0,$context.n.health-1));
    if(R&&!/POTION|BREATH|POISON/.test(b)&&i.isBlocking?.()&&$context.shieldHeld>=.25&&$context.shieldDisabled<=0&&(Hn()===Ni||a.armor?.offhand===Ni)){
      const toward=new e.Vector3(R.x-$context.n.x,0,R.z-$context.n.z).normalize(),forward=new e.Vector3();o.getWorldDirection(forward);forward.y=0;forward.normalize();
      if(forward.dot(toward)>0){
        if(f>=3){a.durability??={};a.durability[Ni]=(a.durability[Ni]??336)-Math.floor(f+1);if(a.durability[Ni]<=0){if(Hn()===Ni)a.slots[27+i.getSelected()]=null;else delete a.armor.offhand;}}
        $context.shieldDisabled=Math.max($context.shieldDisabled,R.disableShield||0);$context.m('hurt');I();return;
      }
    }
    const repeated=playerDamageState.hurtRemaining>.5;f=acceptDamage(playerDamageState,f);if(!f)return;
    if (R&&!repeated) {
      applyKnockback($context.n,R,R.knockback||1,{xKey:'knockVx',zKey:'knockVz',damping:0,liftAlways:true});
    }
    let armorPieces = Object.values(a.armor || {}).map((id) => equipmentValues[id]).filter(Boolean), v = armorPieces.reduce((total, gear) => total + (gear.defense || 0), 0), toughness = armorPieces.reduce((total, gear) => total + (gear.toughness || 0), 0), knockbackResistance = Math.min(1, armorPieces.reduce((total, gear) => total + (gear.knockbackResistance || 0), 0));
    if (R) {
      $context.n.knockVx *= 1 - knockbackResistance;
      $context.n.knockVz *= 1 - knockbackResistance;
    }
    if (v && !/STARV|DROWN|FREEZ|POISON|FALL|SUFFOCAT|WORLD/.test(b)) {
      let wear = Math.max(1, Math.floor(f / 4));
      a.durability ??= {};
      for (const slot of ["helmet", "chestplate", "leggings", "boots"]) {
        let id = a.armor?.[slot], gear = equipmentValues[id];
        if (!gear) continue;
        a.durability[id] = (a.durability[id] ?? gear.durability) - wear;
        if (a.durability[id] <= 0) {
          delete a.armor[slot];
          delete a.durability[id];
          $context.p(`${r[id].name.toUpperCase()} BROKE`);
        }
      }
      f = $context.armorDamage(f,v,toughness);
    }
    if(!['STARVING','DROWNING','BURNED BY LAVA','CAUGHT FIRE','POISON','POISONED','BURNING','FREEZING'].includes(b))addExhaustion(.1);
    if ($context.n.health = Math.max(0, $context.n.health - f), $context.Yo = 0.5, $context.p(b),$context.m(b==='FALL DAMAGE'?'fall':'hurt'), ao(false), I(), $context.n.health <= 0) {
      for (let N of a.slots) N && Yn(N.id, $context.n.x, $context.n.y + 1, $context.n.z, N.n, N.data);
      for (let N of Object.values(a.armor)) N && Yn(N, $context.n.x, $context.n.y + 1, $context.n.z);
      a.armor = {}, a.slots.fill(null), $context.n.health = 20, $context.n.air = 20, $context.n.hunger=20, $context.n.saturation=5, $context.n.exhaustion=0, a.effects={}, i.respawnPlayer(), ao(), $context.p("RESPAWNED \u2014 ITEMS LEFT WHERE YOU FELL");
    }
  }

function dragonMeshHitDistance(mob,origin,direction,maxDistance){
    const {cm} = $context;

    // Use the meshes the player sees, including the head, wings and tail.
    // A single center point made the dragon unhittable on its outer parts.
    if(Math.hypot(mob.x-origin.x,mob.group.position.y-origin.y,mob.z-origin.z)>maxDistance+16)return Infinity;
    cm.set(origin,direction);cm.near=0;cm.far=maxDistance;
    mob.group.updateWorldMatrix(true,true);
    const lod=mob.group.children.find(child=>child.isLOD);
    const target=lod?.getObjectForDistance(origin.distanceTo(mob.group.position))??mob.group;
    const hits=[];
    const cast=(object,selected=false)=>{if(!selected&&!object.visible)return;if(object.isMesh)object.raycast(cm,hits);for(const child of object.children)cast(child)};
    cast(target,true);
    hits.sort((a,b)=>a.distance-b.distance);mob.hitPart=hits[0]?.object.userData.dragonPart||'';return hits[0]?.distance??Infinity;
  }

function fy(f, b, R) {
    const {Xr,Yc,Zr,Zt,cm,dragonMeshHitDistance,hy,o,oo} = $context;

    cm.camera=o;cm.set(f, b), cm.far = R;
    let v = 1 / 0, N = (V, L, z, H, q) => {
      let Ue = (L - f.x) * b.x + (z - f.y) * b.y + (H - f.z) * b.z;
      if (Ue < -q || Ue > Math.min(v, R) + q || (L - f.x) ** 2 + (z - f.y) ** 2 + (H - f.z) ** 2 - Ue * Ue > (q + 1) ** 2) return;
      V.updateMatrixWorld(true);
      let Se = cm.intersectObject(V, true)[0];
      Se && Se.distance < v && (v = Se.distance);
    };
    for (let V of Zt) {
      if(V.type==='dragon'){v=Math.min(v,dragonMeshHitDistance(V,f,b,Math.min(v,R)));continue}
      let L = Yc(V);
      v = Math.min(v, hy(f, b, V.x, V.group.position.y, V.z, Math.max(L.radius, 0.48), L.height, Math.min(v, R)));
    }
    for (let V of oo) N(V.mesh, V.mesh.position.x, V.mesh.position.y, V.mesh.position.z, 0.5);
    for (let V of Zr) N(V.mesh, V.mesh.position.x, V.mesh.position.y, V.mesh.position.z, 0.5);
    for (let V of Xr) N(V.mesh, V.mesh.position.x, V.mesh.position.y, V.mesh.position.z, 0.3);
    return v;
  }

function Cy(f, b, R, v, N, V) {
    const {Xr,Yc,Zt,e,oo} = $context;

    for (let L of Zt) {
      let z = Yc(L), H = L.group.position.y;
      Math.abs(L.x - f - 0.5) > z.radius + 0.5 || Math.abs(L.z - R - 0.5) > z.radius + 0.5 || H >= b + 1 || H + z.height <= b || (L.x += v, L.z += V, L.group.position.set(L.x, H + N, L.z), L.vx += v * 2, L.vy = Math.max(L.vy, N > 0 ? 2 : 0), L.vz += V * 2);
    }
    for (let L of [...oo, ...Xr]) {
      let z = L.mesh;
      Math.abs(z.position.x - f - 0.5) < 0.7 && Math.abs(z.position.z - R - 0.5) < 0.7 && Math.abs(z.position.y - b - 0.5) < 0.8 && z.position.add(new e.Vector3(v, N, V));
    }
  }

function YE(actor,x,z,strength=1){return applyKnockback(actor,{x,z},strength);}


function hitDragonCrystal(range){
    const {destroyCrystal,dragonCrystals,e,ensureDragonCrystals,i,o} = $context;

    if(i.getDimension()!=='end')return false;
    ensureDragonCrystals();
    const direction=new e.Vector3();o.getWorldDirection(direction);
    let target=null,nearest=range;
    for(const crystal of dragonCrystals){
      const offset=new e.Vector3(crystal.x-o.position.x,crystal.y-o.position.y,crystal.z-o.position.z);
      const along=offset.dot(direction);
      if(along<0||along>nearest||offset.addScaledVector(direction,-along).lengthSq()>1.1)continue;
      target=crystal;nearest=along;
    }
    if(!target)return false;
    return destroyCrystal(target);
  }

function syncCrystals(){
    const {a,dragonCrystals,inStoredEntities,releaseEntity} = $context;
inStoredEntities('end',()=>{for(let j=dragonCrystals.length-1;j>=0;j--)if(a.destroyedEndCrystals?.[dragonCrystals[j].index]){releaseEntity(dragonCrystals[j].mesh);dragonCrystals.splice(j,1);}});}

function destroyCrystal(target,authoritative=false){
    const {Zt,a,dragonCrystals,dragonPhase,i,networkAttackQueue,releaseEntity,xi} = $context;

    if(!target||a.destroyedEndCrystals?.[target.index])return false;
    if(i.isRemoteWorld?.()&&!authoritative){networkAttackQueue.push({crystal:target.index,x:$context.n.x,y:$context.n.y,z:$context.n.z,projectile:true});return true;}
    a.destroyedEndCrystals[target.index]=true;i.markDirty?.();
    $context.t.remove(target.mesh);dragonCrystals.splice(dragonCrystals.indexOf(target),1);
    const dragon=Zt.find(mob=>mob.type==='dragon');
    if(dragon){
      dragon.health=Math.max(0,dragon.health-(Math.hypot(dragon.x-target.x,dragon.z-target.z)<20?10:0));
      if(dragon.health<=0){i.onDragonDefeated?.();releaseEntity(dragon.group);Zt.splice(Zt.indexOf(dragon),1);$context.p('THE ENDER DRAGON IS DEFEATED')}
      else dragonPhase(dragon,'strafe');
    }
    if(Math.hypot($context.n.x-target.x,$context.n.y-target.y,$context.n.z-target.z)<5)xi(6,'END CRYSTAL',{x:target.x,z:target.z});
    $context.p('END CRYSTAL DESTROYED');$context.m('explosion');return true;
  }

function HE() {
    const {Hc,Hn,Yc,Zt,a,attackProfile,damageMob,dragonMeshHitDistance,e,es,hitDragonCrystal,i,networkAttackQueue,o,vi} = $context;

    const direction=new e.Vector3();o.getWorldDirection(direction);
    let limit=a.mode==='creative'?5:3;
    const blockHit=i.meleeBlockDistance?.();if(Number.isFinite(blockHit))limit=Math.min(limit,blockHit);
    if(hitDragonCrystal(limit)){attackProfile(true);return true;}
    const ray=new e.Ray(o.position,direction),point=new e.Vector3();let target=null;
    for(const mob of Zt){
      let distance;
      if(mob.type==='dragon')distance=dragonMeshHitDistance(mob,o.position,direction,limit);
      else{const shape=Yc(mob),box=new e.Box3(new e.Vector3(mob.x-shape.radius,mob.group.position.y,mob.z-shape.radius),new e.Vector3(mob.x+shape.radius,mob.group.position.y+shape.height,mob.z+shape.radius));distance=ray.intersectBox(box,point)?point.distanceTo(o.position):Infinity;}
      if(distance<limit){limit=distance;target=mob;}
    }
    if(!target)return false;const attack=attackProfile(true);if(vi[Hn()])es(Hn(),vi[Hn()].kind==='sword'?1:2);
    if(i.isRemoteWorld?.()&&target.networkId){networkAttackQueue.push({id:target.networkId,damage:attack.damage,part:target.hitPart,x:$context.n.x,z:$context.n.z,knockback:attack.knockback});return true;}
    const accepted=damageMob(target,attack.damage,$context.n,attack.knockback);
    if(accepted&&target.type==='enderman'&&target.health>0)Hc(target);
    if(accepted&&attack.sweep&&$context.n.grounded){for(const other of [...Zt])if(other!==target&&other.type!=='dragon'&&Math.hypot(other.x-target.x,other.z-target.z)<1.5&&Math.abs(other.group.position.y-target.group.position.y)<1&&Math.hypot(other.x-$context.n.x,other.z-$context.n.z)<3)damageMob(other,1,$context.n,.4);}
    return true;
  }

function eU() {
    const {En,Gt,Pe,Zt,e,me,mt,o,wn} = $context;

    let f = new e.Vector3();
    o.getWorldDirection(f);
    for (let b of Zt) {
      if (b.type !== "villager") continue;
      let R = new e.Vector3(b.x - $context.n.x, b.group.position.y + 1 - o.position.y, b.z - $context.n.z);
      if (!(R.length() > 4 || R.normalize().dot(f) < 0.96)) return wn(Pe) >= 4 ? (mt(Pe, 4), En(Gt), $context.p("TRADED 4 WHEAT FOR 1 EMERALD")) : wn(Gt) ? (mt(Gt), En(me, 3), $context.p("TRADED 1 EMERALD FOR 3 BREAD")) : $context.p("VILLAGER WANTS 4 WHEAT"), true;
    }
    return false;
  }

function Iy() {
    const {HE,attackProfile,deflectFireball} = $context;
if(deflectFireball()){attackProfile(true);return true;}return HE();}

function dragonBreathCloud(x,y,z){
    const {dragonBreathClouds,e} = $context;

    const mesh=new e.Mesh(new e.CircleGeometry(2.5,24),new e.MeshBasicMaterial({color:0x9b42c3,transparent:true,opacity:.44,depthWrite:false,side:e.DoubleSide}));
    mesh.rotation.x=-Math.PI/2;mesh.position.set(x,y+.04,z);$context.t.add(mesh);
    dragonBreathClouds.push({x,y,z,mesh,age:0,damage:0});
  }

function updateDragonBreathClouds(dt){
    const {dragonBreathClouds,xi} = $context;

    for(let j=dragonBreathClouds.length-1;j>=0;j--){
      const cloud=dragonBreathClouds[j];cloud.age+=dt;cloud.damage-=dt;
      if(cloud.damage<=0&&Math.hypot($context.n.x-cloud.x,$context.n.z-cloud.z)<2&&Math.abs($context.n.y-cloud.y)<2){xi(3,'DRAGON BREATH',{x:cloud.x,z:cloud.z});cloud.damage=.5}
      cloud.mesh.material.opacity=.44*Math.max(0,1-cloud.age/5);
      if(cloud.age>=5){$context.t.remove(cloud.mesh);cloud.mesh.geometry.dispose();cloud.mesh.material.dispose();dragonBreathClouds.splice(j,1)}
    }
  }

function arrowModel(){
    const {e,ka} = $context;

    const arrow=new e.Group(),shaft=new e.Mesh(new e.BoxGeometry(.028,.56,.028),ka(0x9b7744)),point=new e.Mesh(new e.ConeGeometry(.062,.15,4),ka(0xa5a8a3));
    point.position.y=.35;arrow.add(shaft,point);
    const feather=ka(0xe7e3d6);for(const angle of [0,Math.PI/2]){const fin=new e.Mesh(new e.BoxGeometry(.14,.13,.018),feather);fin.position.y=-.26;fin.rotation.y=angle;arrow.add(fin)}
    return arrow;
  }

function Fl(f, b) {
    const {Zr,arrowModel,e,ka,vy} = $context;

    if(b==='bullet')f.lidOpen=2;
    let R = vy[b], v = f.group.position.y + (b === "fireball" ? 2.5 : b === 'dragon_fireball' ? 1.1 : b === "bullet" ? 1.4 : 1.5), N = new e.Vector3($context.n.x - f.x, $context.n.y + 1.25 - v, $context.n.z - f.z).normalize(), V = b==='arrow'?arrowModel():new e.Mesh(new e.BoxGeometry(R.size, R.size, R.size), ka(R.color));
    V.position.set(f.x, v, f.z), $context.t.add(V), Zr.push({ kind: b, harming:b==='potion'&&Math.hypot($context.n.x-f.x,$context.n.z-f.z)<3, mesh: V, x: f.x, y: v, z: f.z, vx: N.x * R.speed, vy: N.y * R.speed + (b === "arrow" ? 0.5 : b === "potion" ? 1.3 : 0), vz: N.z * R.speed, age: 0 });
    if(b==='arrow')$context.m('bow');
    if(b==='fireball')$context.m('ghast_fireball');
  }

function deflectFireball(){
    const {Zr,e,o} = $context;

    const direction=new e.Vector3();o.getWorldDirection(direction);
    let closest=null,nearest=4.5;
    for(const shot of Zr){
      if(shot.kind!=='fireball')continue;
      const offset=new e.Vector3(shot.x-o.position.x,shot.y-o.position.y,shot.z-o.position.z);
      const forward=offset.dot(direction);
      if(forward<0||forward>nearest||offset.addScaledVector(direction,-forward).lengthSq()>.55**2)continue;
      closest=shot;nearest=forward;
    }
    if(!closest)return false;
    const speed=15;
    closest.vx=direction.x*speed;closest.vy=direction.y*speed;closest.vz=direction.z*speed;
    closest.reflected=true;closest.reflectionAge=0;closest.age=0;
    $context.m('ghast_fireball');
    return true;
  }

function KE(f) {
    const {A,Hc,Qc,Yc,Zr,Zt,a,dragonMeshHitDistance,damageMob,destroyCrystal,dragonBreathCloud,dragonCrystals,e,i,networkAttackQueue,xi} = $context;

    for (let b = Zr.length - 1; b >= 0; b--) {
      let R = Zr[b];
      if (R.age += f, R.reflected && (R.reflectionAge+=f), R.kind === "bullet" && !$context.backgroundEntities) {
        let V = new e.Vector3($context.n.x - R.x, $context.n.y + 1.25 - R.y, $context.n.z - R.z).normalize().multiplyScalar(4), L = Math.min(1, f * 2);
        R.vx += (V.x - R.vx) * L, R.vy += (V.y - R.vy) * L, R.vz += (V.z - R.vz) * L;
      } else (R.kind === "arrow" || R.kind === "potion"||R.kind==='snowball'||R.kind==='pearl') && (R.vy -= f * (R.kind === "arrow" ? 20 : R.kind==='snowball'?12:7));
      if(R.kind==='arrow'){const drag=Math.pow(.99,f*20);R.vx*=drag;R.vy*=drag;R.vz*=drag;}
      let v = false, N = Math.max(1, Math.ceil(Math.hypot(R.vx, R.vy, R.vz) * f / 0.25));
      for (let V = 0; V < N; V++) {
        R.x+=R.vx*f/N;R.y+=R.vy*f/N;R.z+=R.vz*f/N;
        const bx=Math.floor(R.x),by=Math.floor(R.y),bz=Math.floor(R.z),block=A(bx,by,bz);
        if(block===i.ids.BIG_DRIPLEAF)i.tiltDripleaf?.(bx,by,bz,true);
        if(R.kind==='pearl'&&block===9990){i.useEndGateway?.(bx,by,bz);v=true;break;}
        if (i.isSolid(A(Math.floor(R.x), Math.floor(R.y), Math.floor(R.z)))) {
          if(R.kind==='pearl'){Object.assign($context.n,i.ensureSafeSpawn({x:R.x,y:R.y+1,z:R.z}));$context.n.vy=0;xi(5,'ENDER PEARL');}
          if(R.kind === "fireball") Qc(Math.floor(R.x), Math.floor(R.y), Math.floor(R.z),1);
          if(R.kind === 'dragon_fireball') dragonBreathCloud(R.x,R.y+1,R.z);
          v = true;
          break;
        }
        if(R.playerShot&&i.hitRemoteProjectile?.(R)){v=true;break;}
        if(R.playerShot){
          const crystal=dragonCrystals.find(c=>Math.hypot(c.x-R.x,c.y-R.y,c.z-R.z)<1);if(crystal){destroyCrystal(crystal);v=true;break;}

          const mob=Zt.find(mob=>{if(mob.type==='dragon'){const direction=new e.Vector3(R.vx,R.vy,R.vz).normalize(),origin=new e.Vector3(R.x,R.y,R.z).addScaledVector(direction,-.3);return dragonMeshHitDistance(mob,origin,direction,.6)<.6;}const shape=Yc(mob);return Math.abs(mob.x-R.x)<=shape.radius&&Math.abs(mob.z-R.z)<=shape.radius&&R.y>=mob.group.position.y&&R.y<=mob.group.position.y+shape.height;});
          if(mob){
            if(mob.type==='enderman'){Hc(mob);continue;}
            if(mob.type==='shulker'&&!(mob.lidOpen>0)&&R.kind==='arrow'){v=true;break;}
            if(mob.type==='dragon'&&['landing','perched','roar','breath'].includes(mob.dragonPhase)){v=true;break;}
            let damage=R.kind==='snowball'?(mob.type==='blaze'?3:0):Math.ceil(Math.hypot(R.vx,R.vy,R.vz)/20*2);if(R.critical)damage+=Math.floor(Math.random()*(damage/2+2));
            if(i.isRemoteWorld?.()&&mob.networkId)networkAttackQueue.push({id:mob.networkId,damage,part:mob.hitPart,x:R.origin.x,z:R.origin.z,projectile:true});else damageMob(mob,damage,R.origin,.75);
            v=true;break;
          }
        }
        if(R.kind==='fireball'&&R.reflected){
          const ghast=Zt.find(mob=>mob.type==='ghast'&&Math.abs(mob.x-R.x)<2&&Math.abs(mob.z-R.z)<2&&R.y>=mob.group.position.y+1&&R.y<=mob.group.position.y+6);
          if(ghast){ghast.health=0;i.awardAdvancement?.('return_to_sender','Return to Sender');Qc(Math.floor(R.x),Math.floor(R.y),Math.floor(R.z),1);v=true;break}
        }
        if (!R.playerShot&&!$context.backgroundEntities&&(!R.reflected||R.reflectionAge>.2)&&Math.hypot(R.x - $context.n.x, R.y - ($context.n.y + 1), R.z - $context.n.z) < 0.7) {
          R.kind === "fireball" ? Qc(Math.floor(R.x), Math.floor(R.y), Math.floor(R.z),1) : R.kind === 'dragon_fireball' ? dragonBreathCloud(R.x,$context.n.y,R.z) : R.kind === "arrow" ? xi(Math.ceil(Math.hypot(R.vx,R.vy,R.vz)/20*2), "SKELETON ARROW", R) : R.kind === "blaze" ? (xi(5, "BLAZE FIREBALL", R), a.effects.burning = 4) : R.kind === "potion" ? (R.harming?xi(6, "WITCH POTION", R):(a.effects.poison=18)) : R.kind === "bullet" && (xi(4, "SHULKER BULLET", R), a.effects.levitation = 10), v = true;
          break;
        }
      }
      R.mesh.position.set(R.x, R.y, R.z);
      if(R.kind==='arrow')R.mesh.quaternion.setFromUnitVectors(new e.Vector3(0,1,0),new e.Vector3(R.vx,R.vy,R.vz).normalize());
      else{R.mesh.rotation.x += f * 3;R.mesh.rotation.y += f * 2}
      if(v||R.age>7){$context.t.remove(R.mesh);R.mesh.traverse(part=>part.geometry?.dispose());Zr.splice(b,1)}
    }
  }

function tickCombat(f){
    const {a,attackMeter,attackProfile,i,playerDamageState} = $context;

    $context.attackElapsed+=f;playerDamageState.hurtRemaining=Math.max(0,playerDamageState.hurtRemaining-f);$context.shieldHeld=i.isBlocking?.()?$context.shieldHeld+f:0;$context.shieldDisabled=Math.max(0,$context.shieldDisabled-f);if($context.bowHeld!==null)$context.bowHeld+=f;
    const recharge=attackProfile().charge;attackMeter.hidden=a.mode==='spectator'||recharge>=1;attackMeter.firstChild.style.transform=`scaleX(${recharge})`;
  }
return {damageMob,Qc,xi,dragonMeshHitDistance,fy,Cy,YE,hitDragonCrystal,syncCrystals,destroyCrystal,HE,eU,Iy,dragonBreathCloud,updateDragonBreathClouds,arrowModel,Fl,deflectFireball,KE,tickCombat};
}
