/** dimensions subsystem. Dependencies are injected at composition time. */
export function createDimensionsSystem($context) {
function makePortalPreviewScene(target){
    const {THREE} = $context;

  const remote=new THREE.Scene();
  remote.background=new THREE.Color(target==='nether'?0x330808:target==='end'?0x15111e:0xc0d8ff);
  remote.fog=new THREE.Fog(remote.background,target==='nether'?9:35,target==='nether'?70:86);
  remote.userData.ambient=new THREE.HemisphereLight(0xe5f3ff,0x75634f,.9);
  remote.userData.sun=new THREE.DirectionalLight(0xffedcb,1);
  remote.add(remote.userData.ambient,remote.userData.sun);
  return remote;
}

function entityWorldChunks(){
    const {chunks} = $context;
return $context.entityWorldContext?.chunks||($context.portalPreviewMode?$context.portalPreviewChunks:chunks);}

function retainEntityTerrain(){
    const {SIZE,chunks,dimensionVoxelCaches,fallingBlocks,key,parkedVehicles,survival} = $context;

  const wanted=new Set();
  const positions=[...survival.entityPositions(),...parkedVehicles.map(v=>[v.mesh.position.x,v.mesh.position.z]),...fallingBlocks.map(v=>[v.x,v.z])];
  for(const [x,z] of positions){const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE);for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++)wanted.add(key(cx+dx,cz+dz));}
  const retained=new Map();for(const [id,chunk] of chunks)if(wanted.has(id))retained.set(id,chunk);
  dimensionVoxelCaches.set($context.dimension,retained);
}

function runEntityWorld(target,fn){
    const {dimensionVoxelCaches,inDimension,portalPreviewWorlds,vehicleDimensions} = $context;

  const previous=$context.entityWorldContext,worldChunks=new Map(dimensionVoxelCaches.get(target)||[]);
  for(const world of portalPreviewWorlds.values())if(world.target===target)for(const [id,chunk] of world.chunks)worldChunks.set(id,chunk);
  $context.entityWorldContext={chunks:worldChunks,power:vehicleDimensions.get(target)?.power};
  try{return inDimension(target,fn);}finally{$context.entityWorldContext=previous;}
}

function setBackgroundBlock(x,y,z,type){
    const {MAX_Y,MIN_Y,SIZE,currentEdits,editKey,entityWorldChunks,getBlock,idx,key,portalPreviewWorlds} = $context;

  if(y<MIN_Y+1||y>=MAX_Y)return false;const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE),chunk=entityWorldChunks().get(key(cx,cz));
  if(!chunk)return false;const cell=editKey(x,y,z);if(getBlock(x,y,z)===type)return false;
  chunk.blocks[idx(x-cx*SIZE,y,z-cz*SIZE)]=type;currentEdits()[cell]=type;chunk.lightingRevision=(chunk.lightingRevision||0)+1;chunk.skyColumns=null;$context.dirtySave=true;
  for(const world of portalPreviewWorlds.values())if(world.target===$context.dimension&&world.chunks.get(key(cx,cz))===chunk&&!world.relight.includes(chunk))world.relight.push(chunk);
  $context.multiplayer?.publishEdit(x,y,z,type);return true;
}

function stepEntityTerrain(target){
    const {SIZE,dimensionVoxelCaches,entityTerrainTasks,entityWorldChunks,generateChunk,key,runEntityWorld,survival,vehicleDimensions} = $context;

  const cache=dimensionVoxelCaches.get(target)||new Map();dimensionVoxelCaches.set(target,cache);
  const positions=[...survival.entityPositions(target),...(vehicleDimensions.get(target)?.vehicles||[]).map(v=>[v.mesh.position.x,v.mesh.position.z]),...(vehicleDimensions.get(target)?.falling||[]).map(v=>[v.x,v.z])];
  const wanted=new Set();for(const [x,z] of positions){const cx=Math.floor(x/SIZE),cz=Math.floor(z/SIZE);for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++)wanted.add(key(cx+dx,cz+dz));}
  for(const id of cache.keys())if(!wanted.has(id))cache.delete(id);
  runEntityWorld(target,()=>{let task=entityTerrainTasks.get(target);if(!task){const missing=[...wanted].find(id=>!entityWorldChunks().has(id));if(!missing)return;task=generateChunk(...missing.split(',').map(Number));entityTerrainTasks.set(target,task);}const start=performance.now();do{if(task.next().done){entityTerrainTasks.delete(target);break}}while(performance.now()-start<1);});
}

function simulateVehicleDimension(target,dt){
    const {fallingBlocks,parkedVehicles,runEntityWorld,updateFallingBlocks,updateMinecarts,vehicleDimensions} = $context;

  const record=vehicleDimensions.get(target);if(!record)return;
  const currentVehicles=parkedVehicles.splice(0),currentFalling=fallingBlocks.splice(0),rider=$context.vehicle;
  parkedVehicles.push(...record.vehicles);fallingBlocks.push(...record.falling);$context.vehicle=null;
  try{runEntityWorld(target,()=>{updateMinecarts(dt);updateFallingBlocks(dt);});}
  finally{record.vehicles=parkedVehicles.splice(0);record.falling=fallingBlocks.splice(0);parkedVehicles.push(...currentVehicles);fallingBlocks.push(...currentFalling);$context.vehicle=rider;}
}

function simulateOtherDimensions(dt,daylight){
    const {moveMobsThroughPortals,runEntityWorld,simulateVehicleDimension,stepEntityTerrain,survival,vehicleDimensions} = $context;

  if($context.multiplayer.guest)return;$context.backgroundEntityTime+=dt;if($context.backgroundEntityTime<.05)return;
  const step=Math.min(.1,$context.backgroundEntityTime);$context.backgroundEntityTime-=step;
  for(const target of new Set([...survival.dimensionIds(),...vehicleDimensions.keys()])){
    stepEntityTerrain(target);
    survival.simulateDimension(target,step,daylight,fn=>runEntityWorld(target,fn));
    simulateVehicleDimension(target,step);
  }
  moveMobsThroughPortals(step);
}

function moveMobsThroughPortals(dt){
    const {END_PORTAL,NETHER_PORTAL,THREE,destinationPortalCenter,endExitArrival,inDimension,mapPortalPoint,mapPortalYaw,portalDestination,portalDestinationAxis,portalInfoAt,runEntityWorld,survival} = $context;

  const visits=[...new Set([$context.dimension,...survival.dimensionIds()])].map(source=>({source,mobs:survival.mobStates(source)}));
  for(const {source,mobs} of visits)for(const mob of mobs){
    if(mob.type==='dragon')continue;
    let info=null;
    const inspect=()=>{const y=mob.group.position.y;for(const dy of [.1,.7,1.2]){info=portalInfoAt(Math.floor(mob.x),Math.floor(y+dy),Math.floor(mob.z));if(info)break}};
    if(source===$context.dimension)inspect();else runEntityWorld(source,inspect);
    // Contact refreshes the arrival cooldown; it counts down after leaving.
    if(mob.portalCooldown>0){mob.portalCooldown=info?15:Math.max(0,mob.portalCooldown-dt);continue;}
    if(!info)continue;
    const travel=()=>{
      const target=portalDestination(info);
      if(source==='overworld'&&info.type===NETHER_PORTAL)$context.save.portalLinks.overworld={...info.center,axis:info.axis};
      const center=destinationPortalCenter(info,target),axis=portalDestinationAxis(target);
      const origin=new THREE.Vector3(mob.x,mob.group.position.y,mob.z),mapped=mapPortalPoint(info,center,axis,origin);
      const velocity=mapPortalPoint(info,center,axis,origin.clone().add(new THREE.Vector3(mob.vx||0,0,mob.vz||0)));
      const exit=info.type===END_PORTAL&&source==='end'?endExitArrival():mapped;
      survival.transferMob(mob,source,target,{...exit,dir:-mapPortalYaw(info.axis,axis,-mob.dir),vx:velocity.x-mapped.x,vz:velocity.z-mapped.z});
    };
    inDimension(source,travel);
  }
}

function inDimension(target,fn){const previous=$context.dimension;$context.dimension=target;try{return fn()}finally{$context.dimension=previous}}
return {makePortalPreviewScene,entityWorldChunks,retainEntityTerrain,runEntityWorld,setBackgroundBlock,stepEntityTerrain,simulateVehicleDimension,simulateOtherDimensions,moveMobsThroughPortals,inDimension};
}
