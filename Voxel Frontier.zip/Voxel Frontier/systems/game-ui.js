import {requestGamePointerLock} from '../pointer-lock.js';
import {internalSkyLight} from '../light-rules.js';
import {itemIconURL} from '../item-icons.js';
/** game ui subsystem. Dependencies are injected at composition time. */
export function createGameUiSystem($context) {
let hotbarSignature="",lastWorldRender=-Infinity;
function showToast(message){$context.ui.toast.classList.remove('show');}


function awardAdvancement(id,name){
    const {showToast} = $context;
if($context.save.advancements[id])return;$context.save.advancements[id]=true;$context.dirtySave=true;showToast(`ADVANCEMENT MADE: ${name.toUpperCase()}`)}

function blockSoundMaterial(id){
    const {BLOCKS} = $context;

  const name=(BLOCKS[id]?.name||'').toLowerCase();
  if(/glass|ice/.test(name))return 'glass';
  if(/wood|plank|log|chest|table|door|ladder|fence|bookshelf|trapdoor/.test(name))return 'wood';
  if(/sand|sandstone/.test(name))return 'sand';
  if(/gravel|concrete powder/.test(name))return 'gravel';
  if(/snow/.test(name))return 'snow';
  if(/wool|carpet|bed/.test(name))return 'cloth';
  if(/grass|leaf|leaves|moss|flower|fern|crop|sapling|vine/.test(name))return 'grass';
  return 'stone';
}

function playSound(event,blockId){
    const {blockSoundMaterial,playGameSound} = $context;

  if(typeof event==='boolean')event=event?'place':'break';
  const material=blockSoundMaterial(blockId);
  playGameSound(event==='place'||event==='break'?material:event,event==='portal'?.58:.38);
}

function playDisc(playing){
    const {playGameSound} = $context;
if($context.discAudio){$context.discAudio.pause();$context.discAudio.currentTime=0;$context.discAudio=null}if(playing)$context.discAudio=playGameSound('disc_otherside',.22)}

function updateHotbar(){
    const {ITEMS,ui} = $context;
const signature=$context.selected+'|'+JSON.stringify($context.save.slots.slice(27))+'|'+$context.save.slots.slice(27).map(stack=>itemIconURL(ITEMS[stack?.id])).join('|');if(signature===hotbarSignature)return;hotbarSignature=signature;ui.hotbar.innerHTML='';for(let i=0;i<9;i++){const stack=$context.save.slots[27+i],item=stack&&ITEMS[stack.id],b=document.createElement('button');b.className='slot'+($context.selected===i?' selected':'')+(!stack?' empty':'');b.title=item?.name||'Empty slot';b.setAttribute('aria-label',`Slot ${i+1}: ${item?.name||'empty'}`);b.innerHTML=`<small>${i+1}</small>${item?`<span class="swatch" style="--block:#${(item.color??0xffffff).toString(16).padStart(6,'0')};background-image:url('${itemIconURL(item)}')"></span><span class="count">${stack.n}</span>`:''}`;b.addEventListener('click',()=>{$context.selected=i;updateHotbar()});ui.hotbar.append(b)}}

function saveGame(background=false){
    const {SAVE_KEY,player,serializeVehicleEntities,showToast,survival} = $context;
if(!$context.dirtySave||$context.resettingWorld)return;survival.serializeEntities();serializeVehicleEntities();if($context.multiplayer?.guest){$context.save.player={x:player.x,y:player.y,z:player.z,yaw:player.yaw,pitch:player.pitch};$context.save.tick=$context.tick;$context.save.dimension=$context.dimension;sessionStorage.setItem('vf-mp-world',JSON.stringify($context.save));$context.dirtySave=false;return;}$context.save.player={x:player.x,y:player.y,z:player.z,yaw:player.yaw,pitch:player.pitch,flight:player.flight,health:player.health,hunger:player.hunger,saturation:player.saturation,exhaustion:player.exhaustion,foodTimer:player.foodTimer,air:player.air};$context.save.tick=$context.tick;$context.save.dimension=$context.dimension;$context.save.positions[$context.dimension]={x:player.x,y:player.y,z:player.z,yaw:player.yaw,pitch:player.pitch};$context.save._savedAt=Date.now();if(background&&window.vfWriteWorld){window.vfWriteWorld($context.save).catch(()=>{$context.dirtySave=true});$context.dirtySave=false;return}try{localStorage.setItem(SAVE_KEY,JSON.stringify($context.save));window.vfWriteWorld?.($context.save).catch(()=>{});$context.dirtySave=false}catch{showToast('SAVE FAILED: BROWSER STORAGE FULL')}}

function dragonDefeated(){
    const {END_PORTAL,setBlock,showToast,terrain} = $context;
$context.save.dragonDefeated=true;$context.gameplayRepairs.spawnGateway();const y=terrain(0,0)+1;for(let z=-1;z<=1;z++)for(let x=-1;x<=1;x++)if(x||z)setBlock(x,y,z,END_PORTAL);$context.dirtySave=true;showToast('THE END EXIT PORTAL HAS OPENED')}

function addChatMessage(name,message){
    const {chatLog} = $context;
const row=document.createElement('p');row.textContent=name?`${name}: ${message}`:message;chatLog.append(row);chatLog.hidden=false;while(chatLog.children.length>8)chatLog.firstElementChild.remove();$context.chatUntil=performance.now()+10000;}

function openCommand(isChat=false){
    const {commandBar,commandFeedback,commandInput,commandMode,keys} = $context;
$context.commandOpen=true;keys.clear();commandBar.hidden=false;commandMode.textContent=isChat?'CHAT':'COMMAND';commandInput.value=isChat?'':'/';commandFeedback.textContent=isChat?'Enter to send · / for commands':'Type /help for available commands';document.exitPointerLock?.();commandInput.focus()}

function closeCommand(){
    const {canvas,commandBar,commandInput} = $context;
$context.commandOpen=false;commandBar.hidden=true;commandInput.blur();if($context.playing&&!$context.mobile?.touch)requestGamePointerLock(canvas)}

function nearbyWorldProgress(){
    const {SIZE,chunks,key,player} = $context;
const cx=Math.floor(player.x/SIZE),cz=Math.floor(player.z/SIZE);let ready=0;for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++)if(chunks.get(key(cx+dx,cz+dz))?.meshComplete)ready++;return ready;}

function updateWorldLoading(){
    const {loading,nearbyWorldProgress,ui,worldReadyWaiters} = $context;
if($context.resettingWorld)return;const count=nearbyWorldProgress(),ready=count===9&&$context.effectsPrepared;ui.play.disabled=false;
 if(ready){loading.end('world');sessionStorage.removeItem('vf-new-world');for(const resolve of worldReadyWaiters.splice(0))resolve();}
 else if(loading.has('world'))loading.update('world',count<9?`Preparing nearby terrain (${count}/9 chunks)`:'Preparing sounds and graphics',count/9*.85+($context.effectsPrepared ? .15 : 0));
}

function waitForNearbyWorld(){
    const {loading,nearbyWorldProgress,worldReadyWaiters} = $context;
if(nearbyWorldProgress()===9&&$context.effectsPrepared)return Promise.resolve();loading.begin('world','Loading world','Preparing nearby terrain',0);return new Promise(resolve=>worldReadyWaiters.push(resolve));}

function pause(){
    const {keys,mining,miningTrack,saveGame,ui} = $context;
if($context.playing){$context.dirtySave=true;saveGame()}$context.playing=false;mining.active=false;miningTrack.classList.remove('active');document.exitPointerLock?.();ui.overlay.classList.add('active');ui.play.innerHTML='RESUME WORLD <span>→</span>';keys.clear()}

async function resume(){
    const {canvas,effectsReady,ui,unlockSounds,waitForNearbyWorld,loading} = $context;
if($context.resuming)return;$context.resuming=true;loading.begin('enter','Entering world','Preparing terrain and graphics',0);unlockSounds();$context.mobile?.requestFullscreen();try{await new Promise(resolve=>requestAnimationFrame(resolve));await effectsReady;loading.update('enter','Preparing nearby terrain',.5);await waitForNearbyWorld();if(!$context.mobile?.touch)requestGamePointerLock(canvas);ui.overlay.classList.remove('active');$context.playing=true;$context.lastTime=performance.now();}finally{loading.end('enter');$context.resuming=false}}

function playerAction(button){
    const {BOAT,BUCKET,FISHING_ROD,GLASS_BOTTLE,SHIELD,boardVehicleAtCrosshair,camera,editKey,hitMinecartAtCrosshair,hitVoxel,keys,mining,survival} = $context;
if($context.save.mode==='spectator')return;if(button===0)$context.firstPerson.swing();const hit=hitVoxel(7,button===0&&(keys.has('ShiftLeft')||keys.has('ShiftRight'))||button===2&&[BUCKET,GLASS_BOTTLE,FISHING_ROD,BOAT].includes(survival.selectedId()));if(button===0){if($context.multiplayer?.attack(camera,hit?Math.hypot(hit.x+.5-camera.position.x,hit.y+.5-camera.position.y,hit.z+.5-camera.position.z):4)||hitMinecartAtCrosshair(hit)||survival.attackMob())return;survival.attackProfile(true);mining.active=true;mining.key=hit?editKey(hit.x,hit.y,hit.z):'';mining.progress=0;if(hit&&$context.save.mode==='creative'){survival.mine(hit);mining.active=false}}else if(button===2){if(boardVehicleAtCrosshair(hit))return;if(survival.beginBow())return;if(survival.selectedId()===SHIELD)$context.blocking=true;else if(!survival.igniteMob(hit)&&!survival.tradeMob()&&!survival.interact(hit)&&$context.save.armor?.offhand===SHIELD)$context.blocking=true}}

function setText(node,value){if(node.textContent!==value)node.textContent=value}

function frame(now){
    const {BLOCKS,END_PORTAL,NETHER_PORTAL,SEA,WATER,ambient,applyAtmosphere,biome,blockSoundMaterial,camera,caveBiome,chatLog,chunks,cloudLayer,crossExperimentalPortal,crossedPortal,drawWeather,editKey,getBlock,getLightLevel,growPlants,hitVoxel,inDimension,keys,lightRebuildQueue,mapPortalPoint,mining,miningFill,miningTrack,move,netherBiome,outline,outlineGeometry,parkedVehicles,playGameSound,player,portalDestinationAxis,portalPreviewWorlds,portalWindow,preparePortalPreview,prepareVehicleDimension,processFire,processFlow,processGravity,processRedstone,refreshTorchLights,renderVehicleDimension,renderer,resetPortalPreview,scene,scheduleChunkMesh,setText,simulateOtherDimensions,stepPortalPreview,stream,sun,survival,teleportTo,terrain,travelThroughEndPortal,ui,updateFallingBlocks,updateMinecarts,updatePortalExitLock,updateWeather,updateWorldLoading,visiblePortals} = $context;

  requestAnimationFrame(frame);
  const elapsed=Math.max(0,(now-$context.lastTime)/1000),dt=Math.min(.05,elapsed);$context.lastTime=now;let daylightNow=(Math.sin($context.tick)+1)/2;
  $context.multiplayer.update(dt);$context.mobile.update(dt);if($context.chatUntil&&now>$context.chatUntil){chatLog.hidden=true;$context.chatUntil=0;}
  const beforeMove={x:player.x,y:player.y,z:player.z};stream();updateWorldLoading();if($context.playing)updateMinecarts(dt);move(dt);
  $context.cartSoundTimer-=dt;
  if($context.playing&&$context.cartSoundTimer<=0&&parkedVehicles.some(cart=>cart.kind==='minecart'&&Math.abs(cart.speed)>1&&Math.hypot(cart.mesh.position.x-player.x,cart.mesh.position.z-player.z)<18)){
    playGameSound('cart',.15);$context.cartSoundTimer=1.3;
  }
  $context.stepSoundTimer-=dt;
  if($context.playing&&$context.stepSoundTimer<=0&&Math.hypot(player.x-beforeMove.x,player.z-beforeMove.z)>.025){
    const feet=getBlock(Math.floor(player.x),Math.floor(player.y+.2),Math.floor(player.z));
    if(feet===WATER){playGameSound('swim',.18);$context.stepSoundTimer=.48}
    else if(player.grounded){
      const below=getBlock(Math.floor(player.x),Math.floor(player.y-.1),Math.floor(player.z));
      const material=blockSoundMaterial(below);
      playGameSound('step_'+(material==='glass'||material==='cloth'?'stone':material),.16);
      $context.stepSoundTimer=.39;
    }
  }
  if($context.playing||survival.isOpen())updateWeather(dt);
  if($context.playing||survival.isOpen()){if($context.save.gamerules.doDaylightCycle!==false)$context.tick+=dt*Math.PI*2/1200;const daylight=daylightNow=(Math.sin($context.tick)+1)/2,underwater=getBlock(Math.floor(player.x),Math.floor(player.y+1.57),Math.floor(player.z))===WATER,underground=player.y+3<terrain(Math.floor(player.x),Math.floor(player.z));$context.lightDay=internalSkyLight($context.tick/(Math.PI*2)*24000,$context.save.weather.kind);applyAtmosphere(scene,$context.dimension,player.x,player.z,daylight,underground,underwater,ambient,sun);cloudLayer.visible=$context.dimension==='overworld'&&!underwater;cloudLayer.position.set(player.x+(performance.now()*.001)%60,192,player.z);cloudLayer.material.opacity=.2+daylight*.28;
    if(!$context.multiplayer.guest){$context.flowTimer+=dt;if($context.flowTimer>=.25){processFlow();$context.flowTimer-=.25}$context.gravityTimer+=dt;if($context.gravityTimer>.09){processGravity();$context.gravityTimer=0}updateFallingBlocks(dt);$context.fireTimer+=dt;if($context.fireTimer>.35){processFire($context.fireTimer);$context.fireTimer=0}$context.redstoneTimer+=dt;if($context.redstoneTimer>=.1){processRedstone();$context.redstoneTimer-=.1}$context.growthTimer+=dt;if($context.growthTimer>4){growPlants();$context.growthTimer=0}$context.lightTimer+=dt;if($context.lightTimer>1){refreshTorchLights();$context.lightTimer=0}}survival.update(dt,daylight);simulateOtherDimensions(dt,daylight);
    $context.portalCooldown=Math.max(0,$context.portalCooldown-dt);if($context.save.experiments){updatePortalExitLock()}if($context.save.experiments){if(now-$context.portalScanAt>300){$context.portalScanAt=now;$context.visiblePortalViews=visiblePortals();$context.nearPortal=$context.visiblePortalViews[0]||null;if($context.nearPortal)preparePortalPreview($context.nearPortal);else if($context.portalPreviewState)resetPortalPreview()}if($context.playing&&$context.save.mode!=='spectator'&&crossedPortal($context.nearPortal,beforeMove))crossExperimentalPortal($context.nearPortal);else if($context.nearPortal)stepPortalPreview()}else if($context.portalCooldown===0&&$context.save.mode!=='spectator'){const px=Math.floor(player.x),pz=Math.floor(player.z),foot=getBlock(px,Math.floor(player.y+.2),pz),body=getBlock(px,Math.floor(player.y+1.2),pz);if(foot===NETHER_PORTAL||body===NETHER_PORTAL)teleportTo($context.dimension==='nether'?'overworld':'nether');else if(foot===END_PORTAL||body===END_PORTAL)travelThroughEndPortal()}
    if($context.playing&&$context.save.mode!=='spectator'&&mining.active){const target=hitVoxel(7,keys.has('ShiftLeft')||keys.has('ShiftRight'));if(!target){mining.progress=0;mining.key='';miningTrack.classList.remove('active')}else{const k=editKey(target.x,target.y,target.z);if(k!==mining.key){mining.key=k;mining.progress=0}const duration=survival.miningTime(target.type);if(Number.isFinite(duration)){mining.progress+=dt;miningFill.style.width=Math.min(100,mining.progress/duration*100)+'%';miningTrack.classList.add('active');if(mining.progress>=duration){survival.mine(target);mining.progress=0;mining.key=''}}else miningTrack.classList.remove('active')}}
    $context.lookHit=$context.save.mode==='spectator'?null:hitVoxel();outline.visible=!!$context.lookHit;ui.crosshair.classList.toggle('hit',!!$context.lookHit);setText(ui.target,$context.lookHit?BLOCKS[$context.lookHit.type].name.toUpperCase():'');if($context.lookHit){outline.geometry=outlineGeometry($context.lookHit.type,$context.lookHit.x,$context.lookHit.y,$context.lookHit.z);outline.position.set($context.lookHit.x,$context.lookHit.y,$context.lookHit.z)}
    if(now-$context.hudAt>=100){$context.hudAt=now;setText(ui.coords,`${Math.floor(player.x)}, ${Math.floor(player.y)}, ${Math.floor(player.z)} · LIGHT ${$context.lightDisplay}/15`);
    }
    $context.fpsTime+=elapsed;$context.frames++;if($context.fpsTime>=.7){ui.fps.textContent=Math.round($context.frames/$context.fpsTime)+' FPS';$context.lightDisplay=getLightLevel(Math.floor(player.x),Math.floor(player.y+1),Math.floor(player.z));$context.frames=0;$context.fpsTime=0}
    if(now-$context.hudAt<1){setText(ui.biome,$context.dimension==='nether'?netherBiome(Math.floor(player.x),Math.floor(player.z)).replace(/_/g,' ').toUpperCase():$context.dimension==='end'?'THE END':underwater?'UNDERWATER':underground?(caveBiome(Math.floor(player.x),Math.floor(player.y),Math.floor(player.z))||'the_caves').replace(/_/g,' ').toUpperCase():terrain(Math.floor(player.x),Math.floor(player.z))<=SEA+1?'THE SHORE':biome(Math.floor(player.x),Math.floor(player.z)).replace(/_/g,' ').toUpperCase());
    const phase=(($context.tick/(Math.PI*2))%1+1)%1,hour=Math.floor((phase*24+6)%24),minute=Math.floor(phase*24*60%60);setText(ui.clock,`DAY ${Math.floor($context.tick/(Math.PI*2))+1} · ${String(hour).padStart(2,'0')}:${String(minute).padStart(2,'0')}`);}
  }
  $context.resourcePacks.tick(now/1000);$context.chestAnimation.tick(dt);drawWeather(dt);$context.gameplayRepairs.tick(dt,now);if(survival.isOpen()&&now-lastWorldRender<100)return;lastWorldRender=now;if($context.save.experiments&&portalWindow.count)portalWindow.render(info=>{const world=portalPreviewWorlds.get(info.previewKey);if(!world)return null;const targetAxis=portalDestinationAxis(world.target),mapped=mapPortalPoint(info,world.center,targetAxis,camera.position);const remoteUnderground=world.target==='overworld'&&inDimension('overworld',()=>mapped.y+1.43<terrain(Math.floor(mapped.x),Math.floor(mapped.z)));applyAtmosphere(world.scene,world.target,mapped.x,mapped.z,daylightNow,remoteUnderground,false,world.scene.userData.ambient,world.scene.userData.sun);inDimension(world.target,()=>{survival.prepareDimension(world.target);prepareVehicleDimension(world.target)});return {scene:world.scene,center:world.center,targetAxis,renderScene:render=>renderVehicleDimension(world.target,world.scene,()=>$context.multiplayer.renderDimension(world.target,world.scene,()=>survival.renderDimension(world.target,world.scene,render))),ready:[...world.chunks.values()].some(c=>c.meshes.length)}},now);$context.materials.endPortal.uniforms.time.value=now/1000;renderer.render(scene,camera);$context.firstPerson.render(dt);
}
return {showToast,awardAdvancement,blockSoundMaterial,playSound,playDisc,updateHotbar,saveGame,dragonDefeated,addChatMessage,openCommand,closeCommand,nearbyWorldProgress,updateWorldLoading,waitForNearbyWorld,pause,resume,playerAction,setText,frame};
}
