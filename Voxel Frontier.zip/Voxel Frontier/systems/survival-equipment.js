/** survival equipment subsystem. Dependencies are injected at composition time. */
export function createSurvivalEquipmentSystem($context) {
function blockProperty(f) {
    const {i} = $context;

    return i.BLOCK_PROPERTIES[f] || { hardness: 0.8, resistance: 1, tool: null, tier: 0, requiresTool: false };
  }

function properTool(f, tool) {
    const {blockProperty} = $context;

    let prop = blockProperty(f);
    return !prop.requiresTool || !!tool && tool.kind === prop.tool && tool.tier >= prop.tier;
  }

function oy(f) {
    const {A,Hn,S,a,blockProperty,properTool,vi} = $context;

    if (a.mode === "creative") return 0.05;
    let prop = blockProperty(f), hardness = prop.hardness;
    if (hardness < 0) return Infinity;
    if (hardness === 0) return 0.05;
    let tool = vi[Hn()], speed = tool?.kind === prop.tool ? tool.speed || 1 : 1, correct = properTool(f, tool), enchant = a.enchants?.[Hn()];
    if (speed > 1 && enchant?.kind === "Efficiency") speed += enchant.tier * enchant.tier + 1;
    if (A(Math.floor($context.n.x), Math.floor($context.n.y + 1.57), Math.floor($context.n.z)) === S) speed /= 5;
    if (!$context.n.grounded) speed /= 5;
    return Math.max(0.05, Math.ceil(hardness * (correct ? 30 : 100) / speed) / 20);
  }

function enchantmentTier(kind, level, enchantability) {
    let roll = Math.floor((enchantability || 1) / 4), modified = Math.round((level + 1 + Math.floor(Math.random() * (roll + 1)) + Math.floor(Math.random() * (roll + 1))) * (0.85 + Math.random() * 0.3)), step = kind === "Efficiency" ? 10 : 11;
    return Math.min(kind === "Protection" ? 4 : 5, Math.max(1, Math.floor((modified - 1) / step) + 1));
  }

function vo(f) {
    const {i} = $context;

    return `${i.getDimension()}:${f.x},${f.y},${f.z}`;
  }

function ay(f) {
    const {Be,Yn,a,i,vo} = $context;

    if(f.type===Be)i.ensureChestLoot?.(f);
    let b = a.chests?.[vo(f)];
    if (b) for (let R of b) R && Yn(R.id, f.x + 0.5, f.y + 0.7, f.z + 0.5, R.n);
    if(f.type===Be)i.clearChestLootReference?.(f);
    b && delete a.chests[vo(f)], a.crafterDisabled && delete a.crafterDisabled[vo(f)];
  }

function ry(f) {
    const {$1,B,Be,Bp,C,Ce,Db,Di,E,Ei,Et,Fs,Gt,Hn,Hp,Hr,Ht,Ks,Lt,Mt,Nt,Ob,Pc,Pe,Pi,Q,Qe,Qp,S,T,Tt,U,Wr,Yn,Ze,_,_n,a,ae,ay,be,blockProperty,ct,eE,ee,ef,eo,es,gi,gt,i,ie,it,k,kc,l,nf,nt,pb,pe,pn,properTool,r,rf,se,tf,to,vi,vo,w,wl,x,xe,yl} = $context;

    if (!f) return false;
    if(i.isDoor?.(f.type))i.breakDoorPartner?.(f.x,f.y,f.z,f.type);
    if(/ bed$/i.test(i.blockRegistry?.get(f.type)?.name||r[f.type]?.name||''))i.breakBedAny?.(f.type,f.x,f.y,f.z);
    let b = f.type, R = b === Et ? i.snowLayerCount(f.x, f.y, f.z) : 0;
    if (b === gi ? (l(f.x, f.y - 1, f.z, E), b = Nt) : b === Nt && l(f.x, f.y + 1, f.z, E), a.mode !== "creative" && (b === Ze || b === ee || b === T)) return $context.p("THIS BLOCK CANNOT BE MINED"), true;
    let v = vi[Hn()], N = v?.kind === "pick" ? v.tier : -1, V = blockProperty(b).tier, L = a.mode === "creative" || properTool(b, v);
    if ([Be, nf, Qp, ef, tf, Ks].includes(b) && ay(f), b === Pc || b === Hp) {
      let z = a.redstoneExtra?.[i.getDimension()]?.[`${f.x},${f.y},${f.z}`], H = b === Pc ? z?.book ? 1 : 0 : z?.books?.filter(Boolean).length || 0;
      if (a.mode === "survival") for (let q = 0; q < H; q++) Yn(Lt, f.x + 0.5, f.y + 0.6, f.z + 0.5);
    }
    if (b === rf) {
      let z = vo(f), H = a.jukeboxDiscs[z];
      H && a.mode === "survival" && Yn(H, f.x + 0.5, f.y + 0.7, f.z + 0.5), delete a.jukeboxDiscs[z], i.playDisc(false);
    }
    if (b === ae) {
      let z = vo(f), H = a.furnaceJobs[z], q = a.furnaceOutputs[z];
      H && Yn(H.input, f.x + 0.5, f.y + 0.7, f.z + 0.5), q && Yn(q.id, f.x + 0.5, f.y + 0.7, f.z + 0.5, q.n), delete a.furnaceJobs[z], delete a.furnaceOutputs[z], delete a.furnaceFuel[z];
    }
    if (!l(f.x, f.y, f.z, E)) return true;
    if ($context.m('break',b), $context.p(L ? `MINED ${(r[b]?.name || "block").toUpperCase()}` : "BLOCK BROKEN \u2014 NEED A STRONGER PICKAXE"), a.mode === "survival" && L) {
      let z = i.itemForBlock?.(b)??b, H = 1;
      b === Et ? (z = v?.kind === "shovel" ? Pi : 0, H = Math.max(1, Math.floor(R / 2))) : b === C ? z = _ : b === w ? z = Mt : b === x || b === Qe ? z = Bp : b === se || b === i.extraId("deepslate_copper_ore") ? (z = eE, H = 2 + Math.floor(Math.random() * 4)) : b === xe || b === i.extraId("deepslate_gold_ore") ? z = $1 : b === i.extraId("emerald_ore") || b === i.extraId("deepslate_emerald_ore") ? z = Gt : b === i.extraId("deepslate_diamond_ore") ? z = eo : b === i.extraId("deepslate_redstone_ore") ? (z = Ht, H = 3) : b === i.extraId("deepslate_lapis_ore") ? (z = Fs, H = 2) : b === i.extraId("nether_quartz_ore") ? z = yl : b === i.extraId("nether_gold_ore") ? (z = pb, H = 2 + Math.floor(Math.random() * 5)) : b === B || b === it || b === pe ? z = Math.random() < 0.18 ? Di : Math.random() < 0.2 ? wl : 0 : b === S || b === Q || b === k || b === kc ? z = 0 : b === Db ? z = Ob : b === Ce && Math.random() < 0.1 ? z = ie : b === be ? (z = Pe, H = 1 + Math.floor(Math.random() * 3), Yn(Ei, f.x + 0.5, f.y + 0.7, f.z + 0.5, 1 + Math.floor(Math.random() * 2))) : [Wr, _n, to].includes(b) ? z = Ei : b === U || b === ct ? z = Hr : b === Qe ? z = x : b === nt ? z = eo : b === gt ? (z = Ht, H = 3) : b === Tt && (z = Fs, H = 2), z && Yn(z, f.x + 0.5, f.y + 0.6, f.z + 0.5, H);
    }
    return v && v.kind !== "sword" && es(Hn()), true;
  }

function es(f,amount=1) {
    const {I,a,mt,r,vi} = $context;

    a.mode === "creative" || !vi[f] || (a.durability ??= {}, a.durability[f] = (a.durability[f] ?? vi[f].durability) - amount, a.durability[f] <= 0 && (mt(f), delete a.durability[f], $context.p(`${r[f].name.toUpperCase()} BROKE`)), I());
  }

function sy(f) {
    const {oy} = $context;

    return oy(f);
  }

function QE(f, b) {
    const {Zt,i} = $context;

    if (i.getDimension() === "nether") for (let R of Zt) R.type === "piglin" && Math.hypot(R.x - f, R.z - b) < 16 && (R.aggro = true, R.provoked = true, R.barterTime = 0);
  }

function Ay(f) {
    const {E,Hn,QE,Qe,Qh,Qs,Tt,U,Vp,Yn,a,addExhaustion,ct,gt,i,l,nt,oa,pf,properTool,ry,sE,se,vi,vo,x,xe} = $context;

    if (!f) return false;
    let b = f.type, R = vi[Hn()], v = R?.kind === "pick" ? R.tier : 0;
    if ([xe, i.extraId("gold_block"), i.extraId("nether_gold_ore")].includes(b) && QE(f.x, f.z), b === oa) {
      let V = vo(f), L = a.chests[V] || Array(27).fill(null);
      return delete a.chests[V], l(f.x, f.y, f.z, E), $context.m('break',b), a.mode === "survival" && Yn(oa, f.x + 0.5, f.y + 0.5, f.z + 0.5, 1, { slots: L }), $context.p("SHULKER BOX COLLECTED"), true;
    }
    if (b === Qs && a.mode !== "creative" && v < 3) return l(f.x, f.y, f.z, E), $context.m('break',b), $context.p("ANCIENT DEBRIS NEEDS A DIAMOND PICKAXE"), true;
    if (b === Qh) return l(f.x, f.y, f.z, E), $context.m('break',b), pf(f.x + 0.5, f.y + 0.5, f.z + 0.5, 15 + Math.floor(Math.random() * 29)), $context.p("MONSTER SPAWNER DESTROYED"), true;
    if (b === sE) return l(f.x, f.y, f.z, E), $context.m('break',b), Yn(Vp, f.x + 0.5, f.y + 0.5, f.z + 0.5, 2 + Math.floor(Math.random() * 3)), true;
    let N = ry(f);if(N)addExhaustion(.005);
    return N && a.mode === "survival" && properTool(b, R) && [x, Qe, se, U, ct, xe, nt, gt, Tt, Qs].includes(b) && pf(f.x + 0.5, f.y + 0.5, f.z + 0.5, b === nt ? 5 : 2), N;
  }

function attackProfile(consume=false){
    const {A,Hn,Q,S,a,addExhaustion,equipmentValues,i,meleeAttack,vi} = $context;

    const id=Hn();if(id!==$context.lastAttackItem){$context.attackElapsed=0;$context.lastAttackItem=id;}
    const wet=[S,Q].includes(A(Math.floor($context.n.x),Math.floor($context.n.y+.5),Math.floor($context.n.z)));
    const enchant=a.enchants[id];
    const profile=meleeAttack(equipmentValues[id]||vi[id],$context.attackElapsed,{critical:!$context.n.grounded&&$context.n.vy<0&&!$context.n.flight&&!wet&&!a.effects.blindness,sprinting:i.isSprinting(),strength:a.effects.strength?1:0,sharpness:enchant?.kind==='Sharpness'?enchant.tier:0});
    if(consume)$context.attackElapsed=0;
    if(consume)addExhaustion(.1);return profile;
  }

function consumeAttack(){
    const {Hn,attackProfile,es,vi} = $context;
const profile=attackProfile(true),id=Hn();if(vi[id])es(id,vi[id].kind==='sword'?1:2);return profile;}

function beginBow(){
    const {Hn,Le,Ml,Pi,Zr,a,e,ka,mt,o,ve,wn} = $context;

    if(Hn()===Ml){if(a.mode!=='creative'&&!mt(Ml))return true;const direction=new e.Vector3();o.getWorldDirection(direction);const mesh=new e.Mesh(new e.SphereGeometry(.12,8,6),ka(0x238a7e));mesh.position.copy(o.position).addScaledVector(direction,.35);$context.t.add(mesh);Zr.push({kind:'pearl',playerShot:false,mesh,x:mesh.position.x,y:mesh.position.y,z:mesh.position.z,vx:direction.x*28,vy:direction.y*28,vz:direction.z*28,age:0});$context.m('bow');return true;}
    if(Hn()===Pi){if(!mt(Pi))return true;const direction=new e.Vector3();o.getWorldDirection(direction);const mesh=new e.Mesh(new e.SphereGeometry(.1,6,4),ka(0xffffff));mesh.position.copy(o.position).addScaledVector(direction,.35);$context.t.add(mesh);Zr.push({kind:'snowball',playerShot:true,mesh,x:mesh.position.x,y:mesh.position.y,z:mesh.position.z,vx:direction.x*30,vy:direction.y*30,vz:direction.z*30,age:0,origin:{x:$context.n.x,z:$context.n.z}});return true;}
    if(Hn()!==ve)return false;if(wn(Le)||a.mode==='creative')$context.bowHeld=0;return true;
  }

function releaseBow(){
    const {Hn,Le,Zr,a,arrowModel,bowPower,e,es,mt,o,ve} = $context;

    if($context.bowHeld===null)return;const charge=bowPower($context.bowHeld);$context.bowHeld=null;
    if(Hn()!==ve||charge<.1||a.mode!=='creative'&&!mt(Le))return;
    const direction=new e.Vector3();o.getWorldDirection(direction);const mesh=arrowModel();mesh.position.copy(o.position).addScaledVector(direction,.35);$context.t.add(mesh);
    Zr.push({kind:'arrow',playerShot:true,critical:charge===1,mesh,x:mesh.position.x,y:mesh.position.y,z:mesh.position.z,vx:direction.x*60*charge,vy:direction.y*60*charge,vz:direction.z*60*charge,age:0,origin:{x:$context.n.x,z:$context.n.z}});es(ve);$context.m('bow');
  }
return {blockProperty,properTool,oy,enchantmentTier,vo,ay,ry,es,sy,QE,Ay,attackProfile,consumeAttack,beginBow,releaseBow};
}
