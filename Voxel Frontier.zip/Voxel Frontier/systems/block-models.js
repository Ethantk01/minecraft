/** block models subsystem. Dependencies are injected at composition time. */
export function createBlockModelsSystem($context) {
function faceUV(type,face,x=0,z=0,y=0){
    const {REDSTONE_LAMP,atlasMap,atlasUVCache,blockTexture,editKey,redstoneLevels} = $context;
const texture=type===REDSTONE_LAMP&&redstoneLevels.get(editKey(x,y,z))?'redstone_lamp_on':typeof type==='string'?type:blockTexture(type,face,x,z),tile=atlasMap.tiles[texture]||0;let rect=atlasUVCache.get(tile);if(!rect){const col=tile%atlasMap.columns,row=Math.floor(tile/atlasMap.columns),w=atlasMap.columns*16,h=atlasMap.rows*16;rect=[(col*16+.35)/w,1-((row+1)*16-.35)/h,((col+1)*16-.35)/w,1-(row*16+.35)/h];atlasUVCache.set(tile,rect)}return rect}

function partUV(face,v,rect){const [u0,v0,u1,v1]=rect;let u,t;if(face===0){u=v[2];t=v[1]}else if(face===1){u=1-v[2];t=v[1]}else if(face===2){u=v[0];t=1-v[2]}else if(face===3){u=v[0];t=v[2]}else if(face===4){u=1-v[0];t=v[1]}else{u=v[0];t=v[1]}return [u0+(u1-u0)*u,v0+(v1-v0)*t]}

function rotateModelPoint(point,rotation){if(Array.isArray(rotation))return rotation.reduce((value,step)=>rotateModelPoint(value,step),point);if(!rotation)return point;const [ox,oy,oz]=rotation.origin,angle=rotation.angle*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle),scale=rotation.rescale?1/Math.max(.001,Math.abs(c)):1,x=(point[0]-ox)*(rotation.axis==='x'?1:scale),y=(point[1]-oy)*(rotation.axis==='y'?1:scale),z=(point[2]-oz)*(rotation.axis==='z'?1:scale);if(rotation.axis==='x')return [x+ox,y*c-z*s+oy,y*s+z*c+oz];if(rotation.axis==='y')return [x*c+z*s+ox,y+oy,-x*s+z*c+oz];return [x*c-y*s+ox,x*s+y*c+oy,z+oz]}

function railSlopePoint(point,slope){if(!slope)return point;const [x,y,z]=point;return [x,y+(slope[0]?slope[0]>0?x:1-x:slope[1]>0?z:1-z),z]}

function modelUV(face,vertex,spec){
    const {faceUV,partUV} = $context;
let [u,v]=partUV(face,vertex,[0,0,1,1]);for(let i=0;i<(spec.rotation||0)/90;i++)[u,v]=[1-v,u];const [u0,v0,u1,v1]=spec.uv,rect=faceUV(spec.tile);return [rect[0]+(rect[2]-rect[0])*(u0+(u1-u0)*u)/16,rect[1]+(rect[3]-rect[1])*(1-(v1+(v0-v1)*v)/16)]}

function curvedRailParts(shape,lod){
  const east=shape.directions.some(d=>d[0]===1),north=shape.directions.some(d=>d[1]===-1),flipX=!east,flipZ=north,rotation=east?(north?270:0):north?180:90;
  const transform=(x,z)=>[flipX?1-x:x,flipZ?1-z:z],point=(radius,angle)=>transform(1-radius*Math.sin(angle),1-radius*Math.cos(angle));
  const parts=[{kind:'box',bounds:[0,0,0,1,.01,1],faces:{2:{tile:'rail_corner',uv:[0,0,16,16],rotation}}}];
  const segment=(a,b,width,bottom,top,tile,uv)=>{const mx=(a[0]+b[0])/2,mz=(a[1]+b[1])/2,length=Math.hypot(b[0]-a[0],b[1]-a[1]),angle=-Math.atan2(b[1]-a[1],b[0]-a[0])*180/Math.PI,spec={tile,uv,rotation:0};parts.push({kind:'box',bounds:[mx-length/2,bottom,mz-width/2,mx+length/2,top,mz+width/2],rotation:{axis:'y',angle,origin:[mx,0,mz]},faces:{0:spec,1:spec,2:spec,3:spec,4:spec,5:spec}})};
  const steps=lod?5:10;
  for(const radius of [.1875,.8125])for(let i=0;i<steps;i++){const a=point(radius,i*Math.PI/(2*steps)),b=point(radius,(i+1)*Math.PI/(2*steps));segment(a,b,.125,.055,.125,'default3d_rail',[2,0,4,16])}
  for(const angle of [.2,.58,.98,1.36])segment(point(.06,angle),point(.94,angle),.125,.015,.065,'default3d_rail_wood',[1,0,15,2]);
  return parts
}

function wireConnections(x,y,z){
    const {CALIBRATED_SCULK_SENSOR,COMPARATOR,DAYLIGHT_DETECTOR,DETECTOR_RAIL,HEAVY_WEIGHTED_PLATE,LEVER,LIGHT_WEIGHTED_PLATE,OBSERVER,REDSTONE_BLOCK,REDSTONE_TORCH,REDSTONE_WIRE,REPEATER,SCULK_SENSOR,STONE_BUTTON,STONE_PRESSURE_PLATE,TARGET,TRAPPED_CHEST,TRIPWIRE_HOOK,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE,editKey,getBlock,occludes} = $context;

  const result={east:'none',west:'none',south:'none',north:'none'};
  for(const [name,dx,dz] of [['east',1,0],['west',-1,0],['south',0,1],['north',0,-1]]){
    const nx=x+dx,nz=z+dz,neighbor=getBlock(nx,y,nz),facing=$context.save.redstoneFacing[editKey(nx,y,nz)]||[0,-1];
    const axisMatches=facing[0]!==0?dx!==0:dz!==0;
    if(neighbor===REDSTONE_WIRE||[REDSTONE_BLOCK,LEVER,REDSTONE_TORCH,STONE_BUTTON,STONE_PRESSURE_PLATE,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE,LIGHT_WEIGHTED_PLATE,HEAVY_WEIGHTED_PLATE,DAYLIGHT_DETECTOR,TARGET,TRAPPED_CHEST,TRIPWIRE_HOOK,SCULK_SENSOR,CALIBRATED_SCULK_SENSOR,DETECTOR_RAIL].includes(neighbor)||[REPEATER,COMPARATOR].includes(neighbor)&&axisMatches||neighbor===OBSERVER&&facing[0]===dx&&facing[1]===dz){result[name]='side';continue}
    if(occludes(neighbor)&&!occludes(getBlock(x,y+1,z))&&getBlock(nx,y+1,nz)===REDSTONE_WIRE){result[name]='up';continue}
    if(!occludes(neighbor)&&getBlock(nx,y-1,nz)===REDSTONE_WIRE)result[name]='side';
  }
  const eastWest=result.east!=='none'||result.west!=='none',northSouth=result.north!=='none'||result.south!=='none';
  if(eastWest&&!northSouth){if(result.east==='none')result.east='side';if(result.west==='none')result.west='side'}
  if(northSouth&&!eastWest){if(result.north==='none')result.north='side';if(result.south==='none')result.south='side'}
  return result;
}

function wireParts(x,y,z){
    const {wireConnections} = $context;

  const connections=wireConnections(x,y,z),parts=[{kind:'box',bounds:[0,.046875,0,1,.0546875,1],faces:{2:{tile:'redstone_dust_dot',uv:[0,0,16,16],rotation:0}}}];
  const line=(bounds,rotation=0)=>parts.push({kind:'box',bounds,faces:{2:{tile:'redstone_dust_line0',uv:[0,0,16,16],rotation}}});
  if(connections.north!=='none')line([0,.046875,0,1,.0546875,.5]);
  if(connections.south!=='none')line([0,.046875,.5,1,.0546875,1]);
  if(connections.west!=='none')line([0,.046875,0,.5,.0546875,1],90);
  if(connections.east!=='none')line([.5,.046875,0,1,.0546875,1],90);
  for(const [name,face,bounds] of [['east',1,[.995,.046875,.375,1.003,1.05,.625]],['west',0,[-.003,.046875,.375,.005,1.05,.625]],['south',5,[.375,.046875,.995,.625,1.05,1.003]],['north',4,[.375,.046875,-.003,.625,1.05,.005]]])if(connections[name]==='up')parts.push({kind:'box',bounds,faces:{[face]:{tile:'redstone_dust_line0',uv:[0,0,16,16],rotation:0}}});
  return parts;
}

function pistonDirection(k){const direction=$context.save.pistonDirections[k];return direction?.length===3?direction:direction?.length===2?[direction[0],0,direction[1]]:[0,0,-1]}

function mirrorModelZ(part){const [x,y,z,X,Y,Z]=part.bounds,faces={};for(const [key,spec] of Object.entries(part.faces)){const face=Number(key),target=face===4?5:face===5?4:face;faces[target]=face===0||face===1?{...spec,uv:[spec.uv[2],spec.uv[1],spec.uv[0],spec.uv[3]]}:spec}return {...part,bounds:[x,y,1-Z,X,Y,1-z],faces}}

function torchModelParts(type,x,y,z){
    const {REDSTONE_TORCH,default3dParts,editKey,redstoneData,redstoneLevels,torchStates} = $context;

  const k=editKey(x,y,z),red=type===REDSTONE_TORCH,support=red?($context.save.redstoneTorchSupports[k]||[0,-1,0]):(redstoneData()[k]?.support||[0,-1,0]),wall=support[1]===0,lit=!red||($context.multiplayer?.guest?redstoneLevels.has(k):torchStates.get(k)!==false);
  const name=red?(wall?'redstone_wall_torch':'redstone_torch')+(lit?'':'_off'):(wall?'wall_torch':'torch'),turn=wall?{axis:'y',angle:support[0]<0?0:support[0]>0?180:support[2]<0?-90:90,origin:[.5,.5,.5]}:null;
  return default3dParts.get('vanilla_'+name).map(part=>({...part,rotation:[part.rotation,turn].filter(Boolean)}));
}

function cardinalName([dx,dz]){return dx>0?'east':dx<0?'west':dz>0?'south':'north'}

function blockParts(type,x,y,z,lod=0){
    const override=$context.blockRegistry.dispatch('model',type,{x,y,z,lod});
    if(override.handled)return override.value;
    const {ACTIVATOR_RAIL,ANVIL,AZALEA,BED,BEE_NEST,BIG_DRIPLEAF,BREWING_STAND,CACTUS,CALIBRATED_SCULK_SENSOR,CHEST,CHISELED_BOOKSHELF,COMPARATOR,COPPER_BULB,CRAFTER,CRIMSON_FUNGUS,CRIMSON_ROOTS,CROP_0,CROP_1,CROP_2,DAYLIGHT_DETECTOR,DETECTOR_RAIL,DISPENSER,DOOR,DOOR_TOP,DROPPER,ENCHANTING_TABLE,END_FRAME,END_PORTAL,FARMLAND,FIRE,FLOWERING_AZALEA,GLOW_BERRIES,HANGING_ROOTS,HEAVY_WEIGHTED_PLATE,HOPPER,IRON_TRAPDOOR,LADDER,LECTERN,LEVER,LIGHTNING_ROD,LIGHT_WEIGHTED_PLATE,MEADOW_FLOWER,MOSS_CARPET,NETHER_PORTAL,NETHER_WART_CROP,OAK_TRAPDOOR,OBSERVER,OBSIDIAN,PISTON,PISTON_HEAD,POINTED_DRIPSTONE_DOWN,POINTED_DRIPSTONE_UP,POWERED_RAIL,RAIL_TYPES,REDSTONE_TORCH,REDSTONE_WIRE,REPEATER,SAPLING,SCULK_SENSOR,SHULKER_BOX,SMALL_DRIPLEAF,SNOW,SPORE_BLOSSOM,STICKY_PISTON,STONECUTTER,STONE_BUTTON,STONE_PRESSURE_PLATE,TORCH,TRAPPED_CHEST,TRIPWIRE,TRIPWIRE_HOOK,TWISTING_VINES,WARPED_FUNGUS,WARPED_ROOTS,WEEPING_VINES,WHEAT_CROP,WOODEN_BUTTON,WOODEN_PRESSURE_PLATE,bedState,blockModelStates,cardinalName,curvedRailParts,default3dIds,default3dParts,doorInfo,editKey,getBlock,hasEndEye,isDoor,mirrorModelZ,modelBlockTypes,pistonDirection,railShape,redstoneData,redstoneLevels,sensorUntil,snowLayerCount,structureParts,torchModelParts,wireParts} = $context;

  if(structureParts.has(type)&&!isDoor(type))return structureParts.get(type);
  if(!modelBlockTypes.has(type))return null;
  const box=(a,b,c,d,e,f,texture)=>({kind:'box',bounds:[a,b,c,d,e,f],texture});
  const cross=(height,texture)=>({kind:'cross',height,texture});
  const modelName=default3dIds.get(type);
  if(type===REDSTONE_WIRE)return wireParts(x,y,z);
  if(RAIL_TYPES.has(type)){const shape=railShape(x,y,z),active=(type===POWERED_RAIL||type===DETECTOR_RAIL||type===ACTIVATOR_RAIL)&&redstoneLevels.get(editKey(x,y,z)),uphill=shape.directions.find(d=>d[2]>0),slope=uphill?[uphill[0],uphill[1]]:null;if(shape.axis==='curve')return curvedRailParts(shape,lod);if(lod>0){const rotation=shape.axis==='x'?90:0,tile=type===POWERED_RAIL?(active?'powered_rail_on':'powered_rail'):type===DETECTOR_RAIL?(active?'detector_rail_on':'detector_rail'):type===ACTIVATOR_RAIL?(active?'activator_rail_on':'activator_rail'):'rail';return [{kind:'box',bounds:[0,0,0,1,.0625,1],slope,faces:{2:{tile,uv:[0,0,16,16],rotation}}}]}const turn=shape.axis==='x'?{axis:'y',angle:90,origin:[.5,.5,.5]}:null,variant=active?(type===POWERED_RAIL?'powered_rail_on':type===DETECTOR_RAIL?'detector_rail_on':'activator_rail_on'):modelName;return default3dParts.get(variant).map(part=>({...part,rotation:turn||part.rotation,slope}))}
  if(type===PISTON||type===STICKY_PISTON){
    const [dx,dy,dz]=pistonDirection(editKey(x,y,z));
    const extended=getBlock(x+dx,y+dy,z+dz)===PISTON_HEAD;
    const angle=dy?dy>0?90:-90:dx?dx>0?-90:90:dz>0?180:0;
    const rotation={axis:dy?'x':'y',angle,origin:[.5,.5,.5]};
    return default3dParts.get(extended?'piston_extended':'piston_retracted').map(part=>({
      ...part,rotation,
      faces:type===STICKY_PISTON&&!extended?Object.fromEntries(Object.entries(part.faces).map(([face,spec])=>[face,spec.tile==='piston_top'?{...spec,tile:'piston_top_sticky'}:spec])):part.faces
    }));
  }
  if(type===OBSERVER){const [dx,,dz]=[($context.save.redstoneFacing[editKey(x,y,z)]||[0,-1])[0],0,($context.save.redstoneFacing[editKey(x,y,z)]||[0,-1])[1]],front=dx>0?0:dx<0?1:dz>0?4:5,back=[1,0,3,2,5,4][front];const faces=Object.fromEntries([0,1,2,3,4,5].map(face=>[face,{tile:face===front?'observer_front':face===back?(redstoneLevels.get(editKey(x,y,z))?'observer_back_on':'observer_back'):face===2||face===3?'observer_top':'observer_side',uv:[0,0,16,16],rotation:0}]));return [{kind:'box',bounds:[0,0,0,1,1,1],faces}]}
  if(type===DISPENSER||type===DROPPER||type===CRAFTER){const direction=redstoneData()[editKey(x,y,z)]?.facing||[0,0,-1],front=direction[1]>0?2:direction[1]<0?3:direction[0]>0?0:direction[0]<0?1:direction[2]>0?4:5,faces=Object.fromEntries([0,1,2,3,4,5].map(face=>[face,{tile:type===CRAFTER?face===2?'crafter_top':face===3?'crafter_bottom':face===front?'crafter_north':'crafter_east':face===front?(type===DISPENSER?'dispenser_front':'dropper_front'):face===2||face===3?'furnace_top':'furnace_side',uv:[0,0,16,16],rotation:0}]));return [{kind:'box',bounds:[0,0,0,1,1,1],faces}]}
  if(type===PISTON_HEAD){
    let [dx,dy,dz]=[0,0,-1],sticky=false;
    for(const [ax,ay,az] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){
      const px=x-ax,py=y-ay,pz=z-az,base=getBlock(px,py,pz);
      if(base!==PISTON&&base!==STICKY_PISTON)continue;
      const facing=pistonDirection(editKey(px,py,pz));
      if(facing[0]===ax&&facing[1]===ay&&facing[2]===az){dx=ax;dy=ay;dz=az;sticky=base===STICKY_PISTON;break}
    }
    const angle=dy?dy>0?90:-90:dx?dx>0?-90:90:dz>0?180:0;
    const rotation={axis:dy?'x':'y',angle,origin:[.5,.5,.5]};
    return default3dParts.get('piston_head').map(part=>({
      ...part,rotation,
      faces:sticky?Object.fromEntries(Object.entries(part.faces).map(([face,spec])=>[face,spec.tile==='piston_top'?{...spec,tile:'piston_top_sticky'}:spec])):part.faces
    }));
  }
  if(type===TORCH||type===REDSTONE_TORCH)return torchModelParts(type,x,y,z);
  if(type===STONE_BUTTON)return [box(.3125,0,.375,.6875,redstoneLevels.has(editKey(x,y,z))?.0625:.125,.625,'stone')];
  if(type===STONE_PRESSURE_PLATE)return [box(.0625,0,.0625,.9375,redstoneLevels.get(editKey(x,y,z))?.03125:.0625,.9375,'stone')];
  if(type===WOODEN_BUTTON)return [box(.3125,0,.375,.6875,redstoneLevels.has(editKey(x,y,z))?.0625:.125,.625,'oak_planks')];
  if([WOODEN_PRESSURE_PLATE,LIGHT_WEIGHTED_PLATE,HEAVY_WEIGHTED_PLATE].includes(type)){const tile=type===WOODEN_PRESSURE_PLATE?'oak_planks':type===LIGHT_WEIGHTED_PLATE?'gold_block':'iron_block';return [box(.0625,0,.0625,.9375,redstoneLevels.get(editKey(x,y,z))?.03125:.0625,.9375,tile)]}
  if(type===DAYLIGHT_DETECTOR)return [box(0,0,0,1,.375,1,'daylight_detector_side',{2:{tile:redstoneData()[editKey(x,y,z)]?.inverted?'daylight_detector_inverted_top':'daylight_detector_top',uv:[0,0,16,16]},0:{tile:'daylight_detector_side',uv:[0,0,16,6]},1:{tile:'daylight_detector_side',uv:[0,0,16,6]},4:{tile:'daylight_detector_side',uv:[0,0,16,6]},5:{tile:'daylight_detector_side',uv:[0,0,16,6]},3:{tile:'oak_planks',uv:[0,0,16,16]}})];
  if(type===HOPPER){const [dx,dy,dz]=redstoneData()[editKey(x,y,z)]?.facing||[0,-1,0];const neck=dy<0?box(.375,0,.375,.625,.25,.625,'hopper_outside'):box(dx>0?.625:dx<0?0:.375,.1875,dz>0?.625:dz<0?0:.375,dx>0?1:dx<0?.375:.625,.4375,dz>0?1:dz<0?.375:.625,'hopper_outside');return [box(.125,.625,.125,.875,1,.875,'hopper_top'),box(.25,.25,.25,.75,.625,.75,'hopper_outside'),neck]}
  if(type===TRIPWIRE_HOOK){const [dx,,dz]=redstoneData()[editKey(x,y,z)]?.facing||[0,0,1],angle=dx>0?90:dx<0?-90:dz<0?180:0,turn={axis:'y',angle,origin:[.5,.5,.5]};return [box(.375,.2,.02,.625,.55,.18,'tripwire_hook'),box(.4375,.36,.15,.5625,.66,.48,'tripwire_hook')].map(part=>({...part,rotation:turn}))}
  if(type===TRIPWIRE){const alongZ=[getBlock(x,y,z-1),getBlock(x,y,z+1)].some(id=>id===TRIPWIRE||id===TRIPWIRE_HOOK),alongX=[getBlock(x-1,y,z),getBlock(x+1,y,z)].some(id=>id===TRIPWIRE||id===TRIPWIRE_HOOK);return [alongZ&&!alongX?box(.47,.055,0,.53,.068,1,'tripwire'):box(0,.055,.47,1,.068,.53,'tripwire')]}
  if(type===SCULK_SENSOR||type===CALIBRATED_SCULK_SENSOR){const tile=type===SCULK_SENSOR?'sculk_sensor_top':'calibrated_sculk_sensor_top',active=(sensorUntil.get(editKey(x,y,z))||0)>performance.now();return [box(0,0,0,1,.5,1,tile),box(.08,.5,.08,.24,.72,.24,active?'sculk_sensor_tendril_active':'sculk_sensor_tendril_inactive'),box(.76,.5,.76,.92,.72,.92,active?'sculk_sensor_tendril_active':'sculk_sensor_tendril_inactive')]}
  if(type===OAK_TRAPDOOR||type===IRON_TRAPDOOR){const open=!!redstoneData()[editKey(x,y,z)]?.open,tile=type===OAK_TRAPDOOR?'oak_trapdoor':'iron_trapdoor';return [open?box(0,0,0,.1875,1,1,tile):box(0,0,0,1,.1875,1,tile)]}
  if(type===COPPER_BULB){const state=redstoneData()[editKey(x,y,z)]||{},tile=state.lit?(state.powered?'copper_bulb_lit_powered':'copper_bulb_lit'):(state.powered?'copper_bulb_powered':'copper_bulb');return [box(0,0,0,1,1,1,tile)]}
  if(type===REPEATER||type===COMPARATOR){const k=editKey(x,y,z),[dx,dz]=$context.save.redstoneFacing[k]||[0,-1],turn={axis:'y',angle:-Math.atan2(dx,-dz)*180/Math.PI,origin:[.5,0,.5]},active=!!redstoneLevels.get(k),tile=type===REPEATER?(active?'repeater_on':'repeater'):(active?'comparator_on':'comparator'),parts=[box(0,0,0,1,.125,1,tile),box(.4375,.125,.19,.5625,.375,.315,active?'redstone_torch':'redstone_torch_off')];if(type===REPEATER)parts.push(box(.4375,.125,.61,.5625,.375,.735,'redstone_torch'));else for(const side of [.25,.75])parts.push(box(side-.0625,.125,.61,side+.0625,.375,.735,'redstone_torch'));return parts.map(part=>({...part,rotation:turn}))}
  if(type===CHEST||type===TRAPPED_CHEST){const facing=redstoneData()[editKey(x,y,z)]?.facing||[0,1],turn={axis:'y',angle:Math.atan2(facing[0],facing.length===3?facing[2]:facing[1])*180/Math.PI,origin:[.5,.5,.5]};const angle=$context.chestAnimation?.angle($context.dimension+':'+editKey(x,y,z))||0;return default3dParts.get(modelName).map((part,index)=>({...part,rotation:index>0?[{axis:'x',angle,origin:[.5,.625,.0625]},turn]:turn}))}
  if(type===LEVER){
    const k=editKey(x,y,z),state=redstoneData()[k]||{},support=state.support||[0,-1,0],facing=state.facing||[0,-1];
    const direction=support[1]===0?[-support[0],-support[2]]:[facing[0],facing.length===3?facing[2]:facing[1]],name=cardinalName(direction),face=support[1]===0?'wall':support[1]>0?'ceiling':'floor';
    const variant=blockModelStates.lever.variants[`face=${face},facing=${name},powered=${!!$context.save.levers[k]}`];
    const turns=[{axis:'x',angle:-(variant.x||0),origin:[.5,.5,.5]},{axis:'y',angle:-(variant.y||0),origin:[.5,.5,.5]}];
    return default3dParts.get(variant.model.endsWith('lever_on')?'lever_on':'lever').map(part=>({...part,rotation:[part.rotation,...turns].filter(Boolean)}));
  }
  if(isDoor(type)){
    const info=doorInfo(type),upper=info.half==='upper',k=editKey(x,upper?y-1:y,z),state=redstoneData()[k]||{facing:({north:[0,-1],south:[0,1],west:[-1,0],east:[1,0]})[info.props.facing]||[0,-1],hinge:info.props.hinge},facing=state.facing||[0,-1],name=cardinalName([facing[0],facing.length===3?facing[2]:facing[1]]),hinge=state.hinge==='right'?'right':'left';
    const variant=blockModelStates.oak_door.variants[`facing=${name},half=${upper?'upper':'lower'},hinge=${hinge},open=${!!$context.save.openDoors?.[k]}`];
    const turn={axis:'y',angle:-(variant.y||0),origin:[.5,.5,.5]};
    return default3dParts.get(upper?'oak_door_top':'oak_door_bottom').map(source=>{const part=hinge==='right'?mirrorModelZ(source):source,faces=info.name==='oak_door'?part.faces:Object.fromEntries(Object.entries(part.faces).map(([f,spec])=>[f,{...spec,tile:`structure_block_${info.name}_${upper?'top':'bottom'}`} ]));return {...part,faces,rotation:[part.rotation,turn].filter(Boolean)}});
  }
  if(modelName&&(lod===0||type===MEADOW_FLOWER)&&((type!==DOOR&&type!==DOOR_TOP)||!$context.save.openDoors?.[editKey(x,type===DOOR?y:y-1,z)])){const parts=default3dParts.get(modelName);if(type===MEADOW_FLOWER)return parts.map(part=>({...part,faces:Object.fromEntries(Object.entries(part.faces).map(([face,spec])=>[face,{...spec,tile:'oxeye_daisy'}]))}));return type===END_FRAME&&hasEndEye(x,y,z)?[...parts,box(.3125,.8125,.3125,.6875,1,.6875,'end_portal_frame_eye')]:parts}
  if(type===TORCH)return [box(.4375,0,.4375,.5625,.65,.5625,'torch_stick_model'),box(.4,.65,.4,.6,.81,.6,'torch_flame_model')];
  if(type===CHEST)return [box(.0625,.0625,.0625,.9375,.875,.9375)];
  if(type===END_FRAME)return hasEndEye(x,y,z)?[box(0,0,0,1,.8125,1),box(.3125,.8125,.3125,.6875,1,.6875,'end_portal_frame_eye')]:[box(0,0,0,1,.8125,1)];
  if(type===FARMLAND)return [box(0,0,0,1,.9375,1)];
  if(type===SNOW)return [box(0,0,0,1,snowLayerCount(x,y,z)/8,1)];
  if(type===CACTUS)return [box(.0625,0,.0625,.9375,1,.9375)];
  if(type===WHEAT_CROP||type===CROP_0||type===CROP_1||type===CROP_2)return [cross(type===CROP_0?.3:type===CROP_1?.5:type===CROP_2?.7:.875)];
  if(type===SAPLING)return [cross(.85)];
  if(type===CRIMSON_ROOTS||type===WARPED_ROOTS)return [cross(.7)];
  if(type===CRIMSON_FUNGUS||type===WARPED_FUNGUS)return [cross(.62)];
  if(type===TWISTING_VINES||type===WEEPING_VINES)return [cross(1)];
  if(type===FIRE)return [cross(1)];
  if(type===LADDER)return [box(0,0,.86,1,1,.91)];
  if(type===BED){const state=bedState(x,y,z),[dx,dz]=state.facing,rotation={axis:'y',angle:Math.atan2(-dx,-dz)*180/Math.PI,origin:[.5,.5,.5]};return default3dParts.get('bed_'+state.bedPart).map(part=>({...part,rotation}))}
  if(type===NETHER_PORTAL){const alongX=[-1,1].some(dx=>[NETHER_PORTAL,OBSIDIAN].includes(getBlock(x+dx,y,z))),alongZ=[-1,1].some(dz=>[NETHER_PORTAL,OBSIDIAN].includes(getBlock(x,y,z+dz)));return [alongX&&!alongZ?box(0,0,.4375,1,1,.5625):box(.4375,0,0,.5625,1,1)]};
  if(type===END_PORTAL)return [box(0,.6875,0,1,.75,1)];
  if(type===REDSTONE_WIRE)return [box(0,0,0,1,.045,1,'redstone_dust_dot')];
  if(type===ENCHANTING_TABLE)return [box(0,0,0,1,.75,1),box(.22,.75,.22,.78,.84,.78,'enchanting_table_top')];
  if(type===ANVIL)return [box(.18,0,.18,.82,.25,.82),box(.35,.25,.35,.65,.75,.65),box(.12,.75,.2,.88,1,.8,'anvil_top')];
  if(type===BREWING_STAND)return [box(.12,0,.12,.88,.125,.88,'brewing_stand_base'),box(.44,.125,.44,.56,.82,.56,'brewing_stand'),box(.31,.48,.31,.69,.57,.69,'brewing_stand')];
  if(RAIL_TYPES.has(type))return [box(0,0,0,1,.0625,1)];
  if(type===SHULKER_BOX)return [box(0,0,0,1,.95,1)];
  if(type===NETHER_WART_CROP)return [cross(.65)];
  if(type===MEADOW_FLOWER)return [cross(.85)];
  if(type===STONECUTTER)return [box(0,0,0,1,.56,1),box(.44,.56,.12,.56,1,.88,'stonecutter_saw')];
  if(type===POINTED_DRIPSTONE_UP||type===POINTED_DRIPSTONE_DOWN)return [cross(1)];
  if(type===AZALEA||type===FLOWERING_AZALEA)return [box(.375,0,.375,.625,.5,.625,'oak_log'),box(.125,.42,.125,.875,.9,.875,type===AZALEA?'azalea_plant':'flowering_azalea_leaves')];
  if(type===GLOW_BERRIES||type===HANGING_ROOTS)return [cross(1)];
  if(type===SPORE_BLOSSOM)return [box(.18,.9,.18,.82,1,.82)];
  if(type===BIG_DRIPLEAF||type===SMALL_DRIPLEAF)return [box(.46,0,.46,.54,.84,.54,'big_dripleaf_stem'),box(.06,.83,.06,.94,.91,.94)];
  if(type===MOSS_CARPET)return [box(0,0,0,1,.0625,1)];
  if(type===BEE_NEST)return [box(.0625,.125,.0625,.9375,.875,.9375)];
  if(type===LIGHTNING_ROD)return [box(.4375,0,.4375,.5625,.125,.5625,'lightning_rod'),box(.46875,.125,.46875,.53125,.875,.53125,'lightning_rod'),box(.4375,.875,.4375,.5625,1,.5625,'lightning_rod')];
  if(type===LECTERN)return [box(.125,0,.125,.875,.125,.875,'lectern_base'),box(.375,.125,.375,.625,.75,.625,'lectern_sides'),box(.125,.75,.125,.875,.875,.875,'lectern_top')];
  if(type===CHISELED_BOOKSHELF){const occupied=redstoneData()[editKey(x,y,z)]?.books?.some(Boolean);return [{kind:'box',bounds:[0,0,0,1,1,1],faces:Object.fromEntries([0,1,2,3,4,5].map(face=>[face,{tile:face===2?'chiseled_bookshelf_top':face===5?occupied?'chiseled_bookshelf_occupied':'chiseled_bookshelf_empty':'chiseled_bookshelf_side',uv:[0,0,16,16],rotation:0}]))}]}
  return null;
}

function quadNormals(positions){
  const result=new Float32Array(positions.length);
  for(let i=0;i<positions.length;i+=12){
    const ax=positions[i+3]-positions[i],ay=positions[i+4]-positions[i+1],az=positions[i+5]-positions[i+2];
    const bx=positions[i+6]-positions[i],by=positions[i+7]-positions[i+1],bz=positions[i+8]-positions[i+2];
    const nx=ay*bz-az*by,ny=az*bx-ax*bz,nz=ax*by-ay*bx,length=Math.hypot(nx,ny,nz)||1;
    for(let j=0;j<12;j+=3){result[i+j]=nx/length;result[i+j+1]=ny/length;result[i+j+2]=nz/length;}
  }
  return result;
}

function appendModelBox(bucket,type,wx,y,wz,x0,y0,z0,x1,y1,z1,override,modelFaces,rotation,slope){
    const {BLOCKS,colorFor,faceUV,faces,getBlock,modelUV,occludes,partUV,railSlopePoint,rotateModelPoint} = $context;
for(let f=0;f<6;f++){const spec=modelFaces?.[f];if(modelFaces&&!spec)continue;if(BLOCKS[type]?.shaped===false&&x0===0&&y0===0&&z0===0&&x1===1&&y1===1&&z1===1){const center=rotateModelPoint([.5,.5,.5],rotation),normal=rotateModelPoint(faces[f].d.map(v=>v+.5),rotation).map((v,a)=>Math.round(v-center[a]));if(occludes(getBlock(wx+normal[0],y+normal[1],wz+normal[2])))continue}const q=bucket.p.length/3,uv=modelFaces?null:faceUV(override||type,f,wx,wz,y),col=colorFor(type,f,wx,y,wz);for(const v of faces[f].v){const point=rotateModelPoint([x0+(x1-x0)*v[0],y0+(y1-y0)*v[1],z0+(z1-z0)*v[2]],rotation),sloped=railSlopePoint(point,slope);bucket.p.push(wx+sloped[0],y+sloped[1],wz+sloped[2]);bucket.c.push(col.r,col.g,col.b);bucket.u.push(...(modelFaces?modelUV(f,v,spec):partUV(f,point,uv)))}bucket.i.push(q,q+1,q+2,q,q+2,q+3)}}

function modelVertexData(type,x,y,z,lod=0){
    const {appendModelBox,blockParts} = $context;

  const data={p:[],c:[],u:[],i:[]};
  for(const part of blockParts(type,x,y,z,lod)||[])if(part.kind==='box')appendModelBox(data,type,x,y,z,...part.bounds,part.texture,part.faces,part.rotation,part.slope);
  return data;
}
return {faceUV,partUV,rotateModelPoint,railSlopePoint,modelUV,curvedRailParts,wireConnections,wireParts,pistonDirection,mirrorModelZ,torchModelParts,cardinalName,blockParts,quadNormals,appendModelBox,modelVertexData};
}
