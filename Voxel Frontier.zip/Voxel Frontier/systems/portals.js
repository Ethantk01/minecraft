/** portals subsystem. Dependencies are injected at composition time. */
export function createPortalsSystem($context) {
function endEyeKey(x,y,z){
    const {editKey} = $context;
return $context.dimension+':'+editKey(x,y,z)}

function hasEndEye(x,y,z){
    const {editKey,endEyeKey,hash3,isStrongholdFrame} = $context;
const scoped=endEyeKey(x,y,z);if(Object.hasOwn($context.save.endEyes,scoped))return !!$context.save.endEyes[scoped];return $context.dimension==='overworld'&&(!!$context.save.endEyes[editKey(x,y,z)]||isStrongholdFrame(x,y,z)&&hash3(x,y,z,701)<.1)}

function endPortalRingAt(x,y,z){
    const {END_FRAME,getBlock,hasEndEye} = $context;

  for(let centerZ=z-2;centerZ<=z+2;centerZ++)for(let centerX=x-2;centerX<=x+2;centerX++){
    const dx=x-centerX,dz=z-centerZ;
    if(!((Math.abs(dx)===2&&Math.abs(dz)<=1)||(Math.abs(dz)===2&&Math.abs(dx)<=1)))continue;
    let complete=true;
    for(let offsetZ=-2;offsetZ<=2&&complete;offsetZ++)for(let offsetX=-2;offsetX<=2;offsetX++){
      if(!((Math.abs(offsetX)===2&&Math.abs(offsetZ)<=1)||(Math.abs(offsetZ)===2&&Math.abs(offsetX)<=1)))continue;
      const frameX=centerX+offsetX,frameZ=centerZ+offsetZ;
      if(getBlock(frameX,y,frameZ)!==END_FRAME||!hasEndEye(frameX,y,frameZ)){complete=false;break}
    }
    if(complete)return {x:centerX,y,z:centerZ};
  }
  return null;
}

function insertEndEye(hit){
    const {END_FRAME,END_PORTAL,endEyeKey,endPortalRingAt,getBlock,hasEndEye,playSound,setBlock,setBlockBatch,showToast} = $context;

  if(hit.type!==END_FRAME||getBlock(hit.x,hit.y,hit.z)!==END_FRAME)return false;
  if(hasEndEye(hit.x,hit.y,hit.z)){showToast('THIS FRAME ALREADY HAS AN EYE');return false}
  $context.save.endEyes[endEyeKey(hit.x,hit.y,hit.z)]=true;$context.dirtySave=true;
  setBlock(hit.x,hit.y,hit.z,END_FRAME);
  const ring=endPortalRingAt(hit.x,hit.y,hit.z);
  if(ring){const edits=[];for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++)edits.push([ring.x+dx,ring.y,ring.z+dz,END_PORTAL]);setBlockBatch(edits);playSound('end_portal');showToast('THE END PORTAL HAS OPENED')}
  else{playSound('click');showToast('EYE OF ENDER INSERTED')}
  return true;
}

function activateNetherPortal(hit){
    const {AIR,NETHER_PORTAL,OBSIDIAN,getBlock,playSound,setBlock,showToast} = $context;
for(const axis of ['x','z'])for(let offset=0;offset<4;offset++)for(let below=0;below<5;below++){const sx=hit.x-(axis==='x'?offset:0),sz=hit.z-(axis==='z'?offset:0),sy=hit.y-below;let valid=true;const inside=[];for(let a=0;a<4&&valid;a++)for(let b=0;b<5;b++){const x=sx+(axis==='x'?a:0),z=sz+(axis==='z'?a:0),y=sy+b,t=getBlock(x,y,z),frame=a===0||a===3||b===0||b===4;if(frame&&t!==OBSIDIAN||!frame&&t!==AIR&&t!==NETHER_PORTAL){valid=false;break}if(!frame)inside.push([x,y,z])}if(valid){for(const [x,y,z] of inside)setBlock(x,y,z,NETHER_PORTAL);playSound('portal_open');showToast('NETHER PORTAL IGNITED');return true}}showToast('BUILD A 4×5 OBSIDIAN FRAME');return false}

function portalInfoAt(x,y,z){
    const {END_PORTAL,NETHER_PORTAL,THREE,getBlock} = $context;

  const type=getBlock(x,y,z);if(type!==NETHER_PORTAL&&type!==END_PORTAL)return null;
  const axis=type===END_PORTAL?'horizontal':[1,-1].some(dx=>getBlock(x+dx,y,z)===NETHER_PORTAL)?'x':[1,-1].some(dz=>getBlock(x,y,z+dz)===NETHER_PORTAL)?'z':'x';
  const bounds={type,axis,minX:x,maxX:x,minY:y,maxY:y,minZ:z,maxZ:z};
  for(const sign of [-1,1]){
    for(let step=1;step<=8;step++){
      const nx=x+(axis==='x'?sign*step:0),nz=z+(axis==='z'||axis==='horizontal'?sign*step:0);
      if(getBlock(nx,y,nz)!==type)break;
      bounds.minX=Math.min(bounds.minX,nx);bounds.maxX=Math.max(bounds.maxX,nx);
      bounds.minZ=Math.min(bounds.minZ,nz);bounds.maxZ=Math.max(bounds.maxZ,nz);
    }
    if(axis==='horizontal')for(let step=1;step<=8;step++){
      const nx=x+sign*step;if(getBlock(nx,y,z)!==type)break;
      bounds.minX=Math.min(bounds.minX,nx);bounds.maxX=Math.max(bounds.maxX,nx);
    }
    if(axis!=='horizontal')for(let step=1;step<=8;step++){
      const ny=y+sign*step;if(getBlock(x,ny,z)!==type)break;
      bounds.minY=Math.min(bounds.minY,ny);bounds.maxY=Math.max(bounds.maxY,ny);
    }
  }
  bounds.center=new THREE.Vector3((bounds.minX+bounds.maxX+1)/2,axis==='horizontal'?y+.76:(bounds.minY+bounds.maxY+1)/2,(bounds.minZ+bounds.maxZ+1)/2);
  return bounds;
}

function visiblePortals(){
    const {camera,player,portalCells,portalInfoAt} = $context;

  const found=new Map();
  for(const cell of portalCells){
    const [x,y,z]=cell.split(',').map(Number);
    if(Math.abs(x-player.x)>42||Math.abs(y-player.y)>30||Math.abs(z-player.z)>42)continue;
    const info=portalInfoAt(x,y,z);if(!info){portalCells.delete(cell);continue}
    const id=`${info.type}:${info.minX},${info.minY},${info.minZ}:${info.maxX},${info.maxY},${info.maxZ}`;
    if(!found.has(id))found.set(id,info);
  }
  return [...found.values()].sort((a,b)=>a.center.distanceToSquared(camera.position)-b.center.distanceToSquared(camera.position));
}

function indexPortalCells(chunk){
    const {END_PORTAL,MIN_Y,NETHER_PORTAL,SIZE,editKey,idx,portalCells} = $context;

  const ox=chunk.cx*SIZE,oz=chunk.cz*SIZE;
  for(let y=MIN_Y;y<=chunk.topY;y++)for(let z=0;z<SIZE;z++)for(let x=0;x<SIZE;x++){
    const type=chunk.blocks[idx(x,y,z)];
    if(type===NETHER_PORTAL||type===END_PORTAL)portalCells.add(editKey(ox+x,y,oz+z));
  }
}

function nearestPortal(){
    const {visiblePortals} = $context;
return visiblePortals()[0]||null}

function portalDestination(info){
    const {END_PORTAL} = $context;
return info.type===END_PORTAL?$context.dimension==='end'?'overworld':'end':$context.dimension==='nether'?'overworld':'nether'}

function portalUsesPreview(type){
    const {END_PORTAL,NETHER_PORTAL} = $context;
return type===NETHER_PORTAL||type===END_PORTAL&&$context.dimension!=='end'}

function usesPortalWindow(info){
    const {portalUsesPreview} = $context;
return portalUsesPreview(info.type)}

function portalDestinationAxis(target){return target==='nether'?'x':target==='overworld'?$context.save.portalLinks.overworld?.axis||'x':'horizontal'}

function destinationPortalCenter(info,target){
    const {THREE,inDimension,netherPortalSite,player,terrain} = $context;

  if(target==='nether')return inDimension('nether',()=>{const site=netherPortalSite();return new THREE.Vector3(site.x+2,site.by+2.5,site.z+.5)});
  if(target==='end')return inDimension('end',()=>new THREE.Vector3(.5,terrain(0,0)+11,.5));
  const link=$context.save.portalLinks.overworld;
  if(link)return new THREE.Vector3(link.x,link.y,link.z);
  const position=$context.save.positions.overworld||{x:player.x,y:player.y,z:player.z};
  return new THREE.Vector3(position.x,position.y+1,position.z);
}

function disposePortalWorld(world){
  for(const chunk of world.chunks.values())for(const mesh of chunk.meshes){world.scene.remove(mesh);mesh.geometry.dispose()}
  world.chunks.clear();world.task=null;world.relight.length=0;
}

function disposePreviewChunks(){
    const {disposePortalWorld,portalPreviewWorlds} = $context;

  for(const world of portalPreviewWorlds.values())disposePortalWorld(world);
  portalPreviewWorlds.clear();
  $context.portalPreviewChunks=new Map();$context.portalPreviewScene=null;
}

function resetPortalPreview(){
    const {disposePreviewChunks,portalWindow} = $context;
disposePreviewChunks();$context.portalPreviewState=null;$context.nearPortal=null;$context.visiblePortalViews=[];portalWindow.hide()}

function preparePortalPreview(){
    const {SIZE,destinationPortalCenter,disposePortalWorld,makePortalPreviewScene,portalDestination,portalPreviewWorlds,portalWindow,usesPortalWindow} = $context;

  const wanted=new Set();
  const previewable=$context.visiblePortalViews.filter(usesPortalWindow);
  for(const info of previewable){
    const target=portalDestination(info),center=destinationPortalCenter(info,target),id=`${target}:${center.x},${center.y},${center.z}`;
    info.previewKey=id;wanted.add(id);
    if(portalPreviewWorlds.has(id)){
      const world=portalPreviewWorlds.get(id);
      if(target==='overworld'&&Math.abs(world.lightBand-$context.lightDay)>=2){world.lightBand=$context.lightDay;world.relight=[...world.chunks.values()]}
      continue;
    }
    const cx=Math.floor(center.x/SIZE),cz=Math.floor(center.z/SIZE),pending=[];
    for(const [dx,dz] of [[0,0],[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,-1],[-1,1],[1,1]])pending.push([cx+dx,cz+dz]);
    portalPreviewWorlds.set(id,{id,target,center,pending,chunks:new Map(),scene:makePortalPreviewScene(target),task:null,relight:[],lightBand:$context.lightDay});
  }
  for(const [id,world] of portalPreviewWorlds)if(!wanted.has(id)){disposePortalWorld(world);portalPreviewWorlds.delete(id)}
  $context.portalPreviewState=$context.nearPortal&&usesPortalWindow($context.nearPortal)?portalPreviewWorlds.get($context.nearPortal.previewKey):null;
  $context.portalPreviewChunks=$context.portalPreviewState?.chunks||new Map();
  $context.portalPreviewScene=$context.portalPreviewState?.scene||null;
  portalWindow.setApertures(previewable);
}

function stepPortalPreview(){
    const {buildChunkTask,generateChunk,portalPreviewWorlds} = $context;

  const pending=[...portalPreviewWorlds.values()].filter(world=>world.task||world.pending.length||world.relight.length);
  if(!pending.length)return;
  const world=pending[$context.portalPreviewCursor++%pending.length],previousDimension=$context.dimension,previousState=$context.portalPreviewState;
  const previousChunks=$context.portalPreviewChunks,previousScene=$context.portalPreviewScene;
  $context.dimension=world.target;$context.portalPreviewState=world;$context.portalPreviewChunks=world.chunks;$context.portalPreviewScene=world.scene;$context.portalPreviewMode=true;
  try{
    const start=performance.now();
    while(performance.now()-start<1.6){
      if(!world.task){const next=world.pending.shift();if(next)world.task={stage:'generate',iterator:generateChunk(next[0],next[1])};else{const chunk=world.relight.shift();if(!chunk)break;world.task={stage:'mesh',iterator:buildChunkTask(chunk,0)}}}
      const result=world.task.iterator.next();
      if(!result.done)continue;
      if(world.task.stage==='generate'){
        world.task.stage='mesh';world.task.iterator=buildChunkTask(result.value,0);
      }else world.task=null;
    }
  }finally{
    $context.portalPreviewMode=false;$context.dimension=previousDimension;$context.portalPreviewState=previousState;
    $context.portalPreviewChunks=previousChunks;$context.portalPreviewScene=previousScene;
  }
}

function updatePortalExitLock(){
    const {player} = $context;

  if(!$context.portalExitLock)return;
  if($context.dimension!==$context.portalExitLock.dimension){$context.portalExitLock=null;return}
  const {axis,center}=$context.portalExitLock;
  const clear=axis==='horizontal'?player.y>center.y+.1||player.y+1.8<center.y-.1:
    Math.abs(player[axis==='x'?'z':'x']-center[axis==='x'?'z':'x'])>.42;
  if(clear)$context.portalExitLock=null;
}

function parkSourceWorldForPortal(info){
    const {SIZE,chunks,key,makePortalPreviewScene,scene} = $context;

  const center=info.center.clone(),source=$context.dimension,cx=Math.floor(center.x/SIZE),cz=Math.floor(center.z/SIZE);
  const world={id:`${source}:${center.x},${center.y},${center.z}`,target:source,center,pending:[],chunks:new Map(),scene:makePortalPreviewScene(source),task:null,relight:[],lightBand:$context.lightDay};
  for(const [id,chunk] of chunks){
    if(Math.abs(chunk.cx-cx)<=2&&Math.abs(chunk.cz-cz)<=2){
      world.chunks.set(id,chunk);
      for(const mesh of chunk.meshes){scene.remove(mesh);world.scene.add(mesh)}
      if(!chunk.meshes.length)world.relight.push(chunk);
    }else for(const mesh of chunk.meshes){scene.remove(mesh);mesh.geometry.dispose()}
  }
  for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=2;dx++)if(!world.chunks.has(key(cx+dx,cz+dz)))world.pending.push([cx+dx,cz+dz]);
  return world;
}

function crossedPortal(info,from){
    const {player} = $context;

  if(!info||$context.portalExitLock)return false;
  const c=info.center;
  if(info.axis==='horizontal')return from.y>=c.y&&player.y<c.y&&player.x>=info.minX&&player.x<=info.maxX+1&&player.z>=info.minZ&&player.z<=info.maxZ+1;
  const edge=info.axis==='x'?'z':'x',along=info.axis==='x'?'x':'z',start=from[edge]-c[edge],end=player[edge]-c[edge];
  return (start<0&&end>=0||start>0&&end<=0||start===0&&Math.abs(end)>.03)&&player[along]>=info['min'+along.toUpperCase()]-.2&&player[along]<=info['max'+along.toUpperCase()]+1.2&&player.y+.9>=info.minY&&player.y+.9<=info.maxY+1;
}

function endExitArrival(){
    const {SEA,inDimension,player,terrain} = $context;
return inDimension('overworld',()=>({x:.5,y:Math.max(SEA,terrain(0,0))+2,z:.5,yaw:player.yaw,pitch:0}))}

function travelThroughEndPortal(){
    const {endExitArrival,loading,teleportTo,waitForNearbyWorld} = $context;
const exiting=$context.dimension==='end',wasPlaying=$context.playing;$context.playing=false;loading.begin('world',exiting?'Returning to the Overworld':'Entering the End','Preparing nearby terrain',0);teleportTo(exiting?'overworld':'end',exiting?endExitArrival():null);waitForNearbyWorld().then(()=>{loading.end('world');$context.playing=wasPlaying;$context.lastTime=performance.now()})}

function crossExperimentalPortal(info){
    const {END_PORTAL,THREE,destinationPortalCenter,mapPortalPoint,mapPortalYaw,player,portalDestination,portalDestinationAxis,teleportTo,travelThroughEndPortal} = $context;

  if(info.type===END_PORTAL&&$context.dimension==='end'){travelThroughEndPortal();return}
  const target=portalDestination(info),center=destinationPortalCenter(info,target);
  if($context.dimension==='overworld')$context.save.portalLinks.overworld={x:info.center.x,y:info.center.y,z:info.center.z,axis:info.axis};
  const targetAxis=portalDestinationAxis(target);
  const mapped=mapPortalPoint(info,center,targetAxis,new THREE.Vector3(player.x,player.y+1.57,player.z));
  const arrival={x:mapped.x,y:mapped.y-1.57,z:mapped.z,yaw:mapPortalYaw(info.axis,targetAxis,player.yaw),pitch:player.pitch};
  teleportTo(target,arrival,info.previewKey,{sourceInfo:info,destinationCenter:center,destinationAxis:targetAxis});
}

function portalArrival(target,arrival){
    const {spawnPoint} = $context;
return arrival||(target==='end'?spawnPoint():$context.save.positions[target]||spawnPoint())}

function teleportTo(target,arrival=null,previewId=null,crossing=null){
    const {BLOCKS,LAVA,SIZE,WATER,activateVehicleDimension,ambient,applyAtmosphere,buildChunk,camera,chunks,cloudLayer,destinationPortalCenter,editLightingQueue,entityTerrainTasks,fallingBlocks,fireCells,firstMeshQueue,flowFalling,flowLevels,flowQueue,flowQueued,flowSources,generate,getBlock,gravityQueue,gravityQueued,growthCells,hopperAt,indexPortalCells,key,meshRebuildQueue,parkSourceWorldForPortal,parkVehicleDimension,parkedVehicles,pistonPowered,playSound,player,portalArrival,portalCells,portalDestination,portalPreviewWorlds,preparePortalPreview,queue,queued,redstoneCells,redstoneDoorPowered,redstoneEdge,redstoneLevels,resetPortalPreview,retainEntityTerrain,scene,scheduleChunkMesh,sensorCells,sensorFrequency,sensorUntil,showToast,spawnPoint,spreadCache,sun,survival,targetUntil,terrain,torchBurnedUntil,torchPending,torchStates,torchSwitches,tripwireUntil,urgentFlowQueue,urgentFlowQueued,urgentGravityQueue,urgentGravityQueued,urgentMeshQueue,visiblePortals} = $context;

  $context.save.positions[$context.dimension]={x:player.x,y:player.y,z:player.z,yaw:player.yaw,pitch:player.pitch};
  retainEntityTerrain();entityTerrainTasks.delete(target);survival.parkDimension();parkVehicleDimension();
  const returnWorld=crossing&&$context.save.experiments?parkSourceWorldForPortal(crossing.sourceInfo):null;
  if(!returnWorld)for(const chunk of chunks.values())for(const mesh of chunk.meshes){scene.remove(mesh);mesh.geometry.dispose()}
  $context.streamKey=null;chunks.clear();portalCells.clear();queue.length=0;queued.clear();$context.pendingGeneration=null;$context.pendingMeshing=null;$context.suspendedMeshing=null;
  urgentMeshQueue.clear();editLightingQueue.clear();$context.pendingEditLighting=null;firstMeshQueue.clear();meshRebuildQueue.clear();
  flowQueue.length=0;$context.flowHead=0;urgentFlowQueue.length=0;$context.urgentFlowHead=0;
  flowQueued.clear();urgentFlowQueued.clear();flowLevels.clear();flowSources.clear();flowFalling.clear();spreadCache.clear();
  for(const block of fallingBlocks)block.mesh.removeFromParent();
  fallingBlocks.length=0;gravityQueue.length=0;$context.gravityHead=0;urgentGravityQueue.length=0;
  gravityQueued.clear();urgentGravityQueued.clear();
  fireCells.clear();growthCells.clear();redstoneCells.clear();sensorCells.clear();redstoneLevels.clear();
  torchStates.clear();torchPending.clear();torchSwitches.clear();torchBurnedUntil.clear();redstoneEdge.clear();
  sensorUntil.clear();sensorFrequency.clear();targetUntil.clear();tripwireUntil.clear();hopperAt.clear();$context.lastSensorStep=null;
  pistonPowered.clear();redstoneDoorPowered.clear();
  for(const cart of parkedVehicles)scene.remove(cart.mesh);
  parkedVehicles.length=0;$context.vehicle=null;
  $context.dimension=target;$context.save.dimension=target;survival.activateDimension(target);activateVehicleDimension(target);
  const previewWorld=$context.save.experiments&&(portalPreviewWorlds.get(previewId)||[...portalPreviewWorlds.values()].find(world=>world.target===target));
  if(previewWorld){
    for(const [id,chunk] of previewWorld.chunks){
      chunks.set(id,chunk);indexPortalCells(chunk);
      for(const mesh of chunk.meshes){previewWorld.scene.remove(mesh);scene.add(mesh)}
      scheduleChunkMesh(chunk,false);
    }
    previewWorld.chunks.clear();
  }
  resetPortalPreview();
  let position=portalArrival(target,arrival);
  if(target==='nether'&&!arrival){
    const x=Math.floor(position.x),y=Math.floor(position.y),z=Math.floor(position.z);
    if(y<29||!BLOCKS[getBlock(x,y-1,z)]?.solid||getBlock(x,y,z)===LAVA||getBlock(x,y+1,z)===LAVA)position=spawnPoint();
  }
  if($context.save.mode!=='spectator')position=$context.ensureSafeSpawn(position);
  Object.assign(player,position);
  if(!arrival)player.vy=0;
  if(crossing){
    const cx=Math.floor(player.x/SIZE),cz=Math.floor(player.z/SIZE),id=key(cx,cz);
    const arrivalChunk=chunks.get(id)||generate(cx,cz);
    if(!arrivalChunk.meshes.length){buildChunk(arrivalChunk,0);firstMeshQueue.delete(id);meshRebuildQueue.delete(id)}
  }
  $context.portalCooldown=crossing?0:arrival?1:3;
  $context.portalExitLock=crossing?{dimension:target,axis:crossing.destinationAxis,center:crossing.destinationCenter.clone()}:null;
  $context.dirtySave=true;
  camera.position.set(player.x,player.y+1.57,player.z);
  camera.rotation.set(player.pitch,player.yaw,0);
  if(crossing){
    const daylight=(Math.sin($context.tick)+1)/2;
    const underwater=getBlock(Math.floor(player.x),Math.floor(player.y+1.57),Math.floor(player.z))===WATER;
    const underground=player.y+3<terrain(Math.floor(player.x),Math.floor(player.z));
    applyAtmosphere(scene,$context.dimension,player.x,player.z,daylight,underground,underwater,ambient,sun);
    cloudLayer.visible=$context.dimension==='overworld'&&!underwater;
    $context.visiblePortalViews=visiblePortals();$context.nearPortal=$context.visiblePortalViews[0]||null;
    if(returnWorld){
      const reverse=$context.visiblePortalViews.find(info=>portalDestination(info)===returnWorld.target);
      if(reverse){
        const center=destinationPortalCenter(reverse,returnWorld.target);
        returnWorld.center.copy(center);
        returnWorld.id=`${returnWorld.target}:${center.x},${center.y},${center.z}`;
      }
      portalPreviewWorlds.set(returnWorld.id,returnWorld);
    }
    if($context.nearPortal)preparePortalPreview();
    $context.portalScanAt=performance.now();
  }else showToast(target==='nether'?'ENTERED THE NETHER':target==='end'?'ENTERED THE END':'RETURNED TO THE OVERWORLD');
  playSound(target==='end'?'end_portal':'portal');
}
return {endEyeKey,hasEndEye,endPortalRingAt,insertEndEye,activateNetherPortal,portalInfoAt,visiblePortals,indexPortalCells,nearestPortal,portalDestination,portalUsesPreview,usesPortalWindow,portalDestinationAxis,destinationPortalCenter,disposePortalWorld,disposePreviewChunks,resetPortalPreview,preparePortalPreview,stepPortalPreview,updatePortalExitLock,parkSourceWorldForPortal,crossedPortal,endExitArrival,travelThroughEndPortal,crossExperimentalPortal,portalArrival,teleportTo};
}
