import {pathNodeCost} from '../path-costs.js';
import {isSuffocating} from '../suffocation.js';
import {approachesActor} from '../actor-physics.js';
/** survival entity ai subsystem. Dependencies are injected at composition time. */
export function createSurvivalEntityAiSystem($context) {
function ts(type,x,z,y=$context.d(Math.floor(x),Math.floor(z))+1,state={}) {
    const {Ga,Kb,Zt,entityRegistry} = $context;

    const definition=Ga[type];if(!definition)return null;
    if(definition.limit&&Zt.filter(mob=>mob.type===type).length>=definition.limit)return null;
    const mob=entityRegistry.create(type,Kb(type),x,y,z,state);if(!mob)return null;
    $context.t.add(mob.group);Zt.push(mob);return mob;
  }

function uy() {
    const {Xr,Zr,Zt,dragonBreathClouds,dragonCrystals,oo,releaseEntity} = $context;

    for (let f of Zt) releaseEntity(f.group);
    Zt.length = 0;
    for (let f of oo) $context.t.remove(f.mesh);
    oo.length = 0;
    for (let f of Xr) $context.t.remove(f.mesh);
    Xr.length = 0;$context.xpBatch.count=0;
    for (let f of Zr) releaseEntity(f.mesh);
    Zr.length = 0;
    for(const crystal of dragonCrystals){releaseEntity(crystal.mesh);crystal.mesh.traverse(part=>part.material?.dispose());}
    dragonCrystals.length=0;
    for(const cloud of dragonBreathClouds){releaseEntity(cloud.mesh);cloud.mesh.material.dispose();}
    dragonBreathClouds.length=0;
  }

function hy(f, b, R, v, N, V, L, z) {
    let H = 0, q = z;
    for (let [Ue, Ye, Se, ue] of [[R - V, R + V, f.x, b.x], [v, v + L, f.y, b.y], [N - V, N + V, f.z, b.z]]) {
      if (Math.abs(ue) < 1e-8) {
        if (Se < Ue || Se > Ye) return 1 / 0;
        continue;
      }
      let qe = (Ue - Se) / ue, ze = (Ye - Se) / ue;
      if (H = Math.max(H, Math.min(qe, ze)), q = Math.min(q, Math.max(qe, ze)), H > q) return 1 / 0;
    }
    return H;
  }

function ensureDragonCrystals(){
    const {a,dragonCrystals,e,i} = $context;

    if(i.getDimension()!=='end'||dragonCrystals.length)return;
    a.destroyedEndCrystals??={};
    for(const [index,pillar] of i.endPillars().entries()){
      if(a.destroyedEndCrystals[index])continue;
      const mesh=new e.Group(),core=new e.Mesh(new e.OctahedronGeometry(.85),new e.MeshBasicMaterial({color:0xb970ea,transparent:true,opacity:.82}));
      const cage=new e.LineSegments(new e.EdgesGeometry(new e.BoxGeometry(1.55,1.55,1.55)),new e.LineBasicMaterial({color:0xb7a0d0}));
      mesh.add(core,cage);mesh.position.set(pillar.x+.5,pillar.top+1.5,pillar.z+.5);$context.t.add(mesh);
      dragonCrystals.push({index,x:mesh.position.x,y:mesh.position.y,z:mesh.position.z,mesh});
    }
  }

function _y(f) {
    const {A,E,Zt,a,d,i,ts} = $context;

    if(i.isRemoteWorld?.())return;
    if(i.getDimension()==='end'&&!a.endPopulationInitialized){
      // The population is created once by the world authority, then saved/synced.
      a.endPopulationInitialized=true;
      for(let index=0;index<40;index++){
        const angle=index*2.39996323,radius=24+Math.sqrt(index/40)*65,x=Math.floor(Math.cos(angle)*radius),z=Math.floor(Math.sin(angle)*radius),y=d(x,z)+1;
        if(A(x,y,z)===E&&A(x,y+2,z)===E&&i.isSolid(A(x,y-1,z)))ts('enderman',x+.5,z+.5,y);
      }
      i.markDirty();
    }
    if (a.mode === "spectator") return;
    if (i.getDimension() === "end" && !a.dragonDefeated && !Zt.some((Ye) => Ye.type === "dragon")) {
      ts("dragon", 0.5, 7.5, d(0, 0) + 13);
      return;
    }
    if(a.testWorld)return;
    if ($context.Xp -= f, $context.Xp > 0 || Zt.length >= (i.getDimension()==='end'?64:12)) return;
    $context.Xp = 3 + Math.random() * 3;
    let b = Math.random() * Math.PI * 2, R = 14 + Math.random() * 17, v = Math.floor($context.n.x + Math.cos(b) * R), N = Math.floor($context.n.z + Math.sin(b) * R), V = i.getDimension(), L = d(v, N) + 1;
    if (V === "overworld" && Math.random() < 0.4 && (L = Math.max(-58, Math.floor($context.n.y + (Math.random() - 0.5) * 17))), L <= -63 || A(v, L, N) !== E || A(v, L + 1, N) !== E || !i.isSolid(A(v, L - 1, N))) return;
    let z = i.getLightLevel(v, L, N), H = V !== "overworld" || i.getBlockLightLevel(v,L,N)===0&&z<=7, q = V === "nether" ? v >= 58 && v <= 91 && Math.abs(N) <= 6 && Math.random() < 0.65 ? "blaze" : i.netherBiome(v, N) === "warped_forest" ? "enderman" : i.netherBiome(v, N) === "soul_sand_valley" || i.netherBiome(v, N) === "basalt_deltas" ? "skeleton" : "piglin" : V === "end" ? "enderman" : H ? Math.random() < 0.04 ? "enderman" : Math.random() < 0.6 ? "zombie" : "creeper" : i.villageAt?.(v,N)&&Math.random()<.3 ? "villager" : Math.random() < 0.5 ? "cow" : "sheep";
    V === "nether" && i.getBlockLightLevel(v,L,N)>({enderman:7,blaze:11,piglin:11,skeleton:11}[q]??15) || Zt.filter((Ye) => Ye.type === q).length >= (V==='end'?56:H ? 6 : 7) || ts(q, v + 0.5, N + 0.5, L);
  }

function Ey(f) {
    const {A,E,Qh,Zt,a,d,i,ts} = $context;

    if(a.testWorld)return;
    if (a.mode === "spectator" || ($context.dm -= f, $context.dm > 0 || Zt.length >= 16)) return;
    $context.dm = 6 + Math.random() * 5;
    let b = i.getDimension();
    if (b === "end") {
      Math.hypot($context.n.x - 144, $context.n.z) < 26 && Zt.filter((z) => z.type === "shulker").length < 3 && ts("shulker", 144 + (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10, 49);
      return;
    }
    if (b === "nether") {
      if (Math.random() < 0.12) {
        let z = $context.n.x + (Math.random() - 0.5) * 24, H = $context.n.z + (Math.random() - 0.5) * 24, q = Math.min(112, Math.max(30, $context.n.y + 5)), Ue = i.netherBiome(z, H);
        ["nether_wastes", "soul_sand_valley", "basalt_deltas"].includes(Ue) && Zt.filter(mob=>mob.type==='ghast').length<3 && A(Math.floor(z), Math.floor(q), Math.floor(H)) === E && ts("ghast", z, H, q);
      }
      return;
    }
    for (let z = Math.floor($context.n.y) - 8; z <= Math.floor($context.n.y) + 8; z++) for (let H = Math.floor($context.n.z) - 12; H <= Math.floor($context.n.z) + 12; H++) for (let q = Math.floor($context.n.x) - 12; q <= Math.floor($context.n.x) + 12; q++) if (A(q, z, H) === Qh && Math.random() < 6e-3 && Zt.filter((Ue) => Ue.type === "skeleton" || Ue.type === "zombie").length < 6) {
      let Ue = q + 1, Ye = H + 1;
      A(Ue, z, Ye) === E && i.getLightLevel(Ue, z, Ye) <= 7 && ts(Math.random() < 0.5 ? "skeleton" : "zombie", Ue + 0.5, Ye + 0.5, z);
      return;
    }
    let R = Math.random() * Math.PI * 2, v = 15 + Math.random() * 11, N = Math.floor($context.n.x + Math.cos(R) * v), V = Math.floor($context.n.z + Math.sin(R) * v), L = d(N, V) + 1;
    A(N, L, V) !== E || A(N, L + 1, V) !== E || (i.getBlockLightLevel(N,L,V)>0||i.getLightLevel(N,L,V)>7) || ts(["skeleton", "spider", "witch"][Math.floor(Math.random() * 3)], N + 0.5, V + 0.5, L);
  }

function Sy(f, b, R, v) {
    const {Yc,a} = $context;

    if($context.backgroundEntities)return false;
    if (a.mode === "spectator") return false;
    return approachesActor(f,b,R,v,$context.n,Yc(f));
  }

function JE(f, b, R, v) {
    const {A,Yc,i} = $context;

    let { radius: N, height: V } = Yc(f);if(i.intersectsBody)return i.intersectsBody(b,R,v,N,V);let L = i.isSolidAt || ((z, H, q) => i.isSolid(A(z, H, q)));
    for (let z = Math.floor(R + 0.05); z <= Math.floor(R + V - 0.01); z++) for (let H = Math.floor(v - N); H <= Math.floor(v + N); H++) for (let q = Math.floor(b - N); q <= Math.floor(b + N); q++) if (L(q, z, H)) return true;
    return false;
  }

function dragonPhase(f, phase){f.dragonPhase=phase;f.dragonPhaseTime=0;f.dragonShot=false}

function recordDragonFlight(f,dt){
    const sample={yaw:(-f.dir-Math.PI/2)*180/Math.PI,y:f.group.position.y};
    if(!f.dragonHistory)f.dragonHistory=Array.from({length:32},()=>({...sample}));
    f.dragonHistoryClock=(f.dragonHistoryClock||0)+dt;
    while(f.dragonHistoryClock>=.05){f.dragonHistory.unshift({...sample});f.dragonHistory.length=32;f.dragonHistoryClock-=.05}
    const speed=Math.hypot(f.vx,f.vy,f.vz)/20;
    f.flapTime=(f.flapTime||0)+dt*20*((f.dragonPhase==='perched'||f.dragonPhase==='roar'||f.dragonPhase==='breath')?.04:.2/(1+speed*10));
  }

function updateDragon(f,dt){
    const {Fl,Ga,XE,d,dragonBreathCloud,dragonCrystals,dragonPhase,recordDragonFlight,xi} = $context;

    if(!f.dragonPhase)dragonPhase(f,'circle');
    if($context.backgroundEntities&&['strafe','charge','roar','breath'].includes(f.dragonPhase))dragonPhase(f,'circle');
    f.dragonPhaseTime+=dt;
    const phase=f.dragonPhase,dist=Math.hypot(f.x-$context.n.x,f.z-$context.n.z);
    const centerY=d(0,0)+3;
    let tx=f.x,tz=f.z,ty=f.group.position.y,speed=Ga.dragon.speed;
    if(phase==='circle'||phase==='strafe'){
      f.dragonOrbit=(f.dragonOrbit||0)+dt*(phase==='strafe'?.24:.17);
      tx=Math.cos(f.dragonOrbit)*34;tz=Math.sin(f.dragonOrbit)*34;ty=centerY+19+Math.sin(f.dragonOrbit*2)*5;
      if(phase==='strafe'){
        tx=$context.n.x+Math.cos(f.dragonOrbit)*20;tz=$context.n.z+Math.sin(f.dragonOrbit)*20;
        if(dist<64&&f.dragonPhaseTime>1&&!f.dragonShot){Fl(f,'dragon_fireball');f.dragonShot=true}
        if(f.dragonShot&&f.dragonPhaseTime>3)dragonPhase(f,'circle');
      }else if(f.dragonPhaseTime>5&&dist<50){
        dragonPhase(f,Math.random()<1/(3+dragonCrystals.length)?'approach':'circle');
        if(f.dragonPhase==='circle'&&Math.random()<.22)dragonPhase(f,'strafe');
      }
    }else if(phase==='approach'){
      tx=0;tz=0;ty=centerY+14;
      if(Math.hypot(f.x,f.z)<3&&Math.abs(f.group.position.y-ty)<3)dragonPhase(f,'landing');
    }else if(phase==='landing'){
      tx=0;tz=0;ty=centerY+1;
      speed=1.5;
      if(Math.hypot(f.x,f.z)<2&&Math.abs(f.group.position.y-ty)<1.4){dragonPhase(f,'perched');f.dragonBreathCount=0}
    }else if(phase==='perched'||phase==='roar'||phase==='breath'){
      tx=0;tz=0;ty=centerY+1;speed=0;
      if(phase==='perched'&&f.dragonPhaseTime>1.25&&dist<20)dragonPhase(f,'roar');
      else if(phase==='perched'&&f.dragonPhaseTime>5)dragonPhase(f,dist<35?'charge':'takeoff');
      if(phase==='roar'&&f.dragonPhaseTime>2)dragonPhase(f,'breath');
      if(phase==='breath'){
        if(f.dragonPhaseTime>.5&&!f.dragonShot){
          dragonBreathCloud(f.x+($context.n.x-f.x)*.45,centerY-2,f.z+($context.n.z-f.z)*.45);
          f.dragonShot=true;
        }
        if(f.dragonPhaseTime>10){
          f.dragonBreathCount=(f.dragonBreathCount||0)+1;
          dragonPhase(f,f.dragonBreathCount>=4?'takeoff':'perched');
        }
      }
      f.vx*=Math.exp(-dt*4);f.vz*=Math.exp(-dt*4);f.vy*=Math.exp(-dt*4);
    }else if(phase==='charge'){
      if(!f.dragonChargeTarget)f.dragonChargeTarget={x:$context.n.x,z:$context.n.z,y:$context.n.y+2};
      tx=f.dragonChargeTarget.x;tz=f.dragonChargeTarget.z;ty=f.dragonChargeTarget.y;speed=4.8;
      if(Math.hypot(f.x-tx,f.z-tz)<3||f.dragonPhaseTime>7){f.dragonChargeTarget=null;dragonPhase(f,'takeoff')}
    }else if(phase==='takeoff'){
      tx=Math.cos(f.dragonOrbit||0)*30;tz=Math.sin(f.dragonOrbit||0)*30;ty=centerY+20;
      speed=3.2;
      if(f.group.position.y>centerY+15)dragonPhase(f,'circle');
    }
    if(['landing','approach','takeoff'].includes(phase)&&f.dragonPhaseTime>14)dragonPhase(f,phase==='takeoff'?'circle':'takeoff');
    if(speed>0){const angle=Math.atan2(tz-f.z,tx-f.x);f.dir=angle;XE(f,Math.cos(angle)*speed,Math.sin(angle)*speed,ty,dt)}
    else {f.x+=(tx-f.x)*Math.min(1,dt*2);f.z+=(tz-f.z)*Math.min(1,dt*2);f.group.position.set(f.x,f.group.position.y+(ty-f.group.position.y)*Math.min(1,dt*2),f.z);}
    f.group.rotation.y=-f.dir-Math.PI/2;
    if(dist<3.5&&f.attack<=0&&phase!=='circle'&&phase!=='strafe'){
      xi(phase==='charge'?10:5,'ENDER DRAGON',f);f.attack=1;
    }
    f.crystalHeal=(f.crystalHeal||0)+dt;
    if(f.crystalHeal>=.5){
      f.crystalHeal=0;
      if(dragonCrystals.some(crystal=>Math.hypot(crystal.x-f.x,crystal.z-f.z)<48))f.health=Math.min(Ga.dragon.health,f.health+1);
    }
    recordDragonFlight(f,dt);
  }

function ZE(f, b, R) {
    const {A,S,i} = $context;

    let v = Math.floor(f), N = Math.floor(b), V = Math.floor(R) - 1;
    for (let L of [0, 1, -1, -2]) {
      let z = V + L;
      if (!(z < (i.getDimension() === "overworld" ? -63 : 1)) && i.isSolid(A(v, z, N)) && !i.isSolid(A(v, z + 1, N)) && !i.isSolid(A(v, z + 2, N)) ) return z + 1;
    }
    return null;
  }

function Ry(f, b = $context.n.x, R = $context.n.z) {
    const {A,MinHeap,S,ZE,i} = $context;

    let v = Math.floor(f.x), N = Math.floor(f.z), V = Math.floor(b), L = Math.floor(R), z = new MinHeap(node=>node.g+node.h), H = /* @__PURE__ */ new Map(), q = {x:v,z:N,y:f.group.position.y,g:0,h:Math.hypot(V-v,L-N),parent:null}, Ue = 0;
    z.push(q);
    for (; z.length && Ue++ < 384; ) {
      let Se = z.shift(), ue = Se.x + "," + Math.floor(Se.y) + "," + Se.z;
      if (!(H.has(ue) && H.get(ue) <= Se.g)) {
        if (H.set(ue, Se.g), Se.h < q.h && (q = Se), Se.h <= 1) {
          q = Se;
          break;
        }
        for (let [qe, ze] of [[1, 0], [-1, 0], [0, 1], [0, -1],[1,1],[1,-1],[-1,1],[-1,-1]]) {
          let tn = Se.x + qe, vn = Se.z + ze;
          if (Math.abs(tn - v) > 14 || Math.abs(vn - N) > 14) continue;
          let Mn = ZE(tn + 0.5, vn + 0.5, Se.y);
          if (Mn === null || Math.abs(Mn - Se.y) > 1.05) continue;
          const malus=pathNodeCost(A,i.ids,tn,Math.floor(Mn),vn,f.definition?.pathMalus);if(malus<0)continue;if(qe&&ze&&(ZE(Se.x+qe+.5,Se.z+.5,Se.y)===null||ZE(Se.x+.5,Se.z+ze+.5,Se.y)===null))continue;const height=f.definition?.collider?.height||1.8;if(Array.from({length:Math.ceil(height)},(_,dy)=>A(tn,Math.floor(Mn)+dy,vn)).some(id=>i.isSolid(id)))continue;let ro=tn+','+Math.floor(Mn)+','+vn,Ft=Se.g+Math.hypot(qe,ze,Mn-Se.y)+malus;
          H.has(ro) && H.get(ro) <= Ft || z.push({ x: tn, z: vn, y: Mn, g: Ft, h: Math.hypot(V-tn,L-vn), parent: Se });
        }
      }
    }
    let Ye = [];
    for (let Se = q; Se?.parent; Se = Se.parent) Ye.push({ x: Se.x + 0.5, z: Se.z + 0.5 });
    return Ye.reverse();
  }

function jE(f) {
    const {A,Bl,C,Ce,Ga,damageMob,entityRegistry,Hc,Hn,Ml,Pe,Qc,Ry,S,Ty,XE,Xe,Yn,Zt,_,_e,a,e,fr,hm,i,l,o,pf,releaseEntity,um,updateDragon,vt,xi} = $context;

    let b = new e.Vector3(), tick={dt:f,distance:0,view:null};
    o.getWorldDirection(b);tick.view=b;
    for (let R = Zt.length - 1; R >= 0; R--) {
      let v = Zt[R], N = Ga[v.type], V = $context.backgroundEntities?Infinity:Math.hypot(v.x - $context.n.x, v.z - $context.n.z);
      if(v.fireTime>0){if(A(Math.floor(v.x),Math.floor(v.group.position.y+.5),Math.floor(v.z))===S||v.definition.fireImmune)v.fireTime=0;else {v.fireTime=Math.max(0,v.fireTime-f);v.burnTimer=(v.burnTimer||0)+f;if(v.burnTimer>=1){v.burnTimer=0;damageMob(v,1);if(v.health<=0)continue;}}}
      if(v.fireTime>0&&!v.fireMesh&&i.createFireVisual){v.fireMesh=i.createFireVisual();if(v.fireMesh){const height=v.definition.collider?.height||1.7;v.fireMesh.scale.set(.9,height,.9);v.fireMesh.position.set(0,height/2,0);v.group.add(v.fireMesh);}}else if(!(v.fireTime>0)&&v.fireMesh){v.group.remove(v.fireMesh);v.fireMesh.geometry.dispose();v.fireMesh.material.dispose();v.fireMesh=null;}
      if(v.noAI){if(v.health<=0){releaseEntity(v.group);Zt.splice(R,1);continue}v.vx=v.vy=v.vz=0;v.aggro=false;v.definition?.onIdle?.(v,f);continue;}
      if(v.definition?.onTick?.(v,f)===false)continue;
      if(i.isChunkLoaded&&!i.isChunkLoaded(v.x,v.z))continue;
      if (!$context.backgroundEntities && V > (N.viewDistance||55)) {
        releaseEntity(v.group), Zt.splice(R, 1);
        continue;
      }
      if(N.terrainCollision!==false&&v.type!=='dragon'){
        const collider=N.collider||{height:1.8,radius:.3};v.suffocationTimer=Math.max(0,(v.suffocationTimer||0)-f);
        if(v.suffocationTimer<=0&&isSuffocating({x:v.x,y:v.group.position.y,z:v.z},i.suffocatingAt,collider.height*.85,collider.radius)){v.health-=1;v.suffocationTimer=.5;$context.m(`${v.type}_hurt`);}
      }
      v.hurtRemaining=Math.max(0,(v.hurtRemaining||0)-f);v.attack -= f, v.decision -= f, v.pathTimer -= f, v.walkPhase += f * N.speed * 7 * ((v.flee||0)>0||v.panic ? N.panicSpeed||3.5 : 1);
      if(!N.customAnimation)for(let ue of v.joints)ue.pivot.rotation.x=ue.baseRotation+Math.sin(v.walkPhase+ue.phase)*.38;
      if(!N.customAnimation)for(let ue of v.wings)ue.pivot.rotation.z=ue.side*(.15+Math.sin(v.walkPhase*1.3)*.25);
      for (let ue of v.rods) {
        let qe = ue.angle + v.walkPhase * (ue.ring % 2 ? -0.55 : 0.55), ze = 0.62 + ue.ring * 0.07;
        ue.mesh.position.set(Math.cos(qe) * ze, 0.72 + ue.ring * 0.43 + Math.sin(v.walkPhase * 1.5 + ue.angle) * 0.13, Math.sin(qe) * ze);
      }
      tick.distance=V;
      if(entityRegistry.runBehavior('specialTick',v,tick)===false)continue;
      Ty(v,f);
      entityRegistry.runBehavior('beforeTick',v,tick);
      if (v.health <= 0) {
        $context.m(`${v.type}_death`),N.drop && !(N.noDropWhen && v[N.noDropWhen]) && Yn(N.drop, v.x, v.group.position.y + 0.7, v.z, N.count), pf(v.x, v.group.position.y + 0.7, v.z, 5), releaseEntity(v.group), Zt.splice(R, 1);
        continue;
      }
      if(V<24&&Math.random()<f*.012)$context.m(`${v.type}_ambient`);
      if(entityRegistry.runBehavior('pauseTick',v,tick)===false)continue;
      v.decision <= 0 && (v.decision = 2 + Math.random() * 3, v.dir += Math.random() * 2 - 1);
      let L = V < 16 && fr(v), z = (v.flee || 0) > 0, H = N.hostile && v.aggro && V < 14 && L;
      if(z){v.flee-=f;v.decision=1;if(v.pathTimer<=0||!v.path?.length){let best=[],score=-Infinity;const origin=v.panicOrigin||$context.n;for(let attempt=0;attempt<10;attempt++){const angle=Math.random()*Math.PI*2,distance=3+Math.random()*2,tx=v.x+Math.cos(angle)*distance,tz=v.z+Math.sin(angle)*distance,path=Ry(v,tx,tz),last=path.at(-1);if(last){const value=Math.hypot(last.x-origin.x,last.z-origin.z);if(value>score){score=value;best=path;}}}v.path=best;v.pathTimer=1;}while(v.path?.length&&Math.hypot(v.path[0].x-v.x,v.path[0].z-v.z)<.42)v.path.shift();const target=v.path?.[0];if(target)v.dir=Math.atan2(target.z-v.z,target.x-v.x);else v.flee=0;}
      else if (N.temptationItem && Hn() === N.temptationItem && V < 8 && V > 1.8 && L) v.dir = Math.atan2($context.n.z - v.z, $context.n.x - v.x), v.decision = 1, H = true;
      else entityRegistry.runBehavior('steer',v,tick);
      if (H && !z) {
        v.pathTimer <= 0 && (v.path = Ry(v), v.pathTimer = 1.5 + Math.random() * 0.6), v.path.length && Math.hypot(v.path[0].x - v.x, v.path[0].z - v.z) < 0.42 && v.path.shift();
        let ue = v.path[0] || { x: $context.n.x, z: $context.n.z };
        v.dir = Math.atan2(ue.z - v.z, ue.x - v.x);
        if(N.backOffRange && V<N.backOffRange)v.dir=Math.atan2(v.z-$context.n.z,v.x-$context.n.x);
        if(entityRegistry.runBehavior('attack',v,tick)===false)continue;
        if(N.meleeRange && V<N.meleeRange && v.attack<=0){xi(N.damage,`ATTACKED BY A ${v.type.toUpperCase()}`,v);v.attack=N.attackCooldown||1;}
      }
      let q = N.temptationItem && Hn() === N.temptationItem && V < 1.8 && !z, Ue = q ? 0 : N.speed * (z || v.panic ? N.panicSpeed||3.5 : H ? 1.25 : 1), Ye = Math.cos(v.dir) * Ue, Se = Math.sin(v.dir) * Ue;
      if (N.flight) {
        v.flight=(v.flight||0)+f;
        const config=N.flight, altitude=Math.max($context.n.y+config.offset,v.homeY||v.group.position.y)+Math.sin(v.flight*config.frequency)*config.amplitude;
        XE(v,Ye,Se,altitude,f);
      } else um(v,Ye,Se,f);
      v.group.rotation.y = -v.dir - Math.PI / 2;
    }
  }
return {ts,uy,hy,ensureDragonCrystals,_y,Ey,Sy,JE,dragonPhase,recordDragonFlight,updateDragon,ZE,Ry,jE};
}
