/** block content subsystem. Dependencies are injected at composition time. */
export function createBlockContentSystem($context) {
function occludes(id){
    return !!$context.blockRegistry.get(id)?.occludes;
}


function blockTexture(id,face=2,x=0,z=0){
    const {BLOCKS,BLOCK_TEXTURES,GRASS,biome} = $context;
const extra=BLOCKS[id]?.texture;if(extra){const sides={podzol_top:'podzol_side',mycelium_top:'mycelium_side',basalt_side:'basalt_top',quartz_block_side:'quartz_block_top',purpur_pillar:'purpur_pillar_top',crimson_nylium:'crimson_nylium_side',warped_nylium:'warped_nylium_side',red_sandstone:'red_sandstone_top'};if(face===3&&['podzol_top','mycelium_top'].includes(extra))return 'dirt';if(face===3&&['crimson_nylium','warped_nylium'].includes(extra))return 'netherrack';if(face===3&&extra==='red_sandstone')return 'red_sandstone_bottom';if(face===3&&extra==='quartz_block_side')return 'quartz_block_bottom';return face===2||face===3?(['basalt_side','quartz_block_side','purpur_pillar'].includes(extra)?sides[extra]:extra):sides[extra]||extra}const list=BLOCK_TEXTURES[id]||['stone'];if(id===GRASS&&face!==2&&face!==3)return `grass_block_side_${({meadow:'plains',grove:'snow',snowy_slopes:'snow',frozen_peaks:'snow',jagged_peaks:'mountains',stony_peaks:'mountains'})[biome(x,z)]||biome(x,z)}`;return list[face]||list[0]}

function doorInfo(type){
    const {BLOCKS,DOOR,DOOR_TOP} = $context;
if(type===DOOR||type===DOOR_TOP)return {half:type===DOOR_TOP?'upper':'lower',name:'oak_door',props:{}};const b=BLOCKS[type];return b?.minecraftId?.endsWith('_door')?{half:b.properties.half,name:b.minecraftId,props:b.properties}:null}

function isDoor(type){
    const {doorInfo} = $context;
return !!doorInfo(type)}
return {occludes,blockTexture,doorInfo,isDoor};
}
