import {itemIconURL} from '../item-icons.js';
/** survival inventory subsystem. Dependencies are injected at composition time. */
export function createSurvivalInventorySystem($context) {
function wn(f) {
    const {a} = $context;

    return a.slots.reduce((b, R) => b + (R?.id === f ? R.n : 0), 0);
  }

function En(f, b = 1, R = null) {
    const {I,La,a,ao,r} = $context;

    if (!r[f] || b <= 0) return 0;
    let v = b;
    if (!R) {
      for (let V of a.slots) if (V?.id === f && V.n < La(f)) {
        let L = Math.min(v, La(f) - V.n);
        if (V.n += L, v -= L, !v) break;
      }
    }
    let N = [...Array(9).keys()].map((V) => 27 + V).concat([...Array(27).keys()]);
    for (let V of N) {
      if (!v) break;
      if (a.slots[V]) continue;
      let L = Math.min(v, La(f));
      a.slots[V] = { id: f, n: L, ...R ? { data: R } : null }, v -= L;
    }
    return v !== b && (I(), ao()), b - v;
  }

function mt(f, b = 1) {
    const {I,a,ao,i,wn} = $context;

    if (a.mode === "creative") return true;
    if (wn(f) < b) return false;
    let R = b, v = [27 + i.getSelected(), ...Array(36).keys()];
    for (let N of v) {
      let V = a.slots[N];
      if (V?.id !== f) continue;
      let L = Math.min(R, V.n);
      if (V.n -= L, R -= L, V.n || (a.slots[N] = null), !R) break;
    }
    return I(), ao(), true;
  }

function qr(f) {
    const {r} = $context;

    return `<span class="swatch" style="background-image:url('${itemIconURL(r[f])}')"></span>`;
  }

function hudWrite(node,value,html=false){
    const {hudValues} = $context;
if(hudValues.get(node)!==value){hudValues.set(node,value);if(html)node.innerHTML=value;else node.textContent=value;}}

function ao(f = true) {
    const {Fa,Fb,Lb,Pl,Vb,a,hudWrite,u} = $context;

    document.body.classList.toggle("spectator-mode", a.mode === "spectator"), f && u(), hudWrite(Lb, a.mode === "spectator" ? "SPECTATOR" : a.mode === "creative" ? "CREATIVE" : Array.from({ length: 10 }, (R, v) => `<i class="${v < Math.ceil($context.n.health / 2) ? "full" : ""}">\u2665</i>`).join(""), true), hudWrite(Fb, a.mode === "spectator" ? "" : a.mode === "creative" ? "\u221E BLOCKS" : Array.from({ length: 10 }, (R, v) => {const points=$context.n.hunger-v*2,icon=points>=2?'full':points===1?'half':'';return `<i class="${icon} ${v*2<$context.n.saturation?'saturated':''}">\u25C6</i>`}).join(""), true), hudWrite(Vb, a.mode === "spectator" ? "" : $context.n.air < 20 ? `\u25CC ${Math.ceil($context.n.air)}s` : "");
    let b = Pl(a.xp);
    document.getElementById("xpFill").style.width = b.remaining / b.needed * 100 + "%", document.getElementById("xpLevel").textContent = b.level || "", $context.Jr && f && Fa();
  }

function Xb() {
    const {Ol,qr} = $context;

    Ol.style.display = $context.Jr && $context.Bt ? "block" : "none", Ol.innerHTML = $context.Bt ? `${qr($context.Bt.id)}<span class="stack-count">${$context.Bt.n}</span>` : "";
  }

function kl() {
    const {Fa,I,u} = $context;

    I(), u(), Fa();
  }

function im(f, b, R = false) {
    const {La,kl} = $context;

    let v = f[b];
    if ($context.Bt) if (!v) R ? (f[b] = { id: $context.Bt.id, n: 1 }, $context.Bt.n--, $context.Bt.n || ($context.Bt = null)) : (f[b] = $context.Bt, $context.Bt = null);
    else if (v.id === $context.Bt.id && v.n < La(v.id)) {
      let N = Math.min(R ? 1 : $context.Bt.n, La(v.id) - v.n);
      v.n += N, $context.Bt.n -= N, $context.Bt.n || ($context.Bt = null);
    } else R || (f[b] = $context.Bt, $context.Bt = v);
    else {
      if (!v) return;
      if (R) {
        let N = Math.ceil(v.n / 2);
        $context.Bt = { id: v.id, n: N }, v.n -= N, v.n || (f[b] = null);
      } else $context.Bt = v, f[b] = null;
    }
    kl();
  }

function DE(f, b = false) {
    const {a,im} = $context;

    im(a.slots, f, b);
  }

function om(f, b) {
    const {jp} = $context;

    return Array.isArray(jp[f]) ? jp[f].includes(b) : jp[f] === b;
  }

function Zb(f) {
    const {a,kl,om} = $context;

    let b = a.armor[f] || 0;
    if ($context.Bt) if (om(f, $context.Bt.id) && $context.Bt.n === 1) a.armor[f] = $context.Bt.id, $context.Bt = b ? { id: b, n: 1 } : null;
    else return;
    else {
      if (!b) return;
      $context.Bt = { id: b, n: 1 }, delete a.armor[f];
    }
    kl();
  }

function NE(f, b = false) {
    const {kl,mn,oa} = $context;

    let R = mn[f];
    $context.Bt?.id !== oa && ($context.Bt ? R ? b || (mn[f] = $context.Bt.id, $context.Bt.id = R) : (mn[f] = $context.Bt.id, $context.Bt.n--, $context.Bt.n || ($context.Bt = null)) : R && (mn[f] = 0, $context.Bt = { id: R, n: 1 }), kl());
  }

function jb(f, b) {
    const {Am,La,Va,a,kl,mn,oa,om,zE} = $context;

    if (!$context.Fc) return;
    let R = $context.Fc;
    if ($context.Fc = null, !(R.kind === f && R.index === b)) {
      if (f === "armor" && R.kind === "slot") {
        let v = a.slots[R.index];
        if (!v || !om(b, v.id) || v.n !== 1) return;
        let N = a.armor[b];
        a.armor[b] = v.id, a.slots[R.index] = N ? { id: N, n: 1 } : null, kl();
        return;
      }
      if (R.kind === "armor" && f === "slot") {
        let v = a.armor[R.index], N = a.slots[b];
        if (!v || N && !om(R.index, N.id)) return;
        a.armor[R.index] = N?.id || 0, a.slots[b] = { id: v, n: 1 }, kl();
        return;
      }
      if (["slot", "chest"].includes(R.kind) && ["slot", "chest"].includes(f)) {
        let v = R.kind === "slot" ? a.slots : Va(), N = f === "slot" ? a.slots : Va(), V = v[R.index], L = N[b];
        if (!V) return;
        if (L?.id === V.id) {
          let z = Math.min(V.n, La(L.id) - L.n);
          L.n += z, V.n -= z, V.n || (v[R.index] = null);
        } else N[b] = V, v[R.index] = L || null;
      } else if (R.kind === "slot" && f === "grid") {
        let v = a.slots[R.index];
        if (!v || mn[b] || v.id === oa) return;
        mn[b] = v.id, v.n--, v.n || (a.slots[R.index] = null);
      } else if (R.kind === "grid" && f === "slot") {
        let v = mn[R.index], N = a.slots[b];
        if (!v || N && N.id !== v || N && N.n >= La(v)) return;
        N ? N.n++ : a.slots[b] = { id: v, n: 1 }, mn[R.index] = 0;
      } else if (R.kind === "chest" && f === "grid") {
        let v = Va()[R.index];
        if (!v || mn[b]) return;
        mn[b] = v.id, v.n--, v.n || (Va()[R.index] = null);
      } else if (R.kind === "grid" && f === "chest") {
        let v = mn[R.index], N = Va()[b];
        if (!v || N && N.id !== v || N && N.n >= La(v)) return;
        N ? N.n++ : Va()[b] = { id: v, n: 1 }, mn[R.index] = 0;
      } else if (R.kind === "grid" && f === "grid") {
        let v = mn[b];
        mn[b] = mn[R.index], mn[R.index] = v;
      } else if (R.kind === "result" && f === "slot") {
        let v = Am(), N = a.slots[b];
        if (!v || N && N.id !== v.out || N && N.n + v.count > La(v.out)) return;
        N ? N.n += v.count : a.slots[b] = { id: v.out, n: v.count }, mn.fill(0), zE(v);
      }
      kl();
    }
  }

function ff(f, b, R) {
    const {jb} = $context;

    f.ondragover = (v) => {
      v.preventDefault(), f.classList.add("drag-over");
    }, f.ondragleave = () => f.classList.remove("drag-over"), f.ondrop = (v) => {
      v.preventDefault(), f.classList.remove("drag-over"), jb(b, R);
    }, f.ondragstart = (v) => {
      $context.Fc = { kind: b, index: R }, v.dataTransfer.setData("text/plain", b + ":" + R), v.dataTransfer.effectAllowed = "move";
    };
  }

function PE(f) {
    return f.pattern.length <= $context.io && f.pattern.every((b) => b.length <= $context.io);
  }

function am(f, b) {
    const {G,Mt,TE,Wp} = $context;

    return f === G ? TE.includes(b) : f === Mt ? [Mt, Wp].includes(b) : f === b;
  }

function kE(f) {
    const {G,Mt,TE,Wp,a,am,mn} = $context;

    let b = /* @__PURE__ */ new Map();
    for (let v of a.slots) v && b.set(v.id, (b.get(v.id) || 0) + v.n);
    for (let v of mn) v && b.set(v, (b.get(v) || 0) + 1);
    let R = [];
    for (let v of f.pattern.flat()) {
      if (!v) {
        R.push(0);
        continue;
      }
      let N = a.mode === "creative" ? v : (v === G ? TE : v === Mt ? [Mt, Wp] : [v]).find((V) => am(v, V) && (b.get(V) || 0) > 0);
      if (N === void 0) return null;
      b.set(N, (b.get(N) || 0) - 1), R.push(N);
    }
    return R;
  }

function Cf(f) {
    const {kE} = $context;

    return !!kE(f);
  }

function qb(f) {
    const {Cf,Fa,I,PE,a,kE,lm,mn} = $context;

    if (!PE(f) || !Cf(f)) return;
    lm();
    let b = kE(f);
    if (!b) {
      Fa();
      return;
    }
    let R = 0;
    for (let v = 0; v < f.pattern.length; v++) for (let N = 0; N < f.pattern[v].length; N++) {
      let V = b[R++];
      if (!V || (mn[v * $context.io + N] = V, a.mode === "creative")) continue;
      let L = a.slots.findIndex((z) => z?.id === V);
      if (L < 0) {
        lm(), Fa();
        return;
      }
      --a.slots[L].n === 0 && (a.slots[L] = null);
    }
    I(), Fa();
  }

function GE() {
    const {Cf,PE,ki,qb,qr} = $context;

    let f = document.getElementById("recipeBook"), b = document.getElementById("recipeButton");
    if (f.hidden = !$context.Vc, b.setAttribute("aria-expanded", String($context.Vc)), !$context.Vc) return;
    f.innerHTML = "<h3>Recipes \xB7 " + $context.io + "\xD7" + $context.io + "</h3>";
    let R = ki.filter(PE).sort((v, N) => Number(Cf(N)) - Number(Cf(v)));
    if (!R.length) {
      f.innerHTML += "<p>No recipes fit this grid.</p>";
      return;
    }
    for (let v of R) {
      let N = Cf(v), V = document.createElement("button");
      V.className = "recipe-entry", V.type = "button", V.disabled = !N, V.title = N ? "Click to place ingredients" : "Collect the required ingredients", V.innerHTML = qr(v.out) + `<span>${v.name}</span><span>${N ? "READY" : "MISSING ITEMS"}</span>`, V.onclick = () => qb(v), f.append(V);
    }
  }

function ty(f) {
    const {i,r} = $context;

    if(r[f].category)return r[f].category;
    let b = r[f].name.toLowerCase();
    return /redstone|piston|lever|rail|button|pressure plate|repeater|comparator|observer|dispenser|dropper|hopper|daylight|target|trapped chest|note block|copper bulb|tripwire|sculk sensor|crafter|trapdoor|lightning rod|lectern|chiseled bookshelf/.test(b) ? "Redstone" : /sword|bow|arrow|shield|helmet|chestplate|leggings|boots|elytra|tnt/.test(b) ? "Combat" : /pickaxe|\baxe\b|shovel|\bhoe\b|shears|fishing rod|flint and steel|\bbucket\b|boat|minecart|firework rocket|eye of ender|ender pearl/.test(b) ? "Tools" : /apple|carrot|potato|bread|meat|chicken|\bcod\b|melon|glow berries|potion|water bottle/.test(b) ? "Food" : i.isBlock(f) ? /crafting|furnace|chest|bed|door|ladder|torch|lantern|table|anvil|brewing|spawner|portal|jukebox|stonecutter|bookshelf|shulker box|bee nest|campfire|bell/.test(b) ? "Functional" : /grass|dirt|stone|sand|gravel|ore|debris|log|wood|leaves|sapling|flower|roots|fungus|vine|moss|azalea|dripleaf|dripstone|snow|water|lava|fire|cactus|clay|basalt|netherrack|end stone|farmland|wheat crop/.test(b) ? "Nature" : "Building" : "Ingredients";
  }

function sm() {
    const {$b,En,FE,Fa,Gl,LE,La,ey,ny,qr,r,rm} = $context;

    let f = Gl.scrollTop, b = LE.value.trim().toLowerCase(), signature=$context.If+"|"+b;
    if($context.catalogKey===signature)return;$context.catalogKey=signature;
    FE.replaceChildren();
    for (let v of $b) {
      let N = document.createElement("button");
      N.type = "button", N.role = "tab", N.textContent = v, N.setAttribute("aria-selected", String($context.If === v)), N.onclick = () => {
        $context.If = v, Gl.scrollTop = 0, sm();
      }, FE.append(N);
    }
    let R = rm.filter((v) => ($context.If === "All" || ny.get(v) === $context.If) && r[v].name.toLowerCase().includes(b));
    ey.textContent = `${R.length} / ${rm.length}`, Gl.replaceChildren();
    for (let v of R) {
      let N = document.createElement("button");
      N.type = "button", N.className = "item-button", N.dataset.itemId = v, N.title = r[v].name, N.setAttribute("aria-label", r[v].name), N.innerHTML = qr(v), N.onclick = () => {
        En(v, La(v)), Fa();
      }, Gl.append(N);
    }
    Gl.scrollTop = f;
  }

function Fa() {
    const {A,Af,Am,BE,Be,DE,GE,I,Jp,Ks,NE,Qb,Ul,VE,Va,Xb,Zb,a,ff,i,im,mn,qr,r,sm} = $context;

    let f = document.getElementById("armorSlots"), b = document.getElementById("offhandSlot");
    f.innerHTML = "", b.innerHTML = "";
    for (let L of Qb) {
      let z = a.armor[L], H = document.createElement("button");
      H.className = "item-button" + (z ? "" : " empty"), H.dataset.symbol = { helmet: "\u2659", chestplate: "\u265C", leggings: "\u265F", boots: "\u2667", offhand: "\u2662" }[L], H.title = z ? r[z].name : `${L} slot`, H.setAttribute("aria-label", H.title), H.innerHTML = z ? qr(z) : "", H.draggable = !!z, H.onclick = () => Zb(L), ff(H, "armor", L), (L === "offhand" ? b : f).append(H);
    }
    BE.innerHTML = "";
    for (let L = 0; L < 36; L++) {
      let z = a.slots[L], H = document.createElement("button");
      H.className = "item-button" + (L >= 27 ? " hotbar-row" : "") + (z ? "" : " empty"), H.title = z ? `${r[z.id].name} \xD7${z.n}` : `Empty slot ${L + 1}`, H.setAttribute("aria-label", H.title), H.innerHTML = z ? `${qr(z.id)}<span class="stack-count">${z.n}</span>` : "", H.draggable = !!z, H.onclick = () => DE(L), H.oncontextmenu = (q) => {
        q.preventDefault(), DE(L, true);
      }, ff(H, "slot", L), BE.append(H);
    }
    Af.style.setProperty("--grid-size", $context.io), Af.innerHTML = "";
    for (let L = 0; L < $context.io * $context.io; L++) {
      let z = document.createElement("button"), H = mn[L];
      z.className = "craft-cell", z.title = H ? r[H].name : "Empty crafting slot", z.innerHTML = H ? qr(H) : "", z.draggable = !!H, z.onclick = () => NE(L), z.oncontextmenu = (q) => {
        q.preventDefault(), NE(L, true);
      }, ff(z, "grid", L), Af.append(z);
    }
    let R = Am();
    Ul.innerHTML = R ? qr(R.out) : "", Ul.title = R ? `Craft ${R.name}` : "No matching recipe", Ul.classList.toggle("ready", !!R), Ul.draggable = !!R, Ul.ondragstart = (L) => {
      $context.Fc = { kind: "result", index: 0 }, L.dataTransfer.setData("text/plain", "result"), L.dataTransfer.effectAllowed = "move";
    }, Xb();
    let v = document.getElementById("chestSection"), N = document.getElementById("chestItems");
    if (v.hidden = !$context.Qo, $context.Qo) {
      let [L, z] = $context.Qo.split(":"), [H, q, Ue] = z.split(",").map(Number), Ye = L === i.getDimension() ? A(H, q, Ue) : Be, Se = a.crafterDisabled?.[$context.Qo] || [];
      v.querySelector("h3").innerHTML = `${(r[Ye]?.name || "Chest").toUpperCase()} <span>${Va().length} SLOTS</span>`, N.innerHTML = "", Va().forEach((ue, qe) => {
        let ze = document.createElement("button");
        ze.className = "item-button" + (ue ? "" : " empty") + (Ye === Ks && Se[qe] ? " disabled" : ""), ze.title = Ye === Ks && Se[qe] ? `Disabled crafter slot ${qe + 1}` : ue ? `${r[ue.id].name} \xD7${ue.n}` : `Empty slot ${qe + 1}`, ze.innerHTML = ue ? `${qr(ue.id)}<span class="stack-count">${ue.n}</span>` : Ye === Ks && Se[qe] ? "\xD7" : "", ze.draggable = !!ue, ze.onclick = () => {
          if (Ye === Ks && !ue && !$context.Bt) {
            (a.crafterDisabled[$context.Qo] ??= Array(9).fill(false))[qe] = !Se[qe], I(), Fa();
            return;
          }
          Se[qe] || im(Va(), qe);
        }, ze.oncontextmenu = (tn) => {
          tn.preventDefault(), Se[qe] || im(Va(), qe, true);
        }, Se[qe] || ff(ze, "chest", qe), N.append(ze);
      });
    }
    let V = document.getElementById("creativeCatalog");
    V.hidden = a.mode !== "creative", Jp.querySelector(".inventory-panel").classList.toggle("creative-open", a.mode === "creative"), a.mode === "creative" && sm(), GE(), VE();
  }

function VE() {
    const {$e,$h,A,Bp,Dc,En,Fa,Fp,Fs,G,Gt,Hn,Hr,I,In,Jh,Lc,Lt,Mt,Pe,Pl,SE,Vp,Vs,Wp,Xh,Xt,Ys,Zh,_e,a,cE,dE,enchantmentTier,eo,equipmentValues,gE,hf,i,j,jh,kb,me,mt,nm,oe,qh,r,rE,re,rt,uE,vi,we,wn,x,y,yt,zp} = $context;

    let f = document.getElementById("featureSection");
    if (f.hidden = !$context.ci, !$context.ci) return;
    f.innerHTML = "";
    let b = document.createElement("h3");
    b.textContent = $context.ci.title, f.append(b);
    let R = (L) => {
      let z = document.createElement("p");
      z.textContent = L, f.append(z);
    }, v = (L, z, H) => {
      let q = document.createElement("button");
      q.type = "button", q.textContent = L, q.disabled = !z, q.onclick = () => {
        H(), I(), Fa();
      }, f.append(q);
    }, N = Hn(), V = Pl(a.xp).level;
    if ($context.ci.kind === "enchant") {
      let L = 0, z = $context.ci.hit;
      for (let q = -2; q <= 2; q++) for (let Ue = -2; Ue <= 2; Ue++) Math.max(Math.abs(Ue), Math.abs(q)) === 2 && A(z.x + Ue, z.y, z.z + q) === rE && L++;
      R(`Select a tool in the hotbar. ${L} nearby bookshelves \xB7 Level ${V} \xB7 Lapis ${wn(Fs)}.`);
      let H = vi[N];
      for (let q = 1; q <= 3; q++) {
        let Ue = q, Ye = q === 3 ? Math.min(30, 8 + L * 2) : q === 2 ? Math.min(15, 4 + L) : 1, Se = H?.kind === "sword" ? "Sharpness" : H?.kind === "armor" ? "Protection" : "Efficiency";
        v(`${Se} offer ${q} \xB7 requires level ${Ye} \xB7 ${Ue} lapis`, !!H && V >= Ye && wn(Fs) >= Ue, () => {
          mt(Fs, Ue), nm(Ue);
          let tier = enchantmentTier(Se, Ye, H.enchantability);
          a.enchants[N] = { kind: Se, tier };
          $context.p(`${r[N].name.toUpperCase()} ENCHANTED \xB7 ${Se.toUpperCase()} ${tier}`);
        });
      }
    } else if ($context.ci.kind === "anvil") {
      let L = vi[N], z = { planks: G, cobblestone: Mt, blackstone: Wp, iron_ingot: _e, diamond: eo, netherite_ingot: Jh, gold_ingot: In, copper_ingot: Vs, leather: yt, turtle_scute: 640 }[L?.repair] || G;
      R(`Select equipment in the hotbar. Level ${V}. Repair restores 25% durability per material.`), v(`Repair selected item \xB7 1 ${r[z].name} + 1 level`, !!L && wn(z) > 0 && V >= 1, () => {
        mt(z), nm(1), a.durability ??= {}, a.durability[N] = Math.min(L.durability, (a.durability[N] ?? L.durability) + Math.ceil(L.durability * 0.25)), $context.p("ITEM REPAIRED");
      });
      let H = document.createElement("input");
      H.placeholder = "New item name", H.maxLength = 32, f.append(H), v("Rename selected item \xB7 1 level", !!N && V >= 1, () => {
        let q = H.value.trim();
        q && (nm(1), a.names ??= {}, a.names[N] = q, $context.p(`RENAMED TO ${q.toUpperCase()}`));
      });
    } else if ($context.ci.kind === "furnace") {
      let L = $context.ci.key, z = a.furnaceJobs[L], H = Math.ceil(a.furnaceFuel[L] || 0), q = a.furnaceOutputs[L];
      R(z ? `Smelting ${r[z.out].name}: ${Math.ceil(z.left)} seconds left, fuel ${H}s` : `Fuel remaining: ${H}s. Smelting takes 10 seconds.`), q && v(`Collect ${q.n} ${r[q.id].name}`, true, () => {
        let Ye = En(q.id, q.n);
        q.n -= Ye, q.n || delete a.furnaceOutputs[L];
      });
      let Ue = () => [[Bp, 80], [Dc, 80], [x, 80], [G, 15], [re, 15], [$e, 15], [y, 15], [rt, 15], [oe, 15], [we, 5]].find(([Ye]) => wn(Ye) > 0);
      v("Add fuel", !!Ue(), () => {
        let [Ye, Se] = Ue();
        mt(Ye), a.furnaceFuel[L] = (a.furnaceFuel[L] || 0) + Se, I();
      });
      for (let [Ye, Se] of kb) v(`${r[Ye].name} to ${r[Se].name}`, !z && wn(Ye) > 0 && (!q || q.id === Se && q.n < 64) && (H >= 10 || !!Ue()), () => {
        if ((a.furnaceFuel[L] || 0) < 10) {
          let [ue, qe] = Ue();
          mt(ue), a.furnaceFuel[L] = (a.furnaceFuel[L] || 0) + qe;
        }
        mt(Ye), a.furnaceJobs[L] = { input: Ye, out: Se, left: 10 }, $context.p("SMELTING STARTED");
      });
    } else if ($context.ci.kind === "stonecut") R("Cut one copper block into four cut copper blocks."), v("1 Copper block \u2192 4 Cut copper", wn(Lc) > 0, () => {
      mt(Lc), En(SE, 4), $context.p("CUT COPPER CRAFTED");
    });
    else if ($context.ci.kind === "brew") {
      let L = $context.ci.key, z = a.brewJobs[L];
      R(z ? `Brewing ${r[z.out].name}: ${Math.ceil(z.left)} seconds remaining` : "Blaze powder fuels the stand. Each brew takes 20 seconds.");
      for (let [H, q, Ue] of [[Fp, Vp, Ys], [Ys, uE, Xh], [Ys, dE, Zh], [Ys, j, jh], [Ys, gE, qh], [Ys, cE, $h]]) v(`${r[H].name} + ${r[q].name} \u2192 ${r[Ue].name}`, !z && wn(H) > 0 && wn(q) > 0 && wn(j) > 0, () => {
        mt(H), mt(q), mt(j), a.brewJobs[L] = { out: Ue, left: 20 }, $context.p("BREWING STARTED");
      });
    } else if ($context.ci.kind === "smith") {
      R("Upgrade diamond equipment with a netherite ingot and upgrade template.");
      for (let [L, z] of Object.entries(equipmentValues).filter(([, gear]) => gear.material === "diamond").map(([id, gear]) => [+id, +Object.keys(equipmentValues).find((key) => {
        let target = equipmentValues[key];
        return target.material === "netherite" && target.kind === gear.kind && target.slot === gear.slot;
      })]).filter(([, target]) => target)) v(`Upgrade ${r[L].name}`, wn(L) > 0 && wn(Jh) > 0 && wn(zp) > 0, () => {
        mt(L), mt(Jh), mt(zp), En(z), a.durability ??= {}, a.durability[z] = vi[z].durability, $context.p("NETHERITE UPGRADE COMPLETE");
      });
    } else if ($context.ci.kind === "trade") {
      let L = $context.ci.mob, z = a.tradeRanks[L.profession] || 0, H = L.profession === "farmer" ? [[Pe, 4, Gt, 1], [Gt, 1, me, 3]] : L.profession === "librarian" ? [[Xt, 8, Gt, 1], [Gt, 2, Lt, 1]] : [[Hr, 4, Gt, 1], [Gt, 2, _e, 1]];
      R(`${L.profession.toUpperCase()} \xB7 ${z} trades. Offers restock while the villager is active.`);
      for (let [q, Ue, Ye, Se] of H) v(`${Ue} ${r[q].name} \u2192 ${Se} ${r[Ye].name}`, wn(q) >= Ue, () => {
        mt(q, Ue), En(Ye, Se), a.tradeRanks[L.profession] = z + 1, hf(2), $context.p("TRADE COMPLETE"), i.getDimension() === "overworld" && $context.n.y >= i.maxY - 2 && i.awardAdvancement("star_trader", "Star Trader");
      });
    }
  }

function $r(f, b = null, R = null) {
    const {Ll,vo} = $context;

    $context.ci = { kind: f, hit: b, mob: R, key: b ? vo(b) : "", title: { enchant: "ENCHANTING TABLE", anvil: "ANVIL", brew: "BREWING STAND", smith: "SMITHING TABLE", trade: "VILLAGER TRADING", furnace: "FURNACE", stonecut: "STONECUTTER" }[f] }, Ll(false);
  }

function iy() {
    const {mn} = $context;

    let f = 3, b = 3, R = -1, v = -1;
    for (let V = 0; V < $context.io; V++) for (let L = 0; L < $context.io; L++) mn[V * $context.io + L] && (f = Math.min(f, L), b = Math.min(b, V), R = Math.max(R, L), v = Math.max(v, V));
    if (R < 0) return [];
    let N = [];
    for (let V = b; V <= v; V++) {
      let L = [];
      for (let z = f; z <= R; z++) L.push(mn[V * $context.io + z]);
      N.push(L);
    }
    return N;
  }

function Am() {
    const {am,iy,ki} = $context;

    let f = iy();
    return ki.find((b) => b.pattern.length === f.length && b.pattern.every((R, v) => R.length === f[v].length && R.every((N, V) => am(N, f[v][V]))));
  }

function zE(f) {
    const {a,vi} = $context;

    vi[f.out] && (a.durability ??= {}, a.durability[f.out] = (a.durability[f.out] || 0) + vi[f.out].durability), $context.p(`CRAFTED ${f.name.toUpperCase()}`), $context.m('click');
  }

function lm() {
    const {En,mn} = $context;

    for (let f of mn) f && En(f);
    mn.fill(0), $context.Bt && (En($context.Bt.id, $context.Bt.n, $context.Bt.data), $context.Bt = null);
  }

function Va() {
    const {a} = $context;

    return $context.Qo ? a.chests[$context.Qo] ?? (a.chests[$context.Qo] = Array(27).fill(null)) : [];
  }

function Ll(f = false, b = null) {
    const {Af,Fa,Jp,a,gm,i,mn} = $context;

    if ($context.Jr) {
      gm();
      return;
    }
    if(b)i.onChestView?.(b,true);
    $context.Qo = b, $context.zb = f, $context.io = f ? 3 : 2, mn.fill(0), $context.Bt = null, $context.Jr = true, Jp.hidden = false, i.onOpen(), document.exitPointerLock?.(), document.getElementById("craftSizeLabel").textContent = f ? "3\xD73" : "2\xD72", document.getElementById("seedDisplay").textContent = a.seed, Af.style.setProperty("--grid-size", $context.io), Fa();
  }

function gm() {
    const {Jp,ao,i,lm} = $context;

    $context.Jr && ($context.Qo&&i.onChestView?.($context.Qo,false),lm(), $context.Qo && i.closeRedstoneContainer?.($context.Qo), $context.Jr = false, $context.Qo = null, $context.ci = null, Jp.hidden = true, ao(), i.onClose());
  }

function Hn() {
    const {a,i} = $context;

    return a.slots[27 + i.getSelected()]?.id || 0;
  }
return {wn,En,mt,qr,hudWrite,ao,Xb,kl,im,DE,om,Zb,NE,jb,ff,PE,am,kE,Cf,qb,GE,ty,sm,Fa,VE,$r,iy,Am,zE,lm,Va,Ll,gm,Hn};
}
