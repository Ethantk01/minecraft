// Pointer lock remains the default. Drag-look is only a browser failure fallback.
let unavailable=false;
export const pointerLockUnavailable=()=>unavailable;
export function requestGamePointerLock(canvas){
  if(document.pointerLockElement===canvas)return;
  if(typeof canvas.requestPointerLock!=='function'){unavailable=true;return;}
  try{const result=canvas.requestPointerLock();result?.catch(()=>{unavailable=true;});}catch{unavailable=true;}
}
document.addEventListener('pointerlockerror',()=>{unavailable=true;});
document.addEventListener('pointerlockchange',()=>{if(document.pointerLockElement)unavailable=false;});
