// Spawn searches use the same collision policy as movement. Never clear builds.
export function safeSpawn(position,{collides,solid,minY=-63,maxY=318,radius=16}){
  const clear=(x,y,z)=>y>=minY&&y<=maxY&&!collides(x,y,z);
  if(clear(position.x,position.y,position.z))return {...position};
  for(let r=0;r<=radius;r++)for(let dz=-r;dz<=r;dz++)for(let dx=-r;dx<=r;dx++){
    if(Math.max(Math.abs(dx),Math.abs(dz))!==r)continue;
    const x=Math.floor(position.x)+dx+.5,z=Math.floor(position.z)+dz+.5;
    for(let offset=0;offset<=32;offset++)for(const sign of offset?[1,-1]:[1]){
      const y=Math.floor(position.y)+offset*sign;
      if(clear(x,y,z)&&solid(Math.floor(x),y-1,Math.floor(z)))return {...position,x,y,z};
    }
  }
  // An open air fallback above the requested column is preferable to suffocation.
  for(let y=Math.max(minY,Math.floor(position.y));y<=maxY;y++)if(clear(position.x,y,position.z))return {...position,y};
  throw new Error('No safe spawn found');
}
