/** Blocks select a machine interface by content ID, independently of interaction dispatch. */
export const MACHINE_INTERFACES={FURNACE:'furnace',STONECUTTER:'stonecut',ENCHANTING_TABLE:'enchant',ANVIL:'anvil',BREWING_STAND:'brew',SMITHING_TABLE:'smith'};
export function registerMachineInterfaces(registry,ids,open) {
  if(!registry)return;
  for(const [name,kind] of Object.entries(MACHINE_INTERFACES))registry.registerHandler('interact',ids[name],({hit})=>{open(kind,hit);return true;});
}
