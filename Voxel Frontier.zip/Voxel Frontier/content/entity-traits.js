/** Collision and attack components are content, not species branches in physics. */
export const ENTITY_TRAITS={
  cow:{collider:{radius:.43,height:1.7}},sheep:{collider:{radius:.43,height:1.7}},
  spider:{collider:{radius:.82,height:1.05},contactAttack:{range:1.8,damage:2,cooldown:1.4,message:'SPIDER BITE'}},
  creeper:{collider:{radius:.31,height:2}},
  enderman:{collider:{radius:.27,height:2.92},eyeHeight:2.62},
  blaze:{collider:{radius:.38,height:2.15},ranged:{projectile:'blaze',range:12,cooldown:2.5}},
  ghast:{collider:{radius:2,height:7},ranged:{projectile:'fireball',range:20,cooldown:3}},
  skeleton:{ranged:{projectile:'arrow',range:13,cooldown:2.2}},
  witch:{ranged:{projectile:'potion',range:9,cooldown:4}},
  shulker:{knockbackImmune:true,collider:{radius:.47,height:1},canStep:false,ranged:{projectile:'bullet',range:13,cooldown:4}},
  dragon:{knockbackImmune:true,collider:{radius:1.4,height:4.2},terrainCollision:false}
};
