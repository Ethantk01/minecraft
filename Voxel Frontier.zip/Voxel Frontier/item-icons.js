import modelIcons from './item-icon-manifest.json';
import iconData from './item-icon-data.json';
/** One icon resolver for inventory, hotbar, machines and dropped-item visuals. */
const decodedIcons=new Map(),iconQueue=new Set();let dynamicRenderer=null,iconsReady=()=>false,iconsChanged=()=>{},scheduled=false,epoch=0,notifyTimer;
export function configureDynamicIcons(render,ready,changed){dynamicRenderer=render;iconsReady=ready;iconsChanged=changed;}
export function invalidateDynamicIcons(items){epoch++;for(const item of Object.values(items))if(item.dynamicIcon)item.iconEpoch=-1;}
function queueIcon(item){if(!dynamicRenderer||!item.dynamicIcon||item.iconEpoch===epoch)return;iconQueue.add(item);if(scheduled)return;scheduled=true;requestAnimationFrame(renderIcons);}
function renderIcons(){scheduled=false;if(!iconsReady()){if(iconQueue.size){scheduled=true;requestAnimationFrame(renderIcons);}return;}const start=performance.now();let count=0;for(const item of iconQueue){iconQueue.delete(item);try{item.iconURL=dynamicRenderer(item.id);item.iconEpoch=epoch;}catch(error){console.warn('Icon render failed',item.name,error);item.iconEpoch=epoch;}if(++count>=4||performance.now()-start>=4)break;}clearTimeout(notifyTimer);notifyTimer=setTimeout(iconsChanged,iconQueue.size?150:0);if(iconQueue.size){scheduled=true;requestAnimationFrame(renderIcons);}}

export function itemIconURL(item) {
 if(item)queueIcon(item);
 const url=item?.iconURL||iconData[item?.icon]||'';
 if(!/^data:image\/[^;]+;base64,/.test(url)||typeof URL.createObjectURL!=='function')return url;
 if(!decodedIcons.has(url)){const comma=url.indexOf(','),bytes=Uint8Array.from(atob(url.slice(comma+1)),c=>c.charCodeAt(0));decodedIcons.set(url,URL.createObjectURL(new Blob([bytes],{type:url.slice(5,url.indexOf(';'))})));}
 return decodedIcons.get(url);
}
export function applyItemIcons(items,blocks,textureFor) {
  for(const [id,item] of Object.entries(items)) {
    item.id=Number(id);item.dynamicIcon=!!blocks[id];item.iconEpoch=-1;
    item.icon=modelIcons[id]||item.icon||(blocks[id]?textureFor(Number(id),2):undefined);
    item.iconURL=iconData[item.icon]||'';
    if(!item.iconURL)console.warn('Missing registered item icon',id,item.name,item.icon);
  }
}
