import modelIcons from './item-icon-manifest.json';
import iconData from './item-icon-data.json';
/** One icon resolver for inventory, hotbar, machines and dropped-item visuals. */
export function itemIconURL(item) {return item?.iconURL || iconData[item?.icon] || '';}
export function applyItemIcons(items,blocks,textureFor) {
  for(const [id,item] of Object.entries(items)) {
    item.icon=modelIcons[id]||item.icon||(blocks[id]?textureFor(Number(id),2):undefined);
    item.iconURL=iconData[item.icon]||'';
    if(!item.iconURL)console.warn('Missing registered item icon',id,item.name,item.icon);
  }
}
