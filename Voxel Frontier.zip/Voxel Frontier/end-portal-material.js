import portal from './textures/end_portal.png';
import sky from './textures/end_sky.png';
// Adapted from the installed Java client's projected, layered End portal shader.
export function createEndPortalMaterial(THREE){
  const loader=new THREE.TextureLoader(),load=url=>{const t=loader.load(url);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.magFilter=t.minFilter=THREE.NearestFilter;return t;};
  const material=new THREE.ShaderMaterial({side:THREE.DoubleSide,uniforms:{sky:{value:load(sky)},portal:{value:load(portal)},time:{value:0}},
    vertexShader:`varying vec4 projected;void main(){gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);projected=gl_Position*.5;projected.xy+=projected.ww;projected.zw=gl_Position.zw;}`,
    fragmentShader:`uniform sampler2D sky;uniform sampler2D portal;uniform float time;varying vec4 projected;
    vec3 tint(int i){if(i==0)return vec3(.022087,.098399,.110818);if(i==1)return vec3(.011892,.095924,.089485);if(i==2)return vec3(.027636,.101689,.100326);if(i==3)return vec3(.046564,.109883,.114838);if(i==4)return vec3(.064901,.117696,.097189);if(i==5)return vec3(.063761,.086895,.123646);if(i==6)return vec3(.084817,.111994,.166380);if(i==7)return vec3(.097489,.154120,.091064);if(i==8)return vec3(.106152,.131144,.195191);if(i==9)return vec3(.097721,.110188,.187229);if(i==10)return vec3(.133516,.138278,.148582);if(i==11)return vec3(.070006,.243332,.235792);if(i==12)return vec3(.196766,.142899,.214696);if(i==13)return vec3(.047281,.315338,.321970);if(i==14)return vec3(.204675,.390010,.302066);return vec3(.080955,.314821,.661491);}
    void main(){vec2 uv=projected.xy/projected.w;vec3 c=texture2D(sky,uv).rgb*tint(0);for(int i=0;i<16;i++){float l=float(i+1),a=radians((l*l*4321.+l*9.)*2.);mat2 r=mat2(cos(a),sin(a),-sin(a),cos(a));vec2 p=uv*.5+vec2(17./l,(2.+l/1.5)*time*.0015)+.25;p=r*p*((4.5-l/4.)*2.);c+=texture2D(portal,p).rgb*tint(i);}gl_FragColor=vec4(c,1.);}`});
  return material;
}
