/** Deduplicated scheduled block updates, ordered by due tick, priority and insertion. */
export function createScheduledUpdates(){
 const heap=[],pending=new Map();let order=0;
 const before=(a,b)=>a.due-b.due||a.priority-b.priority||a.order-b.order;
 function schedule(key,due,payload,priority=0){if(pending.has(key))return false;const entry={key,due,payload,priority,order:order++};pending.set(key,entry);heap.push(entry);let i=heap.length-1;while(i){const parent=(i-1)>>1;if(before(heap[parent],entry)<=0)break;heap[i]=heap[parent];i=parent;}heap[i]=entry;return true;}
 function drain(tick,run,limit=320){let count=0;while(heap.length&&heap[0].due<=tick&&count<limit){const entry=heap[0],last=heap.pop();if(heap.length){let i=0;while(i*2+1<heap.length){let child=i*2+1;if(child+1<heap.length&&before(heap[child+1],heap[child])<0)child++;if(before(last,heap[child])<=0)break;heap[i]=heap[child];i=child;}heap[i]=last;}pending.delete(entry.key);run(entry.payload);count++;}return count;}
 return {schedule,drain,has:key=>pending.has(key),get size(){return heap.length;}};
}
