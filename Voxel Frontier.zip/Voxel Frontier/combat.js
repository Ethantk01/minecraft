// Java Edition 1.21.10: verified against Player.attack, LivingEntity.hurtServer,
// CombatRules and entity createAttributes in the installed client.
export const ENTITY_COMBAT = {
  cow:{health:10,damage:0}, sheep:{health:8,damage:0}, villager:{health:20,damage:0},
  zombie:{health:20,damage:3,armor:2}, creeper:{health:20,damage:0,explosionPower:3},
  skeleton:{health:20,damage:2}, spider:{health:16,damage:2}, witch:{health:26,damage:6},
  blaze:{health:20,damage:6,projectileDamage:5}, piglin:{health:16,damage:5},
  enderman:{health:40,damage:7}, ghast:{health:10,damage:6,explosionPower:1},
  shulker:{health:30,damage:4}, dragon:{health:200,damage:10,wingDamage:5,breathDamage:6}
};
export function attackSpeed(gear){
  if(!gear)return 4;
  if(gear.kind==='sword')return 1.6;
  if(gear.kind==='pick')return 1.2;
  if(gear.kind==='shovel')return 1;
  if(gear.kind==='axe')return {wood:.8,stone:.8,copper:.9,iron:.9,gold:1,diamond:1,netherite:1}[gear.material]||1;
  if(gear.kind==='hoe')return {wood:1,gold:1,stone:2,copper:2,iron:3,diamond:4,netherite:4}[gear.material]||1;
  return 4;
}
export function meleeAttack(gear,elapsed,{critical=false,sprinting=false,strength=0,sharpness=0}={}){
  const charge=Math.min(1,Math.max(0,(elapsed+.025)*attackSpeed(gear))),strong=charge>.9;
  critical=strong&&critical&&!sprinting;
  return {charge,critical,strong,damage:Math.max(0,(gear?.damage??1)+strength*3)*(.2+.8*charge*charge)*(critical?1.5:1)+(sharpness? .5*sharpness+.5:0)*charge,
    knockback:strong&&sprinting?1.5:1,sweep:strong&&!critical&&!sprinting&&gear?.kind==='sword',disableShield:gear?.kind==='axe'?5:0};
}
export function armorDamage(damage,armor=0,toughness=0){
  return damage*(1-Math.min(20,Math.max(armor*.2,armor-damage/(2+toughness/4)))/25);
}
export function acceptDamage(state,amount){
  if(!Number.isFinite(amount)||amount<=0)return 0;
  if((state.hurtRemaining||0)>.5){if(amount<=(state.lastHurt||0))return 0;const delta=amount-state.lastHurt;state.lastHurt=amount;return delta;}
  state.lastHurt=amount;state.hurtRemaining=1;return amount;
}
export function bowPower(seconds){const t=Math.max(0,seconds);return Math.min(1,(t*t+2*t)/3);}
