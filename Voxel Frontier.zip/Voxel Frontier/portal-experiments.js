// Portal-space coordinates are shared by the preview camera and teleportation.
export function mapPortalPoint(info,destinationCenter,destinationAxis,point){
  const dx=point.x-info.center.x,dz=point.z-info.center.z;
  if(info.axis==='x'&&destinationAxis==='z')return {x:destinationCenter.x-dz,y:destinationCenter.y+point.y-info.center.y,z:destinationCenter.z+dx};
  if(info.axis==='z'&&destinationAxis==='x')return {x:destinationCenter.x+dz,y:destinationCenter.y+point.y-info.center.y,z:destinationCenter.z-dx};
  return {x:destinationCenter.x+dx,y:destinationCenter.y+point.y-info.center.y,z:destinationCenter.z+dz};
}
export function mapPortalYaw(sourceAxis,destinationAxis,yaw){
  return yaw+(sourceAxis==='x'&&destinationAxis==='z'?-Math.PI/2:sourceAxis==='z'&&destinationAxis==='x'?Math.PI/2:0);
}
// Render each portal's projected rectangle into its own cropped target.
export function createPortalWindow(THREE,renderer,scene,camera){
  const remoteCamera=new THREE.PerspectiveCamera(camera.fov,camera.aspect,camera.near,camera.far);
  remoteCamera.rotation.order='YXZ';
  const windows=new Map(),reusable=[],viewport=new THREE.Vector2();
  const corners=Array.from({length:4},()=>new THREE.Vector3());
  const idOf=info=>`${info.type}:${info.axis}:${info.minX},${info.minY},${info.minZ}:${info.maxX},${info.maxY},${info.maxZ}`;
  function makeWindow(info){
    const cached=reusable.pop();
    const target=cached?.target||new THREE.WebGLRenderTarget(128,128,{depthBuffer:true,stencilBuffer:false});
    if(!cached){
      // WebGLRenderer writes linear values to render targets. Keep the texture
      // linear until the display shader applies the canvas output color space.
      target.texture.colorSpace=THREE.LinearSRGBColorSpace;
      target.texture.minFilter=THREE.NearestFilter;
      target.texture.magFilter=THREE.NearestFilter;
    }
    const material=cached?.material||new THREE.ShaderMaterial({
      uniforms:{view:{value:target.texture},rect:{value:new THREE.Vector4(0,0,1,1)}},
      vertexShader:'void main(){gl_Position=vec4(position,1.0);}',
      fragmentShader:'uniform sampler2D view;uniform vec4 rect;void main(){gl_FragColor=texture2D(view,(gl_FragCoord.xy-rect.xy)/rect.zw);\n#include <colorspace_fragment>\n}',
      side:THREE.DoubleSide,depthTest:true,depthWrite:true
    });
    const horizontal=info.axis==='horizontal';
    const width=horizontal?info.maxX-info.minX+1:info.axis==='x'?info.maxX-info.minX+1:info.maxZ-info.minZ+1;
    const height=horizontal?info.maxZ-info.minZ+1:info.maxY-info.minY+1;
    // Upload the clipped projected aperture. Clipping raw quad vertices behind
    // the eye in the vertex shader loses triangles on angled close approaches.
    const geometry=new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(16*3),3).setUsage(THREE.DynamicDrawUsage));
    const indices=[];for(let i=1;i<15;i++)indices.push(0,i,i+1);geometry.setIndex(indices);geometry.setDrawRange(0,0);
    const mesh=new THREE.Mesh(geometry,material);mesh.frustumCulled=false;
    mesh.rotation.set(horizontal?-Math.PI/2:0,info.axis==='z'?Math.PI/2:0,0);
    mesh.position.set((info.minX+info.maxX+1)/2,horizontal?info.minY+.76:(info.minY+info.maxY+1)/2,(info.minZ+info.maxZ+1)/2);
    mesh.renderOrder=4;scene.add(mesh);
    return {target,material,mesh,width,height,info};
  }
  function disposeWindow(view){scene.remove(view.mesh);view.mesh.geometry.dispose();view.material.dispose();view.target.dispose()}
  function retireWindow(view){
    scene.remove(view.mesh);view.mesh.geometry.dispose();
    if(reusable.length<2)reusable.push({target:view.target,material:view.material});
    else{view.material.dispose();view.target.dispose()}
  }
  function setApertures(infos){
    const wanted=new Set(infos.map(idOf));
    for(const [id,view] of windows)if(!wanted.has(id)){retireWindow(view);windows.delete(id)}
    for(const info of infos){const id=idOf(info),view=windows.get(id);if(view)view.info=info;else windows.set(id,makeWindow(info))}
  }
  function setAperture(info){setApertures(info?[info]:[])}
  function hide(){setApertures([])}
  function screenBounds(view){
    const {mesh,width,height}=view;
    mesh.updateMatrixWorld(true);
    // Clip against the eye plane before projecting; preserve the visible polygon.
    const nearZ=-.0001;
    const polygon=[0,1,3,2].map(i=>corners[i].set(i&1?width/2:-width/2,i&2?height/2:-height/2,0).applyMatrix4(mesh.matrixWorld).applyMatrix4(camera.matrixWorldInverse).clone());
    const clipped=[];
    for(let i=0;i<polygon.length;i++){
      const a=polygon[i],b=polygon[(i+1)%polygon.length],insideA=a.z<=nearZ,insideB=b.z<=nearZ;
      if(insideA!==insideB)clipped.push(a.clone().lerp(b,(nearZ-a.z)/(b.z-a.z)));
      if(insideB)clipped.push(b.clone());
    }
    if(!clipped.length)return null;
    let projected=clipped.map(vertex=>vertex.applyMatrix4(camera.projectionMatrix));
    // Clip the projected polygon to the viewport, carrying its depth with each
    // intersection. Depth remains correct for terrain occlusion ahead of portals.
    for(const [axis,bound,sign] of [['x',-1,1],['x',1,-1],['y',-1,1],['y',1,-1]]){
      const output=[];
      for(let i=0;i<projected.length;i++){
        const a=projected[i],b=projected[(i+1)%projected.length],insideA=(a[axis]-bound)*sign>=0,insideB=(b[axis]-bound)*sign>=0;
        if(insideA!==insideB)output.push(a.clone().lerp(b,(bound-a[axis])/(b[axis]-a[axis])));
        if(insideB)output.push(b.clone());
      }
      projected=output;if(projected.length<3)return null;
    }
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    const attribute=mesh.geometry.getAttribute('position');
    projected.forEach((vertex,index)=>{
      attribute.setXYZ(index,vertex.x,vertex.y,Math.max(-.99999,Math.min(.99999,vertex.z)));
      const x=(vertex.x+1)*viewport.x/2,y=(1-vertex.y)*viewport.y/2;
      minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);
    });
    attribute.needsUpdate=true;mesh.geometry.setDrawRange(0,(projected.length-2)*3);
    const left=Math.max(0,Math.floor(minX)-2),top=Math.max(0,Math.floor(minY)-2);
    const right=Math.min(viewport.x,Math.ceil(maxX)+2),bottom=Math.min(viewport.y,Math.ceil(maxY)+2);
    if(right<=left||bottom<=top)return null;
    return {left,top,width:right-left,height:bottom-top};
  }
  function render(resolveWorld){
    if(!windows.size)return;
    renderer.getDrawingBufferSize(viewport);
    camera.updateMatrixWorld();
    for(const view of windows.values()){
      if(view.info.axis==='horizontal'&&camera.position.y<=view.mesh.position.y){view.mesh.visible=false;continue}
      const world=resolveWorld(view.info);
      if(!world?.ready){view.mesh.visible=false;continue}
      const bounds=screenBounds(view);
      if(!bounds){view.mesh.visible=false;continue}
      view.mesh.visible=true;
      const {left,top,width,height}=bounds;
      // Bucket allocations so camera movement does not recreate GPU textures
      // every time the projected portal changes by a pixel.
      const targetWidth=Math.min(viewport.x,Math.max(128,Math.ceil(width/128)*128));
      const targetHeight=Math.min(viewport.y,Math.max(128,Math.ceil(height/128)*128));
      if(view.target.width!==targetWidth||view.target.height!==targetHeight)view.target.setSize(targetWidth,targetHeight);
      view.material.uniforms.rect.value.set(left,viewport.y-top-height,width,height);
      remoteCamera.fov=camera.fov;remoteCamera.aspect=camera.aspect;remoteCamera.near=camera.near;remoteCamera.far=camera.far;
      const mapped=mapPortalPoint(view.info,world.center,world.targetAxis,camera.position);
      remoteCamera.position.set(mapped.x,mapped.y,mapped.z);
      remoteCamera.rotation.copy(camera.rotation);
      remoteCamera.rotation.y=mapPortalYaw(view.info.axis,world.targetAxis,camera.rotation.y);
      remoteCamera.clearViewOffset();
      remoteCamera.setViewOffset(viewport.x,viewport.y,left,top,width,height);
      const previous=renderer.getRenderTarget();
      renderer.setRenderTarget(view.target);
      try{if(world.renderScene)world.renderScene(()=>renderer.render(world.scene,remoteCamera));else renderer.render(world.scene,remoteCamera);}finally{renderer.setRenderTarget(previous);}
    }
  }
  function dispose(){for(const view of windows.values())disposeWindow(view);windows.clear();for(const view of reusable){view.material.dispose();view.target.dispose()}reusable.length=0}
  return {setAperture,setApertures,hide,render,dispose,get count(){return windows.size},get visible(){return windows.size>0}};
}
