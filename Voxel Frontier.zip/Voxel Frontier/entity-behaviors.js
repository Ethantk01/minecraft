/** Reusable entity components. Definitions select components; the update loop is species-independent. */
export function installEntityBehaviors(registry, world) {
  const add = registry.registerBehavior;
  add('sunburn', (mob, {dt}) => {
    if (world.dimension() === 'overworld' && world.daylight() > .8 && world.skyExposed(mob)) {
      mob.sunDamage = (mob.sunDamage || 0) + dt;
      if (mob.sunDamage >= 1) { mob.health -= 2; mob.sunDamage = 0; }
      mob.flee = 1;
    }
  });
  add('dark-neutrality', mob => { if (!mob.provoked) mob.aggro = world.daylight() < .45; });
  add('gold-neutrality', mob => { if (!mob.provoked) mob.aggro = world.armor().helmet !== world.ids.GOLD_HELMET; });
  add('enderman', (mob, {dt, distance, view}) => {
    const player = world.player(), camera = world.camera();
    if (!world.background() && !mob.aggro && distance < 28) {
      const direction = new world.THREE.Vector3(mob.x-camera.position.x, mob.group.position.y+2.62-camera.position.y, mob.z-camera.position.z).normalize();
      if (view.dot(direction) > .993 && world.canSee(mob)) {
        mob.stare = (mob.stare || 0) + dt;
        mob.dir = Math.atan2(player.z-mob.z, player.x-mob.x); mob.decision = 1;
        if (mob.stare > .45) { mob.aggro = true; world.toast('YOU LOOKED AT AN ENDERMAN'); }
      } else mob.stare = 0;
    }
    const overworld = world.dimension() === 'overworld';
    if (world.block(Math.floor(mob.x), Math.floor(mob.group.position.y), Math.floor(mob.z)) === world.ids.WATER || overworld && world.raining(mob.x,mob.z) && world.skyExposed(mob)) {
      mob.health -= dt*2; world.teleport(mob);
    }
    if (overworld && world.daylight()>.8 && Math.random()<dt*.12 && world.skyExposed(mob)) world.teleport(mob);
  });
  add('graze', (mob, {dt}) => {
    if (mob.babyAge || Math.random() >= dt*.018) return;
    const x=Math.floor(mob.x), y=Math.floor(mob.group.position.y)-1, z=Math.floor(mob.z);
    if (world.block(x,y,z) !== world.ids.GRASS) return;
    world.setBlock(x,y,z,world.ids.DIRT); mob.sheared=false; mob.grazeTime=2.5; mob.decision=1;
    if (mob.fleece) mob.fleece.visible=true;
  });
  add('barter', (mob, {dt}) => {
    if (!(mob.barterTime>0)) return;
    mob.barterTime-=dt;
    if (mob.barterTime<=0) {
      const choices=world.barterItems(), item=choices[Math.floor(Math.random()*choices.length)];
      world.drop(item,mob.x,mob.group.position.y+1,mob.z,item===world.ids.GRAVEL?4:1);
      world.toast('PIGLIN FINISHED BARTERING');
    }
    world.move(mob,0,0,dt); return false;
  });
  add('avoid-hostiles', mob => {
    const enemy=world.entities().find(other=>other!==mob && other.definition.hostile && other.aggro && Math.hypot(other.x-mob.x,other.z-mob.z)<7);
    if (enemy) { mob.dir=Math.atan2(mob.z-enemy.z,mob.x-enemy.x); mob.decision=1; mob.panic=1; }
    else mob.panic=0;
  });
  add('explode', (mob, {dt,distance}) => {
    mob.fuse=distance<2.5?mob.fuse+dt:Math.max(0,mob.fuse-dt*2);
    if (mob.fuse<=1.4) return;
    world.explode(Math.floor(mob.x),Math.floor(mob.group.position.y),Math.floor(mob.z),3,mob);
    world.remove(mob);return false;
  });
  add('dragon', (mob, {dt}) => {world.updateDragon(mob,dt);world.animate(mob,dt);return false;});
}
