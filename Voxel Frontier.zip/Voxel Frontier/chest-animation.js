export function createChestAnimation(api){
  const moving=new Map(),angles=new Map();
  function target(key,open){const current=angles.get(key)||0;if((moving.get(key)?.open??current>0)!==open)api.sound(open?'chest_open':'chest_close');moving.set(key,{open});}
  function tick(dt){for(const [key,state] of moving){const old=angles.get(key)||0,next=Math.max(0,Math.min(1,old+(state.open?1:-1)*dt*2.5));angles.set(key,next);const [dim,xyz]=key.split(':');if(dim===api.dimension()&&next!==old)api.update(...xyz.split(',').map(Number));if(next===(state.open?1:0))moving.delete(key);}}
  return {target,tick,angle(key){const value=angles.get(key)||0;return (1-Math.pow(1-value,3))*-90;}};
}
