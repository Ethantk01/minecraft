/** Shared environmental contact rules. */
export function touchesCactus(body,block,cactus){
 const r=body.radius||.3,h=body.height||1.8;
 for(let y=Math.floor(body.y);y<=Math.floor(body.y+h-.001);y++)for(let z=Math.floor(body.z-r-.01);z<=Math.floor(body.z+r+.01);z++)for(let x=Math.floor(body.x-r-.01);x<=Math.floor(body.x+r+.01);x++)if(block(x,y,z)===cactus&&body.x+r>=x+.0625-.01&&body.x-r<=x+.9375+.01&&body.z+r>=z+.0625-.01&&body.z-r<=z+.9375+.01&&body.y+h>y&&body.y<y+1)return true;
 return false;
}
export function lavaDestroysItem(item){return !item?.fireResistant&&!/\bnetherite\b/i.test(item?.name||'');}
