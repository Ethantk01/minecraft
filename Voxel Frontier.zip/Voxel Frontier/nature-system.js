import features from './content/vegetation-features.json';
import definitions from './content/nature-catalog.json';
import {createModelResolver} from './resource-pack.js';
/** Shared vegetation definitions, placement, geometry and deterministic decoration. */
export function registerNatureContent({BLOCKS,ITEMS,BLOCK_TEXTURES,BLOCK_PROPERTIES,SHAPED_BLOCKS}){
 for(const d of definitions){const title=d.name.replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase()),texture=d.name+(d.half?'_'+d.half:'');BLOCKS[d.id]={name:title,solid:false,occludes:false,minecraftId:d.name,itemId:d.base,nature:d,biomeTint:d.tint,texture:texture};BLOCK_TEXTURES[d.id]=[texture];BLOCK_PROPERTIES[d.id]={hardness:0,resistance:0};SHAPED_BLOCKS.add(d.id);if(d.id===d.base)ITEMS[d.id]={name:title,stackSize:64,category:'Nature',icon:texture};}
}
export function createNatureSystem(api){
 const byId=new Map(definitions.map(d=>[d.id,d])),byName=new Map(definitions.filter(d=>d.id===d.base).map(d=>[d.name,d]));
 const resolver=createModelResolver({json:()=>null},ref=>ref.replace(/^minecraft:/,'').replace(/^block\//,''));
 function supported(d,id){const name=api.blocks[id]?.minecraftId||api.blocks[id]?.name?.toLowerCase().replaceAll(' ','_')||'';return d.support==='water'?id===api.ids.WATER:d.support==='cactus'?id===api.ids.CACTUS:/grass_block|^grass$|^dirt$|podzol|mycelium|mud|moss_block|farmland|rooted_dirt|coarse_dirt/.test(name)||d.support==='dry'&&/sand|terracotta/.test(name);}
 for(const d of definitions){const parts=resolver.parts(d.model);if(!parts?.length)throw new Error('Missing plant model '+d.model);api.registry.registerHandler('model',d.id,()=>parts);api.modelTypes.add(d.id);if(d.id===d.base)api.items[d.id].onUse=({hit,consume,markDirty})=>{if(!hit?.previous)return true;const p=hit.previous,upper=d.half==='bottom';if(api.block(p.x,p.y,p.z)!==api.ids.AIR||!supported(d,api.block(p.x,p.y-1,p.z))||upper&&api.block(p.x,p.y+1,p.z)!==api.ids.AIR)return true;const edits=[[p.x,p.y,p.z,d.id]];if(upper)edits.push([p.x,p.y+1,p.z,d.id+1]);if(api.setBatch(edits)===edits.length){consume(d.id);markDirty();}return true;};}
 function changed(x,y,z,old,type){const previous=byId.get(old);if(previous?.half&&old!==type){const dy=previous.half==='bottom'?1:-1,partner=previous.half==='bottom'?old+1:previous.base;if(api.block(x,y+dy,z)===partner)api.setBlock(x,y+dy,z,api.ids.AIR);}const above=byId.get(api.block(x,y+1,z));if(above&&above.half!=='top'&&!supported(above,type))api.setBlock(x,y+1,z,api.ids.AIR);}
 function decorate(blocks,cx,cz){
 if(api.dimension()!=='overworld'||api.save.testWorld)return;const {SIZE,idx,terrain,biome,hash}=api;
 for(let oz=cz-1;oz<=cz+1;oz++)for(let ox=cx-1;ox<=cx+1;ox++){
 const centerX=ox*SIZE+8,centerZ=oz*SIZE+8,b=biome(centerX,centerZ),mapped=b==='grove'?'taiga':features[b]?b:'plains';if(/snow|peak|ocean|slope/.test(b))continue;
 for(const [fi,feature]of features[mapped].entries()){
 const countRule=feature.placement.find(p=>/count$/.test(p.type)),rarity=feature.placement.find(p=>p.type.endsWith('rarity_filter'))?.chance||1,patchCount=countRule?.count??(hash(ox,oz,19000+fi)<.1?countRule?.below_noise:countRule?.above_noise)??1;
 if(hash(ox,oz,19050+fi)>=1/(rarity*(feature.name.includes('flower')?3:2)))continue;
 const isTall=feature.name.includes('tall_grass'),flower=feature.name.includes('flower'),forestTall=feature.name==='forest_flowers';
 for(let patch=0;patch<patchCount;patch++){
 const salt=19100+fi*1000+patch*100,px=ox*SIZE+Math.floor(hash(ox,oz,salt)*SIZE),pz=oz*SIZE+Math.floor(hash(ox,oz,salt+1)*SIZE),py=terrain(px,pz)+1;
 for(let attempt=0;attempt<Math.ceil((feature.config.tries||64)*.4);attempt++){
 const seed=salt+attempt*7,spread=feature.config.xz_spread??7,wx=px+Math.floor(hash(px,pz,seed+2)*(spread+1))-Math.floor(hash(px,pz,seed+3)*(spread+1)),wz=pz+Math.floor(hash(px,pz,seed+4)*(spread+1))-Math.floor(hash(px,pz,seed+5)*(spread+1));
 if(wx<cx*SIZE||wx>=(cx+1)*SIZE||wz<cz*SIZE||wz>=(cz+1)*SIZE||biome(wx,wz)!==b)continue;
 const x=wx-cx*SIZE,z=wz-cz*SIZE,y=terrain(wx,wz)+1;if(Math.abs(y-py)>3||blocks[idx(x,y,z)]!==api.ids.AIR)continue;
 let name=isTall?'tall_grass':mapped==='taiga'?(hash(wx,wz,seed)<.8?'fern':'short_grass'):'short_grass';
 if(flower){const r=hash(wx,wz,seed),gradient=hash(Math.floor(wx/8),Math.floor(wz/8),19999);name=forestTall?['lilac','rose_bush','peony'][Math.floor(r*3)]:mapped==='meadow'?['allium','poppy','azure_bluet','dandelion','cornflower','oxeye_daisy','short_grass','tall_grass'][Math.floor(gradient*8)]:mapped==='plains'&&gradient<.2?['red_tulip','orange_tulip','white_tulip','pink_tulip'][Math.floor(r*4)]:r<2/3?'poppy':'dandelion';}
 const d=byName.get(name);if(!d||!supported(d,blocks[idx(x,y-1,z)])||d.half&&blocks[idx(x,y+1,z)]!==api.ids.AIR)continue;blocks[idx(x,y,z)]=d.id;if(d.half)blocks[idx(x,y+1,z)]=d.id+1;
 }}}
 }
 }

 return {definitions,changed,decorate,supported};
}
