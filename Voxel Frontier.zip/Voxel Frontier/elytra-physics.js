// Java 1.21.10 LivingEntity.updateFallFlyingMovement and FireworkRocketEntity.tick.
// Inputs/outputs use blocks per second; vanilla applies these equations at 20 Hz.
export function elytraTick(velocity,look,pitch,boost=false){
 let x=velocity.x/20,y=velocity.y/20,z=velocity.z/20;
 const horizontalLook=Math.hypot(look.x,look.z),horizontalSpeed=Math.hypot(x,z);
 const lift=Math.cos(pitch)**2;
 y+=.08*(-1+lift*.75);
 if(y<0&&horizontalLook>0){const sink=y*-.1*lift;x+=look.x*sink/horizontalLook;y+=sink;z+=look.z*sink/horizontalLook;}
 if(pitch<0&&horizontalLook>0){const climb=horizontalSpeed*-Math.sin(pitch)*.04;x-=look.x*climb/horizontalLook;y+=climb*3.2;z-=look.z*climb/horizontalLook;}
 if(horizontalLook>0){x+=(look.x/horizontalLook*horizontalSpeed-x)*.1;z+=(look.z/horizontalLook*horizontalSpeed-z)*.1;}
 x*=.9900000095367432;y*=.9800000190734863;z*=.9900000095367432;
 if(boost){x+=look.x*.1+(look.x*1.5-x)*.5;y+=look.y*.1+(look.y*1.5-y)*.5;z+=look.z*.1+(look.z*1.5-z)*.5;}
 velocity.x=x*20;velocity.y=y*20;velocity.z=z*20;return velocity;
}
