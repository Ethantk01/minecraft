// Stable binary heap: preserve insertion order when path scores are equal.
export class MinHeap {
  constructor(score){this.score=score;this.items=[];this.serial=0;}
  get length(){return this.items.length;}
  less(a,b){return a.score<b.score||a.score===b.score&&a.order<b.order;}
  push(value){const node={value,score:this.score(value),order:this.serial++},items=this.items;let at=items.length;items.push(node);while(at){const parent=(at-1)>>1;if(!this.less(node,items[parent]))break;items[at]=items[parent];at=parent;}items[at]=node;}
  shift(){const items=this.items;if(!items.length)return;const first=items[0],last=items.pop();if(items.length){let at=0;while(at*2+1<items.length){let child=at*2+1;if(child+1<items.length&&this.less(items[child+1],items[child]))child++;if(!this.less(items[child],last))break;items[at]=items[child];at=child;}items[at]=last;}return first.value;}
  peek(){return this.items[0]?.value;}
}
