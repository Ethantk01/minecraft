import {createDefinitionRegistry} from './content-registry.js';
// Item-specific actions can be supplied as hooks without changing the item factory.
export function createItemRegistry(items){
  const behaviors=new Map(), registry=createDefinitionRegistry(items);
  function register(id,definition,behavior){items[id]={stackSize:64,...definition};if(behavior)behaviors.set(Number(id),behavior);return items[id];}
  function use(id,context){const item=items[id];if(!item)return false;const handler=behaviors.get(Number(id))||item.onUse;if(handler)return !!handler(context,item);if(item.spawnEntity&&context.hit?.previous){const p=context.hit.previous;const mob=context.spawn(item.spawnEntity,p.x+.5,p.z+.5,p.y);if(mob){context.consume(id);context.markDirty();}return true;}return false;}
  return {...registry,definitions:items,register,use};
}
