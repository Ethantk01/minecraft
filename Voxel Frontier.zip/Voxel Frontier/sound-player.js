import soundFiles from './sound-manifest.js';
const context=new (window.AudioContext||window.webkitAudioContext)(),buffers=new Map(),recent=new Map(),loading=new Map();
let unlocked=false;export function unlockSounds(){context.resume().catch(()=>{});if(unlocked)return;unlocked=true;const source=context.createOscillator(),gain=context.createGain();gain.gain.value=0;source.connect(gain);gain.connect(context.destination);source.start();source.stop(context.currentTime+.1);source.onended=()=>{source.disconnect();gain.disconnect()}}
function loadSound(name){
  if(loading.has(name))return loading.get(name);
  const url=soundFiles[name];
  const task=fetch(url).then(r=>{if(!r.ok)throw new Error('Sound request failed');return r.arrayBuffer()}).then(data=>context.decodeAudioData(data)).then(buffer=>{
    if(soundFiles[name]!==url)return false;
    buffers.set(name,buffer);return true;
  }).catch(()=>false);
  loading.set(name,task);return task;
}
export function prepareInteractionSounds(){return Promise.all(Object.keys(soundFiles).filter(name=>name!=='disc_otherside').map(loadSound))}
export function playGameSound(name,volume=.4,rate=1){if(!soundFiles[name])return null;const now=performance.now();if(now-(recent.get(name)||0)<35)return null;recent.set(name,now);const buffer=buffers.get(name);if(!buffer){const url=soundFiles[name];loadSound(name).then(loaded=>{if(loaded&&soundFiles[name]===url)playGameSound(name,volume,rate)});return null}const source=context.createBufferSource(),gain=context.createGain();source.buffer=buffer;source.playbackRate.value=rate;gain.gain.value=Math.max(0,Math.min(1,volume));source.connect(gain);gain.connect(context.destination);source.onended=()=>{source.disconnect();gain.disconnect()};source.start();return {pause(){try{source.stop()}catch{}},currentTime:0}}

export function replaceSound(name,url){soundFiles[name]=url;buffers.delete(name);loading.delete(name);return loadSound(name);}
