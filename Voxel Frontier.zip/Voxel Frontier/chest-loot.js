import tables from './chest-loot-tables.json' with {type:'json'};
const key=name=>name.replace(/^minecraft:/,'');
export function createChestLoot({resolveItem,stackSize=()=>64}){
  const number=(value,rng,integer=false)=>{if(typeof value==='number')return integer?Math.floor(value):value;if(!value)return 0;if(key(value.type||'')==='uniform'){const lo=integer?Math.floor(value.min):value.min,hi=integer?Math.floor(value.max):value.max;return integer?lo+Math.floor(rng()*(hi-lo+1)):lo+rng()*(hi-lo)}return number(value.value||0,rng,integer)};
  const passes=(conditions,rng)=>!conditions||conditions.every(c=>key(c.condition)==='random_chance'?rng()<c.chance:false);
  function functions(stack,list,rng){for(const fn of list||[]){if(!passes(fn.conditions,rng))continue;switch(key(fn.function)){
    case 'set_count':stack.n=Math.max(0,(fn.add?stack.n:0)+number(fn.count,rng,true));break;
    case 'set_damage':stack.data={...stack.data,remainingDurabilityFraction:Math.max(0,Math.min(1,number(fn.damage,rng)))};break;
    case 'set_potion':stack.data={...stack.data,potion:key(fn.id||fn.potion||'')};break;
    default:stack.data={...stack.data,lootFunctions:[...(stack.data?.lootFunctions||[]),fn]};
  }}return stack}
  function roll(name,rng,depth=0){if(depth>8)return [];const table=tables[key(name)];if(!table)return [];const output=[];
    for(const pool of table.pools||[]){if(!passes(pool.conditions,rng))continue;const entries=(pool.entries||[]).filter(e=>passes(e.conditions,rng));const total=entries.reduce((n,e)=>n+Math.max(0,e.weight??1),0);
      for(let i=0,rolls=number(pool.rolls,rng,true);i<rolls&&total>0;i++){let pick=rng()*total,entry;for(const e of entries){pick-=Math.max(0,e.weight??1);if(pick<0){entry=e;break}}if(!entry)continue;
        let result=[];if(key(entry.type)==='item'){const id=resolveItem(key(entry.name));if(id!==undefined&&id!==null)result=[functions({id,n:1},entry.functions,rng)]}else if(key(entry.type)==='loot_table')result=roll(entry.value||entry.name,rng,depth+1).map(s=>functions(s,entry.functions,rng));
        for(const s of result){functions(s,pool.functions,rng);functions(s,table.functions,rng);if(s.n>0)output.push(s)}
      }
    }return output;
  }
  function generate(name,rng=Math.random,size=27){const slots=Array(size).fill(null),singles=[],splittable=[];
    for(const stack of roll(name,rng)){const limit=Math.max(1,stackSize(stack.id));let remaining=stack.n;while(remaining>0){const s={...stack,n:Math.min(limit,remaining)};remaining-=s.n;(s.n>1?splittable:singles).push(s)}}
    while(size-singles.length-splittable.length>0&&splittable.length){const at=Math.floor(rng()*splittable.length),s=splittable.splice(at,1)[0],count=1+Math.floor(rng()*Math.floor(s.n/2)),other={...s,n:count};s.n-=count;for(const piece of [s,other])(piece.n>1&&rng()<.5?splittable:singles).push(piece)}
    const stacks=[...singles,...splittable],positions=Array.from({length:size},(_,i)=>i);
    for(const list of [stacks,positions])for(let i=list.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[list[i],list[j]]=[list[j],list[i]]}
    for(let i=0;i<Math.min(size,stacks.length);i++)slots[positions[i]]=stacks[i];return slots;
  }
  return {generate,tables};
}
export function chestRandom(seed,dimension,x,y,z){let value=2166136261;for(const c of `${seed}:${dimension}:${x},${y},${z}`)value=Math.imul(value^c.charCodeAt(0),16777619);return ()=>{value+=0x6d2b79f5;let n=value;n=Math.imul(n^(n>>>15),n|1);n^=n+Math.imul(n^(n>>>7),n|61);return ((n^(n>>>14))>>>0)/4294967296}}

