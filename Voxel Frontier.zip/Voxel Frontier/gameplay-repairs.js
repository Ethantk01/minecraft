import bedModels from './textures/default3d-models.json';
import {createModelResolver} from './resource-pack.js';
import animationData from './texture-animations.json';
export function createGameplayRepairs(THREE,api){
 api.blocks[api.ids.BIG_DRIPLEAF].solid=true;api.blocks[api.ids.BIG_DRIPLEAF].occludes=false;
 const leaves=new Map(),charges=[];let canvas,texture,lastTick=-1,lastLava=0,gatewayCooldown=0;
 const fire=document.createElement('div');fire.id='playerFire';fire.hidden=true;fire.innerHTML='<i></i><i></i>';document.body.append(fire);
 const sleep=document.createElement('div');sleep.id='sleepEffect';sleep.hidden=true;sleep.textContent='Sleeping…';document.body.append(sleep);
 const animations=animationData.map(a=>({...a,images:a.frames.map(url=>{const image=new Image();image.src=url;return image;}),last:-1,duration:a.sequence.reduce((n,f)=>n+(typeof f==='number'?a.time:f.time||a.time),0)}));
 const resolver=createModelResolver({json:()=>null},ref=>ref.replace(/^minecraft:/,'').replace(/^block\//,''));
 const modelCache=new Map();
 const model=name=>{if(!modelCache.has(name))modelCache.set(name,resolver.parts('block/'+name)||[]);return modelCache.get(name);};
 for(const [id,name] of [[api.ids.HOPPER,'hopper'],[api.ids.SPORE_BLOSSOM,'spore_blossom'],[api.ids.BIG_DRIPLEAF,'big_dripleaf'],[api.ids.SMALL_DRIPLEAF,'small_dripleaf_bottom']]){
  api.registry.registerHandler('model',id,({x,y,z})=>{
   let parts=model(id===api.ids.BIG_DRIPLEAF&&api.block(x,y+1,z)===api.ids.BIG_DRIPLEAF?'big_dripleaf_stem':name);
   if(id===api.ids.HOPPER){const facing=api.redstoneData()[api.key(x,y,z)]?.facing||[0,-1,0];if(facing[1]===0)parts=model('hopper_side').map(p=>({...p,rotation:[...(p.rotation||[]),{axis:'y',angle:Math.atan2(facing[0],-facing[2])*180/Math.PI,origin:[.5,.5,.5]}]}));}
   if(id===api.ids.BIG_DRIPLEAF){const state=leaves.get(api.dimension()+':'+api.key(x,y,z)),angle=state?.angle||0;parts=parts.map(p=>({...p,collision:api.block(x,y+1,z)!==api.ids.BIG_DRIPLEAF&&angle<60&&p.bounds[4]>=.9,rotation:p.bounds[4]>=.9?[...(p.rotation||[]),{axis:'x',angle:-angle,origin:[.5,.9,.5]}]:p.rotation}));}
   if(id===api.ids.SMALL_DRIPLEAF)parts=[...parts,...model('small_dripleaf_top').map(p=>({...p,bounds:p.bounds.map((v,i)=>i===1||i===4?v+1:v)}))];
   return parts;
  });api.modelTypes.add(id);if(id===api.ids.BIG_DRIPLEAF)api.instantTypes.add(id);
 }

 const beds=new Set(Object.keys(api.blocks).filter(id=>/ bed$/i.test(api.blocks[id]?.name||'')).map(Number));
 function bedState(type,x,y,z){const defaults=api.properties[type]||{},state=api.redstoneData()[api.key(x,y,z)];return state?.bedPart?state:{bedPart:defaults.part||'head',facing:({north:[0,-1],south:[0,1],west:[-1,0],east:[1,0]})[defaults.facing]||[0,-1]};}
 function breakBed(type,x,y,z){const state=bedState(type,x,y,z),sign=state.bedPart==='foot'?1:-1,[dx,dz]=state.facing;if(beds.has(api.block(x+dx*sign,y,z+dz*sign)))api.setBlock(x+dx*sign,y,z+dz*sign,api.ids.AIR);}
 for(const type of beds){const color=api.blocks[type].name.toLowerCase().split(' ')[0];api.registry.registerHandler('model',type,({x,y,z})=>{const state=bedState(type,x,y,z),[dx,dz]=state.facing,rotation={axis:'y',angle:Math.atan2(-dx,-dz)*180/Math.PI,origin:[.5,.5,.5]};return bedModels['bed_'+state.bedPart].map((part,index)=>({kind:'box',bounds:[...part.from,...part.to].map(v=>v/16),rotation,faces:Object.fromEntries(Object.entries(part.faces).map(([face,spec])=>[({east:0,west:1,up:2,down:3,south:4,north:5})[face],{...spec,tile:color==='red'||index>0?spec.tile:spec.tile.replace('net_bed_'+state.bedPart+'_','net_bed_'+color+'_'+state.bedPart+'_')}]))}));});api.modelTypes.add(type);
  api.registry.registerHandler('interact',type,({hit})=>{if(api.dimension()!=='overworld'){breakBed(type,hit.x,hit.y,hit.z);api.setBlock(hit.x,hit.y,hit.z,api.ids.AIR);api.explode(hit.x,hit.y,hit.z,5);}else{api.save.bedSpawn={x:hit.x,y:hit.y,z:hit.z};api.sleep();}return true;});
  const item=api.items[type];if(item)item.onUse=({hit,consume})=>{if(beds.has(hit?.type)||!hit?.previous)return false;const {x,y,z}=hit.previous,facing=Math.abs(Math.sin(api.player.yaw))>Math.abs(Math.cos(api.player.yaw))?[Math.sin(api.player.yaw)>0?-1:1,0]:[0,Math.cos(api.player.yaw)>0?-1:1],[dx,dz]=facing;if(api.block(x,y,z)!==0||api.block(x+dx,y,z+dz)!==0||!api.solid(x,y-1,z)||!api.solid(x+dx,y-1,z+dz)||api.occupied(x,y,z)||api.occupied(x+dx,y,z+dz))return true;if(api.save.mode==='survival'&&!api.has(type))return true;api.setBatch([[x,y,z,type],[x+dx,y,z+dz,type]]);api.redstoneData()[api.key(x,y,z)]={bedPart:'foot',facing};api.redstoneData()[api.key(x+dx,y,z+dz)]={bedPart:'head',facing};consume(type);api.sound('wood');return true;};
 }

 for(const [id,item] of Object.entries(api.items))if(item?.name==='Bone meal')item.onUse=({hit,consume})=>{if(!hit||![api.ids.SMALL_DRIPLEAF,api.ids.BIG_DRIPLEAF].includes(hit.type))return false;const y=hit.y+1;if(api.block(hit.x,y,hit.z)!==0)return true;api.setBatch([[hit.x,hit.y,hit.z,api.ids.BIG_DRIPLEAF],[hit.x,y,hit.z,api.ids.BIG_DRIPLEAF]]);consume(Number(id));return true;};
 function prime(x,y,z){const dimension=api.dimension();if(charges.some(c=>c.dimension===dimension&&c.x===x&&c.y===y&&c.z===z))return;api.setBlock(x,y,z,api.ids.AIR);const mesh=api.firstPerson.worldItem(api.ids.TNT);mesh.scale.setScalar(.98);mesh.position.set(x+.5,y+.5,z+.5);api.scene.add(mesh);charges.push({x,y,z,dimension,mesh,left:4});api.sound('creeper_hiss',.35);}
 function tilt(x,y,z,projectile=false){const k=api.dimension()+':'+api.key(x,y,z);let state=leaves.get(k);if(!state){state={x,y,z,dimension:api.dimension(),time:0,angle:0};leaves.set(k,state)}if(projectile)state.time=1.1;}
 function gatewayFrame(x,y,z){api.ensure(x-1,z-1);api.ensure(x+1,z+1);const list=[];for(let dy=-2;dy<=2;dy++)for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)if((Math.abs(dy)===2&&dx===0&&dz===0)||(Math.abs(dy)===1&&(dx===0||dz===0)))list.push([x+dx,y+dy,z+dz,api.ids.BEDROCK]);list.push([x,y,z,9990]);api.setBatch(list);}
 function spawnGateway(){if(api.guest()||api.dimension()!=='end'||api.save.endGateways?.length)return;api.save.endGateways=[];const angle=((api.save.seed||0)>>>0)%20*Math.PI/10,x=Math.round(Math.cos(angle)*96),z=Math.round(Math.sin(angle)*96),y=75;gatewayFrame(x,y,z);api.save.endGateways.push({x,y,z,destination:null});}
 function useGateway(x,y,z){if(api.dimension()!=='end'||gatewayCooldown>0)return false;const entry=api.save.endGateways?.find(g=>g.x===x&&g.y===y&&g.z===z);if(!entry)return false;
  if(!entry.destination){const length=Math.hypot(x,z),tx=Math.round(x/length*1024),tz=Math.round(z/length*1024);let target=null;for(let r=0;r<96&&!target;r+=4)for(const [dx,dz] of [[r,0],[-r,0],[0,r],[0,-r]]){const h=api.terrain(tx+dx,tz+dz);if(h>0){target={x:tx+dx,y:h+4,z:tz+dz};break;}}if(!target)target={x:tx,y:64,z:tz};api.ensure(target.x-5,target.z-5);api.ensure(target.x+5,target.z+5);if(api.terrain(target.x,target.z)<0){const platform=[];for(let dx=-5;dx<=5;dx++)for(let dz=-5;dz<=5;dz++)platform.push([target.x+dx,target.y-4,target.z+dz,api.ids.END_STONE]);api.setBatch(platform);}gatewayFrame(target.x,target.y,target.z);entry.destination=target;api.save.endGateways.push({...target,destination:{x,y,z}});}
  const p=entry.destination;Object.assign(api.player,api.safe({x:p.x+.5,y:p.y+3,z:p.z+.5}));api.player.vy=0;api.player.knockVx=api.player.knockVz=0;gatewayCooldown=2;api.stream();api.sound('enderman_teleport');return true;
 }
 function tick(dt,now){
  const running=api.simulationActive?.()??true;dt=running?dt:0;
  gatewayCooldown=Math.max(0,gatewayCooldown-dt);if(api.dimension()==='end'&&api.save.dragonDefeated)spawnGateway();
  const p=api.player,x=Math.floor(p.x),y=Math.floor(p.y),z=Math.floor(p.z);if(running&&(api.block(x,y,z)===9990||api.block(x,Math.floor(p.y+1),z)===9990))useGateway(x,y,z);
  if(running&&api.block(x,Math.floor(p.y-.05),z)===api.ids.BIG_DRIPLEAF)tilt(x,Math.floor(p.y-.05),z);
  for(const [key,state] of leaves){if(state.dimension===api.dimension()&&api.block(state.x,state.y,state.z)!==api.ids.BIG_DRIPLEAF){leaves.delete(key);continue;}state.time+=dt;const powered=state.dimension===api.dimension()&&api.powered(api.key(state.x,state.y,state.z));let angle=powered?0:state.time<.5?0:state.time<.8?0:state.time<1.1?15:75;if(powered||state.time>6){leaves.delete(key);angle=0;}if(angle!==state.angle){state.angle=angle;if(state.dimension===api.dimension())api.updateModel(state.x,state.y,state.z);}}
  for(let j=charges.length-1;j>=0;j--){const charge=charges[j];charge.mesh.visible=charge.dimension===api.dimension();charge.left-=dt;charge.mesh.material.color.setHex(charge.left<1&&Math.floor(charge.left*10)%2?0xffffff:0xdddddd);if(charge.left<=0){charge.mesh.removeFromParent();charge.mesh.geometry.dispose();charge.mesh.material.dispose();charges.splice(j,1);api.inDimension(charge.dimension,()=>api.explode(charge.x,charge.y,charge.z));}}
  fire.hidden=!(p.fireTime>0&&api.save.mode!=='spectator');sleep.hidden=!(p.sleepingUntil>now);
  if(running&&now-lastLava>2200&&api.block(x,Math.floor(p.y+.3),z)===api.ids.LAVA){lastLava=now;api.sound('lava',.18);if(Math.random()<.35)api.sound('lava_pop',.2);}
  const time=Math.floor(now/50);if(lastTick===time)return;lastTick=time;
  const original=api.materials.solid.map;if(!original?.image||api.packActive())return;
  if(!canvas){canvas=document.createElement('canvas');canvas.width=original.image.width;canvas.height=original.image.height;canvas.getContext('2d').drawImage(original.image,0,0);texture=new THREE.CanvasTexture(canvas);texture.magFilter=texture.minFilter=THREE.NearestFilter;texture.generateMipmaps=false;texture.colorSpace=THREE.SRGBColorSpace;for(const m of Object.values(api.materials))if(!m.isShaderMaterial){m.map=texture;m.needsUpdate=true;}}
  let changed=false;const size=canvas.width/api.atlas.columns,ctx=canvas.getContext('2d');for(const animation of animations){const duration=animation.duration;let at=time%duration,index=0;for(const frame of animation.sequence){const length=typeof frame==='number'?animation.time:frame.time||animation.time;if(at<length){index=typeof frame==='number'?frame:frame.index;break;}at-=length;}const image=animation.images[index];if(!image?.complete||!image.naturalWidth||animation.last===index)continue;animation.last=index;const tile=api.atlas.tiles[animation.tile];if(tile===undefined)continue;const tx=tile%api.atlas.columns*size,ty=Math.floor(tile/api.atlas.columns)*size;ctx.clearRect(tx,ty,size,size);ctx.drawImage(image,tx,ty,size,size);changed=true;if(animation.tile==='fire_0')fire.style.setProperty('--flame',`url('${animation.frames[index]}')`);}
  if(changed)texture.needsUpdate=true;
 }
 return {tick,prime,tilt,breakBed,spawnGateway,useGateway,leafAngle:(x,y,z)=>leaves.get(api.dimension()+':'+api.key(x,y,z))?.angle||0,charges};
}
