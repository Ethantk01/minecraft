// Supported subset of Minecraft Java command syntax and target selectors.
export function createCommandRunner(api){
  const names=['help','seed','gamemode','time','weather','tp','teleport','give','clear','setblock','fill','summon','kill','gamerule','say','tell','msg','w','me','list'];
  const label=id=>id.replace(/^minecraft:/,'').toLowerCase();
  const coordinate=(token,origin)=>{if(token===undefined)throw Error('Missing coordinates');const relative=token.startsWith('~');const number=Number(relative?token.slice(1)||0:token);if(!Number.isFinite(number))throw Error(`Invalid coordinate: ${token}`);return relative?origin+number:number};
  const localTarget=()=>({kind:'player',name:api.playerName?.()||'Player',local:true,x:api.player.x,y:api.player.y,z:api.player.z});
  function resolveTargets(token){
    const local=localTarget(),players=[local,...(api.otherPlayers?.()||[]).filter(p=>!api.getDimension||p.dimension===api.getDimension()).map(p=>({...p,kind:'player',type:'player',local:false}))],entities=(api.entities?.()||[]).map(e=>({...e,kind:'entity'}));local.type='player';
    const match=/^@([saerp])(?:\[([^\]]*)\])?$/.exec(token||'');
    if(!match)return players.filter(p=>p.name?.toLowerCase()===token?.toLowerCase());
    const selector=match[1],options=Object.fromEntries((match[2]||'').split(',').filter(Boolean).map(part=>{const at=part.indexOf('=');return [part.slice(0,at),part.slice(at+1)]}));
    for(const key of Object.keys(options))if(!['type','name','distance','limit','sort','x','y','z','dx','dy','dz'].includes(key))throw Error('Unsupported selector option: '+key);
    let selected=selector==='s'?[local]:selector==='e'?[...players,...entities]:players;
    const origin={x:Number(options.x??local.x),y:Number(options.y??local.y),z:Number(options.z??local.z)},distance=e=>Math.hypot(e.x-origin.x,e.y-origin.y,e.z-origin.z);
    if(!Object.values(origin).every(Number.isFinite))throw Error('Invalid selector coordinates');
    if(options.type){const negate=options.type.startsWith('!'),type=label(options.type.replace(/^!/,''));selected=selected.filter(e=>((label(e.type)==='dragon'?'ender_dragon':label(e.type))===(type==='dragon'?'ender_dragon':type))!==negate)}
    if(options.name){const negate=options.name.startsWith('!'),name=options.name.replace(/^!/,'');selected=selected.filter(e=>((e.name||e.type)===name)!==negate)}
    if(options.distance){const parts=options.distance.split('..'),min=parts.length===1?Number(parts[0]):Number(parts[0]||0),max=parts.length===1?min:Number(parts[1]||Infinity);selected=selected.filter(e=>distance(e)>=min&&distance(e)<=max)}
    for(const axis of ['x','y','z'])if(options['d'+axis]!==undefined){const delta=Number(options['d'+axis]);selected=selected.filter(e=>e[axis]>=origin[axis]+Math.min(0,delta)&&e[axis]<origin[axis]+Math.max(0,delta)+1)}
    const sort=options.sort||(selector==='p'?'nearest':selector==='r'?'random':'arbitrary');
    if(sort==='nearest'||sort==='furthest')selected.sort((a,b)=>(distance(a)-distance(b))*(sort==='nearest'?1:-1));else if(sort==='random'){for(let n=selected.length-1;n>0;n--){const k=Math.floor(Math.random()*(n+1));[selected[n],selected[k]]=[selected[k],selected[n]]}}else if(sort!=='arbitrary')throw Error('Invalid selector sort');
    const limit=options.limit===undefined?(selector==='p'||selector==='r'?1:Infinity):Number(options.limit);if(limit!==Infinity&&(!Number.isInteger(limit)||limit<1))throw Error('Selector limit must be a positive integer');return selected.slice(0,limit);
  }
  const target=token=>{const selected=resolveTargets(token);if(!selected.length)throw Error(`Player not found: ${token}`);if(selected.length!==1||selected[0].kind!=='player'||!selected[0].local)throw Error('This command currently changes only your own inventory or game mode');};
  function teleport(target,position){if(target.kind==='entity'){if(!api.teleportEntity?.(target.id,position))throw Error('Entity cannot be teleported from this client');}else if(target.local)Object.assign(api.player,{x:position.x,y:position.y,z:position.z,vy:0});else if(!api.teleportPlayer?.(target.name,{...position,dimension:api.getDimension?.()}))throw Error(`Player not found: ${target.name}`);}
  const itemId=token=>{const value=label(token);if(api.aliases?.[value]&&api.items[api.aliases[value]])return api.aliases[value];const id=Object.keys(api.items).find(key=>api.items[key]?.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')===value||api.items[key]?.icon===value);if(!id)throw Error(`Unknown item: ${token}`);return Number(id)};
  const blockId=token=>{const id=itemId(token);if(!api.blocks[id])throw Error(`Unknown block: ${token}`);return id};
  const integer=(value,min,max)=>{const n=Number(value);if(!Number.isInteger(n)||n<min||n>max)throw Error(`Expected a number from ${min} to ${max}`);return n};
  function run(input){
    try{
      const parts=input.trim().replace(/^\//,'').split(/\s+/),command=parts.shift()?.toLowerCase(),args=parts,player=api.player,save=api.save;
      if(!command||!names.includes(command))throw Error(`Unknown command. Type /help`);
      if(command==='help')return `Commands: ${names.map(name=>'/'+name).join(' ')} · Selectors: @s self, @p nearest player, @a all players, @r random player, @e all players, mobs, item drops, and End crystals (or @e[type=minecraft:zombie])`;
      if(command==='seed')return `Seed: ${save.seed}`;
      if(command==='say'){const message=args.join(' ').slice(0,160);if(!message)throw Error('Usage: /say <message>');api.chat?.(message);return `[@s] ${message}`;}
      if(['tell','msg','w'].includes(command)){const who=args.shift(),message=args.join(' ').slice(0,160);if(!who||!message)throw Error(`Usage: /${command} <player> <message>`);if(!api.whisper?.(who,message))throw Error(`Player not found: ${who}`);return `To ${who}: ${message}`;}
      if(command==='me'){const message=args.join(' ').slice(0,160);if(!message)throw Error('Usage: /me <action>');api.chat?.(`* ${api.playerName?.()||'Player'} ${message}`);return `* ${message}`;}
      if(command==='list'){const players=api.players?.()||[];return `There are ${players.length+1} of a max 4 players online: ${[api.playerName?.()||'Player',...players].join(', ')}`;}
      if(command==='gamemode'){
        const [mode,who]=args;if(who)target(who);if(!['survival','creative','spectator'].includes(mode))throw Error('Usage: /gamemode <survival|creative|spectator> [@s]');api.setMode(mode);return `Set game mode to ${mode}`;
      }
      if(command==='weather'){
        const [kind,duration]=args;if(!['clear','rain','thunder'].includes(kind))throw Error('Usage: /weather <clear|rain|thunder> [duration]');save.weather.kind=kind;save.weather.remaining=duration?integer(duration,1,1000000):300;api.markDirty();return `Set weather to ${kind}`;
      }
      if(command==='time'){
        const [action,value]=args;if(action==='query'){if(value==='daytime')return `Daytime: ${Math.floor(api.getTime()/(Math.PI*2)*24000)%24000}`;if(value==='gametime')return `Game time: ${Math.floor(api.getTime()/(Math.PI*2)*24000)}`;throw Error('Usage: /time query <daytime|gametime>')}
        const aliases={day:1000,noon:6000,night:13000,midnight:18000},ticks=value in aliases?aliases[value]:Number(value);
        if(!['set','add'].includes(action)||!Number.isFinite(ticks))throw Error('Usage: /time <set|add> <day|noon|night|midnight|ticks>');
        api.setTime(action==='set'?Math.floor(api.getTime()/(Math.PI*2))*Math.PI*2+ticks/24000*Math.PI*2:api.getTime()+ticks/24000*Math.PI*2);return `Time ${action} ${value}`;
      }
      if(command==='gamerule'){
        const [rule,value]=args;if(!['doDaylightCycle','doWeatherCycle'].includes(rule))throw Error('Supported rules: doDaylightCycle, doWeatherCycle');save.gamerules??={};if(value===undefined)return `${rule} = ${save.gamerules[rule]!==false}`;if(!['true','false'].includes(value))throw Error('Expected true or false');save.gamerules[rule]=value==='true';api.markDirty();return `${rule} = ${value}`;
      }
      if(command==='tp'||command==='teleport'){
        let targets=[localTarget()],destination=null,coordinateArgs=args;
        if(args.length===1){destination=resolveTargets(args[0]);coordinateArgs=[];}
        else if(args.length===2){targets=resolveTargets(args[0]);destination=resolveTargets(args[1]);coordinateArgs=[];}
        else if(args.length===4){targets=resolveTargets(args[0]);coordinateArgs=args.slice(1);}
        else if(args.length!==3)throw Error('Usage: /tp [<targets>] <x> <y> <z> | /tp [<targets>] <destination>');
        if(!targets.length)throw Error('No targets matched');if(destination){if(destination.length!==1)throw Error('Teleport destination must select exactly one target');const dest=destination[0];if(![dest.x,dest.y,dest.z].every(Number.isFinite))throw Error('Destination has no position');if(dest.dimension&&api.getDimension&&dest.dimension!==api.getDimension())throw Error('Destination must be in your current dimension');for(const selected of targets)teleport(selected,{x:dest.x,y:dest.y,z:dest.z});}
        else{const [x,y,z]=coordinateArgs.map((part,index)=>coordinate(part,[player.x,player.y,player.z][index]));if(y<api.minY||y>=api.maxY)throw Error('Y is outside the world');for(const selected of targets)teleport(selected,{x,y,z,dimension:api.getDimension?.()});}
        api.markDirty();return `Teleported ${targets.length} target${targets.length===1?'':'s'}`;
      }
      if(command==='give'){
        const [who,item,count='1']=args;target(who);const id=itemId(item),amount=integer(count,1,2304);let remaining=amount;
        for(const slot of save.slots)if(slot?.id===id&&slot.n<64){const added=Math.min(64-slot.n,remaining);slot.n+=added;remaining-=added;if(!remaining)break}
        for(let index=0;index<save.slots.length&&remaining;index++)if(!save.slots[index]){const added=Math.min(64,remaining);save.slots[index]={id,n:added};remaining-=added}
        if(remaining)api.drop(id,player.x,player.y+1,player.z,remaining);api.refresh();api.markDirty();return `Gave ${amount} ${api.items[id].name}`;
      }
      if(command==='clear'){
        if(args[0]?.startsWith('@'))target(args.shift());const id=args[0]?itemId(args[0]):null,limit=args[1]?integer(args[1],0,2304):Infinity;let removed=0;
        for(let index=0;index<save.slots.length;index++){const slot=save.slots[index];if(!slot||(id!==null&&slot.id!==id))continue;const take=Math.min(slot.n,limit-removed);slot.n-=take;removed+=take;if(!slot.n)save.slots[index]=null;if(removed>=limit)break}api.refresh();api.markDirty();return `Cleared ${removed} items`;
      }
      if(command==='setblock'){
        if(args.length<4)throw Error('Usage: /setblock <x> <y> <z> <block> [replace|keep|destroy]');const [x,y,z]=args.slice(0,3).map((part,index)=>Math.floor(coordinate(part,[player.x,player.y,player.z][index]))),id=blockId(args[3]),mode=args[4]||'replace';if(mode==='keep'&&api.getBlock(x,y,z)!==0)return 'Block was not changed';if(!['replace','keep','destroy'].includes(mode))throw Error('Invalid setblock mode');if(!api.setBlock(x,y,z,id))throw Error('Target chunk is not loaded');return 'Block placed';
      }
      if(command==='fill'){
        if(args.length<7)throw Error('Usage: /fill <x1> <y1> <z1> <x2> <y2> <z2> <block>');const coords=args.slice(0,6).map((part,index)=>Math.floor(coordinate(part,[player.x,player.y,player.z][index%3]))),id=blockId(args[6]);const [x0,y0,z0,x1,y1,z1]=coords,bounds=[[Math.min(x0,x1),Math.max(x0,x1)],[Math.min(y0,y1),Math.max(y0,y1)],[Math.min(z0,z1),Math.max(z0,z1)]];const volume=bounds.reduce((n,[a,b])=>n*(b-a+1),1);if(volume>4096)throw Error('Too many blocks for one operation (maximum 4096)');const edits=[];for(let y=bounds[1][0];y<=bounds[1][1];y++)for(let z=bounds[2][0];z<=bounds[2][1];z++)for(let x=bounds[0][0];x<=bounds[0][1];x++)edits.push([x,y,z,id]);return `Filled ${api.setBlockBatch(edits)} loaded blocks`;
      }
      if(command==='summon'){
        const [type,...coords]=args,mob=label(type||'')==='ender_dragon'?'dragon':label(type||'');if(!api.mobTypes.includes(mob))throw Error(`Unknown summonable entity: ${type}`);if(coords.length!==0&&coords.length!==3)throw Error('Usage: /summon <entity> [x y z]');const [x,y,z]=coords.length?coords.map((part,index)=>coordinate(part,[player.x,player.y,player.z][index])):[player.x,player.y,player.z];api.spawnMob(mob,x,z,y);return `Summoned ${mob}`;
      }
      if(command==='kill'){
        const targets=resolveTargets(args[0]||'@s');if(!targets.length)throw Error('No entities matched');let count=0;for(const selected of targets){if(selected.kind==='entity'){if(api.killEntity?.(selected.id))count++;}else if(selected.local){api.hurt(1000,'KILLED BY COMMAND');count++;}else if(api.killPlayer?.(selected.name))count++;}api.markDirty();return `Killed ${count} entities`;
      }
      throw Error('Command unavailable');
    }catch(error){return `Error: ${error.message}`}
  }
  return {run,names};
}
