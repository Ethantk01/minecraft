export function createLoadingScreen(){
 const root=document.getElementById('loadingScreen'),title=document.getElementById('loadingTitle'),detail=document.getElementById('loadingDetail'),bar=document.getElementById('loadingProgress'),tasks=new Map();
 function paint(){const task=[...tasks.values()].at(-1);root.hidden=!task;document.body.classList.toggle('world-loading',!!task);if(!task)return;title.textContent=task.title;detail.textContent=task.detail||'Please wait…';if(Number.isFinite(task.progress)){bar.value=Math.max(0,Math.min(1,task.progress));}else bar.removeAttribute('value');}
 return {begin(id,title,detail='',progress){tasks.set(id,{title,detail,progress});paint()},update(id,detail,progress){const task=tasks.get(id);if(task){task.detail=detail;task.progress=progress;paint()}},end(id){tasks.delete(id);paint()},has:id=>tasks.has(id)};
}
